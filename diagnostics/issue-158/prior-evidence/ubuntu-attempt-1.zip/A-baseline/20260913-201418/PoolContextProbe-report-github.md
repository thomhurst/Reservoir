```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.63GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  A-baseline : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

Job=A-baseline  EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.4.0,DOTNET_TieredPGO=1  Arguments=/p:ReservoirVersion=1.4.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll  
IterationCount=10  LaunchCount=3  WarmupCount=5  

```
| Method           | Mean      | Error    | StdDev    | Median    | Code Size | Allocated |
|----------------- |----------:|---------:|----------:|----------:|----------:|----------:|
| SingleRentReturn |  15.81 ns | 0.060 ns |  0.081 ns |  15.79 ns |   5,441 B |         - |
| NestedRentReturn |  37.73 ns | 0.381 ns |  0.522 ns |  37.49 ns |   6,678 B |         - |
| SingleContext    | 101.19 ns | 2.081 ns |  2.849 ns |  99.39 ns |  16,201 B |         - |
| NestedContext    | 230.86 ns | 7.726 ns | 10.576 ns | 235.39 ns |  30,958 B |         - |
