## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: A-baseline(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.4.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.4.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=10, LaunchCount=3, WarmupCount=5))

```assembly
; PoolContextProbe.SingleRentReturn()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       rbx,rdi
       mov       r15,[rbx+8]
       cmp       dword ptr [r15+1C],0
       jne       near ptr M00_L18
M00_L00:
       mov       r14,[r15+10]
       xor       r13d,r13d
       test      r14,r14
       je        near ptr M00_L12
       mov       rdi,7F79272A0D68
       mov       rax,7F7927BA5820
       call      rax
       add       rax,4C
       mov       r12d,[rax+10]
       test      r12d,r12d
       je        near ptr M00_L23
M00_L01:
       dec       r12d
       mov       eax,[r14+18]
       test      eax,eax
       jl        near ptr M00_L24
       and       r12d,eax
M00_L02:
       xor       eax,eax
       mov       [rbp-34],eax
       mov       rdi,[r14+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M00_L28
M00_L03:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M00_L44
       mov       edx,r12d
       mov       rcx,[rdi+rdx*8+10]
       mov       [rbp-40],rcx
       mov       r8,[rcx+10]
       mov       [rbp-48],r8
       test      r8,r8
       je        near ptr M00_L26
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M00_L41
       mov       rdx,r8
       xor       esi,esi
       call      00007F7927074060
       mov       rcx,[rbp-48]
       cmp       rax,rcx
       jne       near ptr M00_L25
       mov       r8,rcx
       mov       [rbp-30],r8
M00_L04:
       mov       r12,[rbp-30]
       cmp       qword ptr [rbp-30],0
       je        near ptr M00_L29
M00_L05:
       xor       edi,edi
       mov       [rbp-30],rdi
       cmp       dword ptr [r15+1C],0
       jne       near ptr M00_L31
M00_L06:
       mov       r15d,[r12+8]
       mov       rbx,[rbx+8]
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M00_L11
       mov       rdi,rbx
       mov       rsi,r12
       call      qword ptr [7F78A96EDE30]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       test      eax,eax
       je        near ptr M00_L11
       mov       r14,[rbx+10]
       test      r14,r14
       je        near ptr M00_L36
       mov       rdi,7F79272A0D68
       mov       rax,7F7927BA5820
       call      rax
       add       rax,4C
       mov       r13d,[rax+10]
       test      r13d,r13d
       je        near ptr M00_L32
M00_L07:
       dec       r13d
       mov       eax,[r14+18]
       test      eax,eax
       jl        near ptr M00_L33
       and       r13d,eax
M00_L08:
       xor       eax,eax
       mov       [rbp-38],eax
       mov       rdi,[r14+8]
       cmp       dword ptr [rdi+8],0
       jle       short M00_L10
M00_L09:
       mov       rdi,[r14+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M00_L44
       mov       esi,r13d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-50],rcx
       cmp       [rcx],cl
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M00_L41
       mov       rsi,r12
       xor       edx,edx
       call      00007F7927074060
       test      rax,rax
       jne       near ptr M00_L34
M00_L10:
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M00_L43
M00_L11:
       mov       eax,r15d
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M00_L12:
       mov       rdi,7F79272A0D68
       mov       rax,7F7927BA5820
       call      rax
       add       rax,44
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M00_L14
M00_L13:
       mov       rdi,7F78A7C6B1E8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M00_L13
       jmp       short M00_L19
M00_L14:
       dec       edi
       imul      edi,9E3779B9
       mov       edx,[r15+18]
       test      edx,edx
       jge       short M00_L21
       jmp       short M00_L20
M00_L15:
       mov       rdi,[r15+8]
       lea       edx,[r13*8]
       cmp       edx,[rdi+8]
       jae       near ptr M00_L44
       lea       rdi,[rdi+rdx*8+10]
       mov       r12,[rdi]
       test      r12,r12
       jne       short M00_L22
M00_L16:
       xor       edi,edi
M00_L17:
       mov       [rbp-30],rdi
       jmp       near ptr M00_L04
M00_L18:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7F78A96EDBA8]
       jmp       near ptr M00_L00
M00_L19:
       mov       [rax+10],edi
       jmp       short M00_L14
M00_L20:
       mov       r13d,edi
       mov       esi,[r15+20]
       imul      r13,rsi
       shr       r13,20
       jmp       short M00_L15
M00_L21:
       mov       r13d,edi
       and       r13d,edx
       jmp       short M00_L15
M00_L22:
       mov       rdx,r12
       xor       esi,esi
       call      00007F7927074060
       cmp       rax,r12
       jne       short M00_L16
       mov       rdi,r12
       jmp       short M00_L17
M00_L23:
       mov       rdi,7F78A7C6B178
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M00_L23
       mov       rdi,7F79272A0D68
       mov       rax,7F7927BA5820
       call      rax
       add       rax,4C
       mov       [rax+10],r12d
       jmp       near ptr M00_L01
M00_L24:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
       jmp       near ptr M00_L02
M00_L25:
       mov       rcx,[rbp-40]
M00_L26:
       lea       rdx,[rbp-30]
       mov       rsi,rcx
       mov       rdi,offset MT_Reservoir.StripedObjectStore<PoolContextProbe+Item>
       call      qword ptr [7F78A96EDCE0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       near ptr M00_L04
       inc       r12d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r12d
       jne       short M00_L27
       xor       r12d,r12d
M00_L27:
       mov       eax,[rbp-34]
       inc       eax
       mov       rdi,[r14+8]
       cmp       [rdi+8],eax
       mov       [rbp-34],eax
       jg        near ptr M00_L03
M00_L28:
       xor       edi,edi
       mov       [rbp-30],rdi
       jmp       near ptr M00_L04
M00_L29:
       test      r14,r14
       je        short M00_L30
       mov       rdi,offset MT_PoolContextProbe+Item
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       dword ptr [r12+8],2A
       jmp       near ptr M00_L05
M00_L30:
       mov       rdi,r15
       mov       esi,r13d
       call      qword ptr [7F78A96EDC80]
       mov       r12,rax
       jmp       near ptr M00_L05
M00_L31:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7F78A96EDBA8]
       mov       r12,rax
       jmp       near ptr M00_L06
M00_L32:
       mov       rdi,7F78A7C6B178
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M00_L32
       mov       rdi,7F79272A0D68
       mov       rax,7F7927BA5820
       call      rax
       add       rax,4C
       mov       [rax+10],r13d
       jmp       near ptr M00_L07
M00_L33:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r14+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
       jmp       near ptr M00_L08
M00_L34:
       mov       rdx,r12
       mov       rsi,[rbp-50]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<PoolContextProbe+Item>
       call      qword ptr [7F78A96EDF20]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       near ptr M00_L10
       inc       r13d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r13d
       jne       short M00_L35
       xor       r13d,r13d
M00_L35:
       mov       eax,[rbp-38]
       inc       eax
       mov       rdi,[r14+8]
       cmp       [rdi+8],eax
       mov       [rbp-38],eax
       jg        near ptr M00_L09
       jmp       near ptr M00_L10
M00_L36:
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M00_L38
M00_L37:
       mov       rdi,7F78A7C6B1E8
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M00_L37
       mov       [rax+10],edi
M00_L38:
       dec       edi
       imul      r14d,edi,9E3779B9
       cmp       dword ptr [rbx+18],0
       jge       short M00_L39
       mov       r13d,r14d
       mov       r14d,[rbx+20]
       imul      r14,r13
       shr       r14,20
       jmp       short M00_L40
M00_L39:
       and       r14d,[rbx+18]
M00_L40:
       mov       rdi,[rbx+8]
       lea       esi,[r14*8]
       cmp       esi,[rdi+8]
       jae       short M00_L44
       lea       esi,[r14*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M00_L42
M00_L41:
       call      qword ptr [7F78A9C96118]
       int       3
M00_L42:
       mov       rsi,r12
       call      00007F7927074040
       test      rax,rax
       je        near ptr M00_L10
       mov       rdi,rbx
       mov       rsi,r12
       mov       rdx,rax
       mov       ecx,r14d
       call      qword ptr [7F78A96EDF08]
       jmp       near ptr M00_L10
M00_L43:
       mov       rdi,rbx
       call      qword ptr [7F78A96EDF50]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       jmp       near ptr M00_L11
M00_L44:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 1277
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       cmp       [rdi],dil
       mov       eax,1
       add       rsp,10
       pop       rbp
       ret
       push      rax
       mov       rdi,[rbp-8]
       cmp       [rdi],dil
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 42
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+18]
       mov       rdi,[rbp-10]
       call      qword ptr [7F78A96EDD88]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M02_L00
       mov       rax,[rbp-20]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M02_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M02_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rax]
       mov       rdi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M02_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       xor       ecx,ecx
       mov       [rax],rcx
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+20]
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7F78A96EDDA0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       rax,[rbp-20]
       cmp       qword ptr [rax],0
       setne     al
       movzx     eax,al
       add       rsp,30
       pop       rbp
       ret
M02_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 221
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+20]
       mov       rdi,[rbp-10]
       call      qword ptr [7F78A96EDD88]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M03_L00
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M03_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M03_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rbp-20]
       mov       rdi,rax
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+18]
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7F78A96EDDA0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       eax,1
       add       rsp,30
       pop       rbp
       ret
M03_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 171
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       push      rbp
       sub       rsp,0B0
       lea       rbp,[rsp+0B0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       dword ptr [rbp-88],3E8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-98],rax
       mov       rax,[rbp-98]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+40]
       mov       [rbp-0A0],rax
       cmp       qword ptr [rbp-0A0],0
       je        short M04_L00
       mov       rax,[rbp-0A0]
       mov       [rbp-68],rax
       jmp       short M04_L01
M04_L00:
       mov       rdi,[rbp-98]
       mov       rsi,7F78A9D798B8
       call      qword ptr [7F78A8C5F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-68],rax
M04_L01:
       mov       rax,[rbp-38]
       cmp       [rax],al
       mov       rax,[rbp-38]
       lea       rdi,[rax+28]
       mov       rsi,[rbp-68]
       mov       rdx,[rbp-38]
       call      qword ptr [7F78A9C96580]; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       nop
M04_L02:
       mov       rax,[rbp-38]
       mov       rax,[rax+10]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-48],0
       je        near ptr M04_L07
M04_L03:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M04_L04
       lea       rdi,[rbp-88]
       mov       esi,1D
       call      CORINFO_HELP_PATCHPOINT
M04_L04:
       lea       rsi,[rbp-50]
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7F78A96EDC50]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       test      eax,eax
       je        short M04_L05
       mov       rdi,7F78A9D935E4
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-50]
       call      qword ptr [7F78A9D5C0F0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       jmp       short M04_L03
M04_L05:
       cmp       qword ptr [rbp-40],0
       je        short M04_L06
       mov       rdi,7F78A9D935E8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7F78A9D5C108]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F78A9D5C120]
M04_L06:
       mov       rdi,7F78A9D935EC
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M04_L07:
       xor       eax,eax
       mov       [rbp-54],eax
       jmp       near ptr M04_L11
M04_L08:
       mov       rdi,7F78A9D935F0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-38]
       mov       esi,[rbp-54]
       call      qword ptr [7F78A96EDC38]
       mov       [rbp-70],rax
       xor       eax,eax
       mov       [rbp-60],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-0A8],rax
       mov       rax,[rbp-0A8]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+38]
       mov       [rbp-0B0],rax
       cmp       qword ptr [rbp-0B0],0
       je        short M04_L09
       mov       rax,[rbp-0B0]
       mov       [rbp-78],rax
       jmp       short M04_L10
M04_L09:
       mov       rdi,[rbp-0A8]
       mov       rsi,7F78A9AF0280
       call      qword ptr [7F78A8C5F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-78],rax
M04_L10:
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-70]
       mov       rdx,[rbp-60]
       call      qword ptr [7F78A96EDEA8]
       mov       [rbp-90],rax
       mov       rsi,[rbp-90]
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       call      qword ptr [7F78A9D5C0F0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       mov       eax,[rbp-54]
       inc       eax
       mov       [rbp-54],eax
M04_L11:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M04_L12
       lea       rdi,[rbp-88]
       mov       esi,67
       call      CORINFO_HELP_PATCHPOINT
M04_L12:
       mov       rdi,[rbp-38]
       call      qword ptr [7F78A9D5C138]
       cmp       eax,[rbp-54]
       jg        near ptr M04_L08
       cmp       qword ptr [rbp-40],0
       je        short M04_L13
       mov       rdi,7F78A9D935F4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7F78A9D5C108]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F78A9D5C120]
M04_L13:
       mov       rdi,7F78A9D935F8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
       push      rax
       mov       [rbp-80],rdi
       mov       rdi,7F78A9D935E0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-80]
       mov       [rbp-40],rax
       lea       rax,[M04_L02]
       add       rsp,8
       ret
; Total bytes of code 731
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-50],rcx
       mov       dword ptr [rbp-70],3E8
M05_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M05_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M05_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7F78A96EDDB8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-50]
       mov       [rcx],eax
       mov       rax,[rbp-50]
       cmp       dword ptr [rax],0FFFFFFFF
       jne       short M05_L02
       mov       rdi,7F78A9AE5E00
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,70
       pop       rbp
       ret
M05_L02:
       mov       rax,[rbp-50]
       mov       eax,[rax]
       mov       rcx,[rbp-48]
       cmp       eax,[rcx+8]
       jae       short M05_L04
       mov       edx,eax
       imul      rdx,10
       lea       rcx,[rcx+rdx+10]
       mov       eax,[rcx+8]
       mov       [rbp-5C],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-5C]
       call      qword ptr [7F78A96EDDD0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-68],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-68]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M05_L03
       mov       rdi,7F78A9AE5E04
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,70
       pop       rbp
       ret
M05_L03:
       mov       rdi,7F78A9AE5E08
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M05_L00
M05_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 269
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-4C],ecx
       mov       dword ptr [rbp-70],3E8
M06_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M06_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M06_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rax,[rbp-48]
       mov       ecx,[rbp-4C]
       cmp       ecx,[rax+8]
       jae       near ptr M06_L03
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       add       rax,8
       mov       [rbp-68],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7F78A96EDDB8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-68]
       mov       [rcx],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-4C]
       call      qword ptr [7F78A96EDDD0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-60],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-60]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M06_L02
       mov       rdi,7F78A9AE62F8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,70
       pop       rbp
       ret
M06_L02:
       mov       rdi,7F78A9AE62FC
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M06_L00
M06_L03:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 235
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F78A87FEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F78A87FEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       push      rbp
       sub       rsp,110
       lea       rbp,[rsp+110]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0F0],ymm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       xor       eax,eax
       mov       [rbp-50],rax
       mov       [rbp-30],rsi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       dword ptr [rbp-0C8],3E8
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       jne       short M08_L00
       mov       rdi,7F78A9D94D88
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,110
       pop       rbp
       ret
M08_L00:
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+10]
       mov       [rbp-0F8],rax
       cmp       qword ptr [rbp-0F8],0
       je        short M08_L01
       mov       rax,[rbp-0F8]
       mov       [rbp-80],rax
       jmp       short M08_L02
M08_L01:
       mov       rdi,[rbp-40]
       mov       rsi,7F78A9D79E78
       call      qword ptr [7F78A8C5F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-80],rax
M08_L02:
       mov       rdi,[rbp-50]
       cmp       [rdi],edi
       call      qword ptr [7F78A9D5C1F8]
       mov       [rbp-0A8],rax
       mov       rdi,[rbp-0A8]
       mov       rsi,7F78A9D94D90
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0A8]
       mov       [rbp-0D0],rax
       mov       rdi,[rbp-0D0]
       mov       r11,[rbp-80]
       mov       rax,[rbp-80]
       call      qword ptr [rax]
       mov       [rbp-60],rax
       jmp       near ptr M08_L09
M08_L03:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-100],rax
       cmp       qword ptr [rbp-100],0
       je        short M08_L04
       mov       rax,[rbp-100]
       mov       [rbp-88],rax
       jmp       short M08_L05
M08_L04:
       mov       rdi,[rbp-40]
       mov       rsi,7F78A9D79EB0
       call      qword ptr [7F78A8C5F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-88],rax
M08_L05:
       mov       rax,[rbp-60]
       mov       [rbp-0B0],rax
       mov       rdi,[rbp-0B0]
       mov       rsi,7F78A9D94E98
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0B0]
       mov       [rbp-0E0],rax
       mov       rdi,[rbp-0E0]
       mov       r11,[rbp-88]
       mov       rax,[rbp-88]
       call      qword ptr [rax]
       mov       [rbp-0D8],rax
       mov       rax,[rbp-0D8]
       cmp       [rax],al
       mov       rax,[rbp-0D8]
       add       rax,8
       mov       [rbp-90],rax
       xor       eax,eax
       mov       [rbp-70],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-108],rax
       cmp       qword ptr [rbp-108],0
       je        short M08_L06
       mov       rax,[rbp-108]
       mov       [rbp-98],rax
       jmp       short M08_L07
M08_L06:
       mov       rdi,[rbp-40]
       mov       rsi,7F78A9D79F00
       call      qword ptr [7F78A8C5F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-98],rax
M08_L07:
       mov       rdi,[rbp-98]
       mov       rsi,[rbp-90]
       mov       rdx,[rbp-70]
       call      qword ptr [7F78A96EDEA8]
       mov       [rbp-68],rax
       cmp       qword ptr [rbp-68],0
       je        short M08_L08
       mov       rdi,7F78A9D94FA0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-48]
       mov       rsi,[rbp-68]
       cmp       [rdi],edi
       call      qword ptr [7F78A9D5C210]
       jmp       short M08_L09
M08_L08:
       mov       rdi,7F78A9D94FA4
       call      CORINFO_HELP_COUNTPROFILE32
M08_L09:
       mov       eax,[rbp-0C8]
       dec       eax
       mov       [rbp-0C8],eax
       cmp       dword ptr [rbp-0C8],0
       jg        short M08_L10
       lea       rdi,[rbp-0C8]
       mov       esi,57
       call      CORINFO_HELP_PATCHPOINT
M08_L10:
       mov       rax,[rbp-60]
       mov       [rbp-0B8],rax
       mov       rdi,[rbp-0B8]
       mov       rsi,7F78A9D94FB0
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0B8]
       mov       [rbp-0E8],rax
       mov       rdi,[rbp-0E8]
       mov       r11,7F78A7C70880
       call      qword ptr [r11]
       test      eax,eax
       jne       near ptr M08_L03
       call      M08_L13
       nop
       cmp       qword ptr [rbp-58],0
       je        short M08_L11
       mov       rdi,7F78A9D951CC
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-58]
       call      qword ptr [7F78A9D5C108]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F78A9D5C120]
M08_L11:
       mov       rdi,7F78A9D951D0
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,110
       pop       rbp
       ret
       push      rax
       mov       [rbp-0A0],rdi
       mov       rax,[rbp-0A0]
       mov       [rbp-78],rax
       cmp       qword ptr [rbp-58],0
       jne       short M08_L12
       mov       rdi,7F78A9D94FA8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-78]
       mov       [rbp-58],rax
M08_L12:
       mov       rdi,7F78A9D94FAC
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rax,[M08_L09]
       add       rsp,8
       ret
M08_L13:
       push      rax
       cmp       qword ptr [rbp-60],0
       je        short M08_L14
       mov       rdi,7F78A9D950B8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-60]
       mov       [rbp-0C0],rax
       mov       rdi,[rbp-0C0]
       mov       rsi,7F78A9D950C0
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0C0]
       mov       [rbp-0F0],rax
       mov       rdi,[rbp-0F0]
       mov       r11,7F78A7C70888
       call      qword ptr [r11]
M08_L14:
       mov       rdi,7F78A9D951C8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
; Total bytes of code 999
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,18
       lea       rbp,[rsp+40]
       mov       [rbp-30],rdi
       mov       rbx,rdi
       mov       r15,rsi
       mov       rdi,rbx
       call      qword ptr [7F78A96EDCC8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       r14d,eax
       xor       r13d,r13d
       mov       rdi,[rbx+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M09_L05
M09_L00:
       mov       rdi,[rbx+8]
       cmp       r14d,[rdi+8]
       jae       near ptr M09_L06
       mov       edx,r14d
       mov       r12,[rdi+rdx*8+10]
       mov       rax,[r12+10]
       mov       [rbp-38],rax
       test      rax,rax
       je        short M09_L02
       lea       rdi,[r12+10]
       test      rdi,rdi
       je        short M09_L04
       mov       rdx,rax
       xor       esi,esi
       call      00007F7927074060
       mov       rcx,[rbp-38]
       cmp       rax,rcx
       jne       short M09_L02
       mov       rax,rcx
       mov       rdi,r15
       mov       rsi,rax
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
M09_L01:
       mov       eax,1
       add       rsp,18
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M09_L02:
       mov       rdi,[rbx]
       mov       rsi,r12
       mov       rdx,r15
       call      qword ptr [7F78A96EDCE0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M09_L01
       inc       r14d
       mov       rdi,[rbx+8]
       cmp       [rdi+8],r14d
       jne       short M09_L03
       xor       r14d,r14d
M09_L03:
       inc       r13d
       mov       rdi,[rbx+8]
       cmp       [rdi+8],r13d
       jg        near ptr M09_L00
       jmp       short M09_L05
M09_L04:
       call      qword ptr [7F78A9C96118]
       int       3
M09_L05:
       xor       eax,eax
       mov       [r15],rax
       add       rsp,18
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M09_L06:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 244
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       cmp       qword ptr [rbp-10],0
       jne       short M10_L00
       add       rsp,30
       pop       rbp
       ret
M10_L00:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F78A96EDB90]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
M10_L01:
       add       rsp,30
       pop       rbp
       ret
       push      rax
       mov       [rbp-28],rdi
       mov       rax,[rbp-28]
       mov       [rbp-20],rax
       mov       rax,[rbp-18]
       cmp       qword ptr [rax],0
       jne       short M10_L02
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
M10_L02:
       lea       rax,[M10_L01]
       add       rsp,8
       ret
; Total bytes of code 114
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       eax,[rbp-10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 27
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-1C],edx
       mov       rax,[rbp-18]
       sar       rax,20
       lea       esi,[rax+1]
       mov       rdi,[rbp-10]
       mov       edx,[rbp-1C]
       call      qword ptr [7F78A904E0D0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 56
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7F78A8804740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7F78A87FEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7F78A880F690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M13_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M13_L00
       mov       rsi,rax
       call      qword ptr [7F78A87FEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M13_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F78A87FEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F78A87FEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rdi
       mov       rdi,[rbx]
       call      qword ptr [7F78A96EDCF8]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       r15d,[rax+10]
       test      r15d,r15d
       je        short M15_L02
M15_L00:
       dec       r15d
       mov       eax,[rbx+18]
       test      eax,eax
       jl        short M15_L03
       and       eax,r15d
M15_L01:
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
M15_L02:
       mov       rdi,[rbx]
       call      qword ptr [7F78A8C55728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       edi,1
       mov       r15d,edi
       lock xadd [rax],r15d
       inc       r15d
       je        short M15_L02
       mov       rdi,[rbx]
       call      qword ptr [7F78A96EDCF8]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       [rax+10],r15d
       jmp       short M15_L00
M15_L03:
       mov       rax,[rbx+8]
       mov       eax,[rax+8]
       mov       ecx,r15d
       imul      rcx,[rbx+10]
       shr       rcx,20
       inc       rcx
       imul      rax,rcx
       shr       rax,20
       jmp       short M15_L01
; Total bytes of code 134
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7F78A9D5C228]; PoolContextProbe+Policy.Destroy(Item)
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 49
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-10],edx
       movsxd    rax,dword ptr [rbp-0C]
       shl       rax,20
       mov       ecx,[rbp-10]
       or        rax,rcx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 40
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rax,[rdi+20]
       mov       ebx,[rax-28]
       cmp       ebx,0FFFFFFFF
       je        near ptr M18_L04
       mov       rdi,7F79272A0D68
       mov       rax,7F7927BA5820
       call      rax
       add       rax,8
       add       rax,0FFFFFFFFFFFFFFF8
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M18_L01
       cmp       [rax],edi
       jle       short M18_L03
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M18_L03
M18_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M18_L01:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M18_L02
       movsxd    rdi,ecx
       add       rax,rdi
       jmp       short M18_L00
M18_L02:
       cmp       [rax+4],ecx
       jle       short M18_L03
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M18_L03
       mov       rax,[rdi]
       test      rax,rax
       je        short M18_L03
       jmp       short M18_L00
M18_L03:
       mov       edi,ebx
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7F78A9C96250]
M18_L04:
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7F78A96EDD40]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 179
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-10]
       mov       rcx,rax
       test      cl,1
       jne       short M19_L00
       ret
M19_L00:
       jmp       qword ptr [7F78A904EA00]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 23
```
```assembly
; PoolContextProbe+Policy.Destroy(Item)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 24
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       rsi,rdi
       lea       rdi,[rbp-30]
       mov       [rbp-94],rdi
       mov       [rbp-9C],rsi
       xor       edx,edx
       mov       [rbp-8C],edx
       lea       rdi,[rbp-88]
       call      qword ptr [7F78A87FEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       edx,[rbp-8C]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7F78A87FEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,[rbp-30]
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 131
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbx
       sub       rsp,10
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rbx,rdi
       mov       rdi,rbx
       call      qword ptr [7F78A8819718]; Precode of System.Runtime.CompilerServices.InitHelpers.InitClassSlow(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rbx+20]
       mov       rax,[rax-10]
       mov       [rsp+8],rax
       mov       rax,[rsp+8]
       and       rax,0FFFFFFFFFFFFFFFE
       xor       ecx,ecx
       mov       [rsp+8],rcx
       add       rsp,10
       pop       rbx
       ret
; Total bytes of code 59
```

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: A-baseline(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.4.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.4.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=10, LaunchCount=3, WarmupCount=5))

```assembly
; PoolContextProbe.NestedRentReturn()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,0C8
       lea       rbp,[rsp+0F0]
       mov       rbx,rdi
       mov       r15,[rbx+8]
       cmp       dword ptr [r15+1C],0
       jne       near ptr M00_L36
M00_L00:
       mov       r14,[r15+10]
       xor       r13d,r13d
       test      r14,r14
       je        near ptr M00_L37
       mov       rdi,7FD56A4A0D68
       mov       rax,7FD56AE9B820
       call      rax
       add       rax,4C
       mov       r12d,[rax+10]
       test      r12d,r12d
       je        near ptr M00_L45
M00_L01:
       dec       r12d
       mov       eax,[r14+18]
       test      eax,eax
       jl        near ptr M00_L46
       and       r12d,eax
M00_L02:
       xor       eax,eax
M00_L03:
       mov       rdi,[r14+8]
       mov       [rbp-2C],eax
       cmp       [rdi+8],eax
       jle       near ptr M00_L50
       cmp       r12d,[rdi+8]
       jae       near ptr M00_L99
       mov       edx,r12d
       mov       rcx,[rdi+rdx*8+10]
       mov       [rbp-0B0],rcx
       mov       r8,[rcx+10]
       mov       [rbp-0B8],r8
       test      r8,r8
       jne       near ptr M00_L34
M00_L04:
       lea       rdi,[rcx+18]
       mov       rdx,[rcx+8]
       mov       rsi,[rdi]
       mov       r8d,esi
       cmp       r8d,0FFFFFFFF
       je        near ptr M00_L48
       mov       r9d,[rdx+8]
M00_L05:
       cmp       r8d,r9d
       jae       near ptr M00_L99
       mov       r10d,r8d
       shl       r10,4
       mov       r11d,[rdx+r10+18]
       mov       rax,rsi
       sar       rax,20
       inc       eax
       cdqe
       shl       rax,20
       or        r11,rax
       mov       rax,rsi
       lock cmpxchg [rdi],r11
       cmp       rax,rsi
       jne       near ptr M00_L47
       mov       rax,[rcx+8]
       mov       rdi,rax
       mov       edx,[rdi+8]
       cmp       r8d,edx
       jae       near ptr M00_L99
       mov       rdx,[rdi+r10+10]
       lea       rdi,[rax+r10+10]
       xor       eax,eax
       mov       [rdi],rax
       add       rcx,20
M00_L06:
       mov       rax,[rcx]
       mov       [rbp-38],rax
       mov       [rdi+8],eax
       mov       rsi,rax
       sar       rsi,20
       inc       esi
       movsxd    rsi,esi
       shl       rsi,20
       mov       r9d,r8d
       or        rsi,r9
       lock cmpxchg [rcx],rsi
       cmp       rax,[rbp-38]
       jne       short M00_L06
       test      rdx,rdx
       je        near ptr M00_L48
M00_L07:
       test      rdx,rdx
       je        near ptr M00_L51
M00_L08:
       cmp       dword ptr [r15+1C],0
       jne       near ptr M00_L53
       mov       r15,rdx
M00_L09:
       mov       r14,[rbx+8]
       cmp       dword ptr [r14+1C],0
       jne       near ptr M00_L54
M00_L10:
       mov       r13,[r14+10]
       xor       r12d,r12d
       test      r13,r13
       je        near ptr M00_L55
       mov       rdi,7FD56A4A0D68
       mov       rax,7FD56AE9B820
       call      rax
       add       rax,4C
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M00_L63
M00_L11:
       dec       eax
       mov       ecx,[r13+18]
       test      ecx,ecx
       jl        near ptr M00_L64
       and       ecx,eax
M00_L12:
       mov       eax,ecx
       xor       ecx,ecx
M00_L13:
       mov       rdi,[r13+8]
       mov       [rbp-40],ecx
       cmp       [rdi+8],ecx
       jle       near ptr M00_L68
       cmp       eax,[rdi+8]
       jae       near ptr M00_L99
       mov       [rbp-3C],eax
       mov       edx,eax
       mov       r8,[rdi+rdx*8+10]
       mov       [rbp-0C8],r8
       mov       r9,[r8+10]
       mov       [rbp-0D0],r9
       test      r9,r9
       jne       near ptr M00_L35
M00_L14:
       lea       rdi,[r8+18]
       mov       rdx,[r8+8]
       mov       rsi,[rdi]
       mov       r9d,esi
       cmp       r9d,0FFFFFFFF
       je        near ptr M00_L66
       mov       r10d,[rdx+8]
       mov       [rbp-94],r10d
M00_L15:
       cmp       r9d,r10d
       jae       near ptr M00_L99
       mov       r11d,r9d
       shl       r11,4
       mov       ecx,[rdx+r11+18]
       mov       r10,rsi
       sar       r10,20
       inc       r10d
       movsxd    r10,r10d
       shl       r10,20
       or        rcx,r10
       mov       rax,rsi
       lock cmpxchg [rdi],rcx
       cmp       rax,rsi
       jne       near ptr M00_L65
       mov       rax,[r8+8]
       mov       rdi,rax
       mov       ecx,[rdi+8]
       cmp       r9d,ecx
       jae       near ptr M00_L99
       mov       rdx,[rdi+r11+10]
       cmp       r9d,ecx
       jae       near ptr M00_L99
       lea       rdi,[rax+r11+10]
       xor       eax,eax
       mov       [rdi],rax
       add       r8,20
M00_L16:
       mov       rax,[r8]
       mov       [rbp-50],rax
       mov       [rdi+8],eax
       mov       rcx,rax
       sar       rcx,20
       inc       ecx
       movsxd    rcx,ecx
       shl       rcx,20
       mov       esi,r9d
       or        rcx,rsi
       lock cmpxchg [r8],rcx
       cmp       rax,[rbp-50]
       jne       short M00_L16
       test      rdx,rdx
       je        near ptr M00_L66
M00_L17:
       test      rdx,rdx
       je        near ptr M00_L69
M00_L18:
       cmp       dword ptr [r14+1C],0
       jne       near ptr M00_L71
       mov       r14,rdx
M00_L19:
       mov       r13d,[r15+8]
       add       r13d,[r14+8]
       mov       r12,[rbx+8]
       cmp       dword ptr [r12+1C],0
       jne       near ptr M00_L26
       mov       rdi,r12
       mov       rsi,r14
       call      qword ptr [7FD4EC8CDE30]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       test      eax,eax
       je        near ptr M00_L26
       mov       rax,[r12+10]
       mov       [rbp-0D8],rax
       test      rax,rax
       je        near ptr M00_L78
       mov       rdi,7FD56A4A0D68
       mov       rcx,7FD56AE9B820
       call      rcx
       add       rax,4C
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M00_L72
M00_L20:
       dec       eax
       mov       rcx,[rbp-0D8]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M00_L73
       and       r8d,eax
M00_L21:
       mov       eax,r8d
       xor       r8d,r8d
       mov       [rbp-58],r8d
       mov       rdi,[rcx+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M00_L77
M00_L22:
       mov       rdi,[rcx+8]
       cmp       eax,[rdi+8]
       jae       near ptr M00_L99
       mov       [rbp-54],eax
       mov       esi,eax
       mov       r9,[rdi+rsi*8+10]
       mov       [rbp-0E0],r9
       cmp       [r9],r9b
       lea       rdi,[r9+10]
       test      rdi,rdi
       je        near ptr M00_L96
       mov       rsi,r14
       xor       edx,edx
       call      00007FD56A274060
       test      rax,rax
       je        near ptr M00_L25
       mov       rcx,[rbp-0E0]
       lea       rdi,[rcx+20]
       mov       rsi,[rcx+8]
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       je        near ptr M00_L75
M00_L23:
       cmp       edx,[rsi+8]
       jae       near ptr M00_L99
       mov       r8d,edx
       shl       r8,4
       mov       [rbp-0A0],r8
       mov       r9d,[rsi+r8+18]
       mov       r10,rax
       sar       r10,20
       inc       r10d
       movsxd    r10,r10d
       shl       r10,20
       or        r9,r10
       mov       [rbp-68],rax
       lock cmpxchg [rdi],r9
       cmp       rax,[rbp-68]
       jne       near ptr M00_L74
       mov       rdi,[rcx+8]
       mov       [rbp-60],edx
       cmp       edx,[rdi+8]
       jae       near ptr M00_L99
       lea       rdi,[rdi+r8+10]
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       mov       r14,[rbp-0E0]
       lea       rdi,[r14+18]
       mov       rcx,[r14+8]
       mov       r14d,[rbp-60]
M00_L24:
       mov       rax,[rdi]
       mov       [rbp-70],rax
       cmp       r14d,[rcx+8]
       jae       near ptr M00_L99
       mov       r8,[rbp-0A0]
       mov       [rcx+r8+18],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       esi,r14d
       or        rdx,rsi
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-70]
       jne       short M00_L24
M00_L25:
       cmp       dword ptr [r12+1C],0
       jne       near ptr M00_L83
M00_L26:
       mov       rbx,[rbx+8]
       cmp       [rbx],bl
       test      r15,r15
       je        near ptr M00_L84
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M00_L33
       mov       rdi,rbx
       mov       rsi,r15
       call      qword ptr [7FD4EC8CDE30]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       test      eax,eax
       je        near ptr M00_L33
       mov       r14,[rbx+10]
       test      r14,r14
       je        near ptr M00_L91
       mov       rdi,7FD56A4A0D68
       mov       rax,7FD56AE9B820
       call      rax
       add       rax,4C
       mov       r12d,[rax+10]
       test      r12d,r12d
       je        near ptr M00_L85
M00_L27:
       dec       r12d
       mov       eax,[r14+18]
       test      eax,eax
       jl        near ptr M00_L86
       and       r12d,eax
M00_L28:
       xor       eax,eax
       mov       [rbp-78],eax
       mov       rdi,[r14+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M00_L90
M00_L29:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M00_L99
       mov       esi,r12d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-0E8],rcx
       cmp       [rcx],cl
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M00_L96
       mov       rsi,r15
       xor       edx,edx
       call      00007FD56A274060
       test      rax,rax
       je        near ptr M00_L32
       mov       rcx,[rbp-0E8]
       lea       rdi,[rcx+20]
       mov       rsi,[rcx+8]
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       je        near ptr M00_L88
       mov       r8d,[rsi+8]
M00_L30:
       cmp       edx,[rsi+8]
       jae       near ptr M00_L99
       mov       r8d,edx
       shl       r8,4
       mov       [rbp-0A8],r8
       mov       r9d,[rsi+r8+18]
       mov       r10,rax
       sar       r10,20
       inc       r10d
       movsxd    r10,r10d
       shl       r10,20
       or        r9,r10
       mov       [rbp-88],rax
       lock cmpxchg [rdi],r9
       cmp       rax,[rbp-88]
       jne       near ptr M00_L87
       mov       rdi,[rcx+8]
       mov       [rbp-7C],edx
       cmp       edx,[rdi+8]
       jae       near ptr M00_L99
       lea       rdi,[rdi+r8+10]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       r15,[rbp-0E8]
       lea       rdi,[r15+18]
       mov       rcx,[r15+8]
       mov       r15d,[rbp-7C]
M00_L31:
       mov       rax,[rdi]
       mov       [rbp-90],rax
       cmp       r15d,[rcx+8]
       jae       near ptr M00_L99
       mov       r14,[rbp-0A8]
       mov       [rcx+r14+18],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       esi,r15d
       or        rdx,rsi
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-90]
       jne       short M00_L31
M00_L32:
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M00_L98
M00_L33:
       mov       eax,r13d
       add       rsp,0C8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M00_L34:
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M00_L96
       mov       rdx,r8
       xor       esi,esi
       call      00007FD56A274060
       mov       rdi,[rbp-0B8]
       cmp       rax,rdi
       mov       rcx,[rbp-0B0]
       jne       near ptr M00_L04
       mov       r8,rdi
       mov       rdx,r8
       jmp       near ptr M00_L07
M00_L35:
       lea       rdi,[r8+10]
       test      rdi,rdi
       je        near ptr M00_L96
       mov       rdx,r9
       xor       esi,esi
       call      00007FD56A274060
       mov       rdi,[rbp-0D0]
       cmp       rax,rdi
       mov       r8,[rbp-0C8]
       jne       near ptr M00_L14
       mov       r9,rdi
       mov       rdx,r9
       jmp       near ptr M00_L17
M00_L36:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7FD4EC8CDBA8]
       jmp       near ptr M00_L00
M00_L37:
       mov       rdi,7FD56A4A0D68
       mov       rax,7FD56AE9B820
       call      rax
       add       rax,44
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M00_L39
M00_L38:
       mov       rdi,7FD4EAE4B1E8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M00_L38
       mov       [rax+10],edi
M00_L39:
       dec       edi
       imul      edi,9E3779B9
       mov       edx,[r15+18]
       test      edx,edx
       jge       short M00_L40
       mov       r13d,edi
       mov       esi,[r15+20]
       imul      r13,rsi
       shr       r13,20
       jmp       short M00_L41
M00_L40:
       mov       r13d,edi
       and       r13d,edx
M00_L41:
       mov       rdi,[r15+8]
       lea       edx,[r13*8]
       cmp       edx,[rdi+8]
       jae       near ptr M00_L99
       lea       rdi,[rdi+rdx*8+10]
       mov       r12,[rdi]
       test      r12,r12
       je        short M00_L42
       mov       rdx,r12
       xor       esi,esi
       call      00007FD56A274060
       cmp       rax,r12
       je        short M00_L43
M00_L42:
       xor       edx,edx
       jmp       short M00_L44
M00_L43:
       mov       rdx,r12
M00_L44:
       jmp       near ptr M00_L07
M00_L45:
       mov       rdi,7FD4EAE4B178
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M00_L45
       mov       rdi,7FD56A4A0D68
       mov       rax,7FD56AE9B820
       call      rax
       add       rax,4C
       mov       [rax+10],r12d
       jmp       near ptr M00_L01
M00_L46:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
       jmp       near ptr M00_L02
M00_L47:
       mov       rsi,[rdi]
       mov       r8d,esi
       cmp       r8d,0FFFFFFFF
       jne       near ptr M00_L05
M00_L48:
       inc       r12d
       mov       rdx,[r14+8]
       cmp       [rdx+8],r12d
       jne       short M00_L49
       xor       r12d,r12d
M00_L49:
       mov       eax,[rbp-2C]
       inc       eax
       jmp       near ptr M00_L03
M00_L50:
       xor       edx,edx
       jmp       near ptr M00_L07
M00_L51:
       test      r14,r14
       je        short M00_L52
       mov       rdi,offset MT_PoolContextProbe+Item
       call      CORINFO_HELP_NEWSFAST
       mov       rdx,rax
       mov       dword ptr [rdx+8],2A
       jmp       near ptr M00_L08
M00_L52:
       mov       rdi,r15
       mov       esi,r13d
       call      qword ptr [7FD4EC8CDC80]
       mov       rdx,rax
       jmp       near ptr M00_L08
M00_L53:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7FD4EC8CDBA8]
       mov       r15,rax
       jmp       near ptr M00_L09
M00_L54:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7FD4EC8CDBA8]
       jmp       near ptr M00_L10
M00_L55:
       mov       rdi,7FD56A4A0D68
       mov       rax,7FD56AE9B820
       call      rax
       add       rax,44
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M00_L57
M00_L56:
       mov       rdi,7FD4EAE4B1E8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M00_L56
       mov       [rax+10],edi
M00_L57:
       dec       edi
       imul      edi,9E3779B9
       mov       edx,[r14+18]
       test      edx,edx
       jge       short M00_L58
       mov       r12d,edi
       mov       esi,[r14+20]
       imul      r12,rsi
       shr       r12,20
       jmp       short M00_L59
M00_L58:
       mov       r12d,edi
       and       r12d,edx
M00_L59:
       mov       rdi,[r14+8]
       lea       edx,[r12*8]
       cmp       edx,[rdi+8]
       jae       near ptr M00_L99
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       rdx,rax
       mov       [rbp-0C0],rdx
       test      rdx,rdx
       je        short M00_L60
       xor       esi,esi
       call      00007FD56A274060
       mov       rdi,[rbp-0C0]
       cmp       rax,rdi
       je        short M00_L61
M00_L60:
       xor       edx,edx
       jmp       short M00_L62
M00_L61:
       mov       rdx,rdi
M00_L62:
       jmp       near ptr M00_L17
M00_L63:
       mov       rax,7FD4EAE4B178
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-44],eax
       test      eax,eax
       je        short M00_L63
       mov       rdi,7FD56A4A0D68
       mov       rcx,7FD56AE9B820
       call      rcx
       add       rax,4C
       mov       ecx,[rbp-44]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M00_L11
M00_L64:
       mov       rcx,[r13+8]
       mov       edi,[rcx+8]
       mov       ecx,eax
       imul      rcx,[r13+10]
       shr       rcx,20
       inc       rcx
       imul      rcx,rdi
       shr       rcx,20
       mov       eax,ecx
       mov       ecx,eax
       jmp       near ptr M00_L12
M00_L65:
       mov       rsi,[rdi]
       mov       r9d,esi
       cmp       r9d,0FFFFFFFF
       mov       r10d,[rbp-94]
       jne       near ptr M00_L15
M00_L66:
       mov       eax,[rbp-3C]
       inc       eax
       mov       edx,eax
       mov       rdi,[r13+8]
       cmp       [rdi+8],edx
       jne       short M00_L67
       xor       edx,edx
       xor       edi,edi
       mov       edx,edi
M00_L67:
       mov       ecx,[rbp-40]
       inc       ecx
       mov       eax,edx
       jmp       near ptr M00_L13
M00_L68:
       xor       edx,edx
       jmp       near ptr M00_L17
M00_L69:
       test      r13,r13
       je        short M00_L70
       mov       rdi,offset MT_PoolContextProbe+Item
       call      CORINFO_HELP_NEWSFAST
       mov       rdx,rax
       mov       dword ptr [rdx+8],2A
       jmp       near ptr M00_L18
M00_L70:
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7FD4EC8CDC80]
       mov       rdx,rax
       jmp       near ptr M00_L18
M00_L71:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7FD4EC8CDBA8]
       mov       r14,rax
       jmp       near ptr M00_L19
M00_L72:
       mov       rax,7FD4EAE4B178
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-5C],eax
       test      eax,eax
       je        short M00_L72
       mov       rdi,7FD56A4A0D68
       mov       rcx,7FD56AE9B820
       call      rcx
       add       rax,4C
       mov       ecx,[rbp-5C]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M00_L20
M00_L73:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M00_L21
M00_L74:
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       jne       near ptr M00_L23
M00_L75:
       mov       eax,[rbp-54]
       inc       eax
       mov       ecx,eax
       mov       rdx,[rbp-0D8]
       mov       r8,[rdx+8]
       cmp       [r8+8],ecx
       jne       short M00_L76
       xor       ecx,ecx
       xor       edi,edi
       mov       ecx,edi
M00_L76:
       mov       edi,[rbp-58]
       inc       edi
       cmp       [r8+8],edi
       mov       [rbp-58],edi
       mov       eax,ecx
       jle       short M00_L77
       mov       rcx,rdx
       jmp       near ptr M00_L22
M00_L77:
       cmp       [r12],r12b
       jmp       near ptr M00_L25
M00_L78:
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M00_L80
M00_L79:
       mov       rdi,7FD4EAE4B1E8
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M00_L79
       mov       [rax+10],edi
M00_L80:
       dec       edi
       imul      edi,9E3779B9
       cmp       dword ptr [r12+18],0
       jge       short M00_L81
       mov       eax,edi
       mov       ecx,[r12+20]
       imul      rax,rcx
       shr       rax,20
       jmp       short M00_L82
M00_L81:
       mov       eax,edi
       and       eax,[r12+18]
M00_L82:
       mov       rdi,[r12+8]
       lea       esi,[rax*8]
       cmp       esi,[rdi+8]
       jae       near ptr M00_L99
       mov       [rbp-74],eax
       lea       esi,[rax*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       je        near ptr M00_L96
       mov       rsi,r14
       call      00007FD56A274040
       test      rax,rax
       je        near ptr M00_L25
       mov       rdi,r12
       mov       rsi,r14
       mov       rdx,rax
       mov       ecx,[rbp-74]
       call      qword ptr [7FD4EC8CDF08]
       jmp       near ptr M00_L25
M00_L83:
       mov       rdi,r12
       call      qword ptr [7FD4EC8CDF50]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       jmp       near ptr M00_L26
M00_L84:
       mov       edi,29
       mov       rsi,7FD4EC2B54D8
       call      qword ptr [7FD4EBE3EF88]
       mov       rdi,rax
       call      qword ptr [7FD4ECE76298]
       int       3
M00_L85:
       mov       rdi,7FD4EAE4B178
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M00_L85
       mov       rdi,7FD56A4A0D68
       mov       rax,7FD56AE9B820
       call      rax
       add       rax,4C
       mov       [rax+10],r12d
       jmp       near ptr M00_L27
M00_L86:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
       jmp       near ptr M00_L28
M00_L87:
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       jne       near ptr M00_L30
M00_L88:
       inc       r12d
       mov       rcx,[r14+8]
       cmp       [rcx+8],r12d
       jne       short M00_L89
       xor       r12d,r12d
M00_L89:
       mov       eax,[rbp-78]
       inc       eax
       cmp       [rcx+8],eax
       mov       [rbp-78],eax
       jg        near ptr M00_L29
M00_L90:
       cmp       [rbx],bl
       jmp       near ptr M00_L32
M00_L91:
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M00_L93
M00_L92:
       mov       rdi,7FD4EAE4B1E8
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M00_L92
       mov       [rax+10],edi
M00_L93:
       dec       edi
       imul      r14d,edi,9E3779B9
       cmp       dword ptr [rbx+18],0
       jge       short M00_L94
       mov       r12d,r14d
       mov       r14d,[rbx+20]
       imul      r14,r12
       shr       r14,20
       jmp       short M00_L95
M00_L94:
       and       r14d,[rbx+18]
M00_L95:
       mov       rdi,[rbx+8]
       lea       esi,[r14*8]
       cmp       esi,[rdi+8]
       jae       short M00_L99
       lea       esi,[r14*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M00_L97
M00_L96:
       call      qword ptr [7FD4ECE76280]
       int       3
M00_L97:
       mov       rsi,r15
       call      00007FD56A274040
       test      rax,rax
       je        near ptr M00_L32
       mov       rdi,rbx
       mov       rsi,r15
       mov       rdx,rax
       mov       ecx,r14d
       call      qword ptr [7FD4EC8CDF08]
       jmp       near ptr M00_L32
M00_L98:
       mov       rdi,rbx
       call      qword ptr [7FD4EC8CDF50]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       jmp       near ptr M00_L33
M00_L99:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 3333
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       cmp       [rdi],dil
       mov       eax,1
       add       rsp,10
       pop       rbp
       ret
       push      rax
       mov       rdi,[rbp-8]
       cmp       [rdi],dil
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 42
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       push      rbp
       sub       rsp,0B0
       lea       rbp,[rsp+0B0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       dword ptr [rbp-88],3E8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-98],rax
       mov       rax,[rbp-98]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+40]
       mov       [rbp-0A0],rax
       cmp       qword ptr [rbp-0A0],0
       je        short M02_L00
       mov       rax,[rbp-0A0]
       mov       [rbp-68],rax
       jmp       short M02_L01
M02_L00:
       mov       rdi,[rbp-98]
       mov       rsi,7FD4ECF4AE68
       call      qword ptr [7FD4EBE3F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-68],rax
M02_L01:
       mov       rax,[rbp-38]
       cmp       [rax],al
       mov       rax,[rbp-38]
       lea       rdi,[rax+28]
       mov       rsi,[rbp-68]
       mov       rdx,[rbp-38]
       call      qword ptr [7FD4ECE765B0]; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       nop
M02_L02:
       mov       rax,[rbp-38]
       mov       rax,[rax+10]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-48],0
       je        near ptr M02_L07
M02_L03:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M02_L04
       lea       rdi,[rbp-88]
       mov       esi,1D
       call      CORINFO_HELP_PATCHPOINT
M02_L04:
       lea       rsi,[rbp-50]
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7FD4EC8CDC50]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       test      eax,eax
       je        short M02_L05
       mov       rdi,7FD4ECF7466C
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-50]
       call      qword ptr [7FD4ECF3C2A0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       jmp       short M02_L03
M02_L05:
       cmp       qword ptr [rbp-40],0
       je        short M02_L06
       mov       rdi,7FD4ECF74670
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7FD4ECF3C2B8]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FD4ECF3C2D0]
M02_L06:
       mov       rdi,7FD4ECF74674
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M02_L07:
       xor       eax,eax
       mov       [rbp-54],eax
       jmp       near ptr M02_L11
M02_L08:
       mov       rdi,7FD4ECF74678
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-38]
       mov       esi,[rbp-54]
       call      qword ptr [7FD4EC8CDC38]
       mov       [rbp-70],rax
       xor       eax,eax
       mov       [rbp-60],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-0A8],rax
       mov       rax,[rbp-0A8]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+38]
       mov       [rbp-0B0],rax
       cmp       qword ptr [rbp-0B0],0
       je        short M02_L09
       mov       rax,[rbp-0B0]
       mov       [rbp-78],rax
       jmp       short M02_L10
M02_L09:
       mov       rdi,[rbp-0A8]
       mov       rsi,7FD4ECCD0280
       call      qword ptr [7FD4EBE3F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-78],rax
M02_L10:
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-70]
       mov       rdx,[rbp-60]
       call      qword ptr [7FD4EC8CDEA8]
       mov       [rbp-90],rax
       mov       rsi,[rbp-90]
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       call      qword ptr [7FD4ECF3C2A0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       mov       eax,[rbp-54]
       inc       eax
       mov       [rbp-54],eax
M02_L11:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M02_L12
       lea       rdi,[rbp-88]
       mov       esi,67
       call      CORINFO_HELP_PATCHPOINT
M02_L12:
       mov       rdi,[rbp-38]
       call      qword ptr [7FD4ECF3C2E8]
       cmp       eax,[rbp-54]
       jg        near ptr M02_L08
       cmp       qword ptr [rbp-40],0
       je        short M02_L13
       mov       rdi,7FD4ECF7467C
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7FD4ECF3C2B8]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FD4ECF3C2D0]
M02_L13:
       mov       rdi,7FD4ECF74680
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
       push      rax
       mov       [rbp-80],rdi
       mov       rdi,7FD4ECF74668
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-80]
       mov       [rbp-40],rax
       lea       rax,[M02_L02]
       add       rsp,8
       ret
; Total bytes of code 731
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7FD4EB9DEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7FD4EB9DEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       push      rbp
       sub       rsp,110
       lea       rbp,[rsp+110]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0F0],ymm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       xor       eax,eax
       mov       [rbp-50],rax
       mov       [rbp-30],rsi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       dword ptr [rbp-0C8],3E8
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       jne       short M04_L00
       mov       rdi,7FD4ECF75E10
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,110
       pop       rbp
       ret
M04_L00:
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+10]
       mov       [rbp-0F8],rax
       cmp       qword ptr [rbp-0F8],0
       je        short M04_L01
       mov       rax,[rbp-0F8]
       mov       [rbp-80],rax
       jmp       short M04_L02
M04_L01:
       mov       rdi,[rbp-40]
       mov       rsi,7FD4ECF4B428
       call      qword ptr [7FD4EBE3F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-80],rax
M04_L02:
       mov       rdi,[rbp-50]
       cmp       [rdi],edi
       call      qword ptr [7FD4ECF3C3A8]
       mov       [rbp-0A8],rax
       mov       rdi,[rbp-0A8]
       mov       rsi,7FD4ECF75E18
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0A8]
       mov       [rbp-0D0],rax
       mov       rdi,[rbp-0D0]
       mov       r11,[rbp-80]
       mov       rax,[rbp-80]
       call      qword ptr [rax]
       mov       [rbp-60],rax
       jmp       near ptr M04_L09
M04_L03:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-100],rax
       cmp       qword ptr [rbp-100],0
       je        short M04_L04
       mov       rax,[rbp-100]
       mov       [rbp-88],rax
       jmp       short M04_L05
M04_L04:
       mov       rdi,[rbp-40]
       mov       rsi,7FD4ECF4B460
       call      qword ptr [7FD4EBE3F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-88],rax
M04_L05:
       mov       rax,[rbp-60]
       mov       [rbp-0B0],rax
       mov       rdi,[rbp-0B0]
       mov       rsi,7FD4ECF75F20
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0B0]
       mov       [rbp-0E0],rax
       mov       rdi,[rbp-0E0]
       mov       r11,[rbp-88]
       mov       rax,[rbp-88]
       call      qword ptr [rax]
       mov       [rbp-0D8],rax
       mov       rax,[rbp-0D8]
       cmp       [rax],al
       mov       rax,[rbp-0D8]
       add       rax,8
       mov       [rbp-90],rax
       xor       eax,eax
       mov       [rbp-70],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-108],rax
       cmp       qword ptr [rbp-108],0
       je        short M04_L06
       mov       rax,[rbp-108]
       mov       [rbp-98],rax
       jmp       short M04_L07
M04_L06:
       mov       rdi,[rbp-40]
       mov       rsi,7FD4ECF4B4B0
       call      qword ptr [7FD4EBE3F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-98],rax
M04_L07:
       mov       rdi,[rbp-98]
       mov       rsi,[rbp-90]
       mov       rdx,[rbp-70]
       call      qword ptr [7FD4EC8CDEA8]
       mov       [rbp-68],rax
       cmp       qword ptr [rbp-68],0
       je        short M04_L08
       mov       rdi,7FD4ECF76028
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-48]
       mov       rsi,[rbp-68]
       cmp       [rdi],edi
       call      qword ptr [7FD4ECF3C3C0]
       jmp       short M04_L09
M04_L08:
       mov       rdi,7FD4ECF7602C
       call      CORINFO_HELP_COUNTPROFILE32
M04_L09:
       mov       eax,[rbp-0C8]
       dec       eax
       mov       [rbp-0C8],eax
       cmp       dword ptr [rbp-0C8],0
       jg        short M04_L10
       lea       rdi,[rbp-0C8]
       mov       esi,57
       call      CORINFO_HELP_PATCHPOINT
M04_L10:
       mov       rax,[rbp-60]
       mov       [rbp-0B8],rax
       mov       rdi,[rbp-0B8]
       mov       rsi,7FD4ECF76038
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0B8]
       mov       [rbp-0E8],rax
       mov       rdi,[rbp-0E8]
       mov       r11,7FD4EAE50880
       call      qword ptr [r11]
       test      eax,eax
       jne       near ptr M04_L03
       call      M04_L13
       nop
       cmp       qword ptr [rbp-58],0
       je        short M04_L11
       mov       rdi,7FD4ECF76254
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-58]
       call      qword ptr [7FD4ECF3C2B8]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FD4ECF3C2D0]
M04_L11:
       mov       rdi,7FD4ECF76258
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,110
       pop       rbp
       ret
       push      rax
       mov       [rbp-0A0],rdi
       mov       rax,[rbp-0A0]
       mov       [rbp-78],rax
       cmp       qword ptr [rbp-58],0
       jne       short M04_L12
       mov       rdi,7FD4ECF76030
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-78]
       mov       [rbp-58],rax
M04_L12:
       mov       rdi,7FD4ECF76034
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rax,[M04_L09]
       add       rsp,8
       ret
M04_L13:
       push      rax
       cmp       qword ptr [rbp-60],0
       je        short M04_L14
       mov       rdi,7FD4ECF76140
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-60]
       mov       [rbp-0C0],rax
       mov       rdi,[rbp-0C0]
       mov       rsi,7FD4ECF76148
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0C0]
       mov       [rbp-0F0],rax
       mov       rdi,[rbp-0F0]
       mov       r11,7FD4EAE50888
       call      qword ptr [r11]
M04_L14:
       mov       rdi,7FD4ECF76250
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
; Total bytes of code 999
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,38
       lea       rbp,[rsp+60]
       mov       [rbp-30],rdi
       mov       rbx,rdi
       mov       r15,rsi
       mov       rdi,rbx
       call      qword ptr [7FD4EC8CDCC8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       r14d,eax
       xor       r13d,r13d
M05_L00:
       mov       rdi,[rbx+8]
       cmp       [rdi+8],r13d
       jle       near ptr M05_L11
       cmp       r14d,[rdi+8]
       jae       near ptr M05_L12
       mov       edx,r14d
       mov       r12,[rdi+rdx*8+10]
       mov       rax,[r12+10]
       mov       [rbp-58],rax
       test      rax,rax
       jne       near ptr M05_L05
M05_L01:
       lea       rdi,[r12+18]
       mov       rsi,[r12+8]
       mov       rax,[rdi]
       mov       ecx,eax
       cmp       ecx,0FFFFFFFF
       je        near ptr M05_L07
       mov       edx,[rsi+8]
M05_L02:
       cmp       ecx,edx
       jae       near ptr M05_L12
       mov       r8d,ecx
       shl       r8,4
       mov       [rbp-50],r8
       mov       r9d,[rsi+r8+18]
       mov       r10,rax
       sar       r10,20
       inc       r10d
       movsxd    r10,r10d
       shl       r10,20
       or        r9,r10
       mov       [rbp-40],rax
       lock cmpxchg [rdi],r9
       cmp       rax,[rbp-40]
       jne       near ptr M05_L06
       mov       rdi,[r12+8]
       mov       [rbp-34],ecx
       cmp       ecx,[rdi+8]
       jae       near ptr M05_L12
       mov       rsi,[rdi+r8+10]
       mov       rdi,r15
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[r12+8]
       mov       edi,[rbp-34]
       cmp       edi,[rax+8]
       jae       near ptr M05_L12
       mov       rsi,[rbp-50]
       lea       rsi,[rax+rsi+10]
       xor       eax,eax
       mov       [rsi],rax
       add       r12,20
M05_L03:
       mov       rax,[r12]
       mov       [rbp-48],rax
       mov       [rsi+8],eax
       mov       rcx,rax
       sar       rcx,20
       inc       ecx
       movsxd    rcx,ecx
       shl       rcx,20
       mov       edx,edi
       or        rcx,rdx
       lock cmpxchg [r12],rcx
       cmp       rax,[rbp-48]
       jne       short M05_L03
       cmp       qword ptr [r15],0
       je        short M05_L08
M05_L04:
       mov       eax,1
       add       rsp,38
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M05_L05:
       lea       rdi,[r12+10]
       test      rdi,rdi
       je        short M05_L10
       mov       rdx,rax
       xor       esi,esi
       call      00007FD56A274060
       mov       rcx,[rbp-58]
       cmp       rax,rcx
       jne       near ptr M05_L01
       mov       rax,rcx
       mov       rdi,r15
       mov       rsi,rax
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp       short M05_L04
M05_L06:
       mov       rax,[rdi]
       mov       ecx,eax
       cmp       ecx,0FFFFFFFF
       jne       near ptr M05_L02
M05_L07:
       xor       edi,edi
       mov       [r15],rdi
M05_L08:
       inc       r14d
       mov       rdi,[rbx+8]
       cmp       [rdi+8],r14d
       jne       short M05_L09
       xor       r14d,r14d
M05_L09:
       inc       r13d
       jmp       near ptr M05_L00
M05_L10:
       call      qword ptr [7FD4ECE76280]
       int       3
M05_L11:
       xor       eax,eax
       mov       [r15],rax
       add       rsp,38
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M05_L12:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 444
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       cmp       qword ptr [rbp-10],0
       jne       short M06_L00
       add       rsp,30
       pop       rbp
       ret
M06_L00:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FD4EC8CDB90]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
M06_L01:
       add       rsp,30
       pop       rbp
       ret
       push      rax
       mov       [rbp-28],rdi
       mov       rax,[rbp-28]
       mov       [rbp-20],rax
       mov       rax,[rbp-18]
       cmp       qword ptr [rax],0
       jne       short M06_L02
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
M06_L02:
       lea       rax,[M06_L01]
       add       rsp,8
       ret
; Total bytes of code 114
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7FD4EB9E4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7FD4EB9DEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7FD4EB9EF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M07_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M07_L00
       mov       rsi,rax
       call      qword ptr [7FD4EB9DEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M07_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7FD4EB9DEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7FD4EB9DEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rdi
       mov       rdi,[rbx]
       call      qword ptr [7FD4EC8CDCF8]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       r15d,[rax+10]
       test      r15d,r15d
       je        short M09_L02
M09_L00:
       dec       r15d
       mov       eax,[rbx+18]
       test      eax,eax
       jl        short M09_L03
       and       eax,r15d
M09_L01:
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
M09_L02:
       mov       rdi,[rbx]
       call      qword ptr [7FD4EBE35728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       edi,1
       mov       r15d,edi
       lock xadd [rax],r15d
       inc       r15d
       je        short M09_L02
       mov       rdi,[rbx]
       call      qword ptr [7FD4EC8CDCF8]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       [rax+10],r15d
       jmp       short M09_L00
M09_L03:
       mov       rax,[rbx+8]
       mov       eax,[rax+8]
       mov       ecx,r15d
       imul      rcx,[rbx+10]
       shr       rcx,20
       inc       rcx
       imul      rax,rcx
       shr       rax,20
       jmp       short M09_L01
; Total bytes of code 134
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7FD4ECF3C3D8]; PoolContextProbe+Policy.Destroy(Item)
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 49
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rax,[rdi+20]
       mov       ebx,[rax-28]
       cmp       ebx,0FFFFFFFF
       je        near ptr M11_L04
       mov       rdi,7FD56A4A0D68
       mov       rax,7FD56AE9B820
       call      rax
       add       rax,8
       add       rax,0FFFFFFFFFFFFFFF8
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M11_L01
       cmp       [rax],edi
       jle       short M11_L03
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M11_L03
M11_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M11_L01:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M11_L02
       movsxd    rdi,ecx
       add       rax,rdi
       jmp       short M11_L00
M11_L02:
       cmp       [rax+4],ecx
       jle       short M11_L03
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M11_L03
       mov       rax,[rdi]
       test      rax,rax
       je        short M11_L03
       jmp       short M11_L00
M11_L03:
       mov       edi,ebx
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7FD4ECE76250]
M11_L04:
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7FD4EC8CDD40]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 179
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-10]
       mov       rcx,rax
       test      cl,1
       jne       short M12_L00
       ret
M12_L00:
       jmp       qword ptr [7FD4EC22EA00]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 23
```
```assembly
; PoolContextProbe+Policy.Destroy(Item)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 24
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       rsi,rdi
       lea       rdi,[rbp-30]
       mov       [rbp-94],rdi
       mov       [rbp-9C],rsi
       xor       edx,edx
       mov       [rbp-8C],edx
       lea       rdi,[rbp-88]
       call      qword ptr [7FD4EB9DEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       edx,[rbp-8C]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7FD4EB9DEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,[rbp-30]
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 131
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbx
       sub       rsp,10
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rbx,rdi
       mov       rdi,rbx
       call      qword ptr [7FD4EB9F9718]; Precode of System.Runtime.CompilerServices.InitHelpers.InitClassSlow(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rbx+20]
       mov       rax,[rax-10]
       mov       [rsp+8],rax
       mov       rax,[rsp+8]
       and       rax,0FFFFFFFFFFFFFFFE
       xor       ecx,ecx
       mov       [rsp+8],rcx
       add       rsp,10
       pop       rbx
       ret
; Total bytes of code 59
```

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: A-baseline(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.4.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.4.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=10, LaunchCount=3, WarmupCount=5))

```assembly
; PoolContextProbe.SingleContext()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,48
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-48],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-40],xmm8
       mov       [rbp-30],rax
       mov       rdi,7F19D9800AB0
       mov       rbx,[rdi]
       mov       rdi,7F19D9800400
       mov       r15,[rdi]
       test      rbx,rbx
       je        near ptr M00_L04
M00_L00:
       mov       rdi,7F19D9800AF0
       mov       r14,[rdi]
       test      r14,r14
       je        near ptr M00_L05
M00_L01:
       mov       rdi,7F19D9800AF8
       mov       r13,[rdi]
       test      r13,r13
       je        near ptr M00_L06
M00_L02:
       mov       rax,[r15+38]
       test      rax,rax
       jne       near ptr M00_L07
       cmp       byte ptr [r15+48],0
       jne       near ptr M00_L08
       mov       r12,[r15+10]
       xor       edi,edi
       test      rdi,rdi
       cmove     rdi,r15
       mov       rdi,[rdi+20]
       mov       rax,7F19D9800B00
       test      rdi,rdi
       cmove     rdi,[rax]
       mov       [rbp-50],rdi
       mov       rax,[r15+38]
       test      rax,rax
       jne       near ptr M00_L09
       mov       rdi,[rbp-50]
       mov       rcx,[r15+40]
M00_L03:
       mov       [rsp],r13
       xor       esi,esi
       mov       [rsp+8],rsi
       mov       [rsp+10],rsi
       mov       rsi,r12
       mov       rdx,rdi
       mov       r8,rbx
       mov       r9,r14
       mov       rdi,7F21C1EECB40
       call      qword ptr [7F21C1AEE598]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       mov       [rbp-48],rax
       mov       [rbp-40],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-48]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       mov       rax,[rbp-38]
       mov       rdx,[rbp-30]
       add       rsp,48
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M00_L04:
       mov       rdi,offset MT_System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rsi,7F19D9800AA8
       mov       rsi,[rsi]
       mov       rdi,rbx
       mov       rdx,offset PoolContextProbe+<>c.<SingleContext>b__5_0(Kevlar.KevlarContext)
       call      qword ptr [7F21C1056E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F19D9800AB0
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L00
M00_L05:
       mov       rdi,offset MT_System.Action<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarProperties>
       call      CORINFO_HELP_NEWSFAST
       mov       r14,rax
       mov       rsi,7F19D9800AE8
       mov       rsi,[rsi]
       mov       rdi,r14
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       call      qword ptr [7F21C1056E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F19D9800AF0
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L01
M00_L06:
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r13,rax
       mov       rsi,7F19D9800AE8
       mov       rsi,[rsi]
       mov       rdi,r13
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F21C1056E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F19D9800AF8
       mov       rsi,r13
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L02
M00_L07:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       r8,r13
       mov       rdx,rbx
       mov       rcx,r14
       mov       rsi,7F21C1EEB1D0
       xor       r9d,r9d
       cmp       [rdi],edi
       add       rsp,48
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F21C1AEE340]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
M00_L08:
       call      qword ptr [7F21C1AEE508]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M00_L09:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F21C1AEE4F0]; Kevlar.Shield.get_Name()
       mov       rcx,rax
       mov       rdi,[rbp-50]
       jmp       near ptr M00_L03
; Total bytes of code 604
```
```assembly
; BenchmarkDotNet.Helpers.AwaitHelper.GetResult[[System.Int32, System.Private.CoreLib]](System.Threading.Tasks.ValueTask`1<Int32>)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp-48],rax
       mov       [rbp-40],rax
       mov       [rbp-38],rdi
       mov       [rbp-30],rsi
       mov       rbx,rdi
       mov       r15d,esi
       movsx     r14,word ptr [rbp-2C]
       test      rbx,rbx
       je        near ptr M01_L11
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<System.Int32>
       call      qword ptr [7F21C1056838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r13,rax
       mov       rax,r13
       test      rax,rax
       jne       near ptr M01_L05
       mov       rdi,offset MT_Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource
       cmp       [rbx],rdi
       je        short M01_L02
       mov       rdi,rbx
       mov       esi,r14d
       mov       r11,7F21C0070578
       call      qword ptr [r11]
M01_L00:
       test      eax,eax
       je        near ptr M01_L15
M01_L01:
       test      r13,r13
       jne       near ptr M01_L09
       mov       rdi,offset MT_Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource
       cmp       [rbx],rdi
       je        short M01_L06
       mov       rdi,rbx
       mov       esi,r14d
       mov       r11,7F21C0070580
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M01_L02:
       lea       rsi,[rbx+40]
       movsx     rdi,word ptr [rsi+28]
       cmp       r14d,edi
       jne       near ptr M01_L12
       cmp       qword ptr [rsi],0
       jne       near ptr M01_L13
M01_L03:
       xor       r12d,r12d
M01_L04:
       mov       eax,r12d
       jmp       short M01_L00
M01_L05:
       test      dword ptr [rax+34],1600000
       jne       short M01_L01
       jmp       near ptr M01_L15
M01_L06:
       mov       [rbp-50],rbx
       lea       rdi,[rbx+40]
       movsx     rsi,word ptr [rdi+28]
       cmp       r14d,esi
       jne       short M01_L07
       cmp       byte ptr [rdi+2A],0
       je        short M01_L07
       cmp       qword ptr [rdi+18],0
       jne       short M01_L07
       mov       r15,[rdi+20]
       jmp       short M01_L08
M01_L07:
       call      qword ptr [7F21C2096448]
       int       3
M01_L08:
       lea       r13,[rbx+40]
       inc       esi
       mov       [r13+28],si
       xor       edi,edi
       mov       [r13],rdi
       mov       [r13+8],rdi
       mov       [r13+10],rdi
       mov       [r13+18],rdi
       mov       [r13+20],rdi
       mov       byte ptr [r13+2A],0
       mov       rdi,[rbx+8]
       lea       rdi,[rdi+20]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M01_L11
M01_L09:
       mov       edi,[r13+34]
       and       edi,11000000
       cmp       edi,1000000
       jne       near ptr M01_L16
M01_L10:
       mov       r15d,[r13+38]
M01_L11:
       mov       eax,r15d
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M01_L12:
       call      qword ptr [7F21C20963D0]
       int       3
M01_L13:
       cmp       byte ptr [rsi+2A],0
       je        near ptr M01_L03
       cmp       qword ptr [rsi+18],0
       je        short M01_L14
       mov       rsi,[rsi+18]
       mov       rsi,[rsi+8]
       mov       rdi,offset MT_System.OperationCanceledException
       call      qword ptr [7F21C1056838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r12d,3
       mov       ecx,2
       test      rax,rax
       cmove     r12d,ecx
       jmp       near ptr M01_L04
M01_L14:
       mov       r12d,1
       jmp       near ptr M01_L04
M01_L15:
       mov       [rbp-48],rbx
       mov       [rbp-40],r15d
       mov       [rbp-3C],r14w
       call      qword ptr [7F21C1FFFB40]
       mov       rdi,rax
       mov       rsi,[rbp-48]
       mov       rdx,[rbp-40]
       cmp       [rdi],edi
       call      qword ptr [7F21C1FFFB10]
       jmp       near ptr M01_L01
M01_L16:
       mov       rdi,r13
       xor       esi,esi
       call      qword ptr [7F21C2096430]
       jmp       near ptr M01_L10
       push      rax
       mov       rsi,[rbp-50]
       lea       r13,[rsi+40]
       inc       word ptr [r13+28]
       xor       edi,edi
       mov       [r13],rdi
       mov       [r13+8],rdi
       mov       [r13+10],rdi
       mov       [r13+18],rdi
       mov       [r13+20],rdi
       mov       byte ptr [r13+2A],0
       mov       rdi,[rsi+8]
       lea       rdi,[rdi+20]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,8
       ret
; Total bytes of code 585
```
```assembly
; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,278
       vzeroupper
       lea       rbp,[rsp+2A0]
       xor       eax,eax
       mov       [rbp-218],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-210],xmm8
       vmovdqa   xmmword ptr [rbp-200],xmm8
       mov       rax,0FFFFFFFFFFFFFE50
M02_L00:
       vmovdqa   xmmword ptr [rbp+rax-40],xmm8
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       add       rax,30
       jne       short M02_L00
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-220],r8
       mov       r13,rsi
       mov       r14,rdx
       mov       rbx,rcx
       mov       r15,r9
       mov       r12,[rbp+20]
       mov       rax,7F19D9800BA0
       mov       rax,[rax]
       mov       rax,[rax+8]
       cmp       qword ptr [rax+8],0
       jne       near ptr M02_L27
       xor       edi,edi
M02_L01:
       mov       [rbp-40],rdi
       test      r12,r12
       jne       near ptr M02_L28
M02_L02:
       mov       rdi,7F19D98013C0
       mov       rax,[rdi]
       mov       [rbp-280],rax
       mov       rcx,rax
       mov       [rbp-240],rcx
       cmp       dword ptr [rcx+1C],0
       jne       near ptr M02_L49
M02_L03:
       mov       rcx,[rbp-240]
       mov       rdx,[rcx+10]
       mov       [rbp-250],rdx
       xor       esi,esi
       mov       [rbp-98],esi
       test      rdx,rdx
       je        near ptr M02_L50
       mov       rdi,7F223F6A0D68
       mov       r8,7F223FF67820
       call      r8
       add       rax,48
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M02_L59
M02_L04:
       dec       eax
       mov       rcx,[rbp-250]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M02_L60
       and       r8d,eax
M02_L05:
       mov       eax,r8d
       xor       r8d,r8d
       mov       [rbp-0A8],r8d
       mov       rdi,[rcx+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M02_L64
M02_L06:
       mov       rdi,[rcx+8]
       cmp       eax,[rdi+8]
       jae       near ptr M02_L95
       mov       [rbp-0A4],eax
       mov       edx,eax
       mov       r9,[rdi+rdx*8+10]
       mov       [rbp-260],r9
       mov       r10,[r9+10]
       mov       [rbp-268],r10
       test      r10,r10
       je        near ptr M02_L61
       lea       rdi,[r9+10]
       test      rdi,rdi
       je        near ptr M02_L88
       mov       rdx,r10
       xor       esi,esi
       call      00007F223F474060
       mov       rcx,[rbp-268]
       cmp       rax,rcx
       mov       r9,[rbp-260]
       jne       near ptr M02_L61
       mov       r10,rcx
       mov       [rbp-0A0],r10
       mov       rax,[rbp-240]
M02_L07:
       mov       rdx,[rbp-0A0]
       cmp       qword ptr [rbp-0A0],0
       je        near ptr M02_L65
M02_L08:
       mov       rcx,rdx
M02_L09:
       xor       edi,edi
       mov       [rbp-0A0],rdi
       cmp       dword ptr [rax+1C],0
       jne       near ptr M02_L67
       mov       rdx,rcx
M02_L10:
       mov       [rbp-238],rdx
       lea       rdi,[rdx+68]
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       xor       edi,edi
       mov       r12,[rbp-238]
       mov       [r12+60],edi
       lea       rdi,[r12+38]
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r12+30]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       mov       rsi,0FFFFFFFF00000000
       mov       [r12+58],rsi
       xor       esi,esi
       mov       [r12+40],rsi
       mov       [rbp-228],r12
       jmp       short M02_L12
M02_L11:
       mov       rdi,7F21C006B1F8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M02_L11
       jmp       near ptr M02_L51
M02_L12:
       mov       rdx,[r12+8]
       mov       rsi,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       cmp       [r15+18],rsi
       je        short M02_L13
       mov       rsi,[rbp-220]
       mov       rdi,[r15+8]
       call      qword ptr [r15+18]
       nop
M02_L13:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M02_L25
M02_L14:
       lea       rdi,[rbp-60]
       mov       rdx,r13
       mov       rcx,[rbp-220]
       mov       r8,[rbp+10]
       mov       r9,r12
       call      qword ptr [7F21C1AEE670]; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       rbx,[rbp-60]
       test      rbx,rbx
       jne       near ptr M02_L68
       mov       r14,[rbp-50]
       mov       r15d,[rbp-48]
M02_L15:
       test      r14,r14
       sete      bl
       movzx     ebx,bl
       mov       r13,[r12+30]
       cmp       qword ptr [rbp-40],0
       jne       near ptr M02_L73
M02_L16:
       mov       rsi,[r12+30]
       mov       rdi,7F19D9800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M02_L74
M02_L17:
       cmp       byte ptr [r12+64],0
       jne       near ptr M02_L75
       mov       rbx,[r12+8]
M02_L18:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rax,[rsi+28]
       test      rax,rax
       je        near ptr M02_L26
       mov       rdi,rax
M02_L19:
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-220]
       mov       rcx,rbx
       call      qword ptr [7F21C1AEE760]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rbx,[rbp-280]
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M02_L76
       mov       rdi,rbx
       mov       rsi,r12
       call      qword ptr [7F21C1FF72B8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       je        near ptr M02_L77
       mov       r12,[rbx+10]
       test      r12,r12
       je        near ptr M02_L83
       mov       rdi,7F223F6A0D68
       mov       rax,7F223FF67820
       call      rax
       add       rax,48
       mov       r13d,[rax+10]
       test      r13d,r13d
       je        near ptr M02_L78
M02_L20:
       dec       r13d
       mov       eax,[r12+18]
       test      eax,eax
       jl        near ptr M02_L79
       and       r13d,eax
M02_L21:
       xor       eax,eax
       mov       [rbp-1DC],eax
       mov       rdi,[r12+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M02_L82
M02_L22:
       mov       rdi,[r12+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M02_L95
       mov       esi,r13d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-278],rcx
       cmp       [rcx],cl
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M02_L88
       mov       rsi,[rbp-228]
       xor       edx,edx
       call      00007F223F474060
       test      rax,rax
       jne       near ptr M02_L80
M02_L23:
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M02_L90
M02_L24:
       test      r14,r14
       jne       near ptr M02_L91
       xor       eax,eax
       mov       edx,r15d
       mov       rdi,1000000000000
       or        rdx,rdi
       add       rsp,278
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L25:
       mov       rsi,7F21C1EF36D8
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M02_L14
M02_L26:
       mov       rsi,7F21C1EF3AB0
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M02_L19
M02_L27:
       call      00007F21C1048AE0
       mov       rdi,rax
       jmp       near ptr M02_L01
M02_L28:
       cmp       dword ptr [r12+20],0
       je        near ptr M02_L02
       mov       rsi,rbx
       xor       edx,edx
       call      qword ptr [7F21C1AEE868]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       cmp       qword ptr [rbp+18],0
       je        near ptr M02_L48
       mov       rdi,r12
       mov       rcx,rbx
       mov       rdx,r14
       xor       esi,esi
       call      qword ptr [7F21C1AEE880]; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       mov       rbx,rax
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       r15,[rsi+28]
       test      r15,r15
       je        short M02_L29
       jmp       short M02_L30
M02_L29:
       mov       rsi,7F21C1EF3AB0
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r15,rax
M02_L30:
       mov       rdi,rbx
       cmp       [rdi],edi
       call      qword ptr [7F21C1AEE898]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       rcx,rax
       mov       rdi,r15
       mov       rdx,[rbp-220]
       mov       rsi,[rbp+18]
       call      qword ptr [7F21C1AEE760]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,7F19D98013C0
       mov       rdi,[rdi]
       mov       r15,rdi
       cmp       dword ptr [r15+1C],0
       je        short M02_L31
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F21C0070598
       call      qword ptr [r11]
       jmp       near ptr M02_L48
M02_L31:
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7F21C1FF72B8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       jne       short M02_L32
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F21C00705A0
       call      qword ptr [r11]
       jmp       near ptr M02_L48
M02_L32:
       mov       r14,[r15+10]
       test      r14,r14
       je        near ptr M02_L42
       mov       edi,48
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M02_L34
M02_L33:
       mov       rdi,7F21C006B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M02_L33
       mov       edi,48
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M02_L34:
       dec       r13d
       cmp       dword ptr [r14+18],0
       jl        short M02_L35
       and       r13d,[r14+18]
       jmp       short M02_L36
M02_L35:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r14+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
M02_L36:
       xor       eax,eax
       jmp       short M02_L39
M02_L37:
       mov       rdi,[r14+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M02_L95
       mov       esi,r13d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-230],rcx
       cmp       [rcx],cl
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M02_L88
       mov       rsi,rbx
       xor       edx,edx
       call      00007F223F474060
       test      rax,rax
       je        short M02_L40
       mov       rdx,rbx
       mov       rsi,[rbp-230]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F21C1AEDF38]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M02_L40
       inc       r13d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r13d
       jne       short M02_L38
       xor       r13d,r13d
M02_L38:
       mov       eax,[rbp-94]
       inc       eax
M02_L39:
       mov       rdi,[r14+8]
       mov       [rbp-94],eax
       cmp       [rdi+8],eax
       jg        short M02_L37
       jmp       short M02_L41
M02_L40:
       cmp       dword ptr [r15+1C],0
       je        near ptr M02_L48
       jmp       near ptr M02_L47
M02_L41:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F21C00705A8
       call      qword ptr [r11]
       jmp       short M02_L40
M02_L42:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L44
M02_L43:
       mov       rdi,7F21C006B1F8
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M02_L43
       mov       [rax+10],edi
M02_L44:
       dec       edi
       imul      r14d,edi,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M02_L45
       mov       r13d,r14d
       mov       r14d,[r15+20]
       imul      r14,r13
       shr       r14,20
       jmp       short M02_L46
M02_L45:
       and       r14d,[r15+18]
M02_L46:
       mov       rdi,[r15+8]
       lea       esi,[r14*8]
       cmp       esi,[rdi+8]
       jae       near ptr M02_L95
       lea       esi,[r14*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       je        near ptr M02_L88
       mov       rsi,rbx
       call      00007F223F474040
       test      rax,rax
       je        near ptr M02_L40
       mov       rdi,r15
       mov       rsi,rbx
       mov       rdx,rax
       mov       ecx,r14d
       call      qword ptr [7F21C1FF74F8]
       jmp       near ptr M02_L40
M02_L47:
       mov       rdi,r15
       call      qword ptr [7F21C1FF7528]
M02_L48:
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rdi,rbx
       call      qword ptr [7F21C2096E68]
       lea       rdi,[rbx+70]
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,rbx
       call      qword ptr [7F21C1AEE8E0]
       mov       rdi,rax
       mov       esi,edx
       call      qword ptr [7F21C1AEE7F0]
       mov       [rbp-208],rax
       mov       [rbp-200],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-208]
       vmovdqu   xmmword ptr [rbp-90],xmm0
       mov       rax,[rbp-90]
       mov       rdx,[rbp-88]
       add       rsp,278
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L49:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F21C1FF67C0]
       jmp       near ptr M02_L03
M02_L50:
       mov       rdi,7F223F6A0D68
       mov       rsi,7F223FF67820
       call      rsi
       add       rax,3C
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L52
       jmp       near ptr M02_L11
M02_L51:
       mov       [rax+10],edi
M02_L52:
       dec       edi
       imul      edi,9E3779B9
       mov       rax,[rbp-240]
       mov       edx,[rax+18]
       test      edx,edx
       jge       short M02_L53
       mov       esi,edi
       mov       ecx,[rax+20]
       imul      rsi,rcx
       shr       rsi,20
       jmp       short M02_L54
M02_L53:
       mov       esi,edi
       and       esi,edx
M02_L54:
       mov       ecx,esi
       mov       rdi,[rax+8]
       mov       [rbp-98],ecx
       lea       edx,[rcx*8]
       cmp       edx,[rdi+8]
       jae       near ptr M02_L95
       lea       rdi,[rdi+rdx*8+10]
       mov       r8,[rdi]
       mov       [rbp-258],r8
       test      r8,r8
       je        short M02_L56
       mov       rdx,r8
       xor       esi,esi
       call      00007F223F474060
       mov       rdi,[rbp-258]
       cmp       rax,rdi
       mov       rax,[rbp-240]
       je        short M02_L57
M02_L55:
       xor       esi,esi
       jmp       short M02_L58
M02_L56:
       mov       rax,[rbp-240]
       jmp       short M02_L55
M02_L57:
       mov       r8,rdi
       mov       rsi,r8
M02_L58:
       mov       [rbp-0A0],rsi
       jmp       near ptr M02_L07
M02_L59:
       mov       rax,7F21C006B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-0AC],eax
       test      eax,eax
       je        short M02_L59
       mov       rdi,7F223F6A0D68
       mov       rcx,7F223FF67820
       call      rcx
       add       rax,48
       mov       ecx,[rbp-0AC]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M02_L04
M02_L60:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M02_L05
M02_L61:
       lea       rdx,[rbp-0A0]
       mov       rsi,r9
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F21C1AEDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M02_L63
       mov       eax,[rbp-0A4]
       inc       eax
       mov       edi,eax
       mov       rax,[rbp-250]
       mov       rcx,[rax+8]
       cmp       [rcx+8],edi
       jne       short M02_L62
       xor       edi,edi
M02_L62:
       mov       r8d,[rbp-0A8]
       inc       r8d
       mov       rcx,[rax+8]
       cmp       [rcx+8],r8d
       mov       [rbp-0A8],r8d
       mov       eax,edi
       mov       rcx,[rbp-250]
       jg        near ptr M02_L06
       jmp       short M02_L64
M02_L63:
       mov       rax,[rbp-240]
       jmp       near ptr M02_L07
M02_L64:
       xor       edi,edi
       mov       [rbp-0A0],rdi
       mov       rax,[rbp-240]
       jmp       near ptr M02_L07
M02_L65:
       cmp       qword ptr [rbp-250],0
       je        short M02_L66
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       rcx,rax
       mov       [rbp-270],rcx
       mov       rdi,rcx
       call      qword ptr [7F21C1FF6868]; Kevlar.KevlarContext..ctor()
       mov       rcx,[rbp-270]
       mov       rax,rcx
       mov       rcx,rax
       mov       rax,[rbp-240]
       jmp       near ptr M02_L09
M02_L66:
       mov       rdi,rax
       mov       esi,[rbp-98]
       call      qword ptr [7F21C1FF6820]
       mov       rdx,rax
       mov       rax,[rbp-240]
       jmp       near ptr M02_L08
M02_L67:
       mov       [rbp-248],rcx
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-240]
       mov       dil,[rdi+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-248]
       mov       r11,7F21C00705B0
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F21C1FF67C0]
       mov       rdx,rax
       jmp       near ptr M02_L10
M02_L68:
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F21C1056838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       test      rax,rax
       je        short M02_L69
       mov       rdi,rax
       call      qword ptr [7F21C1FF7138]
       jmp       short M02_L70
M02_L69:
       mov       rdi,rbx
       movsx     rsi,word ptr [rbp-58]
       mov       r11,7F21C00705B8
       call      qword ptr [r11]
       cmp       eax,1
       sete      al
       movzx     eax,al
M02_L70:
       test      eax,eax
       je        near ptr M02_L92
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F21C1056838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r15,rax
       test      r15,r15
       je        short M02_L72
       mov       edi,[r15+34]
       and       edi,11000000
       cmp       edi,1000000
       je        short M02_L71
       mov       rdi,r15
       xor       esi,esi
       call      qword ptr [7F21C2096430]
M02_L71:
       mov       r14,[r15+38]
       mov       r15d,[r15+40]
       jmp       near ptr M02_L15
M02_L72:
       mov       rdi,rbx
       movsx     rsi,word ptr [rbp-58]
       mov       r11,7F21C00705C0
       call      qword ptr [r11]
       mov       r14,rax
       mov       r15d,edx
       jmp       near ptr M02_L15
M02_L73:
       mov       rdi,7F19D9800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F21C1AEE9B8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M02_L16
       lea       rdi,[rbp-140]
       mov       rsi,r13
       call      qword ptr [7F21C1FF71F8]
       mov       rdx,7F21ADC0B6A8
       mov       rdi,7F21ADC0B680
       test      ebx,ebx
       cmove     rdx,rdi
       lea       rdi,[rbp-140]
       mov       rsi,7F21ADC0B638
       call      qword ptr [7F21C1FF7210]
       call      00007F21C1048AE0
       mov       rsi,rax
       mov       rdi,[rbp-40]
       call      qword ptr [7F21C20968E0]
       mov       [rbp-148],rax
       lea       rdi,[rbp-148]
       call      qword ptr [7F21C1FF7240]
       mov       rdi,7F19D9800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-140]
       mov       rdx,r12
       call      qword ptr [7F21C1FF7258]
       jmp       near ptr M02_L16
M02_L74:
       lea       rdi,[rbp-1D8]
       call      qword ptr [7F21C1FF71F8]
       mov       rdx,7F21ADC0B6A8
       mov       rdi,7F21ADC0B680
       test      ebx,ebx
       cmove     rdx,rdi
       lea       rdi,[rbp-1D8]
       mov       rsi,7F21ADC0B638
       call      qword ptr [7F21C1FF7210]
       mov       rdi,7F19D9800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-1D8]
       mov       rcx,r12
       mov       esi,1
       call      qword ptr [7F21C1FF7270]
       jmp       near ptr M02_L17
M02_L75:
       mov       rbx,[r12+10]
       jmp       near ptr M02_L18
M02_L76:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F21C00705C8
       call      qword ptr [r11]
       jmp       near ptr M02_L24
M02_L77:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F21C00705D0
       call      qword ptr [r11]
       jmp       near ptr M02_L24
M02_L78:
       mov       rdi,7F21C006B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M02_L78
       mov       rdi,7F223F6A0D68
       mov       rax,7F223FF67820
       call      rax
       add       rax,48
       mov       [rax+10],r13d
       jmp       near ptr M02_L20
M02_L79:
       mov       rdi,[r12+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r12+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
       jmp       near ptr M02_L21
M02_L80:
       mov       rdx,[rbp-228]
       mov       rsi,[rbp-278]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F21C1AEDF38]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       near ptr M02_L23
       inc       r13d
       mov       rdi,[r12+8]
       cmp       [rdi+8],r13d
       jne       short M02_L81
       xor       r13d,r13d
M02_L81:
       mov       eax,[rbp-1DC]
       inc       eax
       mov       rdi,[r12+8]
       cmp       [rdi+8],eax
       mov       [rbp-1DC],eax
       jg        near ptr M02_L22
M02_L82:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-228]
       mov       r11,7F21C00705D8
       call      qword ptr [r11]
       jmp       near ptr M02_L23
M02_L83:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L85
M02_L84:
       mov       rdi,7F21C006B1F8
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M02_L84
       mov       [rax+10],edi
M02_L85:
       dec       edi
       imul      r13d,edi,9E3779B9
       cmp       dword ptr [rbx+18],0
       jge       short M02_L86
       mov       r12d,r13d
       mov       r13d,[rbx+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M02_L87
M02_L86:
       and       r13d,[rbx+18]
M02_L87:
       mov       rdi,[rbx+8]
       lea       esi,[r13*8]
       cmp       esi,[rdi+8]
       jae       near ptr M02_L95
       lea       esi,[r13*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M02_L89
M02_L88:
       call      qword ptr [7F21C2096340]
       int       3
M02_L89:
       mov       rsi,[rbp-228]
       call      00007F223F474040
       test      rax,rax
       je        near ptr M02_L23
       mov       rdi,rbx
       mov       rsi,[rbp-228]
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7F21C1FF74F8]
       jmp       near ptr M02_L23
M02_L90:
       mov       rdi,rbx
       call      qword ptr [7F21C1FF7528]
       jmp       near ptr M02_L24
M02_L91:
       mov       rdi,r14
       mov       esi,r15d
       call      qword ptr [7F21C1AEE7F0]
       mov       [rbp-218],rax
       mov       [rbp-210],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-218]
       vmovdqu   xmmword ptr [rbp-80],xmm0
       mov       rax,[rbp-80]
       mov       rdx,[rbp-78]
       add       rsp,278
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L92:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rax,[rsi+20]
       test      rax,rax
       je        short M02_L93
       mov       rdi,rax
       jmp       short M02_L94
M02_L93:
       mov       rsi,7F21C1EF3870
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M02_L94:
       mov       [rbp-1F8],rdi
       lea       rdi,[rsp]
       lea       rsi,[rbp-60]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,[rbp-1F8]
       mov       rsi,r12
       mov       rdx,[rbp-220]
       mov       rcx,[rbp+18]
       mov       r8,[rbp-40]
       call      qword ptr [7F21C1AEE718]
       mov       [rbp-1F0],rax
       mov       [rbp-1E8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-1F0]
       vmovdqu   xmmword ptr [rbp-70],xmm0
       mov       rax,[rbp-70]
       mov       rdx,[rbp-68]
       add       rsp,278
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L95:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
       sub       rsp,28
       vzeroupper
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-228]
       xor       edx,edx
       call      qword ptr [7F21C1AEE958]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       r13,[rsi+28]
       test      r13,r13
       je        short M02_L96
       jmp       short M02_L97
M02_L96:
       mov       rsi,7F21C1EF3AB0
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r13,rax
M02_L97:
       mov       rdi,[rbp-228]
       cmp       [rdi],edi
       call      qword ptr [7F21C1AEE898]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       rcx,rax
       mov       rdi,r13
       mov       rdx,[rbp-220]
       mov       rsi,[rbp+18]
       call      qword ptr [7F21C1AEE760]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-228]
       call      qword ptr [7F21C1AEE8B0]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 4000
```
```assembly
; PoolContextProbe+<>c.<SingleContext>b__5_0(Kevlar.KevlarContext)
       xor       eax,eax
       mov       rdx,100000000002A
       ret
; Total bytes of code 13
```
```assembly
; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       push      r15
       push      r14
       push      rbx
       mov       rbx,rdi
       mov       r15,rsi
       mov       r14,rdx
       test      r15,r15
       je        short M04_L00
       mov       rdi,7F21C2102404
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdi,[rbx+8]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       [rbx+18],r14
       pop       rbx
       pop       r14
       pop       r15
       ret
M04_L00:
       mov       rdi,7F21C2102400
       call      CORINFO_HELP_COUNTPROFILE32
       call      qword ptr [7F21C209DE30]
       int       3
; Total bytes of code 78
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       ret
; Total bytes of code 1
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       rcx,rsi
       mov       rsi,rdx
       mov       rax,offset PoolContextProbe+<>c.<SingleContext>b__5_0(Kevlar.KevlarContext)
       cmp       [rcx+18],rax
       jne       short M06_L00
       xor       eax,eax
       mov       rdx,100000000002A
       ret
M06_L00:
       mov       rdi,[rcx+8]
       jmp       qword ptr [rcx+18]
; Total bytes of code 43
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
M07_L00:
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,58
       lea       rbp,[rsp+80]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       mov       [rbp-30],rsi
       mov       rbx,rsi
       mov       r13,rdx
       mov       r15,rcx
       mov       r14,r8
       mov       r12,r9
       test      r15,r15
       je        near ptr M07_L06
       test      r14,r14
       je        near ptr M07_L07
       mov       rax,[rdi+38]
       test      rax,rax
       jne       near ptr M07_L08
       cmp       byte ptr [rdi+48],0
       jne       near ptr M07_L09
       mov       rax,[rdi+10]
       mov       [rbp-58],rax
       xor       ecx,ecx
       test      rcx,rcx
       cmove     rcx,rdi
       mov       rcx,[rcx+20]
       mov       rdx,7F19D9800B00
       test      rcx,rcx
       cmove     rcx,[rdx]
       mov       [rbp-60],rcx
       mov       rdx,[rdi+38]
       test      rdx,rdx
       jne       near ptr M07_L10
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rdi+40]
M07_L01:
       mov       rdi,[rbx+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        short M07_L04
M07_L02:
       mov       rdx,[rdi+18]
       mov       rdx,[rdx+18]
       test      rdx,rdx
       je        near ptr M07_L05
       mov       rdi,rdx
       mov       [rbp-68],rsi
M07_L03:
       mov       [rsp],r14
       xor       edx,edx
       mov       [rsp+8],rdx
       mov       [rsp+10],r12
       mov       rsi,rax
       mov       rdx,rcx
       mov       rcx,[rbp-68]
       mov       r8,r13
       mov       r9,r15
       call      qword ptr [7F21C1AEE598]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       mov       [rbp-50],rax
       mov       [rbp-48],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-50]
       vmovdqu   xmmword ptr [rbp-40],xmm0
       mov       rax,[rbp-40]
       mov       rdx,[rbp-38]
       add       rsp,58
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M07_L04:
       mov       [rbp-60],rcx
       mov       [rbp-68],rsi
       mov       rdi,rbx
       mov       rsi,7F21C1EF2E88
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rbp-68]
       jmp       near ptr M07_L02
M07_L05:
       mov       [rbp-60],rcx
       mov       [rbp-68],rsi
       mov       rsi,7F21C1EF3240
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       jmp       near ptr M07_L03
M07_L06:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,92C
       mov       rsi,7F21C1B1D998
       call      qword ptr [7F21C105EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F21C173E2B0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M07_L07:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,902
       mov       rsi,7F21C1B1D998
       call      qword ptr [7F21C105EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F21C173E2B0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M07_L08:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       rsi,rbx
       mov       rdx,r13
       mov       rcx,r15
       mov       r8,r14
       mov       r9,r12
       cmp       [rdi],edi
       add       rsp,58
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F21C1AEE340]
M07_L09:
       call      qword ptr [7F21C1AEE508]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M07_L10:
       mov       rdi,[rdx+8]
       call      qword ptr [rdx+18]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F21C1AEE4F0]; Kevlar.Shield.get_Name()
       mov       [rbp-68],rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rbp-68]
       jmp       near ptr M07_L01
; Total bytes of code 583
```
```assembly
; Kevlar.Shield.get_Name()
       push      rbp
       mov       rbp,rsp
M08_L00:
       mov       rax,[rdi+38]
       test      rax,rax
       jne       short M08_L01
       mov       rax,[rdi+40]
       pop       rbp
       ret
M08_L01:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       jmp       short M08_L00
; Total bytes of code 31
```
```assembly
; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       push      rbp
       mov       rbp,rsp
       test      rsi,rsi
       je        short M09_L02
       mov       rax,[rsi]
       cmp       rax,rdi
       je        short M09_L02
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
M09_L00:
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       jne       short M09_L03
M09_L01:
       xor       esi,esi
M09_L02:
       mov       rax,rsi
       pop       rbp
       ret
M09_L03:
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       jmp       short M09_L00
; Total bytes of code 91
```
```assembly
; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,128
       lea       rbp,[rsp+150]
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFF10
M10_L00:
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       add       rax,30
       jne       short M10_L00
       mov       [rbp-30],rsi
       mov       [rbp-128],r8
       mov       rbx,rdi
       mov       r15,rsi
       mov       r13,rdx
       mov       r12,rcx
       mov       r14,r9
       mov       rdi,[r15+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M10_L19
M10_L01:
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rax+8]
       test      rax,rax
       je        near ptr M10_L24
M10_L02:
       mov       [rbp-50],r13
       mov       [rbp-48],rax
       mov       [rbp-40],r12
       mov       r13,[rbp-128]
       mov       [rbp-38],r13
       mov       rdi,[r15+18]
       mov       rdx,[rdi+28]
       test      rdx,rdx
       je        near ptr M10_L20
M10_L03:
       mov       rax,[rbp-48]
       test      rax,rax
       je        near ptr M10_L31
       cmp       qword ptr [rbp-50],0
       jne       near ptr M10_L36
       mov       rdi,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       cmp       [rax+18],rdi
       jne       near ptr M10_L35
       mov       rdi,[rax+8]
       mov       r15,[rbp-40]
       mov       r13,[rbp-38]
       mov       rdi,[rdi]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M10_L21
M10_L04:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0B0],xmm0
       vmovdqu   xmmword ptr [rbp-0A8],xmm0
       mov       [rbp-98],r15
       mov       [rbp-90],r13
       mov       [rbp-0C0],r14
       mov       dword ptr [rbp-0B8],0FFFFFFFF
       mov       rdi,[rsi+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M10_L22
M10_L05:
       mov       rsi,[rdi+18]
       mov       r14,[rsi+10]
       test      r14,r14
       je        near ptr M10_L23
M10_L06:
       mov       rdi,7F223F6A0D68
       mov       rax,7F223FF67820
       call      rax
       cmp       dword ptr [rax],4
       jle       near ptr M10_L32
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        near ptr M10_L32
M10_L07:
       mov       r15,[rax+10]
       test      r15,r15
       jne       short M10_L08
       call      qword ptr [7F21C173C3F0]; System.Threading.Thread.InitializeCurrentThread()
       mov       r15,rax
M10_L08:
       mov       [rbp-138],r15
       mov       rsi,[r15+8]
       mov       [rbp-140],rsi
       mov       rsi,[r15+10]
       mov       [rbp-148],rsi
       mov       rdi,[r14+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M10_L10
M10_L09:
       lea       rdi,[rbp-0C0]
       call      rax
       jmp       short M10_L11
M10_L10:
       mov       rdi,r14
       mov       rsi,7F21C1FE8060
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M10_L09
M10_L11:
       mov       rsi,[rbp-148]
       cmp       rsi,[r15+10]
       je        short M10_L12
       lea       rdi,[r15+10]
       call      CORINFO_HELP_ASSIGN_REF
M10_L12:
       mov       rdi,[r15+8]
       mov       r14,rdi
       mov       rsi,[rbp-140]
       cmp       rsi,r14
       je        short M10_L14
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      r14,r14
       je        short M10_L13
       cmp       qword ptr [r14+10],0
       jne       near ptr M10_L18
M10_L13:
       cmp       qword ptr [rbp-140],0
       jne       near ptr M10_L17
M10_L14:
       mov       rdi,[rbp-0B0]
       mov       rax,7F19D98013E8
       cmp       rdi,[rax]
       jne       near ptr M10_L33
       vmovdqu   xmm0,xmmword ptr [rbp-0A8]
       vmovdqu   xmmword ptr [rbp-110],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-120]
       vmovdqu   ymmword ptr [rbp-0E0],ymm0
       xor       r15d,r15d
M10_L15:
       vmovdqu   ymm0,ymmword ptr [rbp-0E0]
       vmovdqu   ymmword ptr [rbp-78],ymm0
       xor       r14d,r14d
       mov       r13d,1
M10_L16:
       mov       [rbp-78],r15
       vmovdqu   ymm0,ymmword ptr [rbp-78]
       vmovdqu   ymmword ptr [rbx],ymm0
       mov       [rbx+8],r14w
       mov       [rbx+0A],r13b
       mov       rax,rbx
       vzeroupper
       add       rsp,128
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M10_L17:
       mov       rsi,[rbp-140]
       cmp       qword ptr [rsi+10],0
       je        near ptr M10_L14
M10_L18:
       mov       rdi,r14
       mov       rsi,[rbp-140]
       call      qword ptr [7F21C2096670]
       jmp       near ptr M10_L14
M10_L19:
       mov       rdi,r15
       mov       rsi,7F21C1FE6718
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M10_L01
M10_L20:
       mov       rdi,r15
       mov       rsi,7F21C1FE6830
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdx,rax
       jmp       near ptr M10_L03
M10_L21:
       mov       rsi,7F21C1FE7000
       call      qword ptr [7F21C105F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M10_L04
M10_L22:
       mov       rdi,rsi
       mov       rsi,7F21C1FE7C78
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M10_L05
M10_L23:
       mov       rsi,7F21C1FE7ED8
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r14,rax
       jmp       near ptr M10_L06
M10_L24:
       mov       rdi,[r15+18]
       mov       rax,[rdi+18]
       test      rax,rax
       je        short M10_L25
       mov       [rbp-58],rax
       jmp       short M10_L26
M10_L25:
       mov       rdi,r15
       mov       rsi,7F21C1FE6718
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-58],rax
M10_L26:
       mov       rdi,[r15+18]
       mov       rdi,[rdi+30]
       test      rdi,rdi
       je        short M10_L27
       jmp       short M10_L28
M10_L27:
       mov       rdi,r15
       mov       rsi,7F21C1FE6A10
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M10_L28:
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-130],rax
       mov       rdi,[rbp-58]
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rax]
       mov       rdi,[rbp-130]
       mov       rdx,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       call      qword ptr [7F21C1056E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,[r15+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        short M10_L29
       jmp       short M10_L30
M10_L29:
       mov       rdi,r15
       mov       rsi,7F21C1FE6718
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M10_L30:
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       lea       rdi,[rax+8]
       mov       rsi,[rbp-130]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-130]
       jmp       near ptr M10_L02
M10_L31:
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       mov       rsi,7F21ADC0B5D8
       call      qword ptr [7F21C1735608]
       mov       rdi,r15
       call      qword ptr [7F21C1AEE8E0]
       xor       r15d,r15d
       xor       r14d,r14d
       mov       r13d,1
       mov       [rbp-68],rax
       mov       [rbp-60],edx
       jmp       near ptr M10_L16
M10_L32:
       mov       edi,4
       call      qword ptr [7F21C2096460]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       near ptr M10_L07
M10_L33:
       mov       r15,[rbp-0B0]
       test      r15,r15
       jne       short M10_L34
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       call      qword ptr [7F21C2096688]
       mov       [rbp-0B0],r15
M10_L34:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0F0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-100]
       vmovdqu   ymmword ptr [rbp-0E0],ymm0
       jmp       near ptr M10_L15
M10_L35:
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-38]
       lea       rsi,[rbp-78]
       mov       r8,r14
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       jmp       short M10_L37
M10_L36:
       lea       rdi,[rbp-50]
       lea       rsi,[rbp-78]
       mov       rcx,[rbp-50]
       mov       r8,r14
       call      qword ptr [7F21C1FF6A30]
M10_L37:
       mov       r15,[rbp-78]
       movsx     r14,word ptr [rbp-70]
       movzx     r13d,byte ptr [rbp-6E]
       jmp       near ptr M10_L16
       push      rax
       mov       rsi,[rbp-148]
       mov       rax,[rbp-138]
       cmp       rsi,[rax+10]
       je        short M10_L38
       lea       rdi,[rax+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-138]
M10_L38:
       mov       rbx,[rax+8]
       mov       rsi,[rbp-140]
       cmp       rsi,rbx
       je        short M10_L41
       lea       rdi,[rax+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      rbx,rbx
       je        short M10_L39
       cmp       qword ptr [rbx+10],0
       jne       short M10_L40
M10_L39:
       cmp       qword ptr [rbp-140],0
       je        short M10_L41
       mov       rsi,[rbp-140]
       cmp       qword ptr [rsi+10],0
       je        short M10_L41
M10_L40:
       mov       rdi,rbx
       mov       rsi,[rbp-140]
       call      qword ptr [7F21C2096670]
M10_L41:
       nop
       vzeroupper
       add       rsp,8
       ret
; Total bytes of code 1394
```
```assembly
; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       push      rbp
       mov       rbp,rsp
       mov       rax,rsi
       test      rax,rax
       je        short M11_L00
       mov       rsi,rdx
       mov       rdx,rcx
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       nop
M11_L00:
       pop       rbp
       ret
       push      rax
       lea       rax,[M11_L00]
       add       rsp,8
       ret
; Total bytes of code 41
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-38],rax
       mov       [rbp-50],rax
       mov       [rbp-30],rdi
       mov       [rbp-68],rdi
       mov       [rbp-70],rsi
       cmp       [rdi],dil
       xor       eax,eax
       mov       [rsi+68],rax
       mov       [rsi+60],eax
       mov       [rsi+30],rax
       mov       rax,0FFFFFFFF00000000
       mov       [rsi+58],rax
       xor       eax,eax
       mov       [rsi+40],rax
       mov       [rsi+48],rax
       mov       [rsi+50],rax
       mov       rax,[rsi+28]
       test      rax,rax
       jne       near ptr M12_L11
M12_L00:
       mov       rax,7F19D9800B00
       mov       rsi,[rax]
       mov       rbx,[rbp-70]
       lea       rdi,[rbx+38]
       call      CORINFO_HELP_ASSIGN_REF
       mov       r15,[rbx+8]
       xor       edi,edi
       mov       [r15+20],rdi
       cmp       byte ptr [r15+34],0
       jne       near ptr M12_L12
M12_L01:
       mov       rdi,[r15+28]
       mov       rax,[r15+8]
       cmp       rdi,rax
       jne       short M12_L07
       cmp       dword ptr [rax+8],1
       jne       near ptr M12_L13
M12_L02:
       mov       rdi,[r15+8]
       xor       eax,eax
       mov       [rdi+0C],eax
       mov       [rdi+10],eax
       mov       rdi,[rbx+8]
       cmp       [rdi],edi
       call      qword ptr [7F21C1FF7378]; Kevlar.KevlarProperties.Clear()
       cmp       qword ptr [rbx+10],0
       jne       near ptr M12_L39
M12_L03:
       mov       r15,[rbx+18]
       test      r15,r15
       je        short M12_L06
       cmp       byte ptr [r15+34],0
       jne       near ptr M12_L40
M12_L04:
       mov       rdi,[r15+28]
       mov       rax,[r15+8]
       cmp       rdi,rax
       jne       short M12_L09
       cmp       dword ptr [rax+8],1
       jne       near ptr M12_L41
M12_L05:
       mov       rdi,[r15+8]
       xor       eax,eax
       mov       [rdi+0C],eax
       mov       [rdi+10],eax
       mov       rdi,[rbx+18]
       cmp       [rdi],edi
       call      qword ptr [7F21C1FF7378]; Kevlar.KevlarProperties.Clear()
M12_L06:
       mov       word ptr [rbx+64],0
       jmp       near ptr M12_L69
M12_L07:
       mov       rdi,[r15+28]
       call      qword ptr [7F21C1FF73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
M12_L08:
       mov       rsi,[r15+8]
       lea       rdi,[r15+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M12_L02
M12_L09:
       mov       rdi,[r15+28]
       call      qword ptr [7F21C1FF73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
M12_L10:
       mov       rsi,[r15+8]
       lea       rdi,[r15+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M12_L05
M12_L11:
       mov       rdi,rax
       call      qword ptr [7F21C202EA88]
       jmp       near ptr M12_L00
M12_L12:
       mov       rdi,[r15+28]
       cmp       [rdi],edi
       call      qword ptr [7F21C1FF7390]
       mov       byte ptr [r15+34],0
       jmp       near ptr M12_L01
M12_L13:
       mov       rdi,[r15+8]
       call      qword ptr [7F21C1FF73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F19D98013D0
       mov       r14,[rdi]
       cmp       dword ptr [r14+1C],0
       je        short M12_L14
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F21C20965E0]
M12_L14:
       mov       r13,[r14+10]
       xor       r12d,r12d
       test      r13,r13
       jne       near ptr M12_L21
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M12_L16
M12_L15:
       mov       rdi,7F21C006B1E0
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M12_L15
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M12_L16:
       dec       r12d
       imul      edi,r12d,9E3779B9
       cmp       dword ptr [r14+18],0
       jge       short M12_L17
       mov       r12d,edi
       mov       edx,[r14+20]
       imul      r12,rdx
       shr       r12,20
       jmp       short M12_L18
M12_L17:
       and       edi,[r14+18]
       mov       r12d,edi
M12_L18:
       mov       rdi,[r14+8]
       lea       edx,[r12*8]
       cmp       edx,[rdi+8]
       jae       near ptr M12_L66
       lea       edx,[r12*8]
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       [rbp-78],rax
       test      rax,rax
       je        short M12_L19
       mov       rdx,rax
       xor       esi,esi
       call      00007F223F474060
       mov       rdi,[rbp-78]
       cmp       rax,rdi
       je        short M12_L20
M12_L19:
       xor       edi,edi
M12_L20:
       mov       [rbp-38],rdi
       jmp       near ptr M12_L32
M12_L21:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L23
M12_L22:
       mov       rax,7F21C006B1E8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-44],eax
       test      eax,eax
       je        short M12_L22
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-44]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L23:
       dec       eax
       cmp       dword ptr [r13+18],0
       jl        short M12_L24
       and       eax,[r13+18]
       jmp       short M12_L25
M12_L24:
       mov       rdi,[r13+8]
       mov       edi,[rdi+8]
       mov       eax,eax
       imul      rax,[r13+10]
       shr       rax,20
       inc       rax
       imul      rax,rdi
       shr       rax,20
M12_L25:
       xor       ecx,ecx
       jmp       near ptr M12_L29
M12_L26:
       mov       rdi,[r13+8]
       cmp       eax,[rdi+8]
       jae       near ptr M12_L66
       mov       [rbp-3C],eax
       mov       edx,eax
       mov       r8,[rdi+rdx*8+10]
       mov       [rbp-80],r8
       mov       r9,[r8+10]
       mov       [rbp-88],r9
       test      r9,r9
       je        short M12_L27
       lea       rdi,[r8+10]
       test      rdi,rdi
       je        near ptr M12_L58
       mov       rdx,r9
       xor       esi,esi
       call      00007F223F474060
       mov       rcx,[rbp-88]
       cmp       rax,rcx
       mov       r8,[rbp-80]
       je        short M12_L30
M12_L27:
       lea       rdx,[rbp-38]
       mov       rsi,r8
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F21C1AEDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M12_L32
       mov       eax,[rbp-3C]
       inc       eax
       mov       edi,eax
       mov       rsi,[r13+8]
       cmp       [rsi+8],edi
       jne       short M12_L28
       xor       edi,edi
M12_L28:
       mov       ecx,[rbp-40]
       inc       ecx
       mov       eax,edi
M12_L29:
       mov       rdi,[r13+8]
       mov       [rbp-40],ecx
       cmp       [rdi+8],ecx
       jg        near ptr M12_L26
       jmp       short M12_L31
M12_L30:
       mov       r9,rcx
       mov       [rbp-38],r9
       jmp       short M12_L32
M12_L31:
       xor       edi,edi
       mov       [rbp-38],rdi
M12_L32:
       mov       rax,[rbp-38]
       cmp       qword ptr [rbp-38],0
       jne       short M12_L33
       test      r13,r13
       je        short M12_L34
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       dword ptr [r12+8],1
       jmp       short M12_L36
M12_L33:
       mov       r13,rax
       jmp       short M12_L35
M12_L34:
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7F21C20965F8]
       mov       r13,rax
M12_L35:
       mov       r12,r13
M12_L36:
       xor       edi,edi
       mov       [rbp-38],rdi
       cmp       dword ptr [r14+1C],0
       jne       short M12_L37
       mov       rsi,r12
       jmp       short M12_L38
M12_L37:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F21C0070558
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F21C20965E0]
       mov       rsi,rax
M12_L38:
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M12_L08
M12_L39:
       mov       rdi,[rbx+10]
       cmp       [rdi],edi
       call      qword ptr [7F21C1FF7360]; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       mov       rdi,[rbx+10]
       cmp       [rdi],edi
       call      qword ptr [7F21C1FF7378]; Kevlar.KevlarProperties.Clear()
       jmp       near ptr M12_L03
M12_L40:
       mov       rdi,[r15+28]
       cmp       [rdi],edi
       call      qword ptr [7F21C1FF7390]
       mov       byte ptr [r15+34],0
       jmp       near ptr M12_L04
M12_L41:
       mov       rdi,[r15+8]
       call      qword ptr [7F21C1FF73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F19D98013D0
       mov       r14,[rdi]
       cmp       dword ptr [r14+1C],0
       je        short M12_L42
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F21C20965E0]
M12_L42:
       mov       r13,[r14+10]
       xor       r12d,r12d
       test      r13,r13
       jne       near ptr M12_L49
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M12_L44
M12_L43:
       mov       rdi,7F21C006B1E0
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M12_L43
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M12_L44:
       dec       r12d
       imul      edi,r12d,9E3779B9
       cmp       dword ptr [r14+18],0
       jge       short M12_L45
       mov       r12d,edi
       mov       edx,[r14+20]
       imul      r12,rdx
       shr       r12,20
       jmp       short M12_L46
M12_L45:
       and       edi,[r14+18]
       mov       r12d,edi
M12_L46:
       mov       rdi,[r14+8]
       lea       edx,[r12*8]
       cmp       edx,[rdi+8]
       jae       near ptr M12_L66
       lea       edx,[r12*8]
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       [rbp-90],rax
       test      rax,rax
       je        short M12_L47
       mov       rdx,rax
       xor       esi,esi
       call      00007F223F474060
       mov       rdi,[rbp-90]
       cmp       rax,rdi
       je        short M12_L48
M12_L47:
       xor       edi,edi
M12_L48:
       mov       [rbp-50],rdi
       jmp       near ptr M12_L61
M12_L49:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L51
M12_L50:
       mov       rax,7F21C006B1E8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-5C],eax
       test      eax,eax
       je        short M12_L50
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-5C]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L51:
       dec       eax
       cmp       dword ptr [r13+18],0
       jl        short M12_L52
       and       eax,[r13+18]
       jmp       short M12_L53
M12_L52:
       mov       rdi,[r13+8]
       mov       edi,[rdi+8]
       mov       eax,eax
       imul      rax,[r13+10]
       shr       rax,20
       inc       rax
       imul      rax,rdi
       shr       rax,20
M12_L53:
       xor       ecx,ecx
       jmp       near ptr M12_L57
M12_L54:
       mov       rdi,[r13+8]
       cmp       eax,[rdi+8]
       jae       near ptr M12_L66
       mov       [rbp-54],eax
       mov       esi,eax
       mov       r8,[rdi+rsi*8+10]
       mov       [rbp-98],r8
       mov       r9,[r8+10]
       mov       [rbp-0A0],r9
       test      r9,r9
       je        short M12_L55
       lea       rdi,[r8+10]
       test      rdi,rdi
       je        short M12_L58
       xor       esi,esi
       mov       rdx,r9
       call      00007F223F474060
       mov       rcx,[rbp-0A0]
       cmp       rax,rcx
       mov       r8,[rbp-98]
       je        short M12_L59
M12_L55:
       lea       rdx,[rbp-50]
       mov       rsi,r8
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F21C1AEDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M12_L61
       mov       eax,[rbp-54]
       inc       eax
       mov       rcx,[r13+8]
       cmp       [rcx+8],eax
       jne       short M12_L56
       xor       eax,eax
M12_L56:
       mov       ecx,[rbp-58]
       inc       ecx
M12_L57:
       mov       rdi,[r13+8]
       mov       [rbp-58],ecx
       cmp       [rdi+8],ecx
       jg        near ptr M12_L54
       jmp       short M12_L60
M12_L58:
       call      qword ptr [7F21C2096340]
       int       3
M12_L59:
       mov       r9,rcx
       mov       [rbp-50],r9
       jmp       short M12_L61
M12_L60:
       xor       edi,edi
       mov       [rbp-50],rdi
M12_L61:
       mov       rax,[rbp-50]
       cmp       qword ptr [rbp-50],0
       jne       short M12_L62
       test      r13,r13
       je        short M12_L63
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       dword ptr [r12+8],1
       jmp       short M12_L65
M12_L62:
       mov       r13,rax
       jmp       short M12_L64
M12_L63:
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7F21C20965F8]
       mov       r13,rax
M12_L64:
       mov       r12,r13
M12_L65:
       xor       edi,edi
       mov       [rbp-50],rdi
       cmp       dword ptr [r14+1C],0
       jne       short M12_L67
       mov       rsi,r12
       jmp       short M12_L68
M12_L66:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M12_L67:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F21C0070560
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F21C20965E0]
       mov       rsi,rax
M12_L68:
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M12_L10
M12_L69:
       mov       eax,1
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
       push      rax
       mov       rdi,[rbp-68]
       mov       rsi,[rdi]
       mov       rax,[rsi+30]
       mov       rax,[rax]
       mov       rbx,[rax+40]
       test      rbx,rbx
       je        short M12_L70
       jmp       short M12_L71
M12_L70:
       mov       rdi,rsi
       mov       rsi,7F21C2079710
       call      qword ptr [7F21C105F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rbx,rax
M12_L71:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-68]
       mov       r11b,[rdi+30]
       mov       [rax+8],r11b
       mov       rdi,rax
       mov       r11,rbx
       mov       rsi,[rbp-70]
       call      qword ptr [rbx]
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 1950
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F21C0BFEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F21C0BFEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       movzx     edx,byte ptr [rbp-14]
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       xor       ecx,ecx
       call      qword ptr [7F21C1FF71B0]; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       movzx     esi,byte ptr [rbp-14]
       mov       rdi,[rbp-10]
       xor       edx,edx
       call      qword ptr [7F21C1FF71C8]; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 65
```
```assembly
; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,58
       lea       rbp,[rsp+80]
       xor       eax,eax
       mov       [rbp-38],rax
       mov       r13,rdi
       mov       r14d,esi
       mov       rbx,rdx
       mov       r15,rcx
       mov       rdi,7F19D98013C0
       mov       r12,[rdi]
       cmp       dword ptr [r12+1C],0
       jne       near ptr M15_L08
M15_L00:
       mov       rax,[r12+10]
       mov       [rbp-58],rax
       xor       ecx,ecx
       mov       [rbp-2C],ecx
       test      rax,rax
       je        near ptr M15_L09
       mov       rdi,7F223F6A0D68
       mov       rdx,7F223FF67820
       call      rdx
       add       rax,48
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M15_L18
M15_L01:
       dec       eax
       mov       rcx,[rbp-58]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M15_L19
       and       r8d,eax
M15_L02:
       mov       eax,r8d
       xor       r8d,r8d
       mov       [rbp-40],r8d
       mov       rdi,[rcx+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M15_L24
M15_L03:
       mov       rdi,[rcx+8]
       cmp       eax,[rdi+8]
       jae       near ptr M15_L28
       mov       [rbp-3C],eax
       mov       esi,eax
       mov       r9,[rdi+rsi*8+10]
       mov       [rbp-68],r9
       mov       r10,[r9+10]
       mov       [rbp-70],r10
       test      r10,r10
       je        near ptr M15_L20
       lea       rdi,[r9+10]
       test      rdi,rdi
       je        near ptr M15_L23
       xor       esi,esi
       mov       rdx,r10
       call      00007F223F474060
       mov       rcx,[rbp-70]
       cmp       rax,rcx
       mov       r9,[rbp-68]
       jne       near ptr M15_L20
       mov       r10,rcx
       mov       [rbp-38],r10
       mov       eax,[rbp-2C]
M15_L04:
       mov       rdx,[rbp-38]
       cmp       qword ptr [rbp-38],0
       je        near ptr M15_L25
M15_L05:
       mov       rax,rdx
M15_L06:
       xor       edi,edi
       mov       [rbp-38],rdi
       cmp       dword ptr [r12+1C],0
       jne       near ptr M15_L27
       mov       r12,rax
M15_L07:
       lea       rdi,[r12+68]
       mov       rsi,r13
       call      CORINFO_HELP_ASSIGN_REF
       mov       [r12+60],r14d
       lea       rdi,[r12+38]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r12+30]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,0FFFFFFFF00000000
       mov       [r12+58],rax
       xor       eax,eax
       mov       [r12+40],rax
       mov       rax,r12
       add       rsp,58
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M15_L08:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F21C1FF67C0]
       jmp       near ptr M15_L00
M15_L09:
       mov       rdi,7F223F6A0D68
       mov       rcx,7F223FF67820
       call      rcx
       add       rax,3C
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M15_L11
M15_L10:
       mov       rdi,7F21C006B1F8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M15_L10
       mov       [rax+10],edi
M15_L11:
       dec       edi
       imul      edi,9E3779B9
       mov       edx,[r12+18]
       test      edx,edx
       jge       short M15_L12
       mov       ecx,edi
       mov       esi,[r12+20]
       imul      rcx,rsi
       shr       rcx,20
       jmp       short M15_L13
M15_L12:
       mov       ecx,edi
       and       ecx,edx
M15_L13:
       mov       eax,ecx
       mov       rdi,[r12+8]
       mov       [rbp-2C],eax
       lea       edx,[rax*8]
       cmp       edx,[rdi+8]
       jae       near ptr M15_L28
       lea       rdi,[rdi+rdx*8+10]
       mov       rcx,[rdi]
       mov       [rbp-60],rcx
       test      rcx,rcx
       je        short M15_L15
       mov       rdx,rcx
       xor       esi,esi
       call      00007F223F474060
       mov       rdi,[rbp-60]
       cmp       rax,rdi
       mov       eax,[rbp-2C]
       je        short M15_L16
M15_L14:
       xor       esi,esi
       jmp       short M15_L17
M15_L15:
       mov       eax,[rbp-2C]
       jmp       short M15_L14
M15_L16:
       mov       rcx,rdi
       mov       rsi,rcx
M15_L17:
       mov       [rbp-38],rsi
       jmp       near ptr M15_L04
M15_L18:
       mov       rax,7F21C006B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-44],eax
       test      eax,eax
       je        short M15_L18
       mov       rdi,7F223F6A0D68
       mov       rcx,7F223FF67820
       call      rcx
       add       rax,48
       mov       ecx,[rbp-44]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M15_L01
M15_L19:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M15_L02
M15_L20:
       lea       rdx,[rbp-38]
       mov       rsi,r9
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F21C1AEDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M15_L22
       mov       eax,[rbp-3C]
       inc       eax
       mov       rcx,[rbp-58]
       mov       rdx,[rcx+8]
       cmp       [rdx+8],eax
       jne       short M15_L21
       xor       eax,eax
M15_L21:
       mov       r8d,[rbp-40]
       inc       r8d
       cmp       [rdx+8],r8d
       mov       [rbp-40],r8d
       mov       rcx,[rbp-58]
       jg        near ptr M15_L03
       jmp       short M15_L24
M15_L22:
       mov       eax,[rbp-2C]
       jmp       near ptr M15_L04
M15_L23:
       call      qword ptr [7F21C2096340]
       int       3
M15_L24:
       xor       edi,edi
       mov       [rbp-38],rdi
       mov       eax,[rbp-2C]
       jmp       near ptr M15_L04
M15_L25:
       cmp       qword ptr [rbp-58],0
       je        short M15_L26
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-78],rax
       mov       rdi,rax
       call      qword ptr [7F21C1FF6868]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-78]
       jmp       near ptr M15_L06
M15_L26:
       mov       rdi,r12
       mov       esi,eax
       call      qword ptr [7F21C1FF6820]
       mov       rdx,rax
       jmp       near ptr M15_L05
M15_L27:
       mov       [rbp-50],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r12+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-50]
       mov       r11,7F21C0070518
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F21C1FF67C0]
       mov       r12,rax
       jmp       near ptr M15_L07
M15_L28:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 952
```
```assembly
; Kevlar.KevlarContext.get_PropertiesForCompletion()
       cmp       byte ptr [rdi+64],0
       jne       short M16_L00
       mov       rax,[rdi+8]
       ret
M16_L00:
       mov       rax,[rdi+10]
       ret
; Total bytes of code 16
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+20]
       mov       rdi,[rbp-10]
       call      qword ptr [7F21C1AEDDA0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M17_L00
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M17_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M17_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rbp-20]
       mov       rdi,rax
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+18]
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7F21C1AEDDB8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       eax,1
       add       rsp,30
       pop       rbp
       ret
M17_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 171
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+18]
       mov       rdi,[rbp-10]
       call      qword ptr [7F21C1AEDDA0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M18_L00
       mov       rax,[rbp-20]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M18_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M18_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rax]
       mov       rdi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M18_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       xor       ecx,ecx
       mov       [rax],rcx
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+20]
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7F21C1AEDDB8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       rax,[rbp-20]
       cmp       qword ptr [rax],0
       setne     al
       movzx     eax,al
       add       rsp,30
       pop       rbp
       ret
M18_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 221
```
```assembly
; Kevlar.KevlarContext..ctor()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F21C1FF6880]; Kevlar.KevlarProperties..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,offset MT_System.Object
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-18],rax
       mov       rdi,[rbp-18]
       call      qword ptr [7F21C105C240]; System.Object..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+20]
       mov       rsi,[rbp-18]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-8]
       mov       dword ptr [rax+5C],0FFFFFFFF
       call      qword ptr [7F21C1AEE538]; System.TimeProvider.get_System()
       mov       rcx,[rbp-8]
       lea       rdi,[rcx+38]
       mov       rsi,rax
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-8]
       call      qword ptr [7F21C105C240]; System.Object..ctor()
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 166
```
```assembly
; System.Diagnostics.Metrics.Instrument.get_Enabled()
       mov       rax,[rdi+8]
       cmp       qword ptr [rax+8],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 16
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,130
       vzeroupper
       lea       rbp,[rsp+150]
       xor       eax,eax
       mov       [rbp-148],rax
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFEE0
M21_L00:
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       vmovdqa   xmmword ptr [rax+rbp],xmm8
       add       rax,30
       jne       short M21_L00
       mov       r15,rdi
       mov       rbx,rsi
       mov       r14d,edx
       mov       r13,[rbx+30]
       xor       edi,edi
       mov       [rbp-0B8],rdi
       test      r15,r15
       jne       short M21_L03
M21_L01:
       mov       rsi,[rbx+30]
       mov       rdi,7F19D9800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M21_L04
M21_L02:
       add       rsp,130
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M21_L03:
       mov       rdi,7F19D9800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F21C1AEE9B8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        short M21_L01
       lea       rdi,[rbp-0B0]
       mov       rsi,r13
       call      qword ptr [7F21C1FF71F8]
       mov       rdx,7F21ADC0B6A8
       mov       rdi,7F21ADC0B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-0B0]
       mov       rsi,7F21ADC0B638
       call      qword ptr [7F21C1FF7210]
       call      00007F21C1048AE0
       mov       rsi,rax
       mov       rdi,r15
       call      qword ptr [7F21C20968E0]
       mov       [rbp-0B8],rax
       lea       rdi,[rbp-0B8]
       call      qword ptr [7F21C1FF7240]
       mov       rdi,7F19D9800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-0B0]
       mov       rdx,rbx
       call      qword ptr [7F21C1FF7258]
       jmp       near ptr M21_L01
M21_L04:
       lea       rdi,[rbp-148]
       call      qword ptr [7F21C1FF71F8]
       mov       rdx,7F21ADC0B6A8
       mov       rdi,7F21ADC0B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-148]
       mov       rsi,7F21ADC0B638
       call      qword ptr [7F21C1FF7210]
       mov       rdi,7F19D9800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-148]
       mov       rcx,rbx
       mov       esi,1
       call      qword ptr [7F21C1FF7270]
       jmp       near ptr M21_L02
; Total bytes of code 410
```
```assembly
; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       push      rax
       lea       rbp,[rsp+30]
       mov       rbx,rdi
       mov       rdi,7F19D98013C0
       mov       r15,[rdi]
       test      rbx,rbx
       je        near ptr M22_L04
       cmp       dword ptr [r15+1C],0
       jne       near ptr M22_L05
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7F21C1FF72B8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       je        near ptr M22_L06
       mov       r14,[r15+10]
       test      r14,r14
       je        near ptr M22_L12
       mov       rdi,7F223F6A0D68
       mov       rax,7F223FF67820
       call      rax
       add       rax,48
       mov       r13d,[rax+10]
       test      r13d,r13d
       je        near ptr M22_L07
M22_L00:
       dec       r13d
       mov       r12d,[r14+18]
       test      r12d,r12d
       jl        near ptr M22_L08
       and       r12d,r13d
M22_L01:
       xor       r13d,r13d
       mov       rdi,[r14+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M22_L11
M22_L02:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M22_L20
       mov       esi,r12d
       mov       rax,[rdi+rsi*8+10]
       mov       [rbp-30],rax
       cmp       [rax],al
       lea       rdi,[rax+10]
       test      rdi,rdi
       je        near ptr M22_L17
       mov       rsi,rbx
       xor       edx,edx
       call      00007F223F474060
       test      rax,rax
       jne       near ptr M22_L09
M22_L03:
       cmp       dword ptr [r15+1C],0
       jne       near ptr M22_L19
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M22_L04:
       mov       edi,29
       mov       rsi,7F21C14D54F0
       call      qword ptr [7F21C105EF88]
       mov       rdi,rax
       call      qword ptr [7F21C2096490]
       int       3
M22_L05:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F21C0070540
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M22_L06:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F21C0070548
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M22_L07:
       mov       rdi,7F21C006B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M22_L07
       mov       rdi,7F223F6A0D68
       mov       rax,7F223FF67820
       call      rax
       add       rax,48
       mov       [rax+10],r13d
       jmp       near ptr M22_L00
M22_L08:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r13d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
       jmp       near ptr M22_L01
M22_L09:
       mov       rdx,rbx
       mov       rsi,[rbp-30]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F21C1AEDF38]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       near ptr M22_L03
       inc       r12d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r12d
       jne       short M22_L10
       xor       r12d,r12d
M22_L10:
       inc       r13d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r13d
       jg        near ptr M22_L02
M22_L11:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F21C0070550
       call      qword ptr [r11]
       jmp       near ptr M22_L03
M22_L12:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r14d,[rax+10]
       test      r14d,r14d
       jne       short M22_L14
M22_L13:
       mov       rdi,7F21C006B1F8
       mov       eax,1
       mov       r14d,eax
       lock xadd [rdi],r14d
       inc       r14d
       je        short M22_L13
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r14d
M22_L14:
       dec       r14d
       imul      r14d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M22_L15
       mov       r13d,r14d
       mov       r12d,[r15+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M22_L16
M22_L15:
       and       r14d,[r15+18]
       mov       r13d,r14d
M22_L16:
       mov       rdi,[r15+8]
       lea       esi,[r13*8]
       cmp       esi,[rdi+8]
       jae       short M22_L20
       lea       esi,[r13*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M22_L18
M22_L17:
       call      qword ptr [7F21C2096340]
       int       3
M22_L18:
       mov       rsi,rbx
       call      00007F223F474040
       test      rax,rax
       je        near ptr M22_L03
       mov       rdi,r15
       mov       rsi,rbx
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7F21C1FF74F8]
       jmp       near ptr M22_L03
M22_L19:
       mov       rdi,r15
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F21C1FF7528]
M22_L20:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 811
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-18]
       mov       rcx,rax
       test      cl,1
       jne       short M23_L00
       ret
M23_L00:
       jmp       qword ptr [7F21C1055C20]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 23
```
```assembly
; Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,0D0
       lea       rbp,[rsp+0F0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       xor       eax,eax
       mov       [rbp-30],rax
       mov       [rbp-28],rdi
       mov       [rbp-0D8],rdi
       mov       rbx,rsi
       mov       r14,rdx
       mov       r13,rcx
       mov       r15,r8
       mov       rsi,[rdi]
       mov       rax,[rsi+30]
       mov       rax,[rax]
       mov       rax,[rax+18]
       test      rax,rax
       je        near ptr M24_L14
M24_L00:
       mov       [rbp-48],r14
       mov       [rbp-40],r13
       mov       [rbp-70],r15
       mov       dword ptr [rbp-68],0FFFFFFFF
       mov       rsi,[rax+18]
       mov       rcx,[rsi+18]
       test      rcx,rcx
       je        near ptr M24_L15
M24_L01:
       mov       rsi,[rcx+18]
       mov       r15,[rsi+10]
       test      r15,r15
       je        near ptr M24_L16
M24_L02:
       mov       rdi,7F223F6A0D68
       mov       rax,7F223FF67820
       call      rax
       cmp       dword ptr [rax],4
       jle       near ptr M24_L17
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        near ptr M24_L17
M24_L03:
       mov       r14,[rax+10]
       test      r14,r14
       jne       short M24_L04
       call      qword ptr [7F21C173C3F0]; System.Threading.Thread.InitializeCurrentThread()
       mov       r14,rax
M24_L04:
       mov       [rbp-0E0],r14
       mov       rsi,[r14+8]
       mov       [rbp-0E8],rsi
       mov       rsi,[r14+10]
       mov       [rbp-0F0],rsi
       mov       rdi,[r15+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M24_L06
M24_L05:
       lea       rdi,[rbp-70]
       call      rax
       jmp       short M24_L07
M24_L06:
       mov       rdi,r15
       mov       rsi,7F21C1FE8060
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M24_L05
M24_L07:
       mov       rsi,[rbp-0F0]
       cmp       rsi,[r14+10]
       je        short M24_L08
       lea       rdi,[r14+10]
       call      CORINFO_HELP_ASSIGN_REF
M24_L08:
       mov       rdi,[r14+8]
       mov       r15,rdi
       mov       rsi,[rbp-0E8]
       cmp       rsi,r15
       je        short M24_L10
       lea       rdi,[r14+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      r15,r15
       je        short M24_L09
       cmp       qword ptr [r15+10],0
       jne       near ptr M24_L13
M24_L09:
       cmp       qword ptr [rbp-0E8],0
       jne       short M24_L12
M24_L10:
       mov       rdi,[rbp-60]
       mov       rax,7F19D98013E8
       cmp       rdi,[rax]
       jne       near ptr M24_L18
       vmovdqu   xmm0,xmmword ptr [rbp-58]
       vmovdqu   xmmword ptr [rbp-0C0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-0D0]
       vmovdqu   ymmword ptr [rbp-90],ymm0
       xor       r15d,r15d
M24_L11:
       mov       [rbp-90],r15
       vmovdqu   ymm0,ymmword ptr [rbp-90]
       vmovdqu   ymmword ptr [rbx],ymm0
       mov       word ptr [rbx+8],0
       mov       byte ptr [rbx+0A],1
       mov       rax,rbx
       vzeroupper
       add       rsp,0D0
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M24_L12:
       mov       rsi,[rbp-0E8]
       cmp       qword ptr [rsi+10],0
       je        short M24_L10
M24_L13:
       mov       rdi,r15
       mov       rsi,[rbp-0E8]
       call      qword ptr [7F21C2096670]
       jmp       near ptr M24_L10
M24_L14:
       mov       rdi,rsi
       mov       rsi,7F21C1FE7000
       call      qword ptr [7F21C105F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       jmp       near ptr M24_L00
M24_L15:
       mov       rdi,rax
       mov       rsi,7F21C1FE7C78
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rcx,rdi
       jmp       near ptr M24_L01
M24_L16:
       mov       rdi,rcx
       mov       rsi,7F21C1FE7ED8
       call      qword ptr [7F21C105F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r15,rax
       jmp       near ptr M24_L02
M24_L17:
       mov       edi,4
       call      qword ptr [7F21C2096460]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       near ptr M24_L03
M24_L18:
       mov       r15,[rbp-60]
       test      r15,r15
       jne       short M24_L19
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       call      qword ptr [7F21C2096688]
       mov       [rbp-60],r15
M24_L19:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0A0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-0B0]
       vmovdqu   ymmword ptr [rbp-90],ymm0
       jmp       near ptr M24_L11
       push      rax
       mov       rsi,[rbp-0F0]
       mov       rax,[rbp-0E0]
       cmp       rsi,[rax+10]
       je        short M24_L20
       lea       rdi,[rax+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-0E0]
M24_L20:
       mov       rbx,[rax+8]
       mov       rsi,[rbp-0E8]
       cmp       rsi,rbx
       je        short M24_L23
       lea       rdi,[rax+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      rbx,rbx
       je        short M24_L21
       cmp       qword ptr [rbx+10],0
       jne       short M24_L22
M24_L21:
       cmp       qword ptr [rbp-0E8],0
       je        short M24_L23
       mov       rsi,[rbp-0E8]
       cmp       qword ptr [rsi+10],0
       je        short M24_L23
M24_L22:
       mov       rdi,rbx
       mov       rsi,[rbp-0E8]
       call      qword ptr [7F21C2096670]
M24_L23:
       nop
       vzeroupper
       add       rsp,8
       ret
; Total bytes of code 814
```
```assembly
; System.Threading.Thread.InitializeCurrentThread()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,68
       lea       rbp,[rsp+90]
       xor       eax,eax
       mov       [rbp-30],rax
       lea       rdi,[rbp-30]
       mov       [rbp-90],rdi
       lea       rdi,[rbp-88]
       call      qword ptr [7F21C0BFEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-90]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7F21C0BFEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rbx,[rbp-30]
       call      qword ptr [7F21C0C00B98]
       lea       rdi,[rax+10]
       mov       rsi,[rbp-30]
       call      qword ptr [7F21C0BFEEB8]; CORINFO_HELP_ASSIGN_REF
       mov       rax,rbx
       add       rsp,68
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 123
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F21C0BFEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F21C0BFEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       ebx,edi
       call      qword ptr [7F21C0C16AF0]; Precode of System.Threading.Thread.GetThreadStaticsBase()
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M27_L01
       cmp       [rax],edi
       jle       short M27_L03
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M27_L03
M27_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M27_L01:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M27_L02
       movsxd    rcx,ecx
       add       rax,rcx
       jmp       short M27_L00
M27_L02:
       cmp       [rax+4],ecx
       jle       short M27_L03
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M27_L03
       mov       rax,[rdi]
       test      rax,rax
       je        short M27_L03
       jmp       short M27_L00
M27_L03:
       mov       edi,ebx
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
; Total bytes of code 133
```
```assembly
; Kevlar.KevlarProperties.Clear()
       push      rbp
       push      rbx
       sub       rsp,18
       lea       rbp,[rsp+20]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       rbx,rdi
       cmp       qword ptr [rbx+10],0
       jne       short M28_L01
M28_L00:
       add       rsp,18
       pop       rbx
       pop       rbp
       ret
M28_L01:
       xor       edi,edi
       mov       [rbx+30],edi
       mov       rdi,[rbx+18]
       test      rdi,rdi
       je        short M28_L02
       mov       eax,[rdi+38]
       sub       eax,[rdi+40]
       cmp       eax,20
       jl        short M28_L02
       xor       edi,edi
       mov       [rbx+38],rdi
       mov       [rbx+40],rdi
       mov       [rbx+10],rdi
       mov       [rbx+18],rdi
       jmp       short M28_L00
M28_L02:
       mov       rdi,[rbx+10]
       mov       rax,[rdi]
       mov       rax,[rax+40]
       call      qword ptr [rax+28]
       cmp       qword ptr [rbx+18],0
       je        short M28_L00
       mov       rdi,[rbx+18]
       cmp       [rdi],edi
       call      qword ptr [7F21C1FF7480]
       mov       rdi,rax
       lea       rsi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F21C1FF7498]
       jmp       short M28_L04
M28_L03:
       mov       rdi,[rbp-18]
       mov       rax,[rbp-18]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+28]
M28_L04:
       lea       rdi,[rbp-20]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+ValueCollection+Enumerator
       call      qword ptr [7F21C1FF74C8]
       test      eax,eax
       jne       short M28_L03
       jmp       near ptr M28_L00
; Total bytes of code 186
```
```assembly
; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F21C1FF7AC8]; Kevlar.KevlarProperties+AdditionalAttemptState.ReleaseReference()
       test      eax,eax
       je        short M29_L00
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      qword ptr [7F21C1055710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F19D98013D0
       mov       rax,[rax]
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F21C1FF7AE0]
M29_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 92
```
```assembly
; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       rbx,rdi
       cmp       byte ptr [rbx+34],0
       jne       short M30_L04
M30_L00:
       mov       rdi,[rbx+28]
       mov       rax,[rbx+8]
       cmp       rdi,rax
       jne       short M30_L02
       cmp       dword ptr [rax+8],1
       jne       short M30_L05
M30_L01:
       mov       rax,[rbx+8]
       xor       ecx,ecx
       mov       [rax+0C],ecx
       mov       [rax+10],ecx
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M30_L02:
       mov       rdi,[rbx+28]
       call      qword ptr [7F21C1FF73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
M30_L03:
       mov       rsi,[rbx+8]
       lea       rdi,[rbx+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M30_L01
M30_L04:
       mov       rdi,[rbx+28]
       cmp       [rdi],edi
       call      qword ptr [7F21C1FF7390]
       mov       byte ptr [rbx+34],0
       jmp       short M30_L00
M30_L05:
       mov       rdi,[rbx+8]
       call      qword ptr [7F21C1FF73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F19D98013D0
       mov       r15,[rdi]
       cmp       dword ptr [r15+1C],0
       je        short M30_L06
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F21C20965E0]
M30_L06:
       mov       r14,[r15+10]
       xor       r13d,r13d
       test      r14,r14
       jne       near ptr M30_L13
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M30_L08
M30_L07:
       mov       rdi,7F21C006B1E0
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M30_L07
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M30_L08:
       dec       r13d
       imul      edi,r13d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M30_L09
       mov       r13d,edi
       mov       edx,[r15+20]
       imul      r13,rdx
       shr       r13,20
       jmp       short M30_L10
M30_L09:
       and       edi,[r15+18]
       mov       r13d,edi
M30_L10:
       mov       rdi,[r15+8]
       lea       edx,[r13*8]
       cmp       edx,[rdi+8]
       jae       near ptr M30_L31
       lea       edx,[r13*8]
       lea       rdi,[rdi+rdx*8+10]
       mov       r12,[rdi]
       test      r12,r12
       je        short M30_L11
       mov       rdx,r12
       xor       esi,esi
       call      00007F223F474060
       cmp       rax,r12
       je        short M30_L12
M30_L11:
       xor       r12d,r12d
M30_L12:
       mov       [rbp-30],r12
       jmp       near ptr M30_L25
M30_L13:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M30_L15
M30_L14:
       mov       rdi,7F21C006B1E8
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M30_L14
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M30_L15:
       dec       r12d
       cmp       dword ptr [r14+18],0
       jl        short M30_L16
       and       r12d,[r14+18]
       jmp       short M30_L17
M30_L16:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
M30_L17:
       xor       eax,eax
       jmp       short M30_L21
M30_L18:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M30_L31
       mov       esi,r12d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-40],rcx
       mov       r8,[rcx+10]
       mov       [rbp-48],r8
       test      r8,r8
       je        short M30_L19
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        short M30_L22
       xor       esi,esi
       mov       rdx,r8
       call      00007F223F474060
       mov       rcx,[rbp-48]
       cmp       rax,rcx
       je        short M30_L23
       mov       rcx,[rbp-40]
M30_L19:
       lea       rdx,[rbp-30]
       mov       rsi,rcx
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F21C1AEDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M30_L25
       inc       r12d
       mov       rax,[r14+8]
       cmp       [rax+8],r12d
       jne       short M30_L20
       xor       r12d,r12d
M30_L20:
       mov       eax,[rbp-34]
       inc       eax
M30_L21:
       mov       rdi,[r14+8]
       mov       [rbp-34],eax
       cmp       [rdi+8],eax
       jg        near ptr M30_L18
       jmp       short M30_L24
M30_L22:
       call      qword ptr [7F21C2096340]
       int       3
M30_L23:
       mov       r8,rcx
       mov       [rbp-30],r8
       jmp       short M30_L25
M30_L24:
       xor       edi,edi
       mov       [rbp-30],rdi
M30_L25:
       mov       r12,[rbp-30]
       cmp       qword ptr [rbp-30],0
       jne       short M30_L27
       test      r14,r14
       je        short M30_L26
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       r14,rax
       mov       dword ptr [r14+8],1
       jmp       short M30_L28
M30_L26:
       mov       rdi,r15
       mov       esi,r13d
       call      qword ptr [7F21C20965F8]
       mov       r12,rax
M30_L27:
       mov       r14,r12
M30_L28:
       xor       edi,edi
       mov       [rbp-30],rdi
       cmp       dword ptr [r15+1C],0
       jne       short M30_L29
       mov       rsi,r14
       jmp       short M30_L30
M30_L29:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F21C0070500
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F21C20965E0]
       mov       rsi,rax
M30_L30:
       lea       rdi,[rbx+8]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M30_L03
M30_L31:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 802
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7F21C0C04740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7F21C0BFEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7F21C0C0F690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M31_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M31_L00
       mov       rsi,rax
       call      qword ptr [7F21C0BFEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M31_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,0A0
       vzeroupper
       lea       rbp,[rsp+0C0]
       xor       eax,eax
       mov       [rbp-0B8],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqa   xmmword ptr [rbp-30],xmm8
       mov       rbx,rdi
       mov       r15,rsi
       mov       r13d,edx
       mov       r14,rcx
       test      rbx,rbx
       jne       short M32_L01
M32_L00:
       add       rsp,0A0
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M32_L01:
       mov       rdi,7F19D9800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F21C1AEE9B8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        short M32_L00
       lea       rdi,[rbp-0B0]
       mov       rsi,r15
       call      qword ptr [7F21C1FF71F8]
       mov       rdx,7F21ADC0B6A8
       mov       rdi,7F21ADC0B680
       test      r13b,r13b
       cmove     rdx,rdi
       lea       rdi,[rbp-0B0]
       mov       rsi,7F21ADC0B638
       call      qword ptr [7F21C1FF7210]
       call      00007F21C1048AE0
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F21C20968E0]
       mov       [rbp-0B8],rax
       lea       rdi,[rbp-0B8]
       call      qword ptr [7F21C1FF7240]
       mov       rdi,7F19D9800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-0B0]
       mov       rdx,r14
       call      qword ptr [7F21C1FF7258]
       jmp       near ptr M32_L00
; Total bytes of code 264
```
```assembly
; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,90
       lea       rbp,[rsp+0A0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0A0],ymm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       mov       rax,rdi
       mov       r15d,esi
       mov       rbx,rdx
       mov       rdi,7F19D9800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       short M33_L01
M33_L00:
       add       rsp,90
       pop       rbx
       pop       r15
       pop       rbp
       ret
M33_L01:
       lea       rdi,[rbp-0A0]
       mov       rsi,rax
       call      qword ptr [7F21C1FF71F8]
       mov       rdx,7F21ADC0B6A8
       mov       rdi,7F21ADC0B680
       test      r15b,r15b
       cmove     rdx,rdi
       lea       rdi,[rbp-0A0]
       mov       rsi,7F21ADC0B638
       call      qword ptr [7F21C1FF7210]
       mov       rdi,7F19D9800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-0A0]
       mov       rcx,rbx
       mov       esi,1
       call      qword ptr [7F21C1FF7270]
       jmp       short M33_L00
; Total bytes of code 199
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-50],rcx
       mov       dword ptr [rbp-70],3E8
M34_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M34_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M34_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7F21C1AEDDD0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-50]
       mov       [rcx],eax
       mov       rax,[rbp-50]
       cmp       dword ptr [rax],0FFFFFFFF
       jne       short M34_L02
       mov       rdi,7F21C1EE66B0
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,70
       pop       rbp
       ret
M34_L02:
       mov       rax,[rbp-50]
       mov       eax,[rax]
       mov       rcx,[rbp-48]
       cmp       eax,[rcx+8]
       jae       short M34_L04
       mov       edx,eax
       imul      rdx,10
       lea       rcx,[rcx+rdx+10]
       mov       eax,[rcx+8]
       mov       [rbp-5C],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-5C]
       call      qword ptr [7F21C1AEDDE8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-68],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-68]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M34_L03
       mov       rdi,7F21C1EE66B4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,70
       pop       rbp
       ret
M34_L03:
       mov       rdi,7F21C1EE66B8
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M34_L00
M34_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 269
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-4C],ecx
       mov       dword ptr [rbp-70],3E8
M35_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M35_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M35_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rax,[rbp-48]
       mov       ecx,[rbp-4C]
       cmp       ecx,[rax+8]
       jae       near ptr M35_L03
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       add       rax,8
       mov       [rbp-68],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7F21C1AEDDD0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-68]
       mov       [rcx],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-4C]
       call      qword ptr [7F21C1AEDDE8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-60],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-60]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M35_L02
       mov       rdi,7F21C1EE6BA8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,70
       pop       rbp
       ret
M35_L02:
       mov       rdi,7F21C1EE6BAC
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M35_L00
M35_L03:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 235
```
```assembly
; Kevlar.KevlarProperties..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F21C1FF6898]; Kevlar.KevlarProperties+AdditionalAttemptState..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-8]
       call      qword ptr [7F21C105C240]; System.Object..ctor()
       mov       rax,[rbp-8]
       mov       rsi,[rax+8]
       mov       rax,[rbp-8]
       lea       rdi,[rax+28]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 104
```
```assembly
; System.Object..ctor()
       ret
; Total bytes of code 1
```
```assembly
; System.TimeProvider.get_System()
       mov       rax,7F19D9800B00
       mov       rax,[rax]
       ret
; Total bytes of code 14
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbx
       sub       rsp,10
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rbx,rdi
       mov       rdi,rbx
       call      qword ptr [7F21C0C19718]; Precode of System.Runtime.CompilerServices.InitHelpers.InitClassSlow(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rbx+20]
       mov       rax,[rax-18]
       mov       [rsp+8],rax
       mov       rax,[rsp+8]
       and       rax,0FFFFFFFFFFFFFFFE
       xor       ecx,ecx
       mov       [rsp+8],rcx
       add       rsp,10
       pop       rbx
       ret
; Total bytes of code 59
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState.ReleaseReference()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       call      qword ptr [7F21C1FF7AF8]; System.Threading.Interlocked.Decrement(Int32 ByRef)
       test      eax,eax
       sete      al
       movzx     eax,al
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 48
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       eax,[rbp-10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 27
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-1C],edx
       mov       rax,[rbp-18]
       sar       rax,20
       lea       esi,[rax+1]
       mov       rdi,[rbp-10]
       mov       edx,[rbp-1C]
       call      qword ptr [7F21C144E0D0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 56
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       dword ptr [rax+8],1
       mov       rdi,[rbp-8]
       call      qword ptr [7F21C105C240]; System.Object..ctor()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; System.Threading.Interlocked.Decrement(Int32 ByRef)
       mov       eax,0FFFFFFFF
       lock xadd [rdi],eax
       dec       eax
       ret
; Total bytes of code 12
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-10],edx
       movsxd    rax,dword ptr [rbp-0C]
       shl       rax,20
       mov       ecx,[rbp-10]
       or        rax,rcx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 40
```

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: A-baseline(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.4.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.4.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=10, LaunchCount=3, WarmupCount=5))

```assembly
; PoolContextProbe.NestedContext()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,48
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-48],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-40],xmm8
       mov       [rbp-30],rax
       mov       rdi,7F6DE1800AC0
       mov       rbx,[rdi]
       mov       rdi,7F6DE1800400
       mov       r15,[rdi]
       test      rbx,rbx
       je        near ptr M00_L04
M00_L00:
       mov       rdi,7F6DE1800AF0
       mov       r14,[rdi]
       test      r14,r14
       je        near ptr M00_L05
M00_L01:
       mov       rdi,7F6DE1800AF8
       mov       r13,[rdi]
       test      r13,r13
       je        near ptr M00_L06
M00_L02:
       mov       rax,[r15+38]
       test      rax,rax
       jne       near ptr M00_L07
       cmp       byte ptr [r15+48],0
       jne       near ptr M00_L08
       mov       r12,[r15+10]
       xor       edi,edi
       test      rdi,rdi
       cmove     rdi,r15
       mov       rdi,[rdi+20]
       mov       rax,7F6DE1800B00
       test      rdi,rdi
       cmove     rdi,[rax]
       mov       [rbp-50],rdi
       mov       rax,[r15+38]
       test      rax,rax
       jne       near ptr M00_L09
       mov       rdi,[rbp-50]
       mov       rcx,[r15+40]
M00_L03:
       mov       [rsp],r13
       xor       esi,esi
       mov       [rsp+8],rsi
       mov       [rsp+10],rsi
       mov       rsi,r12
       mov       rdx,rdi
       mov       r8,rbx
       mov       r9,r14
       mov       rdi,7F75C9CBCB40
       call      qword ptr [7F75C98BE598]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       mov       [rbp-48],rax
       mov       [rbp-40],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-48]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       mov       rax,[rbp-38]
       mov       rdx,[rbp-30]
       add       rsp,48
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M00_L04:
       mov       rdi,offset MT_System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rsi,7F6DE1800AA8
       mov       rsi,[rsi]
       mov       rdi,rbx
       mov       rdx,offset PoolContextProbe+<>c.<NestedContext>b__6_0(Kevlar.KevlarContext)
       call      qword ptr [7F75C8E26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F6DE1800AC0
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L00
M00_L05:
       mov       rdi,offset MT_System.Action<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarProperties>
       call      CORINFO_HELP_NEWSFAST
       mov       r14,rax
       mov       rsi,7F6DE1800AE8
       mov       rsi,[rsi]
       mov       rdi,r14
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       call      qword ptr [7F75C8E26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F6DE1800AF0
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L01
M00_L06:
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r13,rax
       mov       rsi,7F6DE1800AE8
       mov       rsi,[rsi]
       mov       rdi,r13
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F75C8E26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F6DE1800AF8
       mov       rsi,r13
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L02
M00_L07:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       r8,r13
       mov       rdx,rbx
       mov       rcx,r14
       mov       rsi,7F75C9CBB1D0
       xor       r9d,r9d
       cmp       [rdi],edi
       add       rsp,48
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F75C98BE340]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
M00_L08:
       call      qword ptr [7F75C98BE508]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M00_L09:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F75C98BE4F0]; Kevlar.Shield.get_Name()
       mov       rcx,rax
       mov       rdi,[rbp-50]
       jmp       near ptr M00_L03
; Total bytes of code 604
```
```assembly
; BenchmarkDotNet.Helpers.AwaitHelper.GetResult[[System.Int32, System.Private.CoreLib]](System.Threading.Tasks.ValueTask`1<Int32>)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp-48],rax
       mov       [rbp-40],rax
       mov       [rbp-38],rdi
       mov       [rbp-30],rsi
       mov       rbx,rdi
       mov       r15d,esi
       movsx     r14,word ptr [rbp-2C]
       test      rbx,rbx
       je        near ptr M01_L11
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<System.Int32>
       call      qword ptr [7F75C8E26838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r13,rax
       mov       rax,r13
       test      rax,rax
       jne       near ptr M01_L05
       mov       rdi,offset MT_Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource
       cmp       [rbx],rdi
       je        short M01_L02
       mov       rdi,rbx
       mov       esi,r14d
       mov       r11,7F75C7E40620
       call      qword ptr [r11]
M01_L00:
       test      eax,eax
       je        near ptr M01_L15
M01_L01:
       test      r13,r13
       jne       near ptr M01_L09
       mov       rdi,offset MT_Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource
       cmp       [rbx],rdi
       je        short M01_L06
       mov       rdi,rbx
       mov       esi,r14d
       mov       r11,7F75C7E40628
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M01_L02:
       lea       rsi,[rbx+40]
       movsx     rdi,word ptr [rsi+28]
       cmp       r14d,edi
       jne       near ptr M01_L12
       cmp       qword ptr [rsi],0
       jne       near ptr M01_L13
M01_L03:
       xor       r12d,r12d
M01_L04:
       mov       eax,r12d
       jmp       short M01_L00
M01_L05:
       test      dword ptr [rax+34],1600000
       jne       short M01_L01
       jmp       near ptr M01_L15
M01_L06:
       mov       [rbp-50],rbx
       lea       rdi,[rbx+40]
       movsx     rsi,word ptr [rdi+28]
       cmp       r14d,esi
       jne       short M01_L07
       cmp       byte ptr [rdi+2A],0
       je        short M01_L07
       cmp       qword ptr [rdi+18],0
       jne       short M01_L07
       mov       r15,[rdi+20]
       jmp       short M01_L08
M01_L07:
       call      qword ptr [7F75C9E66430]
       int       3
M01_L08:
       lea       r13,[rbx+40]
       inc       esi
       mov       [r13+28],si
       xor       edi,edi
       mov       [r13],rdi
       mov       [r13+8],rdi
       mov       [r13+10],rdi
       mov       [r13+18],rdi
       mov       [r13+20],rdi
       mov       byte ptr [r13+2A],0
       mov       rdi,[rbx+8]
       lea       rdi,[rdi+20]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M01_L11
M01_L09:
       mov       edi,[r13+34]
       and       edi,11000000
       cmp       edi,1000000
       jne       near ptr M01_L16
M01_L10:
       mov       r15d,[r13+38]
M01_L11:
       mov       eax,r15d
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M01_L12:
       call      qword ptr [7F75C9E663B8]
       int       3
M01_L13:
       cmp       byte ptr [rsi+2A],0
       je        near ptr M01_L03
       cmp       qword ptr [rsi+18],0
       je        short M01_L14
       mov       rsi,[rsi+18]
       mov       rsi,[rsi+8]
       mov       rdi,offset MT_System.OperationCanceledException
       call      qword ptr [7F75C8E26838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r12d,3
       mov       ecx,2
       test      rax,rax
       cmove     r12d,ecx
       jmp       near ptr M01_L04
M01_L14:
       mov       r12d,1
       jmp       near ptr M01_L04
M01_L15:
       mov       [rbp-48],rbx
       mov       [rbp-40],r15d
       mov       [rbp-3C],r14w
       call      qword ptr [7F75C9DCFA50]
       mov       rdi,rax
       mov       rsi,[rbp-48]
       mov       rdx,[rbp-40]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DCFA20]
       jmp       near ptr M01_L01
M01_L16:
       mov       rdi,r13
       xor       esi,esi
       call      qword ptr [7F75C9E66418]
       jmp       near ptr M01_L10
       push      rax
       mov       rsi,[rbp-50]
       lea       r13,[rsi+40]
       inc       word ptr [r13+28]
       xor       edi,edi
       mov       [r13],rdi
       mov       [r13+8],rdi
       mov       [r13+10],rdi
       mov       [r13+18],rdi
       mov       [r13+20],rdi
       mov       byte ptr [r13+2A],0
       mov       rdi,[rsi+8]
       lea       rdi,[rdi+20]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,8
       ret
; Total bytes of code 585
```
```assembly
; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,298
       vzeroupper
       lea       rbp,[rsp+2C0]
       xor       eax,eax
       mov       [rbp-228],rax
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFE20
M02_L00:
       vmovdqa   xmmword ptr [rbp+rax-40],xmm8
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       add       rax,30
       jne       short M02_L00
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-240],r8
       mov       r13,rsi
       mov       r14,rdx
       mov       rbx,rcx
       mov       r15,r9
       mov       r12,[rbp+20]
       mov       rax,7F6DE1800BA0
       mov       rax,[rax]
       mov       rax,[rax+8]
       cmp       qword ptr [rax+8],0
       jne       near ptr M02_L33
       xor       edi,edi
M02_L01:
       mov       [rbp-40],rdi
       test      r12,r12
       jne       near ptr M02_L34
M02_L02:
       mov       rdi,7F6DE18013C0
       mov       rax,[rdi]
       mov       [rbp-2A0],rax
       mov       rcx,rax
       mov       [rbp-260],rcx
       cmp       dword ptr [rcx+1C],0
       jne       near ptr M02_L55
M02_L03:
       mov       rcx,[rbp-260]
       mov       rdx,[rcx+10]
       mov       [rbp-270],rdx
       xor       esi,esi
       mov       [rbp-98],esi
       test      rdx,rdx
       je        near ptr M02_L56
       mov       rdi,7F76474A0D68
       mov       r8,7F7647CEF820
       call      r8
       add       rax,48
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M02_L65
M02_L04:
       dec       eax
       mov       rcx,[rbp-270]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M02_L66
       and       r8d,eax
M02_L05:
       mov       eax,r8d
       xor       r8d,r8d
M02_L06:
       mov       rdi,[rcx+8]
       mov       [rbp-0A0],r8d
       cmp       [rdi+8],r8d
       jle       near ptr M02_L70
       cmp       eax,[rdi+8]
       jae       near ptr M02_L102
       mov       [rbp-9C],eax
       mov       edx,eax
       mov       r9,[rdi+rdx*8+10]
       mov       [rbp-280],r9
       mov       r10,[r9+10]
       mov       [rbp-288],r10
       test      r10,r10
       jne       near ptr M02_L14
M02_L07:
       lea       rdi,[r9+18]
       mov       rdx,[r9+8]
       mov       rsi,[rdi]
       mov       r10d,esi
       cmp       r10d,0FFFFFFFF
       je        near ptr M02_L68
       mov       r11d,[rdx+8]
       mov       [rbp-22C],r11d
M02_L08:
       cmp       r10d,r11d
       jae       near ptr M02_L102
       mov       r8d,r10d
       shl       r8,4
       mov       r11d,[rdx+r8+18]
       mov       rax,rsi
       sar       rax,20
       inc       eax
       cdqe
       shl       rax,20
       or        r11,rax
       mov       rax,rsi
       lock cmpxchg [rdi],r11
       cmp       rax,rsi
       jne       near ptr M02_L67
       mov       rax,[r9+8]
       mov       rdi,rax
       mov       edx,[rdi+8]
       cmp       r10d,edx
       jae       near ptr M02_L102
       mov       rsi,[rdi+r8+10]
       cmp       r10d,edx
       jae       near ptr M02_L102
       lea       rdi,[rax+r8+10]
       xor       eax,eax
       mov       [rdi],rax
       add       r9,20
M02_L09:
       mov       rax,[r9]
       mov       [rbp-0B0],rax
       mov       [rdi+8],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       r8d,r10d
       or        rdx,r8
       lock cmpxchg [r9],rdx
       cmp       rax,[rbp-0B0]
       jne       short M02_L09
       test      rsi,rsi
       je        near ptr M02_L68
       mov       rax,[rbp-260]
M02_L10:
       mov       rdx,rsi
       test      rdx,rdx
       je        near ptr M02_L71
M02_L11:
       mov       rcx,rdx
M02_L12:
       cmp       dword ptr [rax+1C],0
       jne       near ptr M02_L73
       mov       rdx,rcx
M02_L13:
       mov       [rbp-258],rdx
       lea       rdi,[rdx+68]
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       xor       edi,edi
       mov       r12,[rbp-258]
       mov       [r12+60],edi
       lea       rdi,[r12+38]
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r12+30]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       mov       rsi,0FFFFFFFF00000000
       mov       [r12+58],rsi
       xor       esi,esi
       mov       [r12+40],rsi
       mov       [rbp-248],r12
       jmp       short M02_L16
M02_L14:
       lea       rdi,[r9+10]
       test      rdi,rdi
       je        near ptr M02_L95
       mov       rdx,r10
       xor       esi,esi
       call      00007F7647274060
       mov       rdi,[rbp-288]
       cmp       rax,rdi
       mov       r9,[rbp-280]
       jne       near ptr M02_L07
       mov       r10,rdi
       mov       rsi,r10
       mov       rax,[rbp-260]
       jmp       near ptr M02_L10
M02_L15:
       mov       rdi,7F75C7E3B1F8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M02_L15
       jmp       near ptr M02_L57
M02_L16:
       mov       rdx,[r12+8]
       mov       rsi,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       cmp       [r15+18],rsi
       je        short M02_L17
       mov       rsi,[rbp-240]
       mov       rdi,[r15+8]
       call      qword ptr [r15+18]
       nop
M02_L17:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M02_L31
M02_L18:
       lea       rdi,[rbp-60]
       mov       rdx,r13
       mov       rcx,[rbp-240]
       mov       r8,[rbp+10]
       mov       r9,r12
       call      qword ptr [7F75C98BE670]; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       rbx,[rbp-60]
       test      rbx,rbx
       jne       near ptr M02_L74
       mov       r14,[rbp-50]
       mov       r15d,[rbp-48]
M02_L19:
       test      r14,r14
       sete      bl
       movzx     ebx,bl
       mov       r13,[r12+30]
       cmp       qword ptr [rbp-40],0
       jne       near ptr M02_L79
M02_L20:
       mov       rsi,[r12+30]
       mov       rdi,7F6DE1800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M02_L80
M02_L21:
       cmp       byte ptr [r12+64],0
       jne       near ptr M02_L81
       mov       rbx,[r12+8]
M02_L22:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rax,[rsi+28]
       test      rax,rax
       je        near ptr M02_L32
       mov       rdi,rax
M02_L23:
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-240]
       mov       rcx,rbx
       call      qword ptr [7F75C98BE760]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rbx,[rbp-2A0]
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M02_L82
       mov       rdi,rbx
       mov       rsi,r12
       call      qword ptr [7F75C9DC72B8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       je        near ptr M02_L83
       mov       r12,[rbx+10]
       test      r12,r12
       je        near ptr M02_L90
       mov       rdi,7F76474A0D68
       mov       rax,7F7647CEF820
       call      rax
       add       rax,48
       mov       r13d,[rax+10]
       test      r13d,r13d
       je        near ptr M02_L84
M02_L24:
       dec       r13d
       mov       eax,[r12+18]
       test      eax,eax
       jl        near ptr M02_L85
       and       r13d,eax
M02_L25:
       xor       eax,eax
       mov       [rbp-1DC],eax
       mov       rdi,[r12+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M02_L89
M02_L26:
       mov       rdi,[r12+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M02_L102
       mov       esi,r13d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-298],rcx
       cmp       [rcx],cl
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M02_L95
       mov       rsi,[rbp-248]
       xor       edx,edx
       call      00007F7647274060
       test      rax,rax
       je        near ptr M02_L29
       mov       rcx,[rbp-298]
       lea       rdi,[rcx+20]
       mov       rsi,[rcx+8]
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       je        near ptr M02_L87
       mov       r8d,[rsi+8]
M02_L27:
       cmp       edx,[rsi+8]
       jae       near ptr M02_L102
       mov       r8d,edx
       shl       r8,4
       mov       [rbp-238],r8
       mov       r9d,[rsi+r8+18]
       mov       r10,rax
       sar       r10,20
       inc       r10d
       movsxd    r10,r10d
       shl       r10,20
       or        r9,r10
       mov       [rbp-1E8],rax
       lock cmpxchg [rdi],r9
       cmp       rax,[rbp-1E8]
       jne       near ptr M02_L86
       mov       rdi,[rcx+8]
       mov       [rbp-1E0],edx
       cmp       edx,[rdi+8]
       jae       near ptr M02_L102
       lea       rdi,[rdi+r8+10]
       mov       rsi,[rbp-248]
       call      CORINFO_HELP_ASSIGN_REF
       mov       r13,[rbp-298]
       lea       rdi,[r13+18]
       mov       rcx,[r13+8]
       mov       r13d,[rbp-1E0]
M02_L28:
       mov       rax,[rdi]
       mov       [rbp-1F0],rax
       cmp       r13d,[rcx+8]
       jae       near ptr M02_L102
       mov       r12,[rbp-238]
       mov       [rcx+r12+18],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       esi,r13d
       or        rdx,rsi
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-1F0]
       jne       short M02_L28
M02_L29:
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M02_L97
M02_L30:
       test      r14,r14
       jne       near ptr M02_L98
       xor       eax,eax
       mov       edx,r15d
       mov       rdi,1000000000000
       or        rdx,rdi
       add       rsp,298
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L31:
       mov       rsi,7F75C9CC36D8
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M02_L18
M02_L32:
       mov       rsi,7F75C9CC3AB0
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M02_L23
M02_L33:
       call      00007F75C8E18AE0
       mov       rdi,rax
       jmp       near ptr M02_L01
M02_L34:
       cmp       dword ptr [r12+20],0
       je        near ptr M02_L02
       mov       rsi,rbx
       xor       edx,edx
       call      qword ptr [7F75C98BE868]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       cmp       qword ptr [rbp+18],0
       je        near ptr M02_L54
       mov       rdi,r12
       mov       rcx,rbx
       mov       rdx,r14
       xor       esi,esi
       call      qword ptr [7F75C98BE880]; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       mov       rbx,rax
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       r15,[rsi+28]
       test      r15,r15
       je        short M02_L35
       jmp       short M02_L36
M02_L35:
       mov       rsi,7F75C9CC3AB0
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r15,rax
M02_L36:
       mov       rdi,rbx
       cmp       [rdi],edi
       call      qword ptr [7F75C98BE898]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       rcx,rax
       mov       rdi,r15
       mov       rdx,[rbp-240]
       mov       rsi,[rbp+18]
       call      qword ptr [7F75C98BE760]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,7F6DE18013C0
       mov       rdi,[rdi]
       mov       r15,rdi
       cmp       dword ptr [r15+1C],0
       je        short M02_L37
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F75C7E40640
       call      qword ptr [r11]
       jmp       near ptr M02_L54
M02_L37:
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7F75C9DC72B8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       jne       short M02_L38
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F75C7E40648
       call      qword ptr [r11]
       jmp       near ptr M02_L54
M02_L38:
       mov       r14,[r15+10]
       test      r14,r14
       je        near ptr M02_L48
       mov       edi,48
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M02_L40
M02_L39:
       mov       rdi,7F75C7E3B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M02_L39
       mov       edi,48
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M02_L40:
       dec       r13d
       cmp       dword ptr [r14+18],0
       jl        short M02_L41
       and       r13d,[r14+18]
       jmp       short M02_L42
M02_L41:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r14+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
M02_L42:
       xor       eax,eax
       jmp       short M02_L45
M02_L43:
       mov       rdi,[r14+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M02_L102
       mov       esi,r13d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-250],rcx
       cmp       [rcx],cl
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M02_L95
       mov       rsi,rbx
       xor       edx,edx
       call      00007F7647274060
       test      rax,rax
       je        short M02_L46
       mov       rdx,rbx
       mov       rsi,[rbp-250]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F75C98BDF38]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M02_L46
       inc       r13d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r13d
       jne       short M02_L44
       xor       r13d,r13d
M02_L44:
       mov       eax,[rbp-94]
       inc       eax
M02_L45:
       mov       rdi,[r14+8]
       mov       [rbp-94],eax
       cmp       [rdi+8],eax
       jg        short M02_L43
       jmp       short M02_L47
M02_L46:
       cmp       dword ptr [r15+1C],0
       je        near ptr M02_L54
       jmp       near ptr M02_L53
M02_L47:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F75C7E40650
       call      qword ptr [r11]
       jmp       short M02_L46
M02_L48:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L50
M02_L49:
       mov       rdi,7F75C7E3B1F8
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M02_L49
       mov       [rax+10],edi
M02_L50:
       dec       edi
       imul      r14d,edi,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M02_L51
       mov       r13d,r14d
       mov       r14d,[r15+20]
       imul      r14,r13
       shr       r14,20
       jmp       short M02_L52
M02_L51:
       and       r14d,[r15+18]
M02_L52:
       mov       rdi,[r15+8]
       lea       esi,[r14*8]
       cmp       esi,[rdi+8]
       jae       near ptr M02_L102
       lea       esi,[r14*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       je        near ptr M02_L95
       mov       rsi,rbx
       call      00007F7647274040
       test      rax,rax
       je        near ptr M02_L46
       mov       rdi,r15
       mov       rsi,rbx
       mov       rdx,rax
       mov       ecx,r14d
       call      qword ptr [7F75C9DC74F8]
       jmp       near ptr M02_L46
M02_L53:
       mov       rdi,r15
       call      qword ptr [7F75C9DC7528]
M02_L54:
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rdi,rbx
       call      qword ptr [7F75C9E67120]
       lea       rdi,[rbx+70]
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,rbx
       call      qword ptr [7F75C98BE8E0]
       mov       rdi,rax
       mov       esi,edx
       call      qword ptr [7F75C98BE7F0]
       mov       [rbp-218],rax
       mov       [rbp-210],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-218]
       vmovdqu   xmmword ptr [rbp-90],xmm0
       mov       rax,[rbp-90]
       mov       rdx,[rbp-88]
       add       rsp,298
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L55:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F75C9DC67C0]
       jmp       near ptr M02_L03
M02_L56:
       mov       rdi,7F76474A0D68
       mov       rsi,7F7647CEF820
       call      rsi
       add       rax,3C
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L58
       jmp       near ptr M02_L15
M02_L57:
       mov       [rax+10],edi
M02_L58:
       dec       edi
       imul      edi,9E3779B9
       mov       rax,[rbp-260]
       mov       edx,[rax+18]
       test      edx,edx
       jge       short M02_L59
       mov       esi,edi
       mov       ecx,[rax+20]
       imul      rsi,rcx
       shr       rsi,20
       jmp       short M02_L60
M02_L59:
       mov       esi,edi
       and       esi,edx
M02_L60:
       mov       ecx,esi
       mov       rdi,[rax+8]
       mov       [rbp-98],ecx
       lea       edx,[rcx*8]
       cmp       edx,[rdi+8]
       jae       near ptr M02_L102
       lea       rdi,[rdi+rdx*8+10]
       mov       r8,[rdi]
       mov       rsi,r8
       mov       [rbp-278],rsi
       test      rsi,rsi
       je        short M02_L62
       mov       rdx,rsi
       xor       esi,esi
       call      00007F7647274060
       mov       rdi,[rbp-278]
       cmp       rax,rdi
       mov       rax,[rbp-260]
       je        short M02_L63
M02_L61:
       xor       esi,esi
       jmp       short M02_L64
M02_L62:
       mov       rax,[rbp-260]
       jmp       short M02_L61
M02_L63:
       mov       rsi,rdi
M02_L64:
       jmp       near ptr M02_L10
M02_L65:
       mov       rax,7F75C7E3B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-0A4],eax
       test      eax,eax
       je        short M02_L65
       mov       rdi,7F76474A0D68
       mov       rcx,7F7647CEF820
       call      rcx
       add       rax,48
       mov       ecx,[rbp-0A4]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M02_L04
M02_L66:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M02_L05
M02_L67:
       mov       rsi,[rdi]
       mov       r10d,esi
       cmp       r10d,0FFFFFFFF
       mov       r11d,[rbp-22C]
       jne       near ptr M02_L08
M02_L68:
       mov       eax,[rbp-9C]
       inc       eax
       mov       esi,eax
       mov       rcx,[rbp-270]
       mov       rdi,[rcx+8]
       cmp       [rdi+8],esi
       jne       short M02_L69
       xor       esi,esi
       xor       edi,edi
       mov       esi,edi
M02_L69:
       mov       r8d,[rbp-0A0]
       inc       r8d
       mov       eax,esi
       mov       rcx,[rbp-270]
       jmp       near ptr M02_L06
M02_L70:
       xor       esi,esi
       mov       rax,[rbp-260]
       jmp       near ptr M02_L10
M02_L71:
       cmp       qword ptr [rbp-270],0
       je        short M02_L72
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       rcx,rax
       mov       [rbp-290],rcx
       mov       rdi,rcx
       call      qword ptr [7F75C9DC6868]; Kevlar.KevlarContext..ctor()
       mov       rcx,[rbp-290]
       mov       rax,rcx
       mov       rcx,rax
       mov       rax,[rbp-260]
       jmp       near ptr M02_L12
M02_L72:
       mov       rdi,rax
       mov       esi,[rbp-98]
       call      qword ptr [7F75C9DC6820]
       mov       rdx,rax
       mov       rax,[rbp-260]
       jmp       near ptr M02_L11
M02_L73:
       mov       [rbp-268],rcx
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-260]
       mov       dil,[rdi+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-268]
       mov       r11,7F75C7E40658
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F75C9DC67C0]
       mov       rdx,rax
       jmp       near ptr M02_L13
M02_L74:
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F75C8E26838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       test      rax,rax
       je        short M02_L75
       mov       rdi,rax
       call      qword ptr [7F75C9DC7138]
       jmp       short M02_L76
M02_L75:
       mov       rdi,rbx
       movsx     rsi,word ptr [rbp-58]
       mov       r11,7F75C7E40660
       call      qword ptr [r11]
       cmp       eax,1
       sete      al
       movzx     eax,al
M02_L76:
       test      eax,eax
       je        near ptr M02_L99
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F75C8E26838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r15,rax
       test      r15,r15
       je        short M02_L78
       mov       edi,[r15+34]
       and       edi,11000000
       cmp       edi,1000000
       je        short M02_L77
       mov       rdi,r15
       xor       esi,esi
       call      qword ptr [7F75C9E66418]
M02_L77:
       mov       r14,[r15+38]
       mov       r15d,[r15+40]
       jmp       near ptr M02_L19
M02_L78:
       mov       rdi,rbx
       movsx     rsi,word ptr [rbp-58]
       mov       r11,7F75C7E40668
       call      qword ptr [r11]
       mov       r14,rax
       mov       r15d,edx
       jmp       near ptr M02_L19
M02_L79:
       mov       rdi,7F6DE1800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F75C98BE9B8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M02_L20
       lea       rdi,[rbp-140]
       mov       rsi,r13
       call      qword ptr [7F75C9DC71F8]
       mov       rdx,7F75C4A0B6A8
       mov       rdi,7F75C4A0B680
       test      ebx,ebx
       cmove     rdx,rdi
       lea       rdi,[rbp-140]
       mov       rsi,7F75C4A0B638
       call      qword ptr [7F75C9DC7210]
       call      00007F75C8E18AE0
       mov       rsi,rax
       mov       rdi,[rbp-40]
       call      qword ptr [7F75C9E66AF0]
       mov       [rbp-148],rax
       lea       rdi,[rbp-148]
       call      qword ptr [7F75C9DC7240]
       mov       rdi,7F6DE1800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-140]
       mov       rdx,r12
       call      qword ptr [7F75C9DC7258]
       jmp       near ptr M02_L20
M02_L80:
       lea       rdi,[rbp-1D8]
       call      qword ptr [7F75C9DC71F8]
       mov       rdx,7F75C4A0B6A8
       mov       rdi,7F75C4A0B680
       test      ebx,ebx
       cmove     rdx,rdi
       lea       rdi,[rbp-1D8]
       mov       rsi,7F75C4A0B638
       call      qword ptr [7F75C9DC7210]
       mov       rdi,7F6DE1800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-1D8]
       mov       rcx,r12
       mov       esi,1
       call      qword ptr [7F75C9DC7270]
       jmp       near ptr M02_L21
M02_L81:
       mov       rbx,[r12+10]
       jmp       near ptr M02_L22
M02_L82:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F75C7E40670
       call      qword ptr [r11]
       jmp       near ptr M02_L30
M02_L83:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F75C7E40678
       call      qword ptr [r11]
       jmp       near ptr M02_L30
M02_L84:
       mov       rdi,7F75C7E3B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M02_L84
       mov       rdi,7F76474A0D68
       mov       rax,7F7647CEF820
       call      rax
       add       rax,48
       mov       [rax+10],r13d
       jmp       near ptr M02_L24
M02_L85:
       mov       rdi,[r12+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r12+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
       jmp       near ptr M02_L25
M02_L86:
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       jne       near ptr M02_L27
M02_L87:
       inc       r13d
       mov       rcx,[r12+8]
       cmp       [rcx+8],r13d
       jne       short M02_L88
       xor       r13d,r13d
M02_L88:
       mov       eax,[rbp-1DC]
       inc       eax
       cmp       [rcx+8],eax
       mov       [rbp-1DC],eax
       jg        near ptr M02_L26
M02_L89:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-248]
       mov       r11,7F75C7E40680
       call      qword ptr [r11]
       jmp       near ptr M02_L29
M02_L90:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L92
M02_L91:
       mov       rdi,7F75C7E3B1F8
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M02_L91
       mov       [rax+10],edi
M02_L92:
       dec       edi
       imul      r13d,edi,9E3779B9
       cmp       dword ptr [rbx+18],0
       jge       short M02_L93
       mov       r12d,r13d
       mov       r13d,[rbx+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M02_L94
M02_L93:
       and       r13d,[rbx+18]
M02_L94:
       mov       rdi,[rbx+8]
       lea       esi,[r13*8]
       cmp       esi,[rdi+8]
       jae       near ptr M02_L102
       lea       esi,[r13*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M02_L96
M02_L95:
       call      qword ptr [7F75C9E66460]
       int       3
M02_L96:
       mov       rsi,[rbp-248]
       call      00007F7647274040
       test      rax,rax
       je        near ptr M02_L29
       mov       rdi,rbx
       mov       rsi,[rbp-248]
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7F75C9DC74F8]
       jmp       near ptr M02_L29
M02_L97:
       mov       rdi,rbx
       call      qword ptr [7F75C9DC7528]
       jmp       near ptr M02_L30
M02_L98:
       mov       rdi,r14
       mov       esi,r15d
       call      qword ptr [7F75C98BE7F0]
       mov       [rbp-228],rax
       mov       [rbp-220],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-228]
       vmovdqu   xmmword ptr [rbp-80],xmm0
       mov       rax,[rbp-80]
       mov       rdx,[rbp-78]
       add       rsp,298
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L99:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rax,[rsi+20]
       test      rax,rax
       je        short M02_L100
       mov       rdi,rax
       jmp       short M02_L101
M02_L100:
       mov       rsi,7F75C9CC3870
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M02_L101:
       mov       [rbp-208],rdi
       lea       rdi,[rsp]
       lea       rsi,[rbp-60]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,[rbp-208]
       mov       rsi,r12
       mov       rdx,[rbp-240]
       mov       rcx,[rbp+18]
       mov       r8,[rbp-40]
       call      qword ptr [7F75C98BE718]
       mov       [rbp-200],rax
       mov       [rbp-1F8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-200]
       vmovdqu   xmmword ptr [rbp-70],xmm0
       mov       rax,[rbp-70]
       mov       rdx,[rbp-68]
       add       rsp,298
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L102:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
       sub       rsp,28
       vzeroupper
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-248]
       xor       edx,edx
       call      qword ptr [7F75C98BE958]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       r13,[rsi+28]
       test      r13,r13
       je        short M02_L103
       jmp       short M02_L104
M02_L103:
       mov       rsi,7F75C9CC3AB0
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r13,rax
M02_L104:
       mov       rdi,[rbp-248]
       cmp       [rdi],edi
       call      qword ptr [7F75C98BE898]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       rcx,rax
       mov       rdi,r13
       mov       rdx,[rbp-240]
       mov       rsi,[rbp+18]
       call      qword ptr [7F75C98BE760]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-248]
       call      qword ptr [7F75C98BE8B0]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 4322
```
```assembly
; PoolContextProbe+<>c.<NestedContext>b__6_0(Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,378
       vzeroupper
       lea       rbp,[rsp+3A0]
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFD60
M03_L00:
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       add       rax,30
       jne       short M03_L00
       mov       [rbp-30],rax
       mov       rbx,rsi
       mov       rdi,7F6DE1800AB8
       mov       r15,[rdi]
       mov       rdi,7F6DE1800400
       mov       r14,[rdi]
       test      r15,r15
       je        near ptr M03_L59
M03_L01:
       mov       r13,rbx
       test      r13,r13
       je        near ptr M03_L60
       mov       rax,[r14+38]
       test      rax,rax
       jne       near ptr M03_L61
       cmp       byte ptr [r14+48],0
       jne       near ptr M03_L62
       mov       rbx,[r14+10]
       mov       r14,[r14+40]
       mov       rdi,7F6DE1801410
       mov       r12,[rdi]
       test      r12,r12
       je        near ptr M03_L63
M03_L02:
       mov       [rbp-2E0],r14
       mov       rcx,7F6DE1800BA0
       mov       rcx,[rcx]
       mov       rcx,[rcx+8]
       cmp       qword ptr [rcx+8],0
       jne       near ptr M03_L64
       xor       edi,edi
M03_L03:
       mov       [rbp-50],rdi
       mov       rdx,[r13+68]
       mov       [rbp-370],rdx
       test      rdx,rdx
       jne       near ptr M03_L65
M03_L04:
       mov       r14,[r13+68]
       mov       rdx,[r13+38]
       mov       [rbp-2F8],rdx
       mov       rdi,7F6DE18013C0
       mov       rsi,[rdi]
       mov       [rbp-308],rsi
       cmp       dword ptr [rsi+1C],0
       jne       near ptr M03_L66
M03_L05:
       mov       rsi,[rbp-308]
       mov       r8,[rsi+10]
       mov       [rbp-318],r8
       xor       r9d,r9d
       mov       [rbp-74],r9d
       test      r8,r8
       je        near ptr M03_L67
       mov       rdi,7F76474A0D68
       mov       r10,7F7647CEF820
       call      r10
       add       rax,48
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M03_L76
M03_L06:
       dec       eax
       mov       rcx,[rbp-318]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M03_L77
       and       r8d,eax
M03_L07:
       mov       eax,r8d
       xor       r8d,r8d
M03_L08:
       mov       rdi,[rcx+8]
       mov       [rbp-7C],r8d
       cmp       [rdi+8],r8d
       jle       near ptr M03_L82
       cmp       eax,[rdi+8]
       jae       near ptr M03_L105
       mov       [rbp-78],eax
       mov       esi,eax
       mov       r9,[rdi+rsi*8+10]
       mov       [rbp-328],r9
       mov       r10,[r9+10]
       mov       [rbp-330],r10
       test      r10,r10
       jne       near ptr M03_L52
M03_L09:
       lea       r10,[r9+18]
       mov       rdx,[r9+8]
       mov       rdi,[r10]
       mov       esi,edi
       cmp       esi,0FFFFFFFF
       je        near ptr M03_L79
       mov       r11d,[rdx+8]
       mov       [rbp-2D4],r11d
M03_L10:
       cmp       esi,r11d
       jae       near ptr M03_L105
       mov       r8d,esi
       shl       r8,4
       mov       r11d,[rdx+r8+18]
       mov       rax,rdi
       sar       rax,20
       inc       eax
       cdqe
       shl       rax,20
       or        r11,rax
       mov       rax,rdi
       lock cmpxchg [r10],r11
       cmp       rax,rdi
       jne       near ptr M03_L78
       mov       rax,[r9+8]
       mov       rdx,rax
       mov       edi,[rdx+8]
       cmp       esi,edi
       jae       near ptr M03_L105
       mov       rdx,[rdx+r8+10]
       lea       rdi,[rax+r8+10]
       xor       eax,eax
       mov       [rdi],rax
       add       r9,20
M03_L11:
       mov       rax,[r9]
       mov       [rbp-88],rax
       mov       [rdi+8],eax
       mov       r8,rax
       sar       r8,20
       inc       r8d
       movsxd    r8,r8d
       shl       r8,20
       mov       r10d,esi
       or        r8,r10
       lock cmpxchg [r9],r8
       cmp       rax,[rbp-88]
       jne       short M03_L11
       test      rdx,rdx
       je        near ptr M03_L79
       mov       rax,[rbp-308]
M03_L12:
       test      rdx,rdx
       je        near ptr M03_L83
M03_L13:
       mov       rcx,rdx
M03_L14:
       cmp       dword ptr [rax+1C],0
       jne       near ptr M03_L85
       mov       rdx,rcx
M03_L15:
       mov       [rbp-300],rdx
       lea       rdi,[rdx+68]
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       xor       edi,edi
       mov       r14,[rbp-300]
       mov       [r14+60],edi
       lea       rdi,[r14+38]
       mov       rsi,[rbp-2F8]
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r14+30]
       mov       rsi,[rbp-2E0]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,0FFFFFFFF00000000
       mov       [r14+58],rdi
       xor       edi,edi
       mov       [r14+40],rdi
       cmp       qword ptr [r14+18],0
       je        near ptr M03_L86
M03_L16:
       mov       rdi,[r13+8]
       mov       rsi,[r14+18]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC77F8]; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       mov       rdi,[r14+18]
       mov       rsi,[r14+8]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC77F8]; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       mov       rdi,[r14+8]
       mov       rsi,[r13+8]
       cmp       [rdi],dil
       mov       rax,[rsi+28]
       add       rax,8
       lock inc  dword ptr [rax]
       mov       rsi,[rsi+28]
       lea       rdi,[rdi+28]
       call      CORINFO_HELP_ASSIGN_REF
       mov       byte ptr [r14+65],1
       mov       [rbp-2E8],r14
       mov       rdi,7F6DE18013E0
       mov       rax,[rdi]
       test      rax,rax
       je        near ptr M03_L87
M03_L17:
       mov       [rbp-0A8],rbx
       mov       [rbp-0A0],rax
       mov       [rbp-98],r15
       mov       [rbp-90],r12
       cmp       qword ptr [rbp-0A0],0
       je        near ptr M03_L88
       cmp       qword ptr [rbp-0A8],0
       jne       near ptr M03_L94
       mov       rbx,[rbp-0A0]
       mov       rdi,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       cmp       [rbx+18],rdi
       jne       near ptr M03_L93
       mov       rdi,[rbx+8]
       mov       rbx,[rbp-98]
       mov       r15,[rbp-90]
       mov       rdi,[rdi]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M03_L54
M03_L18:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-100],xmm0
       vmovdqu   xmmword ptr [rbp-0F8],xmm0
       mov       [rbp-0E8],rbx
       mov       [rbp-0E0],r15
       mov       [rbp-110],r14
       mov       dword ptr [rbp-108],0FFFFFFFF
       mov       rdi,[rsi+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M03_L55
M03_L19:
       mov       rsi,[rdi+18]
       mov       rbx,[rsi+10]
       test      rbx,rbx
       je        near ptr M03_L56
M03_L20:
       mov       rdi,7F76474A0D68
       mov       rax,7F7647CEF820
       call      rax
       cmp       dword ptr [rax],4
       jle       near ptr M03_L89
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        near ptr M03_L89
M03_L21:
       mov       r15,[rax+10]
       test      r15,r15
       jne       short M03_L22
       call      qword ptr [7F75C950C3F0]; System.Threading.Thread.InitializeCurrentThread()
       mov       r15,rax
M03_L22:
       mov       [rbp-348],r15
       mov       rsi,[r15+8]
       mov       [rbp-350],rsi
       mov       rsi,[r15+10]
       mov       [rbp-358],rsi
       mov       rdi,[rbx+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M03_L24
M03_L23:
       lea       rdi,[rbp-110]
       call      rax
       jmp       short M03_L25
M03_L24:
       mov       rdi,rbx
       mov       rsi,7F75C9DB8060
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M03_L23
M03_L25:
       mov       rsi,[rbp-358]
       cmp       rsi,[r15+10]
       je        short M03_L26
       lea       rdi,[r15+10]
       call      CORINFO_HELP_ASSIGN_REF
M03_L26:
       mov       rdi,[r15+8]
       mov       rbx,rdi
       mov       rsi,[rbp-350]
       cmp       rsi,rbx
       je        short M03_L28
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      rbx,rbx
       je        short M03_L27
       cmp       qword ptr [rbx+10],0
       jne       near ptr M03_L58
M03_L27:
       cmp       qword ptr [rbp-350],0
       jne       near ptr M03_L57
M03_L28:
       mov       rdi,[rbp-100]
       mov       rax,7F6DE18013E8
       cmp       rdi,[rax]
       jne       near ptr M03_L90
       mov       rbx,[rbp-0F8]
       mov       r15d,[rbp-0F0]
       xor       r12d,r12d
M03_L29:
       xor       eax,eax
       mov       ecx,1
M03_L30:
       test      r12,r12
       jne       near ptr M03_L96
M03_L31:
       test      rbx,rbx
       sete      r12b
       movzx     r12d,r12b
       xor       edi,edi
       mov       [rbp-1A8],rdi
       cmp       qword ptr [rbp-50],0
       jne       near ptr M03_L101
M03_L32:
       mov       rdi,7F6DE1800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M03_L102
M03_L33:
       mov       rdi,[r14+20]
       mov       [rbp-360],rdi
       xor       edi,edi
       mov       [rbp-23C],edi
       cmp       qword ptr [rbp-360],0
       je        near ptr M03_L39
       mov       rdi,[rbp-360]
       call      00007F76470E6020
       test      eax,eax
       je        short M03_L40
M03_L34:
       mov       dword ptr [rbp-23C],1
       cmp       byte ptr [r14+64],0
       jne       short M03_L41
       mov       r12,[r14+8]
M03_L35:
       mov       r14,[r14+18]
       mov       r13,[r13+8]
       mov       rdi,[r12+28]
       cmp       dword ptr [rdi+0C],0
       jne       short M03_L42
M03_L36:
       mov       rax,[r14+10]
       mov       [rbp-368],rax
       mov       rcx,[r14+38]
       mov       [rbp-378],rcx
       mov       rdx,[r14+40]
       mov       [rbp-380],rdx
       test      rax,rax
       jne       short M03_L43
M03_L37:
       cmp       qword ptr [r14+18],0
       jne       near ptr M03_L45
M03_L38:
       mov       rdi,r12
       mov       rsi,r14
       mov       rdx,r13
       call      qword ptr [7F75C9DC79F0]; Kevlar.KevlarProperties.CopyChangedValuesTo(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       jmp       near ptr M03_L48
M03_L39:
       xor       edi,edi
       call      qword ptr [7F75C9E66478]
       int       3
M03_L40:
       mov       rdi,[rbp-360]
       call      qword ptr [7F75C9E664D8]
       jmp       near ptr M03_L34
M03_L41:
       mov       r12,[r14+10]
       jmp       short M03_L35
M03_L42:
       mov       rdi,[r14+28]
       cmp       dword ptr [rdi+0C],0
       jne       short M03_L36
       mov       rdi,[r13+28]
       cmp       dword ptr [rdi+0C],0
       jne       short M03_L36
       mov       rdi,[r13+28]
       mov       esi,1
       cmp       [rdi],edi
       call      qword ptr [7F75C9E66A00]
       jmp       near ptr M03_L36
M03_L43:
       mov       rdi,rax
       mov       rsi,[rax]
       mov       rsi,[rsi+40]
       call      qword ptr [rsi+20]
       test      eax,eax
       je        short M03_L37
       mov       rsi,[rbp-378]
       mov       rdx,[rbp-380]
       mov       rdi,r12
       call      qword ptr [7F75C9DC7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       test      rax,rax
       je        short M03_L44
       mov       rdi,rax
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       jne       near ptr M03_L37
M03_L44:
       mov       rsi,[rbp-378]
       mov       rdx,[rbp-380]
       mov       rdi,r13
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,[rbp-368]
       call      qword ptr [7F75C9DC7A50]
       test      eax,eax
       je        near ptr M03_L37
       mov       rsi,[rbp-378]
       mov       rdx,[rbp-380]
       mov       rdi,r13
       call      qword ptr [7F75C9DC7A68]
       jmp       near ptr M03_L37
M03_L45:
       mov       rdi,[r14+18]
       lea       rsi,[rbp-270]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC78A0]
       jmp       short M03_L47
M03_L46:
       mov       rdi,[rbp-258]
       vmovdqu   xmm0,xmmword ptr [rbp-258]
       vmovdqu   xmmword ptr [rbp-288],xmm0
       mov       rsi,[rbp-248]
       mov       [rbp-278],rsi
       mov       rsi,[rbp-280]
       mov       rdx,[rbp-278]
       mov       rcx,r12
       mov       r8,r13
       call      qword ptr [7F75C9DC7A08]; Kevlar.KevlarProperties.RemoveMissingValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
M03_L47:
       lea       rdi,[rbp-270]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F75C9DC7900]
       test      eax,eax
       jne       short M03_L46
       jmp       near ptr M03_L38
M03_L48:
       mov       rdi,[rbp-360]
       call      00007F76470E6790
       test      eax,eax
       je        short M03_L49
       mov       edi,eax
       mov       rsi,[rbp-360]
       call      qword ptr [7F75C9E664F0]
       nop
M03_L49:
       mov       rdi,7F6DE18013C0
       mov       rdi,[rdi]
       mov       rsi,[rbp-2E8]
       call      qword ptr [7F75C9DC72A0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Return(System.__Canon)
       test      rbx,rbx
       jne       near ptr M03_L103
       xor       edi,edi
       mov       [rbp-48],rdi
       mov       [rbp-40],r15d
       mov       word ptr [rbp-3C],0
       mov       byte ptr [rbp-3A],1
M03_L50:
       vmovdqu   xmm0,xmmword ptr [rbp-48]
       vmovdqu   xmmword ptr [rbp-38],xmm0
M03_L51:
       mov       rax,[rbp-38]
       mov       rdx,[rbp-30]
       add       rsp,378
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M03_L52:
       lea       rdi,[r9+10]
       test      rdi,rdi
       je        near ptr M03_L81
       xor       esi,esi
       mov       rdx,r10
       call      00007F7647274060
       mov       r10,[rbp-330]
       cmp       rax,r10
       mov       r9,[rbp-328]
       jne       near ptr M03_L09
       mov       rdx,r10
       mov       rax,[rbp-308]
       jmp       near ptr M03_L12
M03_L53:
       mov       rdi,7F75C7E3B1F8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M03_L53
       jmp       near ptr M03_L68
M03_L54:
       mov       rsi,7F75C9DB7000
       call      qword ptr [7F75C8E2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M03_L18
M03_L55:
       mov       rdi,rsi
       mov       rsi,7F75C9DB7C78
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M03_L19
M03_L56:
       mov       rsi,7F75C9DB7ED8
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rbx,rax
       jmp       near ptr M03_L20
M03_L57:
       mov       rsi,[rbp-350]
       cmp       qword ptr [rsi+10],0
       je        near ptr M03_L28
M03_L58:
       mov       rdi,rbx
       mov       rsi,[rbp-350]
       call      qword ptr [7F75C9E66E98]
       jmp       near ptr M03_L28
M03_L59:
       mov       rdi,offset MT_System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rsi,7F6DE1800AA8
       mov       rsi,[rsi]
       mov       rdi,r15
       mov       rdx,offset PoolContextProbe+<>c.<NestedContext>b__6_1(Kevlar.KevlarContext)
       call      qword ptr [7F75C8E26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F6DE1800AB8
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M03_L01
M03_L60:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,910
       mov       rsi,7F75C98ED998
       call      qword ptr [7F75C8E2EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F75C950E2B0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M03_L61:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       rsi,rbx
       mov       rdx,r15
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7570]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](Kevlar.KevlarContext, System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
       mov       [rbp-2D0],rax
       mov       [rbp-2C8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-2D0]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       jmp       near ptr M03_L51
M03_L62:
       call      qword ptr [7F75C98BE508]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M03_L63:
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       rsi,7F6DE1801408
       mov       rsi,[rsi]
       mov       rdi,r12
       mov       rdx,offset Kevlar.Shield+<>c__60`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__60_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F75C8E26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F6DE1801410
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M03_L02
M03_L64:
       call      00007F75C8E18AE0
       mov       rdi,rax
       jmp       near ptr M03_L03
M03_L65:
       cmp       dword ptr [rdx+20],0
       je        near ptr M03_L04
       mov       rsi,r14
       xor       edx,edx
       call      qword ptr [7F75C98BE868]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rdi,rbx
       call      qword ptr [7F75C9E67120]
       lea       rdi,[rbx+70]
       mov       rsi,[rbp-370]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,rbx
       call      qword ptr [7F75C98BE8E0]
       mov       rdi,rax
       mov       esi,edx
       call      qword ptr [7F75C98BE7F0]
       mov       [rbp-2C0],rax
       mov       [rbp-2B8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-2C0]
       vmovdqu   xmmword ptr [rbp-48],xmm0
       jmp       near ptr M03_L50
M03_L66:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F75C9DC67C0]
       jmp       near ptr M03_L05
M03_L67:
       mov       rdi,7F76474A0D68
       mov       r9,7F7647CEF820
       call      r9
       add       rax,3C
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M03_L69
       jmp       near ptr M03_L53
M03_L68:
       mov       [rax+10],edi
M03_L69:
       dec       edi
       imul      edi,9E3779B9
       mov       rax,[rbp-308]
       mov       edx,[rax+18]
       test      edx,edx
       jge       short M03_L70
       mov       r9d,edi
       mov       esi,[rax+20]
       imul      r9,rsi
       shr       r9,20
       jmp       short M03_L71
M03_L70:
       mov       r9d,edi
       and       r9d,edx
M03_L71:
       mov       ecx,r9d
       mov       rdi,[rax+8]
       mov       [rbp-74],ecx
       lea       edx,[rcx*8]
       cmp       edx,[rdi+8]
       jae       near ptr M03_L105
       lea       rdi,[rdi+rdx*8+10]
       mov       r8,[rdi]
       mov       rdx,r8
       mov       [rbp-320],rdx
       test      rdx,rdx
       je        short M03_L73
       xor       esi,esi
       call      00007F7647274060
       mov       rdi,[rbp-320]
       cmp       rax,rdi
       mov       rax,[rbp-308]
       je        short M03_L74
M03_L72:
       xor       edx,edx
       jmp       short M03_L75
M03_L73:
       mov       rax,[rbp-308]
       jmp       short M03_L72
M03_L74:
       mov       rdx,rdi
M03_L75:
       jmp       near ptr M03_L12
M03_L76:
       mov       rax,7F75C7E3B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-80],eax
       test      eax,eax
       je        short M03_L76
       mov       rdi,7F76474A0D68
       mov       rcx,7F7647CEF820
       call      rcx
       add       rax,48
       mov       ecx,[rbp-80]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M03_L06
M03_L77:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M03_L07
M03_L78:
       mov       rdi,[r10]
       mov       esi,edi
       cmp       esi,0FFFFFFFF
       mov       r11d,[rbp-2D4]
       jne       near ptr M03_L10
M03_L79:
       mov       eax,[rbp-78]
       inc       eax
       mov       edx,eax
       mov       rcx,[rbp-318]
       mov       rax,[rcx+8]
       cmp       [rax+8],edx
       jne       short M03_L80
       xor       edx,edx
M03_L80:
       mov       r8d,[rbp-7C]
       inc       r8d
       mov       eax,edx
       mov       rcx,[rbp-318]
       jmp       near ptr M03_L08
M03_L81:
       call      qword ptr [7F75C9E66460]
       int       3
M03_L82:
       xor       edx,edx
       mov       rax,[rbp-308]
       jmp       near ptr M03_L12
M03_L83:
       cmp       qword ptr [rbp-318],0
       je        short M03_L84
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       rcx,rax
       mov       [rbp-338],rcx
       mov       rdi,rcx
       call      qword ptr [7F75C9DC6868]; Kevlar.KevlarContext..ctor()
       mov       rcx,[rbp-338]
       mov       rax,rcx
       mov       rcx,rax
       mov       rax,[rbp-308]
       jmp       near ptr M03_L14
M03_L84:
       mov       rdi,rax
       mov       esi,[rbp-74]
       call      qword ptr [7F75C9DC6820]
       mov       rdx,rax
       mov       rax,[rbp-308]
       jmp       near ptr M03_L13
M03_L85:
       mov       [rbp-310],rcx
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-308]
       mov       dil,[rdi+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-310]
       mov       r11,7F75C7E40688
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F75C9DC67C0]
       mov       rdx,rax
       jmp       near ptr M03_L15
M03_L86:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-2F0],rax
       mov       rdi,rax
       call      qword ptr [7F75C9DC6880]; Kevlar.KevlarProperties..ctor()
       lea       rdi,[r14+18]
       mov       rsi,[rbp-2F0]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M03_L16
M03_L87:
       mov       rdi,offset MT_System.Func<Kevlar.Internal.ShieldEngine+ContextAsyncCallback<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, System.Int32>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<Kevlar.Outcome<System.Int32>>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-340],rax
       mov       rsi,7F6DE18013D8
       mov       rsi,[rsi]
       mov       rdi,rax
       mov       rdx,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       call      qword ptr [7F75C8E26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F6DE18013E0
       mov       rsi,[rbp-340]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-340]
       jmp       near ptr M03_L17
M03_L88:
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       rdi,r12
       mov       rsi,7F75C4A0B5D8
       call      qword ptr [7F75C9505608]
       mov       rdi,r12
       call      qword ptr [7F75C98BE8E0]
       mov       ecx,edx
       xor       r12d,r12d
       xor       ebx,ebx
       mov       [rbp-28C],ebx
       mov       dword ptr [rbp-290],1
       mov       rbx,rax
       mov       r15d,ecx
       mov       eax,[rbp-28C]
       mov       ecx,[rbp-290]
       jmp       near ptr M03_L30
M03_L89:
       mov       edi,4
       call      qword ptr [7F75C9E66490]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       near ptr M03_L21
M03_L90:
       mov       r12,[rbp-100]
       test      r12,r12
       jne       short M03_L91
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       rdi,r12
       call      qword ptr [7F75C9E66A48]
       mov       [rbp-100],r12
M03_L91:
       test      r12,r12
       jne       short M03_L92
       mov       edi,9
       call      qword ptr [7F75C8E2FAE0]
       int       3
M03_L92:
       xor       ebx,ebx
       xor       r15d,r15d
       jmp       near ptr M03_L29
M03_L93:
       mov       rdx,[rbp-98]
       mov       rcx,[rbp-90]
       lea       rsi,[rbp-0C8]
       mov       r8,r14
       mov       rdi,[rbx+8]
       call      qword ptr [rbx+18]
       jmp       short M03_L95
M03_L94:
       lea       rdi,[rbp-0A8]
       lea       rsi,[rbp-0C8]
       mov       r8,r14
       mov       rcx,[rbp-0A8]
       mov       rdx,offset MT_Kevlar.Continuation<System.Int32, Kevlar.Internal.ShieldEngine+ContextAsyncCallback<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, System.Int32>>
       call      qword ptr [7F75C9DC6A30]
M03_L95:
       mov       r12,[rbp-0C8]
       movsx     rax,word ptr [rbp-0C0]
       mov       ebx,eax
       movzx     ecx,byte ptr [rbp-0BE]
       mov       r15d,ecx
       mov       rdi,[rbp-0B8]
       mov       rax,rdi
       mov       edi,[rbp-0B0]
       mov       ecx,edi
       mov       rdx,rax
       mov       eax,ebx
       mov       rbx,rdx
       mov       edx,ecx
       mov       ecx,r15d
       mov       r15d,edx
       jmp       near ptr M03_L30
M03_L96:
       mov       [rbp-28C],eax
       mov       [rbp-290],ecx
       mov       rsi,r12
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F75C8E26838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       test      rax,rax
       je        short M03_L97
       mov       rdi,rax
       call      qword ptr [7F75C9DC7138]
       jmp       short M03_L98
M03_L97:
       mov       rdi,r12
       mov       esi,[rbp-28C]
       mov       r11,7F75C7E40690
       call      qword ptr [r11]
       cmp       eax,1
       sete      al
       movzx     eax,al
M03_L98:
       test      eax,eax
       je        near ptr M03_L104
       mov       rsi,r12
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F75C8E26838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       rbx,rax
       test      rbx,rbx
       je        short M03_L100
       mov       edi,[rbx+34]
       and       edi,11000000
       cmp       edi,1000000
       je        short M03_L99
       mov       rdi,rbx
       xor       esi,esi
       call      qword ptr [7F75C9E66418]
M03_L99:
       mov       rdi,[rbx+38]
       mov       r15d,[rbx+40]
       mov       rbx,rdi
       jmp       near ptr M03_L31
M03_L100:
       mov       rdi,r12
       mov       esi,[rbp-28C]
       mov       r11,7F75C7E40698
       call      qword ptr [r11]
       mov       rbx,rax
       mov       r15d,edx
       jmp       near ptr M03_L31
M03_L101:
       mov       rdi,7F6DE1800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F75C98BE9B8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M03_L32
       lea       rdi,[rbp-1A0]
       mov       rsi,[rbp-2E0]
       call      qword ptr [7F75C9DC71F8]
       mov       rdx,7F75C4A0B6A8
       mov       rdi,7F75C4A0B680
       test      r12d,r12d
       cmove     rdx,rdi
       lea       rdi,[rbp-1A0]
       mov       rsi,7F75C4A0B638
       call      qword ptr [7F75C9DC7210]
       call      00007F75C8E18AE0
       mov       rsi,rax
       mov       rdi,[rbp-50]
       call      qword ptr [7F75C9E66AF0]
       mov       [rbp-1A8],rax
       lea       rdi,[rbp-1A8]
       call      qword ptr [7F75C9DC7240]
       mov       rdi,7F6DE1800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-1A0]
       xor       edx,edx
       call      qword ptr [7F75C9DC7258]
       jmp       near ptr M03_L32
M03_L102:
       lea       rdi,[rbp-238]
       mov       rsi,[rbp-2E0]
       call      qword ptr [7F75C9DC71F8]
       mov       rdx,7F75C4A0B6A8
       mov       rdi,7F75C4A0B680
       test      r12d,r12d
       cmove     rdx,rdi
       lea       rdi,[rbp-238]
       mov       rsi,7F75C4A0B638
       call      qword ptr [7F75C9DC7210]
       mov       rdi,7F6DE1800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-238]
       mov       esi,1
       xor       ecx,ecx
       call      qword ptr [7F75C9DC7270]
       jmp       near ptr M03_L33
M03_L103:
       mov       rdi,rbx
       mov       esi,r15d
       call      qword ptr [7F75C98BE7F0]
       mov       [rbp-2B0],rax
       mov       [rbp-2A8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-2B0]
       vmovdqu   xmmword ptr [rbp-48],xmm0
       jmp       near ptr M03_L50
M03_L104:
       mov       [rbp-70],r12
       mov       r12d,[rbp-28C]
       mov       [rbp-68],r12w
       mov       r12d,[rbp-290]
       mov       [rbp-66],r12b
       mov       [rbp-60],rbx
       mov       [rbp-58],r15d
       lea       rdi,[rsp]
       lea       rsi,[rbp-70]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,r14
       mov       rsi,r13
       mov       rdx,[rbp-50]
       call      qword ptr [7F75C9DC7708]
       mov       [rbp-2A0],rax
       mov       [rbp-298],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-2A0]
       vmovdqu   xmmword ptr [rbp-48],xmm0
       jmp       near ptr M03_L50
M03_L105:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
       sub       rsp,28
       vzeroupper
       mov       rsi,[rbp-358]
       mov       rax,[rbp-348]
       cmp       rsi,[rax+10]
       je        short M03_L106
       lea       rdi,[rax+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-348]
M03_L106:
       mov       r14,[rax+8]
       mov       rsi,[rbp-350]
       cmp       rsi,r14
       je        short M03_L109
       lea       rdi,[rax+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      r14,r14
       je        short M03_L107
       cmp       qword ptr [r14+10],0
       jne       short M03_L108
M03_L107:
       cmp       qword ptr [rbp-350],0
       je        short M03_L109
       mov       rsi,[rbp-350]
       cmp       qword ptr [rsi+10],0
       je        short M03_L109
M03_L108:
       mov       rdi,r14
       mov       rsi,[rbp-350]
       call      qword ptr [7F75C9E66E98]
M03_L109:
       nop
       add       rsp,28
       ret
       sub       rsp,28
       vzeroupper
       cmp       dword ptr [rbp-23C],0
       je        short M03_L111
       cmp       qword ptr [rbp-360],0
       jne       short M03_L110
       xor       edi,edi
       call      qword ptr [7F75C9E66478]
       int       3
M03_L110:
       mov       rdi,[rbp-360]
       call      00007F76470E6790
       test      eax,eax
       je        short M03_L111
       mov       edi,eax
       mov       rsi,[rbp-360]
       call      qword ptr [7F75C9E664F0]
M03_L111:
       nop
       add       rsp,28
       ret
       sub       rsp,28
       vzeroupper
       mov       rdi,7F6DE18013C0
       mov       rdi,[rdi]
       mov       rsi,[rbp-2E8]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC72A0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Return(System.__Canon)
       nop
       add       rsp,28
       ret
; Total bytes of code 4557
```
```assembly
; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       push      r15
       push      r14
       push      rbx
       mov       rbx,rdi
       mov       r15,rsi
       mov       r14,rdx
       test      r15,r15
       je        short M04_L00
       mov       rdi,7F75C9EE45D4
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdi,[rbx+8]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       [rbx+18],r14
       pop       rbx
       pop       r14
       pop       r15
       ret
M04_L00:
       mov       rdi,7F75C9EE45D0
       call      CORINFO_HELP_COUNTPROFILE32
       call      qword ptr [7F75C9E6E028]
       int       3
; Total bytes of code 78
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       ret
; Total bytes of code 1
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       rax,rsi
       mov       rsi,rdx
       mov       rdi,offset PoolContextProbe+<>c.<NestedContext>b__6_0(Kevlar.KevlarContext)
       cmp       [rax+18],rdi
       jne       short M06_L00
       mov       rdi,[rax+8]
       jmp       qword ptr [7F75C9DC7558]; PoolContextProbe+<>c.<NestedContext>b__6_0(Kevlar.KevlarContext)
M06_L00:
       mov       rdi,[rax+8]
       jmp       qword ptr [rax+18]
; Total bytes of code 40
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
M07_L00:
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,58
       lea       rbp,[rsp+80]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       mov       [rbp-30],rsi
       mov       rbx,rsi
       mov       r13,rdx
       mov       r15,rcx
       mov       r14,r8
       mov       r12,r9
       test      r15,r15
       je        near ptr M07_L06
       test      r14,r14
       je        near ptr M07_L07
       mov       rax,[rdi+38]
       test      rax,rax
       jne       near ptr M07_L08
       cmp       byte ptr [rdi+48],0
       jne       near ptr M07_L09
       mov       rax,[rdi+10]
       mov       [rbp-58],rax
       xor       ecx,ecx
       test      rcx,rcx
       cmove     rcx,rdi
       mov       rcx,[rcx+20]
       mov       rdx,7F6DE1800B00
       test      rcx,rcx
       cmove     rcx,[rdx]
       mov       [rbp-60],rcx
       mov       rdx,[rdi+38]
       test      rdx,rdx
       jne       near ptr M07_L10
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rdi+40]
M07_L01:
       mov       rdi,[rbx+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        short M07_L04
M07_L02:
       mov       rdx,[rdi+18]
       mov       rdx,[rdx+18]
       test      rdx,rdx
       je        near ptr M07_L05
       mov       rdi,rdx
       mov       [rbp-68],rsi
M07_L03:
       mov       [rsp],r14
       xor       edx,edx
       mov       [rsp+8],rdx
       mov       [rsp+10],r12
       mov       rsi,rax
       mov       rdx,rcx
       mov       rcx,[rbp-68]
       mov       r8,r13
       mov       r9,r15
       call      qword ptr [7F75C98BE598]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       mov       [rbp-50],rax
       mov       [rbp-48],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-50]
       vmovdqu   xmmword ptr [rbp-40],xmm0
       mov       rax,[rbp-40]
       mov       rdx,[rbp-38]
       add       rsp,58
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M07_L04:
       mov       [rbp-60],rcx
       mov       [rbp-68],rsi
       mov       rdi,rbx
       mov       rsi,7F75C9CC2E88
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rbp-68]
       jmp       near ptr M07_L02
M07_L05:
       mov       [rbp-60],rcx
       mov       [rbp-68],rsi
       mov       rsi,7F75C9CC3240
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       jmp       near ptr M07_L03
M07_L06:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,92C
       mov       rsi,7F75C98ED998
       call      qword ptr [7F75C8E2EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F75C950E2B0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M07_L07:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,902
       mov       rsi,7F75C98ED998
       call      qword ptr [7F75C8E2EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F75C950E2B0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M07_L08:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       rsi,rbx
       mov       rdx,r13
       mov       rcx,r15
       mov       r8,r14
       mov       r9,r12
       cmp       [rdi],edi
       add       rsp,58
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F75C98BE340]
M07_L09:
       call      qword ptr [7F75C98BE508]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M07_L10:
       mov       rdi,[rdx+8]
       call      qword ptr [rdx+18]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F75C98BE4F0]; Kevlar.Shield.get_Name()
       mov       [rbp-68],rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rbp-68]
       jmp       near ptr M07_L01
; Total bytes of code 583
```
```assembly
; Kevlar.Shield.get_Name()
       push      rbp
       mov       rbp,rsp
M08_L00:
       mov       rax,[rdi+38]
       test      rax,rax
       jne       short M08_L01
       mov       rax,[rdi+40]
       pop       rbp
       ret
M08_L01:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       jmp       short M08_L00
; Total bytes of code 31
```
```assembly
; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       push      rbp
       mov       rbp,rsp
       test      rsi,rsi
       je        short M09_L02
       mov       rax,[rsi]
       cmp       rax,rdi
       je        short M09_L02
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
M09_L00:
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       jne       short M09_L03
M09_L01:
       xor       esi,esi
M09_L02:
       mov       rax,rsi
       pop       rbp
       ret
M09_L03:
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       jmp       short M09_L00
; Total bytes of code 91
```
```assembly
; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,128
       lea       rbp,[rsp+150]
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFF10
M10_L00:
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       add       rax,30
       jne       short M10_L00
       mov       [rbp-30],rsi
       mov       [rbp-128],r8
       mov       rbx,rdi
       mov       r15,rsi
       mov       r13,rdx
       mov       r12,rcx
       mov       r14,r9
       mov       rdi,[r15+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M10_L19
M10_L01:
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rax+8]
       test      rax,rax
       je        near ptr M10_L24
M10_L02:
       mov       [rbp-50],r13
       mov       [rbp-48],rax
       mov       [rbp-40],r12
       mov       r13,[rbp-128]
       mov       [rbp-38],r13
       mov       rdi,[r15+18]
       mov       rdx,[rdi+28]
       test      rdx,rdx
       je        near ptr M10_L20
M10_L03:
       mov       rax,[rbp-48]
       test      rax,rax
       je        near ptr M10_L31
       cmp       qword ptr [rbp-50],0
       jne       near ptr M10_L36
       mov       rdi,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       cmp       [rax+18],rdi
       jne       near ptr M10_L35
       mov       rdi,[rax+8]
       mov       r15,[rbp-40]
       mov       r13,[rbp-38]
       mov       rdi,[rdi]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M10_L21
M10_L04:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0B0],xmm0
       vmovdqu   xmmword ptr [rbp-0A8],xmm0
       mov       [rbp-98],r15
       mov       [rbp-90],r13
       mov       [rbp-0C0],r14
       mov       dword ptr [rbp-0B8],0FFFFFFFF
       mov       rdi,[rsi+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M10_L22
M10_L05:
       mov       rsi,[rdi+18]
       mov       r14,[rsi+10]
       test      r14,r14
       je        near ptr M10_L23
M10_L06:
       mov       rdi,7F76474A0D68
       mov       rax,7F7647CEF820
       call      rax
       cmp       dword ptr [rax],4
       jle       near ptr M10_L32
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        near ptr M10_L32
M10_L07:
       mov       r15,[rax+10]
       test      r15,r15
       jne       short M10_L08
       call      qword ptr [7F75C950C3F0]; System.Threading.Thread.InitializeCurrentThread()
       mov       r15,rax
M10_L08:
       mov       [rbp-138],r15
       mov       rsi,[r15+8]
       mov       [rbp-140],rsi
       mov       rsi,[r15+10]
       mov       [rbp-148],rsi
       mov       rdi,[r14+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M10_L10
M10_L09:
       lea       rdi,[rbp-0C0]
       call      rax
       jmp       short M10_L11
M10_L10:
       mov       rdi,r14
       mov       rsi,7F75C9DB8060
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M10_L09
M10_L11:
       mov       rsi,[rbp-148]
       cmp       rsi,[r15+10]
       je        short M10_L12
       lea       rdi,[r15+10]
       call      CORINFO_HELP_ASSIGN_REF
M10_L12:
       mov       rdi,[r15+8]
       mov       r14,rdi
       mov       rsi,[rbp-140]
       cmp       rsi,r14
       je        short M10_L14
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      r14,r14
       je        short M10_L13
       cmp       qword ptr [r14+10],0
       jne       near ptr M10_L18
M10_L13:
       cmp       qword ptr [rbp-140],0
       jne       near ptr M10_L17
M10_L14:
       mov       rdi,[rbp-0B0]
       mov       rax,7F6DE18013E8
       cmp       rdi,[rax]
       jne       near ptr M10_L33
       vmovdqu   xmm0,xmmword ptr [rbp-0A8]
       vmovdqu   xmmword ptr [rbp-110],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-120]
       vmovdqu   ymmword ptr [rbp-0E0],ymm0
       xor       r15d,r15d
M10_L15:
       vmovdqu   ymm0,ymmword ptr [rbp-0E0]
       vmovdqu   ymmword ptr [rbp-78],ymm0
       xor       r14d,r14d
       mov       r13d,1
M10_L16:
       mov       [rbp-78],r15
       vmovdqu   ymm0,ymmword ptr [rbp-78]
       vmovdqu   ymmword ptr [rbx],ymm0
       mov       [rbx+8],r14w
       mov       [rbx+0A],r13b
       mov       rax,rbx
       vzeroupper
       add       rsp,128
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M10_L17:
       mov       rsi,[rbp-140]
       cmp       qword ptr [rsi+10],0
       je        near ptr M10_L14
M10_L18:
       mov       rdi,r14
       mov       rsi,[rbp-140]
       call      qword ptr [7F75C9E66E98]
       jmp       near ptr M10_L14
M10_L19:
       mov       rdi,r15
       mov       rsi,7F75C9DB6718
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M10_L01
M10_L20:
       mov       rdi,r15
       mov       rsi,7F75C9DB6830
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdx,rax
       jmp       near ptr M10_L03
M10_L21:
       mov       rsi,7F75C9DB7000
       call      qword ptr [7F75C8E2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M10_L04
M10_L22:
       mov       rdi,rsi
       mov       rsi,7F75C9DB7C78
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M10_L05
M10_L23:
       mov       rsi,7F75C9DB7ED8
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r14,rax
       jmp       near ptr M10_L06
M10_L24:
       mov       rdi,[r15+18]
       mov       rax,[rdi+18]
       test      rax,rax
       je        short M10_L25
       mov       [rbp-58],rax
       jmp       short M10_L26
M10_L25:
       mov       rdi,r15
       mov       rsi,7F75C9DB6718
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-58],rax
M10_L26:
       mov       rdi,[r15+18]
       mov       rdi,[rdi+30]
       test      rdi,rdi
       je        short M10_L27
       jmp       short M10_L28
M10_L27:
       mov       rdi,r15
       mov       rsi,7F75C9DB6A10
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M10_L28:
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-130],rax
       mov       rdi,[rbp-58]
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rax]
       mov       rdi,[rbp-130]
       mov       rdx,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       call      qword ptr [7F75C8E26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,[r15+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        short M10_L29
       jmp       short M10_L30
M10_L29:
       mov       rdi,r15
       mov       rsi,7F75C9DB6718
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M10_L30:
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       lea       rdi,[rax+8]
       mov       rsi,[rbp-130]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-130]
       jmp       near ptr M10_L02
M10_L31:
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       mov       rsi,7F75C4A0B5D8
       call      qword ptr [7F75C9505608]
       mov       rdi,r15
       call      qword ptr [7F75C98BE8E0]
       xor       r15d,r15d
       xor       r14d,r14d
       mov       r13d,1
       mov       [rbp-68],rax
       mov       [rbp-60],edx
       jmp       near ptr M10_L16
M10_L32:
       mov       edi,4
       call      qword ptr [7F75C9E66490]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       near ptr M10_L07
M10_L33:
       mov       r15,[rbp-0B0]
       test      r15,r15
       jne       short M10_L34
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       call      qword ptr [7F75C9E66A48]
       mov       [rbp-0B0],r15
M10_L34:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0F0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-100]
       vmovdqu   ymmword ptr [rbp-0E0],ymm0
       jmp       near ptr M10_L15
M10_L35:
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-38]
       lea       rsi,[rbp-78]
       mov       r8,r14
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       jmp       short M10_L37
M10_L36:
       lea       rdi,[rbp-50]
       lea       rsi,[rbp-78]
       mov       rcx,[rbp-50]
       mov       r8,r14
       call      qword ptr [7F75C9DC6A30]
M10_L37:
       mov       r15,[rbp-78]
       movsx     r14,word ptr [rbp-70]
       movzx     r13d,byte ptr [rbp-6E]
       jmp       near ptr M10_L16
       push      rax
       mov       rsi,[rbp-148]
       mov       rax,[rbp-138]
       cmp       rsi,[rax+10]
       je        short M10_L38
       lea       rdi,[rax+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-138]
M10_L38:
       mov       rbx,[rax+8]
       mov       rsi,[rbp-140]
       cmp       rsi,rbx
       je        short M10_L41
       lea       rdi,[rax+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      rbx,rbx
       je        short M10_L39
       cmp       qword ptr [rbx+10],0
       jne       short M10_L40
M10_L39:
       cmp       qword ptr [rbp-140],0
       je        short M10_L41
       mov       rsi,[rbp-140]
       cmp       qword ptr [rsi+10],0
       je        short M10_L41
M10_L40:
       mov       rdi,rbx
       mov       rsi,[rbp-140]
       call      qword ptr [7F75C9E66E98]
M10_L41:
       nop
       vzeroupper
       add       rsp,8
       ret
; Total bytes of code 1394
```
```assembly
; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       push      rbp
       mov       rbp,rsp
       mov       rax,rsi
       test      rax,rax
       je        short M11_L00
       mov       rsi,rdx
       mov       rdx,rcx
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       nop
M11_L00:
       pop       rbp
       ret
       push      rax
       lea       rax,[M11_L00]
       add       rsp,8
       ret
; Total bytes of code 41
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-48],rax
       mov       [rbp-30],rdi
       mov       [rbp-68],rdi
       mov       [rbp-70],rsi
       cmp       [rdi],dil
       xor       eax,eax
       mov       [rsi+68],rax
       mov       [rsi+60],eax
       mov       [rsi+30],rax
       mov       rax,0FFFFFFFF00000000
       mov       [rsi+58],rax
       xor       eax,eax
       mov       [rsi+40],rax
       mov       [rsi+48],rax
       mov       [rsi+50],rax
       mov       rax,[rsi+28]
       test      rax,rax
       jne       near ptr M12_L11
M12_L00:
       mov       rax,7F6DE1800B00
       mov       rsi,[rax]
       mov       rbx,[rbp-70]
       lea       rdi,[rbx+38]
       call      CORINFO_HELP_ASSIGN_REF
       mov       r15,[rbx+8]
       xor       edi,edi
       mov       [r15+20],rdi
       cmp       byte ptr [r15+34],0
       jne       near ptr M12_L12
M12_L01:
       mov       rdi,[r15+28]
       mov       rax,[r15+8]
       cmp       rdi,rax
       jne       short M12_L07
       cmp       dword ptr [rax+8],1
       jne       near ptr M12_L31
M12_L02:
       mov       rdi,[r15+8]
       xor       eax,eax
       mov       [rdi+0C],eax
       mov       [rdi+10],eax
       mov       rdi,[rbx+8]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7378]; Kevlar.KevlarProperties.Clear()
       cmp       qword ptr [rbx+10],0
       jne       near ptr M12_L57
M12_L03:
       mov       r15,[rbx+18]
       test      r15,r15
       je        short M12_L06
       cmp       byte ptr [r15+34],0
       jne       near ptr M12_L58
M12_L04:
       mov       rdi,[r15+28]
       mov       rax,[r15+8]
       cmp       rdi,rax
       jne       short M12_L09
       cmp       dword ptr [rax+8],1
       jne       near ptr M12_L74
M12_L05:
       mov       rdi,[r15+8]
       xor       eax,eax
       mov       [rdi+0C],eax
       mov       [rdi+10],eax
       mov       rdi,[rbx+18]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7378]; Kevlar.KevlarProperties.Clear()
M12_L06:
       mov       word ptr [rbx+64],0
       jmp       near ptr M12_L76
M12_L07:
       mov       r14,[r15+28]
       lea       rdi,[r14+8]
       mov       eax,0FFFFFFFF
       lock xadd [rdi],eax
       dec       eax
       je        short M12_L13
M12_L08:
       mov       rsi,[r15+8]
       lea       rdi,[r15+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M12_L02
M12_L09:
       mov       r14,[r15+28]
       lea       rdi,[r14+8]
       mov       eax,0FFFFFFFF
       lock xadd [rdi],eax
       dec       eax
       je        near ptr M12_L59
M12_L10:
       mov       rsi,[r15+8]
       lea       rdi,[r15+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M12_L05
M12_L11:
       mov       rdi,rax
       call      qword ptr [7F75C9DFEA88]
       jmp       near ptr M12_L00
M12_L12:
       mov       rdi,[r15+28]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7390]
       mov       byte ptr [r15+34],0
       jmp       near ptr M12_L01
M12_L13:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F6DE18013D0
       mov       r13,[rdi]
       cmp       dword ptr [r13+1C],0
       je        short M12_L14
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r13+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F75C7E40558
       call      qword ptr [r11]
       jmp       near ptr M12_L08
M12_L14:
       mov       rdi,r13
       mov       rsi,r14
       call      qword ptr [7F75C9E66988]
       test      eax,eax
       jne       short M12_L15
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r13+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F75C7E40560
       call      qword ptr [r11]
       jmp       near ptr M12_L08
M12_L15:
       mov       r12,[r13+10]
       test      r12,r12
       je        near ptr M12_L25
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L17
M12_L16:
       mov       rax,7F75C7E3B1E8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-3C],eax
       test      eax,eax
       je        short M12_L16
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-3C]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L17:
       dec       eax
       cmp       dword ptr [r12+18],0
       jl        short M12_L18
       and       eax,[r12+18]
       jmp       short M12_L19
M12_L18:
       mov       rdi,[r12+8]
       mov       edi,[rdi+8]
       mov       eax,eax
       imul      rax,[r12+10]
       shr       rax,20
       inc       rax
       imul      rax,rdi
       shr       rax,20
M12_L19:
       xor       ecx,ecx
       jmp       short M12_L22
M12_L20:
       mov       rdi,[r12+8]
       cmp       eax,[rdi+8]
       jae       near ptr M12_L75
       mov       [rbp-34],eax
       mov       esi,eax
       mov       r8,[rdi+rsi*8+10]
       mov       [rbp-78],r8
       cmp       [r8],r8b
       lea       rdi,[r8+10]
       test      rdi,rdi
       je        near ptr M12_L69
       mov       rsi,r14
       xor       edx,edx
       call      00007F7647274060
       test      rax,rax
       je        short M12_L23
       mov       rdx,r14
       mov       rsi,[rbp-78]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F75C98BDF38]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M12_L23
       mov       eax,[rbp-34]
       inc       eax
       mov       edi,eax
       mov       rax,[r12+8]
       cmp       [rax+8],edi
       jne       short M12_L21
       xor       edi,edi
M12_L21:
       mov       ecx,[rbp-38]
       inc       ecx
       mov       eax,edi
M12_L22:
       mov       rdi,[r12+8]
       mov       [rbp-38],ecx
       cmp       [rdi+8],ecx
       jg        short M12_L20
       jmp       short M12_L24
M12_L23:
       cmp       dword ptr [r13+1C],0
       je        near ptr M12_L08
       jmp       near ptr M12_L30
M12_L24:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r13+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F75C7E40568
       call      qword ptr [r11]
       jmp       short M12_L23
M12_L25:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M12_L27
M12_L26:
       mov       rdi,7F75C7E3B1E0
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M12_L26
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M12_L27:
       dec       r12d
       imul      r12d,9E3779B9
       cmp       dword ptr [r13+18],0
       jge       short M12_L28
       mov       eax,[r13+20]
       imul      r12,rax
       shr       r12,20
       jmp       short M12_L29
M12_L28:
       and       r12d,[r13+18]
M12_L29:
       mov       rdi,[r13+8]
       lea       esi,[r12*8]
       cmp       esi,[rdi+8]
       jae       near ptr M12_L75
       lea       esi,[r12*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       je        near ptr M12_L69
       mov       rsi,r14
       call      00007F7647274040
       test      rax,rax
       je        near ptr M12_L23
       mov       rdi,r13
       mov       rsi,r14
       mov       rdx,rax
       mov       ecx,r12d
       call      qword ptr [7F75C9E669A0]
       jmp       near ptr M12_L23
M12_L30:
       mov       rdi,r13
       call      qword ptr [7F75C9E669B8]
       jmp       near ptr M12_L08
M12_L31:
       mov       rdi,[r15+8]
       call      qword ptr [7F75C9DC73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F6DE18013D0
       mov       r14,[rdi]
       cmp       dword ptr [r14+1C],0
       je        short M12_L32
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F75C9E669D0]
M12_L32:
       mov       r13,[r14+10]
       xor       r12d,r12d
       test      r13,r13
       jne       near ptr M12_L39
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M12_L34
M12_L33:
       mov       rdi,7F75C7E3B1E0
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M12_L33
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M12_L34:
       dec       r12d
       imul      edi,r12d,9E3779B9
       cmp       dword ptr [r14+18],0
       jge       short M12_L35
       mov       r12d,edi
       mov       edx,[r14+20]
       imul      r12,rdx
       shr       r12,20
       jmp       short M12_L36
M12_L35:
       and       edi,[r14+18]
       mov       r12d,edi
M12_L36:
       mov       rdi,[r14+8]
       lea       edx,[r12*8]
       cmp       edx,[rdi+8]
       jae       near ptr M12_L75
       lea       edx,[r12*8]
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       [rbp-80],rax
       test      rax,rax
       je        short M12_L37
       mov       rdx,rax
       xor       esi,esi
       call      00007F7647274060
       mov       rdi,[rbp-80]
       cmp       rax,rdi
       je        short M12_L38
M12_L37:
       xor       edi,edi
M12_L38:
       mov       [rbp-48],rdi
       jmp       near ptr M12_L50
M12_L39:
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L41
M12_L40:
       mov       rax,7F75C7E3B1E8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-54],eax
       test      eax,eax
       je        short M12_L40
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-54]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L41:
       dec       eax
       cmp       dword ptr [r13+18],0
       jl        short M12_L42
       and       eax,[r13+18]
       jmp       short M12_L43
M12_L42:
       mov       rdi,[r13+8]
       mov       edi,[rdi+8]
       mov       eax,eax
       imul      rax,[r13+10]
       shr       rax,20
       inc       rax
       imul      rax,rdi
       shr       rax,20
M12_L43:
       xor       ecx,ecx
       jmp       near ptr M12_L47
M12_L44:
       mov       rdi,[r13+8]
       cmp       eax,[rdi+8]
       jae       near ptr M12_L75
       mov       [rbp-4C],eax
       mov       edx,eax
       mov       r8,[rdi+rdx*8+10]
       mov       [rbp-88],r8
       mov       r9,[r8+10]
       mov       [rbp-90],r9
       test      r9,r9
       je        short M12_L45
       lea       rdi,[r8+10]
       test      rdi,rdi
       je        near ptr M12_L69
       mov       rdx,r9
       xor       esi,esi
       call      00007F7647274060
       mov       rcx,[rbp-90]
       cmp       rax,rcx
       mov       r8,[rbp-88]
       je        short M12_L48
M12_L45:
       lea       rdx,[rbp-48]
       mov       rsi,r8
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F75C98BDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M12_L50
       mov       eax,[rbp-4C]
       inc       eax
       mov       edi,eax
       mov       rsi,[r13+8]
       cmp       [rsi+8],edi
       jne       short M12_L46
       xor       edi,edi
M12_L46:
       mov       ecx,[rbp-50]
       inc       ecx
       mov       eax,edi
M12_L47:
       mov       rdi,[r13+8]
       mov       [rbp-50],ecx
       cmp       [rdi+8],ecx
       jg        near ptr M12_L44
       jmp       short M12_L49
M12_L48:
       mov       r9,rcx
       mov       [rbp-48],r9
       jmp       short M12_L50
M12_L49:
       xor       edi,edi
       mov       [rbp-48],rdi
M12_L50:
       mov       rax,[rbp-48]
       cmp       qword ptr [rbp-48],0
       jne       short M12_L51
       test      r13,r13
       je        short M12_L52
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       dword ptr [r12+8],1
       jmp       short M12_L54
M12_L51:
       mov       r13,rax
       jmp       short M12_L53
M12_L52:
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7F75C9E669E8]
       mov       r13,rax
M12_L53:
       mov       r12,r13
M12_L54:
       xor       edi,edi
       mov       [rbp-48],rdi
       cmp       dword ptr [r14+1C],0
       jne       short M12_L55
       mov       rsi,r12
       jmp       short M12_L56
M12_L55:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F75C7E40570
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F75C9E669D0]
       mov       rsi,rax
M12_L56:
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M12_L08
M12_L57:
       mov       rdi,[rbx+10]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7360]; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       mov       rdi,[rbx+10]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7378]; Kevlar.KevlarProperties.Clear()
       jmp       near ptr M12_L03
M12_L58:
       mov       rdi,[r15+28]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7390]
       mov       byte ptr [r15+34],0
       jmp       near ptr M12_L04
M12_L59:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F6DE18013D0
       mov       r13,[rdi]
       cmp       dword ptr [r13+1C],0
       je        short M12_L60
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r13+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F75C7E40578
       call      qword ptr [r11]
       jmp       near ptr M12_L10
M12_L60:
       mov       rdi,r13
       mov       rsi,r14
       call      qword ptr [7F75C9E66988]
       test      eax,eax
       jne       short M12_L61
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r13+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F75C7E40580
       call      qword ptr [r11]
       jmp       near ptr M12_L10
M12_L61:
       mov       r12,[r13+10]
       test      r12,r12
       je        near ptr M12_L72
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L63
M12_L62:
       mov       rax,7F75C7E3B1E8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-60],eax
       test      eax,eax
       je        short M12_L62
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-60]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L63:
       dec       eax
       cmp       dword ptr [r12+18],0
       jl        short M12_L64
       and       eax,[r12+18]
       jmp       short M12_L65
M12_L64:
       mov       rdi,[r12+8]
       mov       edi,[rdi+8]
       mov       eax,eax
       imul      rax,[r12+10]
       shr       rax,20
       inc       rax
       imul      rax,rdi
       shr       rax,20
M12_L65:
       xor       ecx,ecx
       jmp       short M12_L68
M12_L66:
       mov       rdi,[r12+8]
       cmp       eax,[rdi+8]
       jae       near ptr M12_L75
       mov       [rbp-58],eax
       mov       esi,eax
       mov       r8,[rdi+rsi*8+10]
       mov       [rbp-98],r8
       cmp       [r8],r8b
       lea       rdi,[r8+10]
       test      rdi,rdi
       je        short M12_L69
       mov       rsi,r14
       xor       edx,edx
       call      00007F7647274060
       test      rax,rax
       je        short M12_L70
       mov       rdx,r14
       mov       rsi,[rbp-98]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F75C98BDF38]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M12_L70
       mov       eax,[rbp-58]
       inc       eax
       mov       rcx,[r12+8]
       cmp       [rcx+8],eax
       jne       short M12_L67
       xor       eax,eax
M12_L67:
       mov       ecx,[rbp-5C]
       inc       ecx
M12_L68:
       mov       rdi,[r12+8]
       mov       [rbp-5C],ecx
       cmp       [rdi+8],ecx
       jg        short M12_L66
       jmp       short M12_L71
M12_L69:
       call      qword ptr [7F75C9E66460]
       int       3
M12_L70:
       cmp       dword ptr [r13+1C],0
       je        near ptr M12_L10
       jmp       near ptr M12_L73
M12_L71:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r13+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F75C7E40588
       call      qword ptr [r11]
       jmp       short M12_L70
M12_L72:
       mov       rdi,r13
       call      qword ptr [7F75C9E66E38]
       mov       r12d,eax
       mov       rsi,[r13+8]
       lea       edx,[r12*8]
       cmp       edx,[rsi+8]
       jae       near ptr M12_L75
       lea       edx,[r12*8]
       lea       rsi,[rsi+rdx*8+10]
       mov       rdx,r14
       mov       rdi,7F75C9E934C0
       call      qword ptr [7F75C98BDEC0]
       test      rax,rax
       je        near ptr M12_L70
       mov       rdi,r13
       mov       rsi,r14
       mov       rdx,rax
       mov       ecx,r12d
       call      qword ptr [7F75C9E669A0]
       jmp       near ptr M12_L70
M12_L73:
       mov       rdi,r13
       call      qword ptr [7F75C9E669B8]
       jmp       near ptr M12_L10
M12_L74:
       mov       rdi,[r15+8]
       call      qword ptr [7F75C9DC73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F6DE18013D0
       mov       rdi,[rdi]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC73D8]
       lea       rdi,[r15+8]
       mov       rsi,rax
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M12_L10
M12_L75:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M12_L76:
       mov       eax,1
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
       push      rax
       mov       rdi,[rbp-68]
       mov       rsi,[rdi]
       mov       rax,[rsi+30]
       mov       rax,[rax]
       mov       rbx,[rax+40]
       test      rbx,rbx
       je        short M12_L77
       jmp       short M12_L78
M12_L77:
       mov       rdi,rsi
       mov       rsi,7F75C9E4DAF0
       call      qword ptr [7F75C8E2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rbx,rax
M12_L78:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-68]
       mov       r11b,[rdi+30]
       mov       [rax+8],r11b
       mov       rdi,rax
       mov       r11,rbx
       mov       rsi,[rbp-70]
       call      qword ptr [rbx]
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 2563
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F75C89CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F75C89CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       push      rbp
       push      r15
       push      r14
       push      rbx
       sub       rsp,128
       vzeroupper
       lea       rbp,[rsp+140]
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFEE0
M14_L00:
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       vmovdqa   xmmword ptr [rax+rbp],xmm8
       add       rax,30
       jne       short M14_L00
       mov       [rbp-20],rax
       mov       rbx,rdi
       mov       r15,rsi
       mov       r14d,edx
       xor       edi,edi
       mov       [rbp-0B0],rdi
       test      rbx,rbx
       jne       short M14_L03
M14_L01:
       mov       rdi,7F6DE1800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M14_L04
M14_L02:
       add       rsp,128
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M14_L03:
       mov       rdi,7F6DE1800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F75C98BE9B8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        short M14_L01
       lea       rdi,[rbp-0A8]
       mov       rsi,r15
       call      qword ptr [7F75C9DC71F8]
       mov       rdx,7F75C4A0B6A8
       mov       rdi,7F75C4A0B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-0A8]
       mov       rsi,7F75C4A0B638
       call      qword ptr [7F75C9DC7210]
       call      00007F75C8E18AE0
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F75C9E66AF0]
       mov       [rbp-0B0],rax
       lea       rdi,[rbp-0B0]
       call      qword ptr [7F75C9DC7240]
       mov       rdi,7F6DE1800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-0A8]
       xor       edx,edx
       call      qword ptr [7F75C9DC7258]
       jmp       near ptr M14_L01
M14_L04:
       lea       rdi,[rbp-140]
       mov       rsi,r15
       call      qword ptr [7F75C9DC71F8]
       mov       rdx,7F75C4A0B6A8
       mov       rdi,7F75C4A0B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-140]
       mov       rsi,7F75C4A0B638
       call      qword ptr [7F75C9DC7210]
       mov       rdi,7F6DE1800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-140]
       mov       esi,1
       xor       ecx,ecx
       call      qword ptr [7F75C9DC7270]
       jmp       near ptr M14_L02
; Total bytes of code 394
```
```assembly
; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,58
       lea       rbp,[rsp+80]
       mov       r13,rdi
       mov       r14d,esi
       mov       rbx,rdx
       mov       r15,rcx
       mov       rdi,7F6DE18013C0
       mov       r12,[rdi]
       cmp       dword ptr [r12+1C],0
       jne       near ptr M15_L13
M15_L00:
       mov       rax,[r12+10]
       mov       [rbp-58],rax
       xor       ecx,ecx
       mov       [rbp-2C],ecx
       test      rax,rax
       je        near ptr M15_L14
       mov       rdi,7F76474A0D68
       mov       rdx,7F7647CEF820
       call      rdx
       add       rax,48
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M15_L23
M15_L01:
       dec       eax
       mov       rcx,[rbp-58]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M15_L24
       and       r8d,eax
M15_L02:
       mov       eax,r8d
       xor       r8d,r8d
M15_L03:
       mov       rdi,[rcx+8]
       mov       [rbp-34],r8d
       cmp       [rdi+8],r8d
       jle       near ptr M15_L29
       cmp       eax,[rdi+8]
       jae       near ptr M15_L33
       mov       [rbp-30],eax
       mov       esi,eax
       mov       r9,[rdi+rsi*8+10]
       mov       [rbp-68],r9
       mov       r10,[r9+10]
       mov       [rbp-70],r10
       test      r10,r10
       jne       near ptr M15_L11
M15_L04:
       lea       r10,[r9+18]
       mov       rdx,[r9+8]
       mov       rdi,[r10]
       mov       esi,edi
       cmp       esi,0FFFFFFFF
       je        near ptr M15_L26
       mov       r11d,[rdx+8]
       mov       [rbp-44],r11d
M15_L05:
       cmp       esi,r11d
       jae       near ptr M15_L33
       mov       r8d,esi
       shl       r8,4
       mov       r11d,[rdx+r8+18]
       mov       rax,rdi
       sar       rax,20
       inc       eax
       cdqe
       shl       rax,20
       or        r11,rax
       mov       rax,rdi
       lock cmpxchg [r10],r11
       cmp       rax,rdi
       jne       near ptr M15_L25
       mov       rax,[r9+8]
       mov       rdx,rax
       mov       edi,[rdx+8]
       cmp       esi,edi
       jae       near ptr M15_L33
       mov       rdx,[rdx+r8+10]
       lea       rdi,[rax+r8+10]
       xor       eax,eax
       mov       [rdi],rax
       add       r9,20
M15_L06:
       mov       rax,[r9]
       mov       [rbp-40],rax
       mov       [rdi+8],eax
       mov       r8,rax
       sar       r8,20
       inc       r8d
       movsxd    r8,r8d
       shl       r8,20
       mov       r10d,esi
       or        r8,r10
       lock cmpxchg [r9],r8
       cmp       rax,[rbp-40]
       jne       short M15_L06
       test      rdx,rdx
       je        near ptr M15_L26
       mov       eax,[rbp-2C]
M15_L07:
       test      rdx,rdx
       je        near ptr M15_L30
M15_L08:
       mov       rax,rdx
M15_L09:
       cmp       dword ptr [r12+1C],0
       jne       near ptr M15_L32
       mov       r12,rax
M15_L10:
       lea       rdi,[r12+68]
       mov       rsi,r13
       call      CORINFO_HELP_ASSIGN_REF
       mov       [r12+60],r14d
       lea       rdi,[r12+38]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r12+30]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,0FFFFFFFF00000000
       mov       [r12+58],rax
       xor       eax,eax
       mov       [r12+40],rax
       mov       rax,r12
       add       rsp,58
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M15_L11:
       lea       rdi,[r9+10]
       test      rdi,rdi
       je        near ptr M15_L28
       xor       esi,esi
       mov       rdx,r10
       call      00007F7647274060
       mov       r10,[rbp-70]
       cmp       rax,r10
       mov       r9,[rbp-68]
       jne       near ptr M15_L04
       mov       rdx,r10
       mov       eax,[rbp-2C]
       jmp       near ptr M15_L07
M15_L12:
       mov       rdi,7F75C7E3B1F8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M15_L12
       jmp       short M15_L15
M15_L13:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F75C9DC67C0]
       jmp       near ptr M15_L00
M15_L14:
       mov       rdi,7F76474A0D68
       mov       rcx,7F7647CEF820
       call      rcx
       add       rax,3C
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M15_L16
       jmp       short M15_L12
M15_L15:
       mov       [rax+10],edi
M15_L16:
       dec       edi
       imul      edi,9E3779B9
       mov       edx,[r12+18]
       test      edx,edx
       jge       short M15_L17
       mov       ecx,edi
       mov       esi,[r12+20]
       imul      rcx,rsi
       shr       rcx,20
       jmp       short M15_L18
M15_L17:
       mov       ecx,edi
       and       ecx,edx
M15_L18:
       mov       eax,ecx
       mov       rdi,[r12+8]
       mov       [rbp-2C],eax
       lea       edx,[rax*8]
       cmp       edx,[rdi+8]
       jae       near ptr M15_L33
       lea       rdi,[rdi+rdx*8+10]
       mov       rcx,[rdi]
       mov       rdx,rcx
       mov       [rbp-60],rdx
       test      rdx,rdx
       je        short M15_L20
       xor       esi,esi
       call      00007F7647274060
       mov       rdi,[rbp-60]
       cmp       rax,rdi
       mov       eax,[rbp-2C]
       je        short M15_L21
M15_L19:
       xor       edx,edx
       jmp       short M15_L22
M15_L20:
       mov       eax,[rbp-2C]
       jmp       short M15_L19
M15_L21:
       mov       rdx,rdi
M15_L22:
       jmp       near ptr M15_L07
M15_L23:
       mov       rax,7F75C7E3B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-38],eax
       test      eax,eax
       je        short M15_L23
       mov       rdi,7F76474A0D68
       mov       rcx,7F7647CEF820
       call      rcx
       add       rax,48
       mov       ecx,[rbp-38]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M15_L01
M15_L24:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M15_L02
M15_L25:
       mov       rdi,[r10]
       mov       esi,edi
       cmp       esi,0FFFFFFFF
       mov       r11d,[rbp-44]
       jne       near ptr M15_L05
M15_L26:
       mov       eax,[rbp-30]
       inc       eax
       mov       edx,eax
       mov       rcx,[rbp-58]
       mov       rax,[rcx+8]
       cmp       [rax+8],edx
       jne       short M15_L27
       xor       edx,edx
M15_L27:
       mov       r8d,[rbp-34]
       inc       r8d
       mov       eax,edx
       mov       rcx,[rbp-58]
       jmp       near ptr M15_L03
M15_L28:
       call      qword ptr [7F75C9E66460]
       int       3
M15_L29:
       xor       edx,edx
       mov       eax,[rbp-2C]
       jmp       near ptr M15_L07
M15_L30:
       cmp       qword ptr [rbp-58],0
       je        short M15_L31
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-78],rax
       mov       rdi,rax
       call      qword ptr [7F75C9DC6868]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-78]
       jmp       near ptr M15_L09
M15_L31:
       mov       rdi,r12
       mov       esi,eax
       call      qword ptr [7F75C9DC6820]
       mov       rdx,rax
       jmp       near ptr M15_L08
M15_L32:
       mov       [rbp-50],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r12+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-50]
       mov       r11,7F75C7E405D0
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F75C9DC67C0]
       mov       r12,rax
       jmp       near ptr M15_L10
M15_L33:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 1079
```
```assembly
; Kevlar.KevlarContext.get_PropertiesForCompletion()
       cmp       byte ptr [rdi+64],0
       jne       short M16_L00
       mov       rax,[rdi+8]
       ret
M16_L00:
       mov       rax,[rdi+10]
       ret
; Total bytes of code 16
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       push      rbp
       push      r15
       push      r14
       push      rbx
       sub       rsp,18
       lea       rbp,[rsp+30]
       mov       rbx,rsi
       lea       rdi,[rbx+20]
       mov       rsi,[rbx+8]
       mov       rax,[rdi]
       mov       r15d,eax
       cmp       r15d,0FFFFFFFF
       je        near ptr M17_L03
       mov       ecx,[rsi+8]
M17_L00:
       cmp       r15d,ecx
       jae       near ptr M17_L04
       mov       r14d,r15d
       shl       r14,4
       mov       r8d,[rsi+r14+18]
       mov       r9,rax
       sar       r9,20
       inc       r9d
       movsxd    r9,r9d
       shl       r9,20
       or        r8,r9
       mov       [rbp-20],rax
       lock cmpxchg [rdi],r8
       cmp       rax,[rbp-20]
       jne       short M17_L02
       mov       rdi,[rbx+8]
       cmp       r15d,[rdi+8]
       jae       short M17_L04
       lea       rdi,[rdi+r14+10]
       mov       rsi,rdx
       call      CORINFO_HELP_ASSIGN_REF
       lea       rcx,[rbx+18]
       mov       rdx,[rbx+8]
M17_L01:
       mov       rax,[rcx]
       mov       [rbp-28],rax
       cmp       r15d,[rdx+8]
       jae       short M17_L04
       mov       [rdx+r14+18],eax
       mov       rdi,rax
       sar       rdi,20
       inc       edi
       movsxd    rdi,edi
       shl       rdi,20
       mov       esi,r15d
       or        rdi,rsi
       lock cmpxchg [rcx],rdi
       cmp       rax,[rbp-28]
       jne       short M17_L01
       mov       eax,1
       add       rsp,18
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M17_L02:
       mov       rax,[rdi]
       mov       r15d,eax
       cmp       r15d,0FFFFFFFF
       jne       near ptr M17_L00
M17_L03:
       xor       eax,eax
       add       rsp,18
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M17_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 234
```
```assembly
; Kevlar.KevlarContext..ctor()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F75C9DC6880]; Kevlar.KevlarProperties..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,offset MT_System.Object
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-18],rax
       mov       rdi,[rbp-18]
       call      qword ptr [7F75C8E2C240]; System.Object..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+20]
       mov       rsi,[rbp-18]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-8]
       mov       dword ptr [rax+5C],0FFFFFFFF
       call      qword ptr [7F75C98BE538]; System.TimeProvider.get_System()
       mov       rcx,[rbp-8]
       lea       rdi,[rcx+38]
       mov       rsi,rax
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-8]
       call      qword ptr [7F75C8E2C240]; System.Object..ctor()
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 166
```
```assembly
; System.Diagnostics.Metrics.Instrument.get_Enabled()
       mov       rax,[rdi+8]
       cmp       qword ptr [rax+8],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 16
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,130
       vzeroupper
       lea       rbp,[rsp+150]
       xor       eax,eax
       mov       [rbp-148],rax
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFEE0
M20_L00:
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       vmovdqa   xmmword ptr [rax+rbp],xmm8
       add       rax,30
       jne       short M20_L00
       mov       r15,rdi
       mov       rbx,rsi
       mov       r14d,edx
       mov       r13,[rbx+30]
       xor       edi,edi
       mov       [rbp-0B8],rdi
       test      r15,r15
       jne       short M20_L03
M20_L01:
       mov       rsi,[rbx+30]
       mov       rdi,7F6DE1800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M20_L04
M20_L02:
       add       rsp,130
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M20_L03:
       mov       rdi,7F6DE1800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F75C98BE9B8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        short M20_L01
       lea       rdi,[rbp-0B0]
       mov       rsi,r13
       call      qword ptr [7F75C9DC71F8]
       mov       rdx,7F75C4A0B6A8
       mov       rdi,7F75C4A0B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-0B0]
       mov       rsi,7F75C4A0B638
       call      qword ptr [7F75C9DC7210]
       call      00007F75C8E18AE0
       mov       rsi,rax
       mov       rdi,r15
       call      qword ptr [7F75C9E66AF0]
       mov       [rbp-0B8],rax
       lea       rdi,[rbp-0B8]
       call      qword ptr [7F75C9DC7240]
       mov       rdi,7F6DE1800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-0B0]
       mov       rdx,rbx
       call      qword ptr [7F75C9DC7258]
       jmp       near ptr M20_L01
M20_L04:
       lea       rdi,[rbp-148]
       call      qword ptr [7F75C9DC71F8]
       mov       rdx,7F75C4A0B6A8
       mov       rdi,7F75C4A0B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-148]
       mov       rsi,7F75C4A0B638
       call      qword ptr [7F75C9DC7210]
       mov       rdi,7F6DE1800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-148]
       mov       rcx,rbx
       mov       esi,1
       call      qword ptr [7F75C9DC7270]
       jmp       near ptr M20_L02
; Total bytes of code 410
```
```assembly
; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+50]
       mov       rbx,rdi
       mov       rdi,7F6DE18013C0
       mov       r15,[rdi]
       test      rbx,rbx
       je        near ptr M21_L06
       cmp       dword ptr [r15+1C],0
       jne       near ptr M21_L07
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7F75C9DC72B8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       je        near ptr M21_L08
       mov       r14,[r15+10]
       test      r14,r14
       je        near ptr M21_L15
       mov       rdi,7F76474A0D68
       mov       rax,7F7647CEF820
       call      rax
       add       rax,48
       mov       r13d,[rax+10]
       test      r13d,r13d
       je        near ptr M21_L09
M21_L00:
       dec       r13d
       mov       r12d,[r14+18]
       test      r12d,r12d
       jl        near ptr M21_L10
       and       r12d,r13d
M21_L01:
       xor       r13d,r13d
       mov       rdi,[r14+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M21_L14
M21_L02:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M21_L23
       mov       esi,r12d
       mov       rax,[rdi+rsi*8+10]
       mov       [rbp-50],rax
       cmp       [rax],al
       lea       rdi,[rax+10]
       test      rdi,rdi
       je        near ptr M21_L20
       mov       rsi,rbx
       xor       edx,edx
       call      00007F7647274060
       test      rax,rax
       je        near ptr M21_L05
       mov       rcx,[rbp-50]
       lea       rdi,[rcx+20]
       mov       rsi,[rcx+8]
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       je        near ptr M21_L12
       mov       r8d,[rsi+8]
M21_L03:
       cmp       edx,r8d
       jae       near ptr M21_L23
       mov       r9d,edx
       shl       r9,4
       mov       [rbp-48],r9
       mov       r10d,[rsi+r9+18]
       mov       r11,rax
       sar       r11,20
       inc       r11d
       movsxd    r11,r11d
       shl       r11,20
       or        r10,r11
       mov       [rbp-38],rax
       lock cmpxchg [rdi],r10
       cmp       rax,[rbp-38]
       jne       near ptr M21_L11
       mov       rdi,[rcx+8]
       mov       [rbp-2C],edx
       cmp       edx,[rdi+8]
       jae       near ptr M21_L23
       lea       rdi,[rdi+r9+10]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       mov       rbx,[rbp-50]
       lea       rdi,[rbx+18]
       mov       rcx,[rbx+8]
       mov       ebx,[rbp-2C]
M21_L04:
       mov       rax,[rdi]
       mov       [rbp-40],rax
       cmp       ebx,[rcx+8]
       jae       near ptr M21_L23
       mov       r14,[rbp-48]
       mov       [rcx+r14+18],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       esi,ebx
       or        rdx,rsi
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-40]
       jne       short M21_L04
M21_L05:
       cmp       dword ptr [r15+1C],0
       jne       near ptr M21_L22
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M21_L06:
       mov       edi,29
       mov       rsi,7F75C92A54F0
       call      qword ptr [7F75C8E2EF88]
       mov       rdi,rax
       call      qword ptr [7F75C9E66478]
       int       3
M21_L07:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F75C7E40540
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M21_L08:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F75C7E40548
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M21_L09:
       mov       rdi,7F75C7E3B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M21_L09
       mov       rdi,7F76474A0D68
       mov       rax,7F7647CEF820
       call      rax
       add       rax,48
       mov       [rax+10],r13d
       jmp       near ptr M21_L00
M21_L10:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r13d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
       jmp       near ptr M21_L01
M21_L11:
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       jne       near ptr M21_L03
M21_L12:
       inc       r12d
       mov       rcx,[r14+8]
       cmp       [rcx+8],r12d
       jne       short M21_L13
       xor       r12d,r12d
M21_L13:
       inc       r13d
       cmp       [rcx+8],r13d
       jg        near ptr M21_L02
M21_L14:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F75C7E40550
       call      qword ptr [r11]
       jmp       near ptr M21_L05
M21_L15:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r14d,[rax+10]
       test      r14d,r14d
       jne       short M21_L17
M21_L16:
       mov       rdi,7F75C7E3B1F8
       mov       eax,1
       mov       r14d,eax
       lock xadd [rdi],r14d
       inc       r14d
       je        short M21_L16
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r14d
M21_L17:
       dec       r14d
       imul      r14d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M21_L18
       mov       r13d,r14d
       mov       r12d,[r15+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M21_L19
M21_L18:
       and       r14d,[r15+18]
       mov       r13d,r14d
M21_L19:
       mov       rdi,[r15+8]
       lea       esi,[r13*8]
       cmp       esi,[rdi+8]
       jae       short M21_L23
       lea       esi,[r13*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M21_L21
M21_L20:
       call      qword ptr [7F75C9E66460]
       int       3
M21_L21:
       mov       rsi,rbx
       call      00007F7647274040
       test      rax,rax
       je        near ptr M21_L05
       mov       rdi,r15
       mov       rsi,rbx
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7F75C9DC74F8]
       jmp       near ptr M21_L05
M21_L22:
       mov       rdi,r15
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F75C9DC7528]
M21_L23:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 988
```
```assembly
; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,50
       lea       rbp,[rsp+60]
       xor       eax,eax
       mov       [rbp-58],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       rbx,rdi
       mov       r15,rsi
       mov       rdi,[rbx+28]
       cmp       dword ptr [rdi+0C],0
       jne       short M22_L02
M22_L00:
       cmp       qword ptr [rbx+10],0
       jne       short M22_L03
M22_L01:
       add       rsp,50
       pop       rbx
       pop       r15
       pop       rbp
       ret
M22_L02:
       mov       rdi,[r15+28]
       mov       esi,1
       cmp       [rdi],edi
       call      qword ptr [7F75C9E66A00]
       jmp       short M22_L00
M22_L03:
       mov       rdi,[rbx+10]
       mov       rdx,[rbx+38]
       mov       rcx,[rbx+40]
       mov       rsi,r15
       mov       rax,[rdi]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
       cmp       qword ptr [rbx+18],0
       je        short M22_L01
       mov       rdi,[rbx+18]
       lea       rsi,[rbp-40]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC78A0]
       jmp       short M22_L05
M22_L04:
       mov       rdi,[rbp-28]
       vmovdqu   xmm0,xmmword ptr [rbp-28]
       vmovdqu   xmmword ptr [rbp-58],xmm0
       mov       rdx,[rbp-18]
       mov       [rbp-48],rdx
       mov       rdx,[rbp-50]
       mov       rcx,[rbp-48]
       mov       rsi,r15
       mov       rax,[rdi]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
M22_L05:
       lea       rdi,[rbp-40]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F75C9DC7900]
       test      eax,eax
       jne       short M22_L04
       jmp       near ptr M22_L01
; Total bytes of code 207
```
```assembly
; Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,0D0
       lea       rbp,[rsp+0F0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       xor       eax,eax
       mov       [rbp-30],rax
       mov       [rbp-28],rdi
       mov       [rbp-0D8],rdi
       mov       rbx,rsi
       mov       r14,rdx
       mov       r13,rcx
       mov       r15,r8
       mov       rsi,[rdi]
       mov       rax,[rsi+30]
       mov       rax,[rax]
       mov       rax,[rax+18]
       test      rax,rax
       je        near ptr M23_L14
M23_L00:
       mov       [rbp-48],r14
       mov       [rbp-40],r13
       mov       [rbp-70],r15
       mov       dword ptr [rbp-68],0FFFFFFFF
       mov       rsi,[rax+18]
       mov       rcx,[rsi+18]
       test      rcx,rcx
       je        near ptr M23_L15
M23_L01:
       mov       rsi,[rcx+18]
       mov       r15,[rsi+10]
       test      r15,r15
       je        near ptr M23_L16
M23_L02:
       mov       rdi,7F76474A0D68
       mov       rax,7F7647CEF820
       call      rax
       cmp       dword ptr [rax],4
       jle       near ptr M23_L17
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        near ptr M23_L17
M23_L03:
       mov       r14,[rax+10]
       test      r14,r14
       jne       short M23_L04
       call      qword ptr [7F75C950C3F0]; System.Threading.Thread.InitializeCurrentThread()
       mov       r14,rax
M23_L04:
       mov       [rbp-0E0],r14
       mov       rsi,[r14+8]
       mov       [rbp-0E8],rsi
       mov       rsi,[r14+10]
       mov       [rbp-0F0],rsi
       mov       rdi,[r15+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M23_L06
M23_L05:
       lea       rdi,[rbp-70]
       call      rax
       jmp       short M23_L07
M23_L06:
       mov       rdi,r15
       mov       rsi,7F75C9DB8060
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M23_L05
M23_L07:
       mov       rsi,[rbp-0F0]
       cmp       rsi,[r14+10]
       je        short M23_L08
       lea       rdi,[r14+10]
       call      CORINFO_HELP_ASSIGN_REF
M23_L08:
       mov       rdi,[r14+8]
       mov       r15,rdi
       mov       rsi,[rbp-0E8]
       cmp       rsi,r15
       je        short M23_L10
       lea       rdi,[r14+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      r15,r15
       je        short M23_L09
       cmp       qword ptr [r15+10],0
       jne       near ptr M23_L13
M23_L09:
       cmp       qword ptr [rbp-0E8],0
       jne       short M23_L12
M23_L10:
       mov       rdi,[rbp-60]
       mov       rax,7F6DE18013E8
       cmp       rdi,[rax]
       jne       near ptr M23_L18
       vmovdqu   xmm0,xmmword ptr [rbp-58]
       vmovdqu   xmmword ptr [rbp-0C0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-0D0]
       vmovdqu   ymmword ptr [rbp-90],ymm0
       xor       r15d,r15d
M23_L11:
       mov       [rbp-90],r15
       vmovdqu   ymm0,ymmword ptr [rbp-90]
       vmovdqu   ymmword ptr [rbx],ymm0
       mov       word ptr [rbx+8],0
       mov       byte ptr [rbx+0A],1
       mov       rax,rbx
       vzeroupper
       add       rsp,0D0
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M23_L12:
       mov       rsi,[rbp-0E8]
       cmp       qword ptr [rsi+10],0
       je        short M23_L10
M23_L13:
       mov       rdi,r15
       mov       rsi,[rbp-0E8]
       call      qword ptr [7F75C9E66E98]
       jmp       near ptr M23_L10
M23_L14:
       mov       rdi,rsi
       mov       rsi,7F75C9DB7000
       call      qword ptr [7F75C8E2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       jmp       near ptr M23_L00
M23_L15:
       mov       rdi,rax
       mov       rsi,7F75C9DB7C78
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rcx,rdi
       jmp       near ptr M23_L01
M23_L16:
       mov       rdi,rcx
       mov       rsi,7F75C9DB7ED8
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r15,rax
       jmp       near ptr M23_L02
M23_L17:
       mov       edi,4
       call      qword ptr [7F75C9E66490]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       near ptr M23_L03
M23_L18:
       mov       r15,[rbp-60]
       test      r15,r15
       jne       short M23_L19
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       call      qword ptr [7F75C9E66A48]
       mov       [rbp-60],r15
M23_L19:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0A0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-0B0]
       vmovdqu   ymmword ptr [rbp-90],ymm0
       jmp       near ptr M23_L11
       push      rax
       mov       rsi,[rbp-0F0]
       mov       rax,[rbp-0E0]
       cmp       rsi,[rax+10]
       je        short M23_L20
       lea       rdi,[rax+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-0E0]
M23_L20:
       mov       rbx,[rax+8]
       mov       rsi,[rbp-0E8]
       cmp       rsi,rbx
       je        short M23_L23
       lea       rdi,[rax+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      rbx,rbx
       je        short M23_L21
       cmp       qword ptr [rbx+10],0
       jne       short M23_L22
M23_L21:
       cmp       qword ptr [rbp-0E8],0
       je        short M23_L23
       mov       rsi,[rbp-0E8]
       cmp       qword ptr [rsi+10],0
       je        short M23_L23
M23_L22:
       mov       rdi,rbx
       mov       rsi,[rbp-0E8]
       call      qword ptr [7F75C9E66E98]
M23_L23:
       nop
       vzeroupper
       add       rsp,8
       ret
; Total bytes of code 814
```
```assembly
; System.Threading.Thread.InitializeCurrentThread()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,68
       lea       rbp,[rsp+90]
       xor       eax,eax
       mov       [rbp-30],rax
       lea       rdi,[rbp-30]
       mov       [rbp-90],rdi
       lea       rdi,[rbp-88]
       call      qword ptr [7F75C89CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-90]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7F75C89CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rbx,[rbp-30]
       call      qword ptr [7F75C89D0B98]
       lea       rdi,[rax+10]
       mov       rsi,[rbp-30]
       call      qword ptr [7F75C89CEEB8]; CORINFO_HELP_ASSIGN_REF
       mov       rax,rbx
       add       rsp,68
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 123
```
```assembly
; Kevlar.KevlarProperties.CopyChangedValuesTo(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-88],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       vmovdqa   xmmword ptr [rbp-40],xmm8
       mov       [rbp-30],rax
       mov       rbx,rdi
       mov       r15,rsi
       mov       r14,rdx
       mov       r13,[rbx+10]
       mov       r12,[rbx+38]
       mov       rax,[rbx+40]
       mov       [rbp-98],rax
       cmp       qword ptr [r15+10],0
       jne       short M25_L05
M25_L00:
       cmp       qword ptr [r15+18],0
       jne       short M25_L06
M25_L01:
       xor       ecx,ecx
M25_L02:
       xor       edi,edi
       mov       [rbp-78],rdi
       test      r13,r13
       mov       [rbp-90],rcx
       jne       near ptr M25_L07
M25_L03:
       cmp       qword ptr [rbx+18],0
       jne       near ptr M25_L08
M25_L04:
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M25_L05:
       vmovdqu   xmm0,xmmword ptr [r15+38]
       vmovdqu   xmmword ptr [rbp-88],xmm0
       mov       rsi,r12
       mov       rdx,rax
       lea       rdi,[rbp-88]
       call      qword ptr [7F75C9E67048]
       test      eax,eax
       mov       rax,[rbp-98]
       je        short M25_L00
       mov       rcx,[r15+10]
       mov       [rbp-90],rcx
       mov       rcx,[rbp-90]
       jmp       short M25_L02
M25_L06:
       mov       rdi,[r15+18]
       mov       rsi,r12
       mov       rdx,rax
       lea       rcx,[rbp-78]
       cmp       [rdi],edi
       call      qword ptr [7F75C9E00BB0]
       test      eax,eax
       mov       rax,[rbp-98]
       je        near ptr M25_L01
       mov       rcx,[rbp-78]
       jmp       near ptr M25_L02
M25_L07:
       mov       rdi,r13
       mov       rdx,[r13]
       mov       rdx,[rdx+40]
       call      qword ptr [rdx+20]
       test      eax,eax
       je        near ptr M25_L03
       mov       rdi,r13
       mov       rsi,[rbp-90]
       call      qword ptr [7F75C9DC7A50]
       test      eax,eax
       jne       near ptr M25_L03
       mov       rsi,r12
       mov       rdx,[rbp-98]
       mov       rdi,r14
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,[rbp-90]
       call      qword ptr [7F75C9DC7A50]
       test      eax,eax
       je        near ptr M25_L03
       mov       rdx,r12
       mov       rcx,[rbp-98]
       mov       rdi,r13
       mov       rsi,r14
       mov       rax,[r13]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
       jmp       near ptr M25_L03
M25_L08:
       mov       rdi,[rbx+18]
       lea       rsi,[rbp-58]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC78A0]
       jmp       short M25_L10
M25_L09:
       mov       rdi,[rbp-40]
       vmovdqu   xmm0,xmmword ptr [rbp-40]
       vmovdqu   xmmword ptr [rbp-70],xmm0
       mov       rsi,[rbp-30]
       mov       [rbp-60],rsi
       mov       rsi,[rbp-68]
       mov       rdx,[rbp-60]
       mov       rcx,r15
       mov       r8,r14
       call      qword ptr [7F75C9DC7A80]; Kevlar.KevlarProperties.CopyChangedValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
M25_L10:
       lea       rdi,[rbp-58]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F75C9DC7900]
       test      eax,eax
       jne       short M25_L09
       jmp       near ptr M25_L04
; Total bytes of code 469
```
```assembly
; Kevlar.KevlarProperties.Find(PropertyIdentity)
       push      rbp
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+30]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-28],rsi
       mov       [rbp-30],rdx
       mov       rbx,rdi
       cmp       qword ptr [rbx+10],0
       jne       short M26_L02
M26_L00:
       cmp       qword ptr [rbx+18],0
       jne       short M26_L03
M26_L01:
       xor       eax,eax
       add       rsp,28
       pop       rbx
       pop       rbp
       ret
M26_L02:
       vmovdqu   xmm0,xmmword ptr [rbx+38]
       vmovdqu   xmmword ptr [rbp-20],xmm0
       mov       rsi,[rbp-28]
       mov       rdx,[rbp-30]
       lea       rdi,[rbp-20]
       call      qword ptr [7F75C9E67048]
       test      eax,eax
       je        short M26_L00
       mov       rax,[rbx+10]
       add       rsp,28
       pop       rbx
       pop       rbp
       ret
M26_L03:
       mov       rdi,[rbx+18]
       mov       rsi,[rbp-28]
       mov       rdx,[rbp-30]
       lea       rcx,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F75C9E00BB0]
       test      eax,eax
       je        short M26_L01
       mov       rax,[rbp-10]
       add       rsp,28
       pop       rbx
       pop       rbp
       ret
; Total bytes of code 143
```
```assembly
; Kevlar.KevlarProperties.RemoveMissingValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       push      r15
       push      r14
       push      rbx
       sub       rsp,18
       lea       rbp,[rsp+30]
       mov       [rbp-20],rsi
       mov       [rbp-28],rdx
       mov       rbx,rdi
       mov       r14,rcx
       mov       r15,r8
       test      rbx,rbx
       jne       short M27_L01
M27_L00:
       add       rsp,18
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M27_L01:
       mov       rdi,rbx
       mov       rax,[rbx]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       je        short M27_L00
       mov       rsi,[rbp-20]
       mov       rdx,[rbp-28]
       mov       rdi,r14
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       test      rax,rax
       je        short M27_L02
       mov       rdi,rax
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       jne       short M27_L00
M27_L02:
       mov       rsi,[rbp-20]
       mov       rdx,[rbp-28]
       mov       rdi,r15
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,rbx
       call      qword ptr [7F75C9DC7A50]
       test      eax,eax
       je        short M27_L00
       mov       rsi,[rbp-20]
       mov       rdx,[rbp-28]
       mov       rdi,r15
       call      qword ptr [7F75C9DC7A68]
       jmp       short M27_L00
; Total bytes of code 160
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Return(System.__Canon)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,38
       lea       rbp,[rsp+60]
       mov       [rbp-30],rdi
       mov       rbx,rdi
       mov       r15,rsi
       test      r15,r15
       je        near ptr M28_L04
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M28_L05
       mov       rdi,rbx
       mov       rsi,r15
       call      qword ptr [7F75C9DC72B8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       je        near ptr M28_L08
       mov       r14,[rbx+10]
       test      r14,r14
       je        near ptr M28_L17
       mov       rdi,r14
       call      qword ptr [7F75C98BDCE0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       r13d,eax
       xor       r12d,r12d
       mov       rdi,[r14+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M28_L14
M28_L00:
       mov       rdi,[r14+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M28_L21
       mov       esi,r13d
       mov       rax,[rdi+rsi*8+10]
       mov       [rbp-58],rax
       cmp       [rax],al
       lea       rdi,[rax+10]
       test      rdi,rdi
       je        near ptr M28_L18
       mov       rsi,r15
       xor       edx,edx
       call      00007F7647274060
       test      rax,rax
       je        near ptr M28_L03
       mov       rcx,[rbp-58]
       lea       rdi,[rcx+20]
       mov       rsi,[rcx+8]
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       je        near ptr M28_L12
       mov       r8d,[rsi+8]
M28_L01:
       cmp       edx,r8d
       jae       near ptr M28_L21
       mov       r9d,edx
       shl       r9,4
       mov       [rbp-50],r9
       mov       r10d,[rsi+r9+18]
       mov       r11,rax
       sar       r11,20
       inc       r11d
       movsxd    r11,r11d
       shl       r11,20
       or        r10,r11
       mov       [rbp-40],rax
       lock cmpxchg [rdi],r10
       cmp       rax,[rbp-40]
       jne       near ptr M28_L11
       mov       rdi,[rcx+8]
       mov       [rbp-34],edx
       cmp       edx,[rdi+8]
       jae       near ptr M28_L21
       lea       rdi,[rdi+r9+10]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       r15,[rbp-58]
       lea       rdi,[r15+18]
       mov       rsi,[r15+8]
       mov       r15d,[rbp-34]
M28_L02:
       mov       rax,[rdi]
       mov       [rbp-48],rax
       cmp       r15d,[rsi+8]
       jae       near ptr M28_L21
       mov       r14,[rbp-50]
       mov       [rsi+r14+18],eax
       mov       rcx,rax
       sar       rcx,20
       inc       ecx
       movsxd    rcx,ecx
       shl       rcx,20
       mov       edx,r15d
       or        rcx,rdx
       lock cmpxchg [rdi],rcx
       cmp       rax,[rbp-48]
       jne       short M28_L02
M28_L03:
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M28_L20
       add       rsp,38
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M28_L04:
       mov       edi,29
       mov       rsi,7F75C92A54F0
       call      qword ptr [7F75C8E2EF88]
       mov       rdi,rax
       call      qword ptr [7F75C9E66478]
       int       3
M28_L05:
       mov       rdi,[rbx]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       r14,[rsi+40]
       test      r14,r14
       je        short M28_L06
       jmp       short M28_L07
M28_L06:
       mov       rsi,7F75C9E4DAF0
       call      qword ptr [7F75C8E2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       r14,rax
M28_L07:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       r11,r14
       mov       rsi,r15
       mov       rax,r14
       add       rsp,38
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [rax]
M28_L08:
       mov       rdi,[rbx]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       r14,[rsi+40]
       test      r14,r14
       je        short M28_L09
       jmp       short M28_L10
M28_L09:
       mov       rsi,7F75C9E4DAF0
       call      qword ptr [7F75C8E2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       r14,rax
M28_L10:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       r11,r14
       mov       rsi,r15
       mov       rax,r14
       add       rsp,38
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [rax]
M28_L11:
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       jne       near ptr M28_L01
M28_L12:
       inc       r13d
       mov       rcx,[r14+8]
       cmp       [rcx+8],r13d
       jne       short M28_L13
       xor       r13d,r13d
M28_L13:
       inc       r12d
       cmp       [rcx+8],r12d
       jg        near ptr M28_L00
M28_L14:
       mov       rdi,[rbx]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       r14,[rsi+40]
       test      r14,r14
       je        short M28_L15
       jmp       short M28_L16
M28_L15:
       mov       rsi,7F75C9E4DAF0
       call      qword ptr [7F75C8E2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       r14,rax
M28_L16:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       r11,r14
       mov       rsi,r15
       call      qword ptr [r14]
       jmp       near ptr M28_L03
M28_L17:
       mov       rdi,rbx
       call      qword ptr [7F75C9DC67D8]
       mov       r14d,eax
       mov       rdi,[rbx+8]
       lea       esi,[r14*8]
       cmp       esi,[rdi+8]
       jae       short M28_L21
       lea       esi,[r14*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M28_L19
M28_L18:
       call      qword ptr [7F75C9E66460]
       int       3
M28_L19:
       mov       rsi,r15
       call      00007F7647274040
       test      rax,rax
       je        near ptr M28_L03
       mov       rdi,rbx
       mov       rsi,r15
       mov       rdx,rax
       mov       ecx,r14d
       call      qword ptr [7F75C9DC74F8]
       jmp       near ptr M28_L03
M28_L20:
       mov       rdi,rbx
       add       rsp,38
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F75C9DC7528]
M28_L21:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 854
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F75C89CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F75C89CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; PoolContextProbe+<>c.<NestedContext>b__6_1(Kevlar.KevlarContext)
       xor       eax,eax
       mov       rdx,100000000002A
       ret
; Total bytes of code 13
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](Kevlar.KevlarContext, System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
M31_L00:
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,3E8
       vzeroupper
       lea       rbp,[rsp+410]
       xor       eax,eax
       mov       [rbp-3D8],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-3D0],xmm8
       mov       rax,0FFFFFFFFFFFFFC70
M31_L01:
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       add       rax,30
       jne       short M31_L01
       mov       [rbp-30],rax
       mov       rbx,rsi
       mov       r15,rdx
       test      r15,r15
       je        near ptr M31_L58
       test      rbx,rbx
       je        near ptr M31_L59
       mov       rax,[rdi+38]
       test      rax,rax
       jne       near ptr M31_L60
       cmp       byte ptr [rdi+48],0
       jne       near ptr M31_L61
       mov       r14,[rdi+10]
       mov       r13,[rdi+40]
       mov       rdi,7F6DE1801410
       mov       r12,[rdi]
       test      r12,r12
       je        near ptr M31_L62
M31_L02:
       mov       [rbp-358],r13
       mov       rcx,7F6DE1800BA0
       mov       rcx,[rcx]
       mov       rcx,[rcx+8]
       cmp       qword ptr [rcx+8],0
       jne       near ptr M31_L63
       xor       edi,edi
M31_L03:
       mov       [rbp-40],rdi
       mov       rdx,[rbx+68]
       mov       [rbp-3D0],rdx
       test      rdx,rdx
       jne       near ptr M31_L64
M31_L04:
       mov       r13,[rbx+68]
       mov       rdx,[rbx+38]
       mov       [rbp-370],rdx
       mov       rdi,7F6DE18013C0
       mov       rsi,[rdi]
       mov       [rbp-380],rsi
       cmp       dword ptr [rsi+1C],0
       jne       near ptr M31_L65
M31_L05:
       mov       rsi,[rbp-380]
       mov       r8,[rsi+10]
       mov       [rbp-390],r8
       xor       r9d,r9d
       mov       [rbp-64],r9d
       test      r8,r8
       je        near ptr M31_L66
       mov       rdi,7F76474A0D68
       mov       r10,7F7647CEF820
       call      r10
       add       rax,48
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M31_L75
M31_L06:
       dec       eax
       mov       rcx,[rbp-390]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M31_L76
       and       r8d,eax
M31_L07:
       mov       eax,r8d
       xor       r8d,r8d
M31_L08:
       mov       rdi,[rcx+8]
       mov       [rbp-6C],r8d
       cmp       [rdi+8],r8d
       jle       near ptr M31_L81
       cmp       eax,[rdi+8]
       jae       near ptr M31_L102
       mov       [rbp-68],eax
       mov       esi,eax
       mov       r9,[rdi+rsi*8+10]
       mov       [rbp-3A0],r9
       mov       r10,[r9+10]
       mov       [rbp-3A8],r10
       test      r10,r10
       jne       near ptr M31_L53
M31_L09:
       lea       r10,[r9+18]
       mov       rdx,[r9+8]
       mov       rdi,[r10]
       mov       esi,edi
       cmp       esi,0FFFFFFFF
       je        near ptr M31_L78
       mov       r11d,[rdx+8]
       mov       [rbp-344],r11d
M31_L10:
       cmp       esi,r11d
       jae       near ptr M31_L102
       mov       r8d,esi
       shl       r8,4
       mov       r11d,[rdx+r8+18]
       mov       rax,rdi
       sar       rax,20
       inc       eax
       cdqe
       shl       rax,20
       or        r11,rax
       mov       rax,rdi
       lock cmpxchg [r10],r11
       cmp       rax,rdi
       jne       near ptr M31_L77
       mov       rax,[r9+8]
       mov       rdx,rax
       mov       edi,[rdx+8]
       cmp       esi,edi
       jae       near ptr M31_L102
       mov       rdx,[rdx+r8+10]
       lea       rdi,[rax+r8+10]
       xor       eax,eax
       mov       [rdi],rax
       add       r9,20
M31_L11:
       mov       rax,[r9]
       mov       [rbp-78],rax
       mov       [rdi+8],eax
       mov       r8,rax
       sar       r8,20
       inc       r8d
       movsxd    r8,r8d
       shl       r8,20
       mov       r10d,esi
       or        r8,r10
       lock cmpxchg [r9],r8
       cmp       rax,[rbp-78]
       jne       short M31_L11
       test      rdx,rdx
       je        near ptr M31_L78
       mov       rax,[rbp-380]
M31_L12:
       test      rdx,rdx
       je        near ptr M31_L82
M31_L13:
       mov       rcx,rdx
M31_L14:
       cmp       dword ptr [rax+1C],0
       jne       near ptr M31_L84
       mov       rdx,rcx
M31_L15:
       mov       [rbp-378],rdx
       lea       rdi,[rdx+68]
       mov       rsi,r13
       call      CORINFO_HELP_ASSIGN_REF
       xor       edi,edi
       mov       r13,[rbp-378]
       mov       [r13+60],edi
       lea       rdi,[r13+38]
       mov       rsi,[rbp-370]
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r13+30]
       mov       rsi,[rbp-358]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,0FFFFFFFF00000000
       mov       [r13+58],rdi
       xor       edi,edi
       mov       [r13+40],rdi
       cmp       qword ptr [r13+18],0
       je        near ptr M31_L85
M31_L16:
       mov       rdi,[rbx+8]
       mov       rsi,[r13+18]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC77F8]; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       mov       rdi,[r13+18]
       mov       rsi,[r13+8]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC77F8]; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       mov       rdi,[r13+8]
       mov       rsi,[rbx+8]
       cmp       [rdi],dil
       mov       rax,[rsi+28]
       add       rax,8
       lock inc  dword ptr [rax]
       mov       rsi,[rsi+28]
       lea       rdi,[rdi+28]
       call      CORINFO_HELP_ASSIGN_REF
       mov       byte ptr [r13+65],1
       mov       [rbp-360],r13
       mov       rdi,7F6DE18013E0
       mov       rax,[rdi]
       test      rax,rax
       je        near ptr M31_L86
M31_L17:
       mov       [rbp-98],r14
       mov       [rbp-90],rax
       mov       [rbp-88],r15
       mov       [rbp-80],r12
       cmp       qword ptr [rbp-90],0
       je        near ptr M31_L87
       cmp       qword ptr [rbp-98],0
       jne       near ptr M31_L91
       mov       r15,[rbp-90]
       mov       rdi,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       cmp       [r15+18],rdi
       jne       near ptr M31_L90
       mov       rdi,[r15+8]
       mov       r15,[rbp-88]
       mov       r14,[rbp-80]
       mov       rdi,[rdi]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M31_L55
M31_L18:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0F0],xmm0
       vmovdqu   xmmword ptr [rbp-0E8],xmm0
       mov       [rbp-0D8],r15
       mov       [rbp-0D0],r14
       mov       [rbp-100],r13
       mov       dword ptr [rbp-0F8],0FFFFFFFF
       mov       rdi,[rsi+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M31_L56
M31_L19:
       mov       rsi,[rdi+18]
       mov       rax,[rsi+10]
       test      rax,rax
       je        near ptr M31_L57
       mov       rdi,rax
M31_L20:
       lea       rsi,[rbp-100]
       call      qword ptr [7F75C9DC6CB8]; System.Runtime.CompilerServices.AsyncMethodBuilderCore.Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       mov       rdi,[rbp-0F0]
       mov       rax,7F6DE18013E8
       cmp       rdi,[rax]
       jne       near ptr M31_L88
       mov       r15,[rbp-0E8]
       mov       r14d,[rbp-0E0]
       xor       r12d,r12d
M31_L21:
       xor       eax,eax
       mov       r9d,1
M31_L22:
       test      r12,r12
       jne       near ptr M31_L93
M31_L23:
       mov       [rbp-3D8],r15
       mov       [rbp-2F4],r14d
       test      r15,r15
       sete      r12b
       movzx     r12d,r12b
       mov       r15,[rbp-40]
       test      r15,r15
       jne       near ptr M31_L98
M31_L24:
       mov       rdi,7F6DE1800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M31_L99
M31_L25:
       mov       rdi,[r13+20]
       mov       [rbp-3C0],rdi
       xor       edi,edi
       mov       [rbp-22C],edi
       cmp       qword ptr [rbp-3C0],0
       je        near ptr M31_L35
       mov       rdi,[rbp-3C0]
       call      00007F76470E6020
       test      eax,eax
       je        near ptr M31_L36
M31_L26:
       mov       dword ptr [rbp-22C],1
       cmp       byte ptr [r13+64],0
       jne       near ptr M31_L37
       mov       r15,[r13+8]
M31_L27:
       mov       r13,[r13+18]
       mov       rbx,[rbx+8]
       mov       rdi,[r15+28]
       cmp       dword ptr [rdi+0C],0
       jne       near ptr M31_L38
M31_L28:
       mov       r14,[r13+10]
       mov       r12,[r13+38]
       mov       rax,[r13+40]
       mov       [rbp-3E0],rax
       test      r14,r14
       jne       near ptr M31_L39
M31_L29:
       cmp       qword ptr [r13+18],0
       jne       near ptr M31_L41
M31_L30:
       mov       r14,[r15+10]
       mov       r12,[r15+38]
       mov       rax,[r15+40]
       mov       [rbp-3E8],rax
       cmp       qword ptr [r13+10],0
       jne       near ptr M31_L44
M31_L31:
       cmp       qword ptr [r13+18],0
       jne       near ptr M31_L45
M31_L32:
       xor       ecx,ecx
M31_L33:
       xor       edi,edi
       mov       [rbp-2C8],rdi
       test      r14,r14
       mov       [rbp-3C8],rcx
       jne       near ptr M31_L46
M31_L34:
       cmp       qword ptr [r15+18],0
       je        near ptr M31_L50
       jmp       near ptr M31_L47
M31_L35:
       xor       edi,edi
       call      qword ptr [7F75C9E66478]
       int       3
M31_L36:
       mov       rdi,[rbp-3C0]
       call      qword ptr [7F75C9E664D8]
       jmp       near ptr M31_L26
M31_L37:
       mov       r15,[r13+10]
       jmp       near ptr M31_L27
M31_L38:
       mov       rdi,[r13+28]
       cmp       dword ptr [rdi+0C],0
       jne       near ptr M31_L28
       mov       rdi,[rbx+28]
       cmp       dword ptr [rdi+0C],0
       jne       near ptr M31_L28
       mov       rdi,[rbx+28]
       mov       esi,1
       cmp       [rdi],edi
       call      qword ptr [7F75C9E66A00]
       jmp       near ptr M31_L28
M31_L39:
       mov       rdi,r14
       mov       rcx,[r14]
       mov       rcx,[rcx+40]
       call      qword ptr [rcx+20]
       test      eax,eax
       je        near ptr M31_L29
       mov       rsi,r12
       mov       rdx,[rbp-3E0]
       mov       rdi,r15
       call      qword ptr [7F75C9DC7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       test      rax,rax
       je        short M31_L40
       mov       rdi,rax
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       jne       near ptr M31_L29
M31_L40:
       mov       rsi,r12
       mov       rdx,[rbp-3E0]
       mov       rdi,rbx
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,r14
       call      qword ptr [7F75C9DC7A50]
       test      eax,eax
       je        near ptr M31_L29
       mov       rsi,r12
       mov       rdx,[rbp-3E0]
       mov       rdi,rbx
       call      qword ptr [7F75C9DC7A68]
       jmp       near ptr M31_L29
M31_L41:
       mov       rdi,[r13+18]
       lea       rsi,[rbp-260]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC78A0]
       jmp       short M31_L43
M31_L42:
       mov       rdi,[rbp-248]
       vmovdqu   xmm0,xmmword ptr [rbp-248]
       vmovdqu   xmmword ptr [rbp-278],xmm0
       mov       rsi,[rbp-238]
       mov       [rbp-268],rsi
       mov       rsi,[rbp-270]
       mov       rdx,[rbp-268]
       mov       rcx,r15
       mov       r8,rbx
       call      qword ptr [7F75C9DC7A08]; Kevlar.KevlarProperties.RemoveMissingValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
M31_L43:
       lea       rdi,[rbp-260]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F75C9DC7900]
       test      eax,eax
       jne       short M31_L42
       jmp       near ptr M31_L30
M31_L44:
       vmovdqu   xmm0,xmmword ptr [r13+38]
       vmovdqu   xmmword ptr [rbp-2D8],xmm0
       mov       rsi,r12
       mov       rdx,rax
       lea       rdi,[rbp-2D8]
       call      qword ptr [7F75C9E67048]
       test      eax,eax
       mov       rax,[rbp-3E8]
       je        near ptr M31_L31
       mov       rcx,[r13+10]
       mov       [rbp-3C8],rcx
       mov       rcx,[rbp-3C8]
       jmp       near ptr M31_L33
M31_L45:
       mov       rdi,[r13+18]
       mov       rsi,r12
       mov       rdx,rax
       lea       rcx,[rbp-2C8]
       cmp       [rdi],edi
       call      qword ptr [7F75C9E00BB0]
       test      eax,eax
       mov       rax,[rbp-3E8]
       je        near ptr M31_L32
       mov       rcx,[rbp-2C8]
       jmp       near ptr M31_L33
M31_L46:
       mov       rdi,r14
       mov       rdx,[r14]
       mov       rdx,[rdx+40]
       call      qword ptr [rdx+20]
       test      eax,eax
       je        near ptr M31_L34
       mov       rdi,r14
       mov       rsi,[rbp-3C8]
       call      qword ptr [7F75C9DC7A50]
       test      eax,eax
       jne       near ptr M31_L34
       mov       rsi,r12
       mov       rdx,[rbp-3E8]
       mov       rdi,rbx
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,[rbp-3C8]
       call      qword ptr [7F75C9DC7A50]
       test      eax,eax
       je        near ptr M31_L34
       mov       rdx,r12
       mov       rcx,[rbp-3E8]
       mov       rdi,r14
       mov       rsi,rbx
       mov       rax,[r14]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
       jmp       near ptr M31_L34
M31_L47:
       mov       rdi,[r15+18]
       lea       rsi,[rbp-2A8]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC78A0]
       jmp       short M31_L49
M31_L48:
       mov       rdi,[rbp-290]
       vmovdqu   xmm0,xmmword ptr [rbp-290]
       vmovdqu   xmmword ptr [rbp-2C0],xmm0
       mov       rsi,[rbp-280]
       mov       [rbp-2B0],rsi
       mov       rsi,[rbp-2B8]
       mov       rdx,[rbp-2B0]
       mov       rcx,r13
       mov       r8,rbx
       call      qword ptr [7F75C9DC7A80]; Kevlar.KevlarProperties.CopyChangedValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
M31_L49:
       lea       rdi,[rbp-2A8]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F75C9DC7900]
       test      eax,eax
       jne       short M31_L48
M31_L50:
       mov       rdi,[rbp-3C0]
       call      00007F76470E6790
       test      eax,eax
       je        short M31_L51
       mov       edi,eax
       mov       rsi,[rbp-3C0]
       call      qword ptr [7F75C9E664F0]
       nop
M31_L51:
       call      M31_L105
       nop
       cmp       qword ptr [rbp-3D8],0
       jne       near ptr M31_L100
       mov       esi,[rbp-2F4]
       mov       [rbp-30],esi
       mov       byte ptr [rbp-2A],1
M31_L52:
       mov       rax,[rbp-38]
       mov       rdx,[rbp-30]
       add       rsp,3E8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M31_L53:
       lea       rdi,[r9+10]
       test      rdi,rdi
       je        near ptr M31_L80
       xor       esi,esi
       mov       rdx,r10
       call      00007F7647274060
       mov       r10,[rbp-3A8]
       cmp       rax,r10
       mov       r9,[rbp-3A0]
       jne       near ptr M31_L09
       mov       rdx,r10
       mov       rax,[rbp-380]
       jmp       near ptr M31_L12
M31_L54:
       mov       rdi,7F75C7E3B1F8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M31_L54
       jmp       near ptr M31_L67
M31_L55:
       mov       rsi,7F75C9DB7000
       call      qword ptr [7F75C8E2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M31_L18
M31_L56:
       mov       rdi,rsi
       mov       rsi,7F75C9DB7C78
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M31_L19
M31_L57:
       mov       rsi,7F75C9DB7ED8
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M31_L20
M31_L58:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,902
       mov       rsi,7F75C98ED998
       call      qword ptr [7F75C8E2EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F75C950E2B0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M31_L59:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,910
       mov       rsi,7F75C98ED998
       call      qword ptr [7F75C8E2EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F75C950E2B0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M31_L60:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       rsi,rbx
       mov       rdx,r15
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7570]
       mov       [rbp-340],rax
       mov       [rbp-338],rdx
       mov       rax,[rbp-340]
       mov       rdx,[rbp-338]
       add       rsp,3E8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M31_L61:
       call      qword ptr [7F75C98BE508]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M31_L62:
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       rsi,7F6DE1801408
       mov       rsi,[rsi]
       mov       rdi,r12
       mov       rdx,offset Kevlar.Shield+<>c__60`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__60_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F75C8E26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F6DE1801410
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M31_L02
M31_L63:
       call      00007F75C8E18AE0
       mov       rdi,rax
       jmp       near ptr M31_L03
M31_L64:
       cmp       dword ptr [rdx+20],0
       je        near ptr M31_L04
       mov       rsi,r13
       xor       edx,edx
       call      qword ptr [7F75C98BE868]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rdi,rbx
       call      qword ptr [7F75C9E67120]
       lea       rdi,[rbx+70]
       mov       rsi,[rbp-3D0]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,rbx
       call      qword ptr [7F75C98BE8E0]
       mov       rdi,rax
       mov       esi,edx
       call      qword ptr [7F75C98BE7F0]
       mov       [rbp-330],rax
       mov       [rbp-328],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-330]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       jmp       near ptr M31_L52
M31_L65:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F75C9DC67C0]
       jmp       near ptr M31_L05
M31_L66:
       mov       rdi,7F76474A0D68
       mov       r9,7F7647CEF820
       call      r9
       add       rax,3C
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M31_L68
       jmp       near ptr M31_L54
M31_L67:
       mov       [rax+10],edi
M31_L68:
       dec       edi
       imul      edi,9E3779B9
       mov       rax,[rbp-380]
       mov       edx,[rax+18]
       test      edx,edx
       jge       short M31_L69
       mov       r9d,edi
       mov       esi,[rax+20]
       imul      r9,rsi
       shr       r9,20
       jmp       short M31_L70
M31_L69:
       mov       r9d,edi
       and       r9d,edx
M31_L70:
       mov       ecx,r9d
       mov       rdi,[rax+8]
       mov       [rbp-64],ecx
       lea       edx,[rcx*8]
       cmp       edx,[rdi+8]
       jae       near ptr M31_L102
       lea       rdi,[rdi+rdx*8+10]
       mov       r8,[rdi]
       mov       rdx,r8
       mov       [rbp-398],rdx
       test      rdx,rdx
       je        short M31_L72
       xor       esi,esi
       call      00007F7647274060
       mov       rdi,[rbp-398]
       cmp       rax,rdi
       mov       rax,[rbp-380]
       je        short M31_L73
M31_L71:
       xor       edx,edx
       jmp       short M31_L74
M31_L72:
       mov       rax,[rbp-380]
       jmp       short M31_L71
M31_L73:
       mov       rdx,rdi
M31_L74:
       jmp       near ptr M31_L12
M31_L75:
       mov       rax,7F75C7E3B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-70],eax
       test      eax,eax
       je        short M31_L75
       mov       rdi,7F76474A0D68
       mov       rcx,7F7647CEF820
       call      rcx
       add       rax,48
       mov       ecx,[rbp-70]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M31_L06
M31_L76:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M31_L07
M31_L77:
       mov       rdi,[r10]
       mov       esi,edi
       cmp       esi,0FFFFFFFF
       mov       r11d,[rbp-344]
       jne       near ptr M31_L10
M31_L78:
       mov       eax,[rbp-68]
       inc       eax
       mov       edx,eax
       mov       rcx,[rbp-390]
       mov       rax,[rcx+8]
       cmp       [rax+8],edx
       jne       short M31_L79
       xor       edx,edx
M31_L79:
       mov       r8d,[rbp-6C]
       inc       r8d
       mov       eax,edx
       mov       rcx,[rbp-390]
       jmp       near ptr M31_L08
M31_L80:
       call      qword ptr [7F75C9E66460]
       int       3
M31_L81:
       xor       edx,edx
       mov       rax,[rbp-380]
       jmp       near ptr M31_L12
M31_L82:
       cmp       qword ptr [rbp-390],0
       je        short M31_L83
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       rcx,rax
       mov       [rbp-3B0],rcx
       mov       rdi,rcx
       call      qword ptr [7F75C9DC6868]; Kevlar.KevlarContext..ctor()
       mov       rcx,[rbp-3B0]
       mov       rax,rcx
       mov       rcx,rax
       mov       rax,[rbp-380]
       jmp       near ptr M31_L14
M31_L83:
       mov       rdi,rax
       mov       esi,[rbp-64]
       call      qword ptr [7F75C9DC6820]
       mov       rdx,rax
       mov       rax,[rbp-380]
       jmp       near ptr M31_L13
M31_L84:
       mov       [rbp-388],rcx
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-380]
       mov       dil,[rdi+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-388]
       mov       r11,7F75C7E406A0
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F75C9DC67C0]
       mov       rdx,rax
       jmp       near ptr M31_L15
M31_L85:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-368],rax
       mov       rdi,rax
       call      qword ptr [7F75C9DC6880]; Kevlar.KevlarProperties..ctor()
       lea       rdi,[r13+18]
       mov       rsi,[rbp-368]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M31_L16
M31_L86:
       mov       rdi,offset MT_System.Func<Kevlar.Internal.ShieldEngine+ContextAsyncCallback<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, System.Int32>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<Kevlar.Outcome<System.Int32>>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-3B8],rax
       mov       rsi,7F6DE18013D8
       mov       rsi,[rsi]
       mov       rdi,rax
       mov       rdx,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       call      qword ptr [7F75C8E26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F6DE18013E0
       mov       rsi,[rbp-3B8]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-3B8]
       jmp       near ptr M31_L17
M31_L87:
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       rdi,r12
       mov       rsi,7F75C4A0B5D8
       call      qword ptr [7F75C9505608]
       mov       rdi,r12
       call      qword ptr [7F75C98BE8E0]
       mov       esi,edx
       xor       r12d,r12d
       xor       r15d,r15d
       mov       [rbp-2F8],r15d
       mov       dword ptr [rbp-2FC],1
       mov       r14d,esi
       mov       r15,rax
       mov       eax,[rbp-2F8]
       mov       r9d,[rbp-2FC]
       jmp       near ptr M31_L22
M31_L88:
       mov       r12,[rbp-0F0]
       test      r12,r12
       jne       short M31_L89
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       rdi,r12
       call      qword ptr [7F75C9E66A48]
       mov       [rbp-0F0],r12
M31_L89:
       xor       r15d,r15d
       xor       r14d,r14d
       jmp       near ptr M31_L21
M31_L90:
       mov       rdx,[rbp-88]
       mov       rcx,[rbp-80]
       lea       rsi,[rbp-0B8]
       mov       r8,r13
       mov       rdi,[r15+8]
       call      qword ptr [r15+18]
       jmp       short M31_L92
M31_L91:
       lea       rdi,[rbp-98]
       lea       rsi,[rbp-0B8]
       mov       r8,r13
       mov       rcx,[rbp-98]
       mov       rdx,offset MT_Kevlar.Continuation<System.Int32, Kevlar.Internal.ShieldEngine+ContextAsyncCallback<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, System.Int32>>
       call      qword ptr [7F75C9DC6A30]
M31_L92:
       mov       r12,[rbp-0B8]
       movsx     rax,word ptr [rbp-0B0]
       mov       r15d,eax
       movzx     r9d,byte ptr [rbp-0AE]
       mov       r14d,r9d
       mov       rdi,[rbp-0A8]
       mov       rax,rdi
       mov       edi,[rbp-0A0]
       mov       esi,edi
       mov       r9d,r14d
       mov       r14d,esi
       mov       rcx,rax
       mov       eax,r15d
       mov       r15,rcx
       jmp       near ptr M31_L22
M31_L93:
       mov       [rbp-2F8],eax
       mov       [rbp-2FC],r9d
       mov       rsi,r12
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F75C8E26838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       test      rax,rax
       je        short M31_L94
       mov       rdi,rax
       call      qword ptr [7F75C9DC7138]
       jmp       short M31_L95
M31_L94:
       mov       rdi,r12
       mov       esi,[rbp-2F8]
       mov       r11,7F75C7E406A8
       call      qword ptr [r11]
       cmp       eax,1
       sete      al
       movzx     eax,al
M31_L95:
       test      eax,eax
       je        near ptr M31_L101
       mov       rsi,r12
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F75C8E26838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r15,rax
       test      r15,r15
       je        short M31_L97
       mov       edi,[r15+34]
       and       edi,11000000
       cmp       edi,1000000
       je        short M31_L96
       mov       rdi,r15
       xor       esi,esi
       call      qword ptr [7F75C9E66418]
M31_L96:
       mov       rdi,[r15+38]
       mov       r14d,[r15+40]
       mov       r15,rdi
       jmp       near ptr M31_L23
M31_L97:
       mov       rdi,r12
       mov       esi,[rbp-2F8]
       mov       r11,7F75C7E406B0
       call      qword ptr [r11]
       mov       rdi,rax
       mov       r14d,edx
       mov       r15,rdi
       jmp       near ptr M31_L23
M31_L98:
       mov       rdi,7F6DE1800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F75C98BE9B8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M31_L24
       lea       rdi,[rbp-190]
       mov       rsi,[rbp-358]
       call      qword ptr [7F75C9DC71F8]
       mov       rdx,7F75C4A0B6A8
       mov       rdi,7F75C4A0B680
       test      r12d,r12d
       cmove     rdx,rdi
       lea       rdi,[rbp-190]
       mov       rsi,7F75C4A0B638
       call      qword ptr [7F75C9DC7210]
       call      00007F75C8E18AE0
       mov       rsi,rax
       mov       rdi,r15
       call      qword ptr [7F75C9E66AF0]
       mov       [rbp-198],rax
       lea       rdi,[rbp-198]
       call      qword ptr [7F75C9DC7240]
       mov       rdi,7F6DE1800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-190]
       xor       edx,edx
       call      qword ptr [7F75C9DC7258]
       jmp       near ptr M31_L24
M31_L99:
       lea       rdi,[rbp-228]
       mov       rsi,[rbp-358]
       call      qword ptr [7F75C9DC71F8]
       mov       rdx,7F75C4A0B6A8
       mov       rdi,7F75C4A0B680
       test      r12d,r12d
       cmove     rdx,rdi
       lea       rdi,[rbp-228]
       mov       rsi,7F75C4A0B638
       call      qword ptr [7F75C9DC7210]
       mov       rdi,7F6DE1800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-228]
       mov       esi,1
       xor       ecx,ecx
       call      qword ptr [7F75C9DC7270]
       jmp       near ptr M31_L25
M31_L100:
       mov       rdi,[rbp-3D8]
       mov       esi,[rbp-2F4]
       call      qword ptr [7F75C98BE7F0]
       mov       [rbp-320],rax
       mov       [rbp-318],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-320]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       jmp       near ptr M31_L52
M31_L101:
       mov       [rbp-60],r12
       mov       r12d,[rbp-2F8]
       mov       [rbp-58],r12w
       mov       r12d,[rbp-2FC]
       mov       [rbp-56],r12b
       mov       [rbp-50],r15
       mov       [rbp-48],r14d
       lea       rdi,[rsp]
       lea       rsi,[rbp-60]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,r13
       mov       rsi,rbx
       mov       rdx,[rbp-40]
       call      qword ptr [7F75C9DC7708]
       mov       [rbp-310],rax
       mov       [rbp-308],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-310]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       jmp       near ptr M31_L52
M31_L102:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
       sub       rsp,28
       vzeroupper
       cmp       dword ptr [rbp-22C],0
       je        short M31_L104
       cmp       qword ptr [rbp-3C0],0
       jne       short M31_L103
       xor       edi,edi
       call      qword ptr [7F75C9E66478]
       int       3
M31_L103:
       mov       rdi,[rbp-3C0]
       call      00007F76470E6790
       test      eax,eax
       je        short M31_L104
       mov       edi,eax
       mov       rsi,[rbp-3C0]
       call      qword ptr [7F75C9E664F0]
M31_L104:
       nop
       add       rsp,28
       ret
M31_L105:
       sub       rsp,28
       vzeroupper
       mov       rdi,7F6DE18013C0
       mov       rbx,[rdi]
       cmp       dword ptr [rbx+1C],0
       je        short M31_L106
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-360]
       mov       r11,7F75C7E406B8
       call      qword ptr [r11]
       jmp       near ptr M31_L129
M31_L106:
       mov       rdi,rbx
       mov       rsi,[rbp-360]
       call      qword ptr [7F75C9DC72B8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       jne       short M31_L107
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-360]
       mov       r11,7F75C7E406C0
       call      qword ptr [r11]
       jmp       near ptr M31_L129
M31_L107:
       mov       r15,[rbx+10]
       test      r15,r15
       je        near ptr M31_L120
       mov       rdi,7F76474A0D68
       mov       rax,7F7647CEF820
       call      rax
       add       rax,48
       mov       r14d,[rax+10]
       test      r14d,r14d
       jne       short M31_L109
M31_L108:
       mov       rdi,7F75C7E3B1A8
       mov       eax,1
       mov       r14d,eax
       lock xadd [rdi],r14d
       inc       r14d
       je        short M31_L108
       mov       rdi,7F76474A0D68
       mov       rax,7F7647CEF820
       call      rax
       add       rax,48
       mov       [rax+10],r14d
M31_L109:
       dec       r14d
       mov       r13d,[r15+18]
       test      r13d,r13d
       jl        short M31_L110
       and       r13d,r14d
       jmp       short M31_L111
M31_L110:
       mov       rdi,[r15+8]
       mov       edi,[rdi+8]
       mov       r13d,r14d
       imul      r13,[r15+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
M31_L111:
       xor       r14d,r14d
       mov       rdi,[r15+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M31_L119
M31_L112:
       mov       rdi,[r15+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M31_L127
       mov       esi,r13d
       mov       r12,[rdi+rsi*8+10]
       cmp       [r12],r12b
       lea       rdi,[r12+10]
       test      rdi,rdi
       je        near ptr M31_L125
       mov       rsi,[rbp-360]
       xor       edx,edx
       call      00007F7647274060
       test      rax,rax
       je        near ptr M31_L118
       lea       rdi,[r12+20]
       mov       rsi,[r12+8]
       mov       rax,[rdi]
       mov       ecx,eax
       cmp       ecx,0FFFFFFFF
       je        short M31_L114
M31_L113:
       cmp       ecx,[rsi+8]
       jae       near ptr M31_L127
       mov       edx,ecx
       shl       rdx,4
       mov       [rbp-350],rdx
       mov       r8d,[rsi+rdx+18]
       mov       r9,rax
       sar       r9,20
       inc       r9d
       movsxd    r9,r9d
       shl       r9,20
       or        r8,r9
       mov       [rbp-2E8],rax
       lock cmpxchg [rdi],r8
       cmp       rax,[rbp-2E8]
       je        short M31_L116
       mov       rax,[rdi]
       mov       ecx,eax
       cmp       ecx,0FFFFFFFF
       jne       short M31_L113
M31_L114:
       inc       r13d
       mov       rcx,[r15+8]
       cmp       [rcx+8],r13d
       jne       short M31_L115
       xor       r13d,r13d
M31_L115:
       inc       r14d
       cmp       [rcx+8],r14d
       jg        near ptr M31_L112
       jmp       near ptr M31_L119
M31_L116:
       mov       rdi,[r12+8]
       mov       [rbp-2DC],ecx
       cmp       ecx,[rdi+8]
       jae       near ptr M31_L127
       lea       rdi,[rdi+rdx+10]
       mov       rsi,[rbp-360]
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r12+18]
       mov       rcx,[r12+8]
       mov       r15d,[rbp-2DC]
M31_L117:
       mov       rax,[rdi]
       mov       [rbp-2F0],rax
       cmp       r15d,[rcx+8]
       jae       near ptr M31_L127
       mov       r14,[rbp-350]
       mov       [rcx+r14+18],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       esi,r15d
       or        rdx,rsi
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-2F0]
       jne       short M31_L117
M31_L118:
       cmp       dword ptr [rbx+1C],0
       je        near ptr M31_L129
       jmp       near ptr M31_L128
M31_L119:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-360]
       mov       r11,7F75C7E406C8
       call      qword ptr [r11]
       jmp       short M31_L118
M31_L120:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M31_L122
M31_L121:
       mov       rdi,7F75C7E3B1F8
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M31_L121
       mov       [rax+10],edi
M31_L122:
       dec       edi
       imul      r15d,edi,9E3779B9
       cmp       dword ptr [rbx+18],0
       jge       short M31_L123
       mov       r14d,r15d
       mov       r13d,[rbx+20]
       imul      r14,r13
       shr       r14,20
       jmp       short M31_L124
M31_L123:
       and       r15d,[rbx+18]
       mov       r14d,r15d
M31_L124:
       mov       rdi,[rbx+8]
       lea       esi,[r14*8]
       cmp       esi,[rdi+8]
       jae       short M31_L127
       lea       esi,[r14*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M31_L126
M31_L125:
       call      qword ptr [7F75C9E66460]
       int       3
M31_L126:
       mov       rsi,[rbp-360]
       call      00007F7647274040
       test      rax,rax
       je        near ptr M31_L118
       mov       rdi,rbx
       mov       rsi,[rbp-360]
       mov       rdx,rax
       mov       ecx,r14d
       call      qword ptr [7F75C9DC74F8]
       jmp       near ptr M31_L118
M31_L127:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M31_L128:
       mov       rdi,rbx
       call      qword ptr [7F75C9DC7528]
M31_L129:
       nop
       add       rsp,28
       ret
; Total bytes of code 5396
```
```assembly
; Kevlar.Shield+<>c__60`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__60_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       rcx,rsi
       mov       rsi,rdx
       mov       rax,offset PoolContextProbe+<>c.<NestedContext>b__6_1(Kevlar.KevlarContext)
       cmp       [rcx+18],rax
       jne       short M32_L00
       xor       eax,eax
       mov       rdx,100000000002A
       ret
M32_L00:
       mov       rdi,[rcx+8]
       jmp       qword ptr [rcx+18]
; Total bytes of code 43
```
```assembly
; Kevlar.KevlarProperties..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F75C9DC6898]; Kevlar.KevlarProperties+AdditionalAttemptState..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-8]
       call      qword ptr [7F75C8E2C240]; System.Object..ctor()
       mov       rax,[rbp-8]
       mov       rsi,[rax+8]
       mov       rax,[rbp-8]
       lea       rdi,[rax+28]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 104
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       ebx,edi
       call      qword ptr [7F75C89E6AF0]; Precode of System.Threading.Thread.GetThreadStaticsBase()
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M34_L01
       cmp       [rax],edi
       jle       short M34_L03
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M34_L03
M34_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M34_L01:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M34_L02
       movsxd    rcx,ecx
       add       rax,rcx
       jmp       short M34_L00
M34_L02:
       cmp       [rax+4],ecx
       jle       short M34_L03
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M34_L03
       mov       rax,[rdi]
       test      rax,rax
       je        short M34_L03
       jmp       short M34_L00
M34_L03:
       mov       edi,ebx
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
; Total bytes of code 133
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-18]
       mov       rcx,rax
       test      cl,1
       jne       short M35_L00
       ret
M35_L00:
       jmp       qword ptr [7F75C8E25C20]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 23
```
```assembly
; Kevlar.KevlarProperties.Clear()
       push      rbp
       push      rbx
       sub       rsp,18
       lea       rbp,[rsp+20]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       rbx,rdi
       cmp       qword ptr [rbx+10],0
       jne       short M36_L01
M36_L00:
       add       rsp,18
       pop       rbx
       pop       rbp
       ret
M36_L01:
       xor       edi,edi
       mov       [rbx+30],edi
       mov       rdi,[rbx+18]
       test      rdi,rdi
       je        short M36_L02
       mov       eax,[rdi+38]
       sub       eax,[rdi+40]
       cmp       eax,20
       jl        short M36_L02
       xor       edi,edi
       mov       [rbx+38],rdi
       mov       [rbx+40],rdi
       mov       [rbx+10],rdi
       mov       [rbx+18],rdi
       jmp       short M36_L00
M36_L02:
       mov       rdi,[rbx+10]
       mov       rax,[rdi]
       mov       rax,[rax+40]
       call      qword ptr [rax+28]
       cmp       qword ptr [rbx+18],0
       je        short M36_L00
       mov       rdi,[rbx+18]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7480]
       mov       rdi,rax
       lea       rsi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7498]
       jmp       short M36_L04
M36_L03:
       mov       rdi,[rbp-18]
       mov       rax,[rbp-18]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+28]
M36_L04:
       lea       rdi,[rbp-20]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+ValueCollection+Enumerator
       call      qword ptr [7F75C9DC74C8]
       test      eax,eax
       jne       short M36_L03
       jmp       near ptr M36_L00
; Total bytes of code 186
```
```assembly
; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       push      rax
       lea       rbp,[rsp+30]
       mov       rbx,rdi
       lea       rdi,[rbx+8]
       mov       eax,0FFFFFFFF
       lock xadd [rdi],eax
       dec       eax
       je        short M37_L01
M37_L00:
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M37_L01:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F6DE18013D0
       mov       r15,[rdi]
       cmp       dword ptr [r15+1C],0
       je        short M37_L02
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F75C7E40608
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M37_L02:
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7F75C9E66988]
       test      eax,eax
       jne       short M37_L03
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F75C7E40610
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M37_L03:
       mov       r14,[r15+10]
       test      r14,r14
       je        near ptr M37_L13
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M37_L05
M37_L04:
       mov       rdi,7F75C7E3B1E8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M37_L04
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M37_L05:
       dec       r13d
       cmp       dword ptr [r14+18],0
       jl        short M37_L06
       and       r13d,[r14+18]
       jmp       short M37_L07
M37_L06:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r14+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
M37_L07:
       xor       r12d,r12d
       jmp       short M37_L10
M37_L08:
       mov       rdi,[r14+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M37_L21
       mov       esi,r13d
       mov       rax,[rdi+rsi*8+10]
       mov       [rbp-30],rax
       cmp       [rax],al
       lea       rdi,[rax+10]
       test      rdi,rdi
       je        near ptr M37_L18
       mov       rsi,rbx
       xor       edx,edx
       call      00007F7647274060
       test      rax,rax
       je        short M37_L11
       mov       rdx,rbx
       mov       rsi,[rbp-30]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F75C98BDF38]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M37_L11
       inc       r13d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r13d
       jne       short M37_L09
       xor       r13d,r13d
M37_L09:
       inc       r12d
M37_L10:
       mov       rdi,[r14+8]
       cmp       [rdi+8],r12d
       jg        short M37_L08
       jmp       short M37_L12
M37_L11:
       cmp       dword ptr [r15+1C],0
       je        near ptr M37_L00
       jmp       near ptr M37_L20
M37_L12:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F75C7E40618
       call      qword ptr [r11]
       jmp       short M37_L11
M37_L13:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r14d,[rax+10]
       test      r14d,r14d
       jne       short M37_L15
M37_L14:
       mov       rdi,7F75C7E3B1E0
       mov       eax,1
       mov       r14d,eax
       lock xadd [rdi],r14d
       inc       r14d
       je        short M37_L14
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r14d
M37_L15:
       dec       r14d
       imul      r14d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M37_L16
       mov       r13d,r14d
       mov       r12d,[r15+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M37_L17
M37_L16:
       and       r14d,[r15+18]
       mov       r13d,r14d
M37_L17:
       mov       rdi,[r15+8]
       lea       esi,[r13*8]
       cmp       esi,[rdi+8]
       jae       short M37_L21
       lea       esi,[r13*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M37_L19
M37_L18:
       call      qword ptr [7F75C9E66460]
       int       3
M37_L19:
       mov       rsi,rbx
       call      00007F7647274040
       test      rax,rax
       je        near ptr M37_L11
       mov       rdi,r15
       mov       rsi,rbx
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7F75C9E669A0]
       jmp       near ptr M37_L11
M37_L20:
       mov       rdi,r15
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F75C9E669B8]
M37_L21:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 726
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+30]
       mov       rbx,rsi
       mov       r15,rdx
       lea       rdi,[rbx+18]
       mov       rsi,[rbx+8]
       mov       rax,[rdi]
       mov       r14d,eax
       cmp       r14d,0FFFFFFFF
       je        near ptr M38_L03
       mov       ecx,[rsi+8]
M38_L00:
       cmp       r14d,ecx
       jae       near ptr M38_L04
       mov       r13d,r14d
       shl       r13,4
       mov       edx,[rsi+r13+18]
       mov       r8,rax
       sar       r8,20
       inc       r8d
       movsxd    r8,r8d
       shl       r8,20
       or        rdx,r8
       mov       [rbp-28],rax
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-28]
       jne       short M38_L02
       mov       rdi,[rbx+8]
       cmp       r14d,[rdi+8]
       jae       near ptr M38_L04
       mov       rsi,[rdi+r13+10]
       mov       rdi,r15
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbx+8]
       cmp       r14d,[rax+8]
       jae       short M38_L04
       lea       rcx,[rax+r13+10]
       xor       eax,eax
       mov       [rcx],rax
       add       rbx,20
M38_L01:
       mov       rax,[rbx]
       mov       [rbp-30],rax
       mov       [rcx+8],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       edi,r14d
       or        rdx,rdi
       lock cmpxchg [rbx],rdx
       cmp       rax,[rbp-30]
       jne       short M38_L01
       cmp       qword ptr [r15],0
       setne     al
       movzx     eax,al
       add       rsp,10
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M38_L02:
       mov       rax,[rdi]
       mov       r14d,eax
       cmp       r14d,0FFFFFFFF
       jne       near ptr M38_L00
M38_L03:
       xor       eax,eax
       mov       [r15],rax
       add       rsp,10
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M38_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 263
```
```assembly
; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,38
       lea       rbp,[rsp+60]
       xor       eax,eax
       mov       [rbp-38],rax
       mov       rbx,rdi
       cmp       byte ptr [rbx+34],0
       jne       short M39_L04
M39_L00:
       mov       rdi,[rbx+28]
       mov       rax,[rbx+8]
       cmp       rdi,rax
       jne       short M39_L02
       cmp       dword ptr [rax+8],1
       jne       near ptr M39_L23
M39_L01:
       mov       rax,[rbx+8]
       xor       ecx,ecx
       mov       [rax+0C],ecx
       mov       [rax+10],ecx
       add       rsp,38
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M39_L02:
       mov       r15,[rbx+28]
       lea       rdi,[r15+8]
       mov       eax,0FFFFFFFF
       lock xadd [rdi],eax
       dec       eax
       je        short M39_L05
M39_L03:
       mov       rsi,[rbx+8]
       lea       rdi,[rbx+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M39_L01
M39_L04:
       mov       rdi,[rbx+28]
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7390]
       mov       byte ptr [rbx+34],0
       jmp       short M39_L00
M39_L05:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F6DE18013D0
       mov       r14,[rdi]
       cmp       dword ptr [r14+1C],0
       je        short M39_L06
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r15
       mov       r11,7F75C7E40500
       call      qword ptr [r11]
       jmp       short M39_L03
M39_L06:
       mov       rdi,r14
       mov       rsi,r15
       call      qword ptr [7F75C9E66988]
       test      eax,eax
       jne       short M39_L07
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r15
       mov       r11,7F75C7E40508
       call      qword ptr [r11]
       jmp       near ptr M39_L03
M39_L07:
       mov       r13,[r14+10]
       test      r13,r13
       je        near ptr M39_L17
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M39_L09
M39_L08:
       mov       rdi,7F75C7E3B1E8
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M39_L08
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M39_L09:
       dec       r12d
       cmp       dword ptr [r13+18],0
       jl        short M39_L10
       and       r12d,[r13+18]
       jmp       short M39_L11
M39_L10:
       mov       rdi,[r13+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r13+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
M39_L11:
       xor       eax,eax
       jmp       short M39_L14
M39_L12:
       mov       rdi,[r13+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M39_L49
       mov       esi,r12d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-48],rcx
       cmp       [rcx],cl
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M39_L40
       mov       rsi,r15
       xor       edx,edx
       call      00007F7647274060
       test      rax,rax
       je        short M39_L15
       mov       rdx,r15
       mov       rsi,[rbp-48]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F75C98BDF38]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M39_L15
       inc       r12d
       mov       rdi,[r13+8]
       cmp       [rdi+8],r12d
       jne       short M39_L13
       xor       r12d,r12d
M39_L13:
       mov       eax,[rbp-2C]
       inc       eax
M39_L14:
       mov       rdi,[r13+8]
       mov       [rbp-2C],eax
       cmp       [rdi+8],eax
       jg        short M39_L12
       jmp       short M39_L16
M39_L15:
       cmp       dword ptr [r14+1C],0
       je        near ptr M39_L03
       jmp       near ptr M39_L22
M39_L16:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r15
       mov       r11,7F75C7E40510
       call      qword ptr [r11]
       jmp       short M39_L15
M39_L17:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M39_L19
M39_L18:
       mov       rdi,7F75C7E3B1E0
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M39_L18
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M39_L19:
       dec       r13d
       imul      r13d,9E3779B9
       cmp       dword ptr [r14+18],0
       jge       short M39_L20
       mov       r12d,r13d
       mov       r13d,[r14+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M39_L21
M39_L20:
       and       r13d,[r14+18]
M39_L21:
       mov       rdi,[r14+8]
       lea       esi,[r13*8]
       cmp       esi,[rdi+8]
       jae       near ptr M39_L49
       lea       esi,[r13*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       je        near ptr M39_L40
       mov       rsi,r15
       call      00007F7647274040
       test      rax,rax
       je        near ptr M39_L15
       mov       rdi,r14
       mov       rsi,r15
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7F75C9E669A0]
       jmp       near ptr M39_L15
M39_L22:
       mov       rdi,r14
       call      qword ptr [7F75C9E669B8]
       jmp       near ptr M39_L03
M39_L23:
       mov       rdi,[rbx+8]
       call      qword ptr [7F75C9DC73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F6DE18013D0
       mov       r15,[rdi]
       cmp       dword ptr [r15+1C],0
       je        short M39_L24
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F75C9E669D0]
M39_L24:
       mov       r14,[r15+10]
       xor       r13d,r13d
       test      r14,r14
       jne       near ptr M39_L31
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M39_L26
M39_L25:
       mov       rdi,7F75C7E3B1E0
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M39_L25
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M39_L26:
       dec       r13d
       imul      edi,r13d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M39_L27
       mov       r13d,edi
       mov       edx,[r15+20]
       imul      r13,rdx
       shr       r13,20
       jmp       short M39_L28
M39_L27:
       and       edi,[r15+18]
       mov       r13d,edi
M39_L28:
       mov       rdi,[r15+8]
       lea       edx,[r13*8]
       cmp       edx,[rdi+8]
       jae       near ptr M39_L49
       lea       edx,[r13*8]
       lea       rdi,[rdi+rdx*8+10]
       mov       r12,[rdi]
       test      r12,r12
       je        short M39_L29
       mov       rdx,r12
       xor       esi,esi
       call      00007F7647274060
       cmp       rax,r12
       je        short M39_L30
M39_L29:
       xor       r12d,r12d
M39_L30:
       mov       [rbp-38],r12
       jmp       near ptr M39_L43
M39_L31:
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M39_L33
M39_L32:
       mov       rdi,7F75C7E3B1E8
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M39_L32
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M39_L33:
       dec       r12d
       cmp       dword ptr [r14+18],0
       jl        short M39_L34
       and       r12d,[r14+18]
       jmp       short M39_L35
M39_L34:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
M39_L35:
       xor       eax,eax
       jmp       short M39_L39
M39_L36:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M39_L49
       mov       esi,r12d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-50],rcx
       mov       r8,[rcx+10]
       mov       [rbp-58],r8
       test      r8,r8
       je        short M39_L37
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        short M39_L40
       xor       esi,esi
       mov       rdx,r8
       call      00007F7647274060
       mov       rcx,[rbp-58]
       cmp       rax,rcx
       je        short M39_L41
       mov       rcx,[rbp-50]
M39_L37:
       lea       rdx,[rbp-38]
       mov       rsi,rcx
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F75C98BDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M39_L43
       inc       r12d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r12d
       jne       short M39_L38
       xor       r12d,r12d
M39_L38:
       mov       eax,[rbp-3C]
       inc       eax
M39_L39:
       mov       rdi,[r14+8]
       mov       [rbp-3C],eax
       cmp       [rdi+8],eax
       jg        near ptr M39_L36
       jmp       short M39_L42
M39_L40:
       call      qword ptr [7F75C9E66460]
       int       3
M39_L41:
       mov       r8,rcx
       mov       [rbp-38],r8
       jmp       short M39_L43
M39_L42:
       xor       edi,edi
       mov       [rbp-38],rdi
M39_L43:
       mov       r12,[rbp-38]
       cmp       qword ptr [rbp-38],0
       jne       short M39_L45
       test      r14,r14
       je        short M39_L44
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       r14,rax
       mov       dword ptr [r14+8],1
       jmp       short M39_L46
M39_L44:
       mov       rdi,r15
       mov       esi,r13d
       call      qword ptr [7F75C9E669E8]
       mov       r12,rax
M39_L45:
       mov       r14,r12
M39_L46:
       xor       edi,edi
       mov       [rbp-38],rdi
       cmp       dword ptr [r15+1C],0
       jne       short M39_L47
       mov       rsi,r14
       jmp       short M39_L48
M39_L47:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F75C7E40518
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F75C9E669D0]
       mov       rsi,rax
M39_L48:
       lea       rdi,[rbx+8]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M39_L03
M39_L49:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 1457
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7F75C89D4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7F75C89CEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7F75C89DF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M40_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M40_L00
       mov       rsi,rax
       call      qword ptr [7F75C89CEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M40_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; System.Object..ctor()
       ret
; Total bytes of code 1
```
```assembly
; System.TimeProvider.get_System()
       mov       rax,7F6DE1800B00
       mov       rax,[rax]
       ret
; Total bytes of code 14
```
```assembly
; Kevlar.KevlarProperties.CopyChangedValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,30
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-38],xmm8
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       r15,rdi
       mov       rbx,rcx
       mov       r14,r8
       cmp       qword ptr [rbx+10],0
       jne       short M43_L04
M43_L00:
       cmp       qword ptr [rbx+18],0
       jne       short M43_L05
M43_L01:
       xor       r13d,r13d
M43_L02:
       xor       edi,edi
       mov       [rbp-28],rdi
       test      r15,r15
       jne       short M43_L06
M43_L03:
       add       rsp,30
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M43_L04:
       vmovdqu   xmm0,xmmword ptr [rbx+38]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-48]
       lea       rdi,[rbp-38]
       call      qword ptr [7F75C9E67048]
       test      eax,eax
       je        short M43_L00
       mov       r13,[rbx+10]
       jmp       short M43_L02
M43_L05:
       mov       rdi,[rbx+18]
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-48]
       lea       rcx,[rbp-28]
       cmp       [rdi],edi
       call      qword ptr [7F75C9E00BB0]
       test      eax,eax
       je        short M43_L01
       mov       r13,[rbp-28]
       jmp       short M43_L02
M43_L06:
       mov       rdi,r15
       mov       rax,[r15]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       je        short M43_L03
       mov       rdi,r15
       mov       rsi,r13
       call      qword ptr [7F75C9DC7A50]
       test      eax,eax
       jne       short M43_L03
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-48]
       mov       rdi,r14
       cmp       [rdi],edi
       call      qword ptr [7F75C9DC7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,r13
       call      qword ptr [7F75C9DC7A50]
       test      eax,eax
       je        near ptr M43_L03
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-48]
       mov       rdi,r15
       mov       rsi,r14
       mov       rax,[r15]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
       jmp       near ptr M43_L03
; Total bytes of code 264
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rdi
       mov       rdi,[rbx]
       call      qword ptr [7F75C98BDD10]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       r15d,[rax+10]
       test      r15d,r15d
       je        short M44_L02
M44_L00:
       dec       r15d
       mov       eax,[rbx+18]
       test      eax,eax
       jl        short M44_L03
       and       eax,r15d
M44_L01:
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
M44_L02:
       mov       rdi,[rbx]
       call      qword ptr [7F75C8E25728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       edi,1
       mov       r15d,edi
       lock xadd [rax],r15d
       inc       r15d
       je        short M44_L02
       mov       rdi,[rbx]
       call      qword ptr [7F75C98BDD10]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       [rax+10],r15d
       jmp       short M44_L00
M44_L03:
       mov       rax,[rbx+8]
       mov       eax,[rax+8]
       mov       ecx,r15d
       imul      rcx,[rbx+10]
       shr       rcx,20
       inc       rcx
       imul      rax,rcx
       shr       rax,20
       jmp       short M44_L01
; Total bytes of code 134
```
```assembly
; System.Runtime.CompilerServices.AsyncMethodBuilderCore.Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       push      rbp
       push      r15
       push      r14
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+40]
       mov       [rbp-20],rdi
       mov       rbx,rdi
       mov       r15,rsi
       cmp       [r15],r15b
       mov       rdi,7F76474A0D68
       mov       rax,7F7647CEF820
       call      rax
       cmp       dword ptr [rax],4
       jle       short M45_L07
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        short M45_L07
M45_L00:
       mov       r14,[rax+10]
       test      r14,r14
       jne       short M45_L01
       call      qword ptr [7F75C950C3F0]; System.Threading.Thread.InitializeCurrentThread()
       mov       r14,rax
M45_L01:
       mov       [rbp-28],r14
       mov       rsi,[r14+8]
       mov       [rbp-30],rsi
       mov       rsi,[r14+10]
       mov       [rbp-38],rsi
       mov       rdi,[rbx+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M45_L03
M45_L02:
       mov       rdi,r15
       call      rax
       jmp       short M45_L04
M45_L03:
       mov       rdi,rbx
       mov       rsi,7F75C9DB8060
       call      qword ptr [7F75C8E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M45_L02
M45_L04:
       mov       rsi,[rbp-38]
       cmp       rsi,[r14+10]
       jne       short M45_L08
M45_L05:
       mov       rdx,[r14+8]
       cmp       [rbp-30],rdx
       jne       short M45_L09
M45_L06:
       add       rsp,28
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M45_L07:
       mov       edi,4
       call      qword ptr [7F75C9E66490]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       short M45_L00
M45_L08:
       lea       rdi,[r14+10]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M45_L05
M45_L09:
       mov       rdi,r14
       mov       rsi,[rbp-30]
       call      qword ptr [7F75C9DC6D60]
       jmp       short M45_L06
       push      rax
       mov       rsi,[rbp-38]
       mov       rdi,[rbp-28]
       cmp       rsi,[rdi+10]
       je        short M45_L10
       lea       rdi,[rdi+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-28]
M45_L10:
       mov       rdx,[rdi+8]
       cmp       [rbp-30],rdx
       je        short M45_L11
       mov       rsi,[rbp-30]
       call      qword ptr [7F75C9DC6D60]
M45_L11:
       nop
       add       rsp,8
       ret
; Total bytes of code 271
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       dword ptr [rax+8],1
       mov       rdi,[rbp-8]
       call      qword ptr [7F75C8E2C240]; System.Object..ctor()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbx
       sub       rsp,10
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rbx,rdi
       mov       rdi,rbx
       call      qword ptr [7F75C89E9718]; Precode of System.Runtime.CompilerServices.InitHelpers.InitClassSlow(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rbx+20]
       mov       rax,[rax-18]
       mov       [rsp+8],rax
       mov       rax,[rsp+8]
       and       rax,0FFFFFFFFFFFFFFFE
       xor       ecx,ecx
       mov       [rsp+8],rcx
       add       rsp,10
       pop       rbx
       ret
; Total bytes of code 59
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rax,[rdi+20]
       mov       ebx,[rax-28]
       cmp       ebx,0FFFFFFFF
       je        near ptr M48_L04
       mov       rdi,7F76474A0D68
       mov       rax,7F7647CEF820
       call      rax
       add       rax,8
       add       rax,0FFFFFFFFFFFFFFF8
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M48_L01
       cmp       [rax],edi
       jle       short M48_L03
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M48_L03
M48_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M48_L01:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M48_L02
       movsxd    rdi,ecx
       add       rax,rdi
       jmp       short M48_L00
M48_L02:
       cmp       [rax+4],ecx
       jle       short M48_L03
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M48_L03
       mov       rax,[rdi]
       test      rax,rax
       je        short M48_L03
       jmp       short M48_L00
M48_L03:
       mov       edi,ebx
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7F75C9E66328]
M48_L04:
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7F75C98BDD58]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 179
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      r15
       push      rbx
       push      rax
       mov       rbx,rdi
       mov       rdi,[rbx+20]
       mov       r15,[rdi-10]
       mov       rdi,r15
       test      dil,1
       jne       short M49_L00
       mov       rdi,7F75C9EB9054
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,r15
       add       rsp,8
       pop       rbx
       pop       r15
       ret
M49_L00:
       mov       rdi,7F75C9EB9050
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,rbx
       add       rsp,8
       pop       rbx
       pop       r15
       jmp       qword ptr [7F75C921EA00]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 81
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       rsi,rdi
       lea       rdi,[rbp-30]
       mov       [rbp-94],rdi
       mov       [rbp-9C],rsi
       xor       edx,edx
       mov       [rbp-8C],edx
       lea       rdi,[rbp-88]
       call      qword ptr [7F75C89CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       edx,[rbp-8C]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7F75C89CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,[rbp-30]
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 131
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbx
       sub       rsp,10
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rbx,rdi
       mov       rdi,rbx
       call      qword ptr [7F75C89E9718]; Precode of System.Runtime.CompilerServices.InitHelpers.InitClassSlow(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rbx+20]
       mov       rax,[rax-10]
       mov       [rsp+8],rax
       mov       rax,[rsp+8]
       and       rax,0FFFFFFFFFFFFFFFE
       xor       ecx,ecx
       mov       [rsp+8],rcx
       add       rsp,10
       pop       rbx
       ret
; Total bytes of code 59
```

