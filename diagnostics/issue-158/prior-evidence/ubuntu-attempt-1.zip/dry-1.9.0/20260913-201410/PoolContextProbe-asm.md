## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: dry-1.9.0(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.9.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.9.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=1, LaunchCount=1, RunStrategy=ColdStart, UnrollFactor=1, WarmupCount=1))

```assembly
; PoolContextProbe.SingleRentReturn()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rdi,[rax+8]
       cmp       [rdi],edi
       call      qword ptr [7F2D7B0DDBC0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Rent()
       mov       [rbp-10],rax
       mov       rax,[rbp-10]
       mov       eax,[rax+8]
       mov       [rbp-14],eax
       mov       rax,[rbp-8]
       mov       rdi,[rax+8]
       mov       rsi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F2D7B0DDBD8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Return(System.__Canon)
       mov       eax,[rbp-14]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 79
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Rent()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-18],rax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       movzx     eax,byte ptr [rax+24]
       test      eax,eax
       je        short M01_L00
       lea       rsi,[rbp-20]
       mov       rdi,[rbp-10]
       call      qword ptr [7F2D7B0DDBF0]
       nop
       add       rsp,20
       pop       rbp
       ret
M01_L00:
       mov       rdi,[rbp-10]
       call      qword ptr [7F2D7B0DDC08]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ThrowIfDisposed()
       mov       rdi,[rbp-10]
       call      qword ptr [7F2D7B0DDC20]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].RentWithoutLifecycle()
       mov       [rbp-18],rax
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+1C],0
       jne       short M01_L01
       mov       rax,[rbp-18]
       add       rsp,20
       pop       rbp
       ret
M01_L01:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7F2D7B0DDC38]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       call      qword ptr [7F2D7B0DDC50]
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 139
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Return(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rdi,[rbp-10]
       mov       rsi,7F2D782044E0
       call      qword ptr [7F2D7AD25878]; System.ArgumentNullException.ThrowIfNull(System.Object, System.String)
       mov       rax,[rbp-8]
       movzx     eax,byte ptr [rax+24]
       test      eax,eax
       je        short M02_L00
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2D7B0DDF08]
       nop
       add       rsp,10
       pop       rbp
       ret
M02_L00:
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+1C],0
       je        short M02_L01
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2D7B0DDC38]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
       add       rsp,10
       pop       rbp
       ret
M02_L01:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2D7B0DDF20]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       test      eax,eax
       jne       short M02_L02
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2D7B0DDC38]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
       add       rsp,10
       pop       rbp
       ret
M02_L02:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2D7B0DDF38]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ReturnWithoutReset(System.__Canon)
       mov       rdi,[rbp-8]
       call      qword ptr [7F2D7B0DDF50]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ClearIfDisposed()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 172
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ThrowIfDisposed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+1C],0
       je        short M03_L00
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       call      qword ptr [7F2D7B0DDC50]
M03_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 48
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].RentWithoutLifecycle()
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-18],rax
       xor       eax,eax
       mov       [rbp-1C],eax
       cmp       qword ptr [rbp-18],0
       jne       near ptr M04_L05
       mov       rdi,[rbp-10]
       call      qword ptr [7F2D7B0DDCC8]
       mov       [rbp-1C],eax
       mov       rdi,[rbp-10]
       mov       esi,[rbp-1C]
       call      qword ptr [7F2D7B0DDCE0]
       mov       [rbp-30],rax
       mov       rax,[rbp-30]
       mov       rax,[rax]
       mov       [rbp-38],rax
       cmp       qword ptr [rbp-38],0
       je        short M04_L02
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-60],rax
       mov       rax,[rbp-60]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+30]
       mov       [rbp-68],rax
       cmp       qword ptr [rbp-68],0
       je        short M04_L00
       mov       rax,[rbp-68]
       mov       [rbp-58],rax
       jmp       short M04_L01
M04_L00:
       mov       rdi,[rbp-60]
       mov       rsi,7F2D7B42FA68
       call      qword ptr [7F2D7A64F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-58],rax
M04_L01:
       mov       rdi,[rbp-58]
       mov       rsi,[rbp-30]
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-38]
       call      qword ptr [7F2D7AA3E868]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       cmp       rax,[rbp-38]
       je        short M04_L03
M04_L02:
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-40]
       mov       [rbp-50],rax
       jmp       short M04_L04
M04_L03:
       mov       rax,[rbp-38]
       mov       [rbp-50],rax
M04_L04:
       mov       rax,[rbp-50]
       mov       [rbp-28],rax
       jmp       short M04_L06
M04_L05:
       lea       rsi,[rbp-28]
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2D7B0DDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
M04_L06:
       mov       rax,[rbp-28]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-28],0
       jne       short M04_L08
       cmp       qword ptr [rbp-18],0
       je        short M04_L07
       mov       rdi,[rbp-10]
       call      qword ptr [7F2D7B0DDD10]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].CreateItem()
       nop
       add       rsp,70
       pop       rbp
       ret
M04_L07:
       mov       rdi,[rbp-10]
       mov       esi,[rbp-1C]
       call      qword ptr [7F2D7B0DDD28]
       mov       [rbp-48],rax
M04_L08:
       mov       rax,[rbp-48]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 330
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2D7B68C5E8]; PoolContextProbe+Policy.Destroy(Item)
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 49
```
```assembly
; System.ArgumentNullException.ThrowIfNull(System.Object, System.String)
       push      rax
       test      rdi,rdi
       je        short M06_L00
       add       rsp,8
       ret
M06_L00:
       mov       rdi,rsi
       call      qword ptr [7F2D7A201208]
       int       3
; Total bytes of code 21
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-30],rax
       mov       rax,[rbp-30]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+38]
       mov       [rbp-38],rax
       cmp       qword ptr [rbp-38],0
       je        short M07_L00
       mov       rax,[rbp-38]
       mov       [rbp-28],rax
       jmp       short M07_L01
M07_L00:
       mov       rdi,[rbp-30]
       mov       rsi,7F2D7B4E0540
       call      qword ptr [7F2D7A64F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-28],rax
M07_L01:
       mov       byte ptr [rbp-20],0
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7F2D7B0DDF68]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItemGuarded(System.__Canon)
       nop
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 124
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ReturnWithoutReset(System.__Canon)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-20],0
       je        short M08_L01
       mov       rdi,[rbp-20]
       mov       rsi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2D7B0DE070]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(System.__Canon)
       test      eax,eax
       jne       short M08_L00
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7F2D7B0DDC38]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
M08_L00:
       nop
       add       rsp,50
       pop       rbp
       ret
M08_L01:
       mov       rdi,[rbp-10]
       call      qword ptr [7F2D7B0DDCC8]
       mov       [rbp-24],eax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-48],rax
       mov       rax,[rbp-48]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+40]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       je        short M08_L02
       mov       rax,[rbp-50]
       mov       [rbp-38],rax
       jmp       short M08_L03
M08_L02:
       mov       rdi,[rbp-48]
       mov       rsi,7F2D7B4E08A8
       call      qword ptr [7F2D7A64F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-38],rax
M08_L03:
       mov       rdi,[rbp-10]
       mov       esi,[rbp-24]
       call      qword ptr [7F2D7B0DDCE0]
       mov       [rbp-40],rax
       mov       rsi,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rdx,[rbp-18]
       call      qword ptr [7F2D7B0DE028]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-30],0
       jne       short M08_L04
       add       rsp,50
       pop       rbp
       ret
M08_L04:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-30]
       mov       ecx,[rbp-24]
       call      qword ptr [7F2D7B0DE088]
       nop
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 262
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ClearIfDisposed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+1C],0
       je        short M09_L00
       mov       rdi,[rbp-8]
       call      qword ptr [7F2D7B0DE0D0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
M09_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 41
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F2D7A1EEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F2D7A1EEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       push      rax
       mov       rax,rdx
       test      rsi,rsi
       je        short M11_L00
       mov       rdx,rcx
       mov       rdi,rsi
       mov       rsi,rax
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       jmp       qword ptr [rax]
M11_L00:
       call      qword ptr [7F2D7A204288]
       int       3
; Total bytes of code 39
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-14],eax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rdi,[rbp-8]
       call      qword ptr [7F2D7B0DDD40]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-14],eax
       mov       rdi,[rbp-8]
       mov       esi,[rbp-14]
       mov       rdx,[rbp-10]
       call      qword ptr [7F2D7B0DDD58]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       je        short M12_L00
       mov       eax,1
       add       rsp,20
       pop       rbp
       ret
M12_L00:
       mov       rdi,[rbp-8]
       mov       esi,[rbp-14]
       mov       rdx,[rbp-10]
       call      qword ptr [7F2D7B0DDD70]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 92
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].CreateItem()
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       call      qword ptr [7F2D7B0DDED8]; PoolContextProbe+Policy.Create()
       mov       [rbp-18],rax
       mov       rax,[rbp-18]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-18],0
       jne       short M13_L00
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-28],rax
       mov       edi,67
       mov       rsi,7F2D7AAC56B0
       call      qword ptr [7F2D7A64EF88]
       mov       [rbp-30],rax
       mov       rsi,[rbp-30]
       mov       rdi,[rbp-28]
       call      qword ptr [7F2D7AD25680]
       mov       rdi,[rbp-28]
       call      CORINFO_HELP_THROW
       int       3
M13_L00:
       mov       rax,[rbp-20]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 147
```
```assembly
; PoolContextProbe+Policy.Destroy(Item)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 24
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItemGuarded(System.__Canon)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2D7B0DDFF8]; PoolContextProbe+Policy.TryReset(Item)
       mov       [rbp-14],eax
       mov       eax,[rbp-14]
       add       rsp,50
       pop       rbp
       ret
       push      rax
       mov       [rbp-38],rdi
       mov       rax,[rbp-38]
       mov       [rbp-28],rax
       mov       rdi,offset MT_System.Exception[]
       mov       esi,2
       call      CORINFO_HELP_NEWARR_1_PTR
       mov       [rbp-40],rax
       mov       rdi,[rbp-40]
       mov       rdx,[rbp-20]
       xor       esi,esi
       call      qword ptr [7F2D7A6457A0]; System.Runtime.CompilerServices.CastHelpers.StelemRef(System.Object[], IntPtr, System.Object)
       mov       rdi,[rbp-40]
       mov       rdx,[rbp-28]
       mov       esi,1
       call      qword ptr [7F2D7A6457A0]; System.Runtime.CompilerServices.CastHelpers.StelemRef(System.Object[], IntPtr, System.Object)
       mov       rdi,offset MT_System.AggregateException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-48],rax
       mov       edi,0C1
       mov       rsi,7F2D7AAC56B0
       call      qword ptr [7F2D7A64EF88]
       mov       [rbp-50],rax
       mov       rsi,[rbp-50]
       mov       rdi,[rbp-48]
       mov       rdx,[rbp-40]
       call      qword ptr [7F2D7B0DE010]
       mov       rdi,[rbp-48]
       call      CORINFO_HELP_THROW
       int       3
       push      rax
       mov       [rbp-30],rdi
       mov       rax,[rbp-30]
       mov       [rbp-20],rax
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2D7B0DDC38]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 247
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(System.__Canon)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       xor       eax,eax
       mov       [rbp-68],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       dword ptr [rbp-78],3E8
       mov       rdi,[rbp-38]
       call      qword ptr [7F2D7B0DDD40]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-44],eax
       xor       eax,eax
       mov       [rbp-48],eax
       jmp       near ptr M16_L08
M16_L00:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       ecx,[rbp-44]
       cmp       ecx,[rax+8]
       jae       near ptr M16_L10
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       rax,[rax]
       mov       [rbp-50],rax
       mov       rax,[rbp-50]
       cmp       qword ptr [rax+50],0
       jne       near ptr M16_L03
       mov       rax,[rbp-50]
       cmp       [rax],al
       mov       rax,[rbp-50]
       add       rax,50
       mov       [rbp-68],rax
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-80],rax
       mov       rax,[rbp-80]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+20]
       mov       [rbp-88],rax
       cmp       qword ptr [rbp-88],0
       je        short M16_L01
       mov       rax,[rbp-88]
       mov       [rbp-70],rax
       jmp       short M16_L02
M16_L01:
       mov       rdi,[rbp-80]
       mov       rsi,7F2D7B42FCD8
       call      qword ptr [7F2D7A64F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-70],rax
M16_L02:
       mov       rdi,[rbp-70]
       mov       rsi,[rbp-68]
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-58]
       call      qword ptr [7F2D7AA3E868]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       test      rax,rax
       je        short M16_L05
       mov       rdi,7F2D7B4D7A70
       call      CORINFO_HELP_COUNTPROFILE32
M16_L03:
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       mov       rsi,[rbp-50]
       mov       rdx,[rbp-40]
       call      qword ptr [7F2D7B0DE0A0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       je        short M16_L06
M16_L04:
       mov       rdi,7F2D7B4D7A74
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,90
       pop       rbp
       ret
M16_L05:
       mov       rdi,7F2D7B4D7A78
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       short M16_L04
M16_L06:
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-5C],eax
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-44],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-5C]
       jne       short M16_L07
       mov       rdi,7F2D7B4D7A7C
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-44],eax
M16_L07:
       mov       rdi,7F2D7B4D7A80
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-48]
       inc       eax
       mov       [rbp-48],eax
M16_L08:
       mov       eax,[rbp-78]
       dec       eax
       mov       [rbp-78],eax
       cmp       dword ptr [rbp-78],0
       jg        short M16_L09
       lea       rdi,[rbp-78]
       mov       esi,62
       call      CORINFO_HELP_PATCHPOINT
M16_L09:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-48]
       jg        near ptr M16_L00
       mov       rdi,7F2D7B4D7A84
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,90
       pop       rbp
       ret
M16_L10:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 495
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       push      rbp
       sub       rsp,0B0
       lea       rbp,[rsp+0B0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       dword ptr [rbp-88],3E8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-98],rax
       mov       rax,[rbp-98]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+48]
       mov       [rbp-0A0],rax
       cmp       qword ptr [rbp-0A0],0
       je        short M17_L00
       mov       rax,[rbp-0A0]
       mov       [rbp-70],rax
       jmp       short M17_L01
M17_L00:
       mov       rdi,[rbp-98]
       mov       rsi,7F2D7B6C3D78
       call      qword ptr [7F2D7A64F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-70],rax
M17_L01:
       mov       rax,[rbp-38]
       cmp       [rax],al
       mov       rax,[rbp-38]
       lea       rdi,[rax+28]
       mov       rsi,[rbp-70]
       mov       rdx,[rbp-38]
       call      qword ptr [7F2D7B68C360]; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       nop
M17_L02:
       mov       rax,[rbp-38]
       mov       rax,[rax+10]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-48],0
       je        near ptr M17_L07
M17_L03:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M17_L04
       lea       rdi,[rbp-88]
       mov       esi,1D
       call      CORINFO_HELP_PATCHPOINT
M17_L04:
       lea       rsi,[rbp-50]
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7F2D7B0DDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       test      eax,eax
       je        short M17_L05
       mov       rdi,7F2D7B6BD7BC
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-50]
       call      qword ptr [7F2D7B68C3A8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       jmp       short M17_L03
M17_L05:
       cmp       qword ptr [rbp-40],0
       je        short M17_L06
       mov       rdi,7F2D7B6BD7C0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7F2D7B68C3C0]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F2D7B68C3D8]
M17_L06:
       mov       rdi,7F2D7B6BD7C4
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M17_L07:
       xor       eax,eax
       mov       [rbp-54],eax
       jmp       near ptr M17_L12
M17_L08:
       mov       rdi,[rbp-38]
       mov       esi,[rbp-54]
       call      qword ptr [7F2D7B0DDCE0]
       mov       [rbp-60],rax
       mov       rax,[rbp-60]
       cmp       qword ptr [rax],0
       je        near ptr M17_L11
       mov       rdi,7F2D7B6BD7C8
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-68],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-0A8],rax
       mov       rax,[rbp-0A8]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+40]
       mov       [rbp-0B0],rax
       cmp       qword ptr [rbp-0B0],0
       je        short M17_L09
       mov       rax,[rbp-0B0]
       mov       [rbp-78],rax
       jmp       short M17_L10
M17_L09:
       mov       rdi,[rbp-0A8]
       mov       rsi,7F2D7B4E08A8
       call      qword ptr [7F2D7A64F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-78],rax
M17_L10:
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-60]
       mov       rdx,[rbp-68]
       call      qword ptr [7F2D7B0DE028]
       mov       [rbp-90],rax
       mov       rsi,[rbp-90]
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       call      qword ptr [7F2D7B68C3A8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
M17_L11:
       mov       rdi,7F2D7B6BD7CC
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-54]
       inc       eax
       mov       [rbp-54],eax
M17_L12:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M17_L13
       lea       rdi,[rbp-88]
       mov       esi,79
       call      CORINFO_HELP_PATCHPOINT
M17_L13:
       mov       rdi,[rbp-38]
       call      qword ptr [7F2D7B68C3F0]
       cmp       eax,[rbp-54]
       jg        near ptr M17_L08
       cmp       qword ptr [rbp-40],0
       je        short M17_L14
       mov       rdi,7F2D7B6BD7D0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7F2D7B68C3C0]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F2D7B68C3D8]
M17_L14:
       mov       rdi,7F2D7B6BD7D4
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
       push      rax
       mov       [rbp-80],rdi
       mov       rdi,7F2D7B6BD7B8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-80]
       mov       [rbp-40],rax
       lea       rax,[M17_L02]
       add       rsp,8
       ret
; Total bytes of code 760
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7F2D7A1F4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7F2D7A1EEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7F2D7A1FF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M18_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M18_L00
       mov       rsi,rax
       call      qword ptr [7F2D7A1EEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M18_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp-3C],eax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       dword ptr [rbp-48],3E8
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7F2D7B0DDD88]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       eax,[rax+10]
       mov       [rbp-3C],eax
       cmp       dword ptr [rbp-3C],0
       jne       short M19_L02
M19_L00:
       mov       eax,[rbp-48]
       dec       eax
       mov       [rbp-48],eax
       cmp       dword ptr [rbp-48],0
       jg        short M19_L01
       lea       rdi,[rbp-48]
       mov       esi,9
       call      CORINFO_HELP_PATCHPOINT
M19_L01:
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7F2D7A645728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,rax
       call      qword ptr [7F2D7B0DDDA0]; System.Threading.Interlocked.Increment(Int32 ByRef)
       mov       [rbp-3C],eax
       cmp       dword ptr [rbp-3C],0
       je        short M19_L03
       mov       rdi,7F2D7B4D6810
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7F2D7B0DDD88]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       ecx,[rbp-3C]
       mov       [rax+10],ecx
M19_L02:
       mov       rdi,7F2D7B4D6814
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-3C]
       lea       esi,[rax-1]
       mov       rdi,[rbp-38]
       call      qword ptr [7F2D7B0DDDB8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetAffinityIndex(UInt32)
       nop
       add       rsp,50
       pop       rbp
       ret
M19_L03:
       mov       rdi,7F2D7B4D6818
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M19_L00
; Total bytes of code 206
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       push      rbp
       sub       rsp,60
       lea       rbp,[rsp+60]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-14],esi
       mov       [rbp-20],rdx
       mov       rax,[rbp-10]
       mov       rax,[rax+8]
       mov       ecx,[rbp-14]
       cmp       ecx,[rax+8]
       jae       near ptr M20_L03
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       rax,[rax]
       mov       [rbp-28],rax
       mov       rax,[rbp-28]
       mov       rax,[rax+50]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-30],0
       je        near ptr M20_L02
       mov       rax,[rbp-28]
       cmp       [rax],al
       mov       rax,[rbp-28]
       add       rax,50
       mov       [rbp-40],rax
       xor       eax,eax
       mov       [rbp-38],rax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-50],rax
       mov       rax,[rbp-50]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+20]
       mov       [rbp-58],rax
       cmp       qword ptr [rbp-58],0
       je        short M20_L00
       mov       rax,[rbp-58]
       mov       [rbp-48],rax
       jmp       short M20_L01
M20_L00:
       mov       rdi,[rbp-50]
       mov       rsi,7F2D7B42FCD8
       call      qword ptr [7F2D7A64F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-48],rax
M20_L01:
       mov       rdi,[rbp-48]
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-38]
       mov       rcx,[rbp-30]
       call      qword ptr [7F2D7AA3E868]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       cmp       rax,[rbp-30]
       jne       short M20_L02
       mov       rdi,[rbp-20]
       mov       rsi,[rbp-30]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       eax,1
       add       rsp,60
       pop       rbp
       ret
M20_L02:
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       mov       rsi,[rbp-28]
       mov       rdx,[rbp-20]
       call      qword ptr [7F2D7B0DDE48]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       nop
       add       rsp,60
       pop       rbp
       ret
M20_L03:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 273
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       push      rbp
       sub       rsp,60
       lea       rbp,[rsp+60]
       xor       eax,eax
       mov       [rbp-54],rax
       mov       [rbp-4C],eax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-3C],esi
       mov       [rbp-48],rdx
       mov       dword ptr [rbp-60],3E8
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7F2D7B0DDD88]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       eax,[rax+14]
       dec       eax
       mov       [rbp-4C],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-4C]
       jbe       short M21_L02
       mov       eax,[rbp-4C]
       cmp       eax,[rbp-3C]
       je        short M21_L01
       mov       rdi,[rbp-38]
       mov       esi,[rbp-4C]
       mov       rdx,[rbp-48]
       call      qword ptr [7F2D7B0DDD58]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       je        short M21_L00
       mov       rdi,7F2D7B4D6AD0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,60
       pop       rbp
       ret
M21_L00:
       mov       rdi,7F2D7B4D6AD4
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       short M21_L02
M21_L01:
       mov       rdi,7F2D7B4D6AD8
       call      CORINFO_HELP_COUNTPROFILE32
M21_L02:
       mov       eax,[rbp-3C]
       mov       [rbp-50],eax
       mov       dword ptr [rbp-54],1
       jmp       near ptr M21_L06
M21_L03:
       mov       eax,[rbp-50]
       inc       eax
       mov       [rbp-58],eax
       mov       eax,[rbp-50]
       inc       eax
       mov       [rbp-50],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-58]
       jne       short M21_L04
       mov       rdi,7F2D7B4D6ADC
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-50],eax
M21_L04:
       mov       rdi,[rbp-38]
       mov       esi,[rbp-50]
       mov       rdx,[rbp-48]
       call      qword ptr [7F2D7B0DDD58]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       je        short M21_L05
       mov       rdi,7F2D7B4D6AE0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7F2D7B0DDD88]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       ecx,[rbp-50]
       inc       ecx
       mov       [rax+14],ecx
       mov       eax,1
       add       rsp,60
       pop       rbp
       ret
M21_L05:
       mov       rdi,7F2D7B4D6AE4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-54]
       inc       eax
       mov       [rbp-54],eax
M21_L06:
       mov       eax,[rbp-60]
       dec       eax
       mov       [rbp-60],eax
       cmp       dword ptr [rbp-60],0
       jg        short M21_L07
       lea       rdi,[rbp-60]
       mov       esi,52
       call      CORINFO_HELP_PATCHPOINT
M21_L07:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-54]
       jg        near ptr M21_L03
       mov       rdi,7F2D7B4D6AE8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-48]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,60
       pop       rbp
       ret
; Total bytes of code 406
```
```assembly
; PoolContextProbe+Policy.Create()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_PoolContextProbe+Item
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F2D7B0DDEF0]; PoolContextProbe+Item..ctor()
       mov       rax,[rbp-10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 59
```
```assembly
; PoolContextProbe+Policy.TryReset(Item)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       eax,1
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 29
```
```assembly
; System.Runtime.CompilerServices.CastHelpers.StelemRef(System.Object[], IntPtr, System.Object)
       push      rbp
       mov       rbp,rsp
       mov       eax,[rdi+8]
       cmp       rax,rsi
       jbe       short M24_L03
       lea       rcx,[rdi+rsi*8+10]
       mov       rsi,[rdi]
       mov       rsi,[rsi+30]
       test      rdx,rdx
       je        short M24_L02
       cmp       rsi,[rdx]
       jne       short M24_L01
M24_L00:
       mov       rsi,rdx
       mov       rdi,rcx
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       pop       rbp
       jmp       qword ptr [rax]
M24_L01:
       mov       rdi,[rdi]
       cmp       rdi,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       je        short M24_L00
       mov       rdi,rcx
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       pop       rbp
       jmp       qword ptr [rax]
M24_L02:
       xor       eax,eax
       mov       [rcx],rax
       pop       rbp
       ret
M24_L03:
       call      qword ptr [7F2D7A2096B8]
       int       3
; Total bytes of code 91
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+48]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+60]
       mov       rdi,[rbp-10]
       call      qword ptr [7F2D7B0DDE60]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M25_L00
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M25_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+48]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M25_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rbp-20]
       mov       rdi,rax
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+58]
       mov       rax,[rbp-18]
       mov       rdx,[rax+48]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7F2D7B0DDE78]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       eax,1
       add       rsp,30
       pop       rbp
       ret
M25_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 171
```
```assembly
; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       push      rbp
       sub       rsp,310
       lea       rbp,[rsp+310]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-270],xmm8
       mov       rax,0FFFFFFFFFFFFFDF0
M26_L00:
       vmovdqa   xmmword ptr [rbp+rax-50],xmm8
       vmovdqa   xmmword ptr [rbp+rax-40],xmm8
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       add       rax,30
       jne       short M26_L00
       mov       [rbp-50],rax
       mov       [rbp-30],rsi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       dword ptr [rbp-228],3E8
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       jne       short M26_L01
       mov       rdi,7F2D7B6D00E0
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,310
       pop       rbp
       ret
M26_L01:
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+10]
       mov       [rbp-278],rax
       cmp       qword ptr [rbp-278],0
       je        short M26_L02
       mov       rax,[rbp-278]
       mov       [rbp-148],rax
       jmp       short M26_L03
M26_L02:
       mov       rdi,[rbp-40]
       mov       rsi,7F2D7B6C43E8
       call      qword ptr [7F2D7A64F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-148],rax
M26_L03:
       mov       rdi,[rbp-148]
       call      qword ptr [7F2D7A645728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       movzx     eax,byte ptr [rax]
       test      eax,eax
       je        near ptr M26_L37
       vxorps    ymm0,ymm0,ymm0
       vmovdqu   ymmword ptr [rbp-98],ymm0
       vmovdqu   ymmword ptr [rbp-78],ymm0
       mov       rax,[rbp-50]
       mov       [rbp-0B8],rax
       xor       eax,eax
       mov       [rbp-0C0],eax
       lea       rsi,[rbp-0C0]
       mov       rdi,[rbp-0B8]
       call      qword ptr [7F2D7A645980]; System.Threading.Monitor.Enter(System.Object, Boolean ByRef)
       mov       rdi,[rbp-50]
       cmp       [rdi],edi
       call      qword ptr [7F2D7B68C570]
       mov       [rbp-0C8],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-280],rax
       mov       rax,[rbp-280]
       cmp       qword ptr [rax+8],30
       jle       short M26_L04
       mov       rax,[rbp-280]
       mov       rax,[rax+30]
       mov       [rbp-288],rax
       cmp       qword ptr [rbp-288],0
       je        short M26_L04
       mov       rax,[rbp-288]
       mov       [rbp-178],rax
       jmp       short M26_L05
M26_L04:
       mov       rdi,[rbp-40]
       mov       rsi,7F2D7B6C45E8
       call      qword ptr [7F2D7A64F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-178],rax
M26_L05:
       mov       rax,[rbp-0C8]
       mov       [rbp-1F0],rax
       mov       rdi,[rbp-1F0]
       mov       rsi,7F2D7B6D00E8
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-1F0]
       mov       [rbp-230],rax
       mov       rdi,[rbp-230]
       mov       r11,[rbp-178]
       mov       rax,[rbp-178]
       call      qword ptr [rax]
       mov       [rbp-0AC],eax
       cmp       dword ptr [rbp-0AC],8
       jg        near ptr M26_L08
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-290],rax
       mov       rax,[rbp-290]
       cmp       qword ptr [rax+8],58
       jle       short M26_L06
       mov       rax,[rbp-290]
       mov       rax,[rax+58]
       mov       [rbp-298],rax
       cmp       qword ptr [rbp-298],0
       je        short M26_L06
       mov       rax,[rbp-298]
       mov       [rbp-1D8],rax
       jmp       short M26_L07
M26_L06:
       mov       rdi,[rbp-40]
       mov       rsi,7F2D7B6C4A18
       call      qword ptr [7F2D7A64F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1D8],rax
M26_L07:
       lea       rsi,[rbp-98]
       mov       rdi,[rbp-1D8]
       mov       edx,8
       call      qword ptr [7F2D7B68C528]
       mov       [rbp-1E8],rax
       mov       [rbp-1E0],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-1E8]
       vmovdqu   xmmword ptr [rbp-0A8],xmm0
       jmp       near ptr M26_L13
M26_L08:
       mov       rdi,7F2D7B6D01F0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2A0],rax
       mov       rax,[rbp-2A0]
       cmp       qword ptr [rax+8],38
       jle       short M26_L09
       mov       rax,[rbp-2A0]
       mov       rax,[rax+38]
       mov       [rbp-2A8],rax
       cmp       qword ptr [rbp-2A8],0
       je        short M26_L09
       mov       rax,[rbp-2A8]
       mov       [rbp-180],rax
       jmp       short M26_L10
M26_L09:
       mov       rdi,[rbp-40]
       mov       rsi,7F2D7B6C4620
       call      qword ptr [7F2D7A64F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-180],rax
M26_L10:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2B0],rax
       mov       rax,[rbp-2B0]
       cmp       qword ptr [rax+8],40
       jle       short M26_L11
       mov       rax,[rbp-2B0]
       mov       rax,[rax+40]
       mov       [rbp-2B8],rax
       cmp       qword ptr [rbp-2B8],0
       je        short M26_L11
       mov       rax,[rbp-2B8]
       mov       [rbp-188],rax
       jmp       short M26_L12
M26_L11:
       mov       rdi,[rbp-40]
       mov       rsi,7F2D7B6C46B0
       call      qword ptr [7F2D7A64F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-188],rax
M26_L12:
       movsxd    rsi,dword ptr [rbp-0AC]
       mov       rdi,[rbp-180]
       call      CORINFO_HELP_NEWARR_1_PTR
       mov       [rbp-238],rax
       mov       rsi,[rbp-238]
       mov       rdi,[rbp-188]
       call      qword ptr [7F2D7B0D5488]; System.Span`1[[System.__Canon, System.Private.CoreLib]].op_Implicit(System.__Canon[])
       mov       [rbp-198],rax
       mov       [rbp-190],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-198]
       vmovdqu   xmmword ptr [rbp-0A8],xmm0
M26_L13:
       xor       eax,eax
       mov       [rbp-0CC],eax
       jmp       near ptr M26_L17
M26_L14:
       mov       rdi,7F2D7B6D01F4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2C0],rax
       mov       rax,[rbp-2C0]
       cmp       qword ptr [rax+8],48
       jle       short M26_L15
       mov       rax,[rbp-2C0]
       mov       rax,[rax+48]
       mov       [rbp-2C8],rax
       cmp       qword ptr [rbp-2C8],0
       je        short M26_L15
       mov       rax,[rbp-2C8]
       mov       [rbp-1A0],rax
       jmp       short M26_L16
M26_L15:
       mov       rdi,[rbp-40]
       mov       rsi,7F2D7B6C46C0
       call      qword ptr [7F2D7A64F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1A0],rax
M26_L16:
       mov       rax,[rbp-0C8]
       mov       [rbp-1F8],rax
       mov       rdi,[rbp-1F8]
       mov       rsi,7F2D7B6D01F8
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-1F8]
       mov       [rbp-240],rax
       mov       rdi,[rbp-240]
       mov       r11,[rbp-1A0]
       mov       esi,[rbp-0CC]
       mov       rax,[rbp-1A0]
       call      qword ptr [rax]
       mov       [rbp-0D8],rax
       mov       rax,[rbp-0D8]
       inc       dword ptr [rax+68]
       mov       eax,[rbp-0CC]
       inc       eax
       mov       [rbp-0CC],eax
M26_L17:
       mov       eax,[rbp-228]
       dec       eax
       mov       [rbp-228],eax
       cmp       dword ptr [rbp-228],0
       jg        short M26_L18
       lea       rdi,[rbp-228]
       mov       esi,8C
       call      CORINFO_HELP_PATCHPOINT
M26_L18:
       mov       eax,[rbp-0CC]
       cmp       eax,[rbp-0AC]
       jl        near ptr M26_L14
       call      qword ptr [7F2D7B68C588]
       xor       eax,eax
       mov       [rbp-0DC],eax
       jmp       near ptr M26_L30
M26_L19:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2D0],rax
       mov       rax,[rbp-2D0]
       cmp       qword ptr [rax+8],48
       jle       short M26_L20
       mov       rax,[rbp-2D0]
       mov       rax,[rax+48]
       mov       [rbp-2D8],rax
       cmp       qword ptr [rbp-2D8],0
       je        short M26_L20
       mov       rax,[rbp-2D8]
       mov       [rbp-1A8],rax
       jmp       short M26_L21
M26_L20:
       mov       rdi,[rbp-40]
       mov       rsi,7F2D7B6C46C0
       call      qword ptr [7F2D7A64F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1A8],rax
M26_L21:
       mov       rax,[rbp-0C8]
       mov       [rbp-200],rax
       mov       rdi,[rbp-200]
       mov       rsi,7F2D7B6D0300
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-200]
       mov       [rbp-248],rax
       mov       rdi,[rbp-248]
       mov       r11,[rbp-1A8]
       mov       esi,[rbp-0DC]
       mov       rax,[rbp-1A8]
       call      qword ptr [rax]
       mov       [rbp-0E8],rax
       mov       rax,[rbp-0E8]
       mov       [rbp-0F8],rax
       xor       eax,eax
       mov       [rbp-100],eax
       lea       rsi,[rbp-100]
       mov       rdi,[rbp-0F8]
       call      qword ptr [7F2D7A645980]; System.Threading.Monitor.Enter(System.Object, Boolean ByRef)
       mov       rax,[rbp-0E8]
       cmp       [rax],al
       mov       rax,[rbp-0E8]
       add       rax,58
       mov       [rbp-1B0],rax
       xor       eax,eax
       mov       [rbp-108],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-2E0],rax
       cmp       qword ptr [rbp-2E0],0
       je        short M26_L22
       mov       rax,[rbp-2E0]
       mov       [rbp-1B8],rax
       jmp       short M26_L23
M26_L22:
       mov       rdi,[rbp-40]
       mov       rsi,7F2D7B6C4480
       call      qword ptr [7F2D7A64F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1B8],rax
M26_L23:
       mov       rdi,[rbp-1B8]
       mov       rsi,[rbp-1B0]
       mov       rdx,[rbp-108]
       call      qword ptr [7F2D7B0DE028]
       mov       [rbp-0F0],rax
       cmp       qword ptr [rbp-0F0],0
       je        near ptr M26_L27
       mov       rax,[rbp-0E8]
       mov       rax,[rax+60]
       mov       [rbp-110],rax
       cmp       qword ptr [rbp-110],0
       je        short M26_L24
       mov       rdi,7F2D7B6D0408
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-110]
       mov       rsi,[rbp-0F0]
       cmp       [rdi],edi
       call      qword ptr [7F2D7B68C5A0]
       jmp       near ptr M26_L27
M26_L24:
       mov       rdi,7F2D7B6D040C
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2E8],rax
       mov       rax,[rbp-2E8]
       cmp       qword ptr [rax+8],50
       jle       short M26_L25
       mov       rax,[rbp-2E8]
       mov       rax,[rax+50]
       mov       [rbp-2F0],rax
       cmp       qword ptr [rbp-2F0],0
       je        short M26_L25
       mov       rax,[rbp-2F0]
       mov       [rbp-1C8],rax
       jmp       short M26_L26
M26_L25:
       mov       rdi,[rbp-40]
       mov       rsi,7F2D7B6C4860
       call      qword ptr [7F2D7A64F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1C8],rax
M26_L26:
       mov       rdi,[rbp-1C8]
       call      CORINFO_HELP_NEWFAST
       mov       [rbp-1C0],rax
       mov       rdi,[rbp-1C0]
       mov       rsi,[rbp-0F0]
       call      qword ptr [7F2D7B0DE400]; System.WeakReference`1[[System.__Canon, System.Private.CoreLib]]..ctor(System.__Canon)
       mov       rax,[rbp-0E8]
       lea       rdi,[rax+60]
       mov       rsi,[rbp-1C0]
       call      CORINFO_HELP_ASSIGN_REF
M26_L27:
       mov       rax,[rbp-0E8]
       inc       dword ptr [rax+68]
       call      M26_L50
       jmp       short M26_L29
M26_L28:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M26_L29:
       mov       rdi,7F2D7B6D0418
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-0A0]
       cmp       [rbp-0DC],eax
       jae       short M26_L28
       mov       eax,[rbp-0DC]
       mov       rcx,[rbp-0A8]
       lea       rdi,[rcx+rax*8]
       mov       rsi,[rbp-0F0]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       eax,[rbp-0DC]
       inc       eax
       mov       [rbp-0DC],eax
M26_L30:
       mov       eax,[rbp-228]
       dec       eax
       mov       [rbp-228],eax
       cmp       dword ptr [rbp-228],0
       jg        short M26_L31
       lea       rdi,[rbp-228]
       mov       esi,13A
       call      CORINFO_HELP_PATCHPOINT
M26_L31:
       mov       eax,[rbp-0DC]
       cmp       eax,[rbp-0AC]
       jl        near ptr M26_L19
       call      M26_L52
       nop
       xor       eax,eax
       mov       [rbp-114],eax
       jmp       short M26_L34
M26_L32:
       mov       eax,[rbp-0A0]
       cmp       [rbp-114],eax
       jae       near ptr M26_L49
       mov       eax,[rbp-114]
       mov       rcx,[rbp-0A8]
       mov       rax,[rcx+rax*8]
       mov       [rbp-120],rax
       cmp       qword ptr [rbp-120],0
       je        short M26_L33
       mov       rdi,7F2D7B6D0424
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-48]
       mov       rsi,[rbp-120]
       cmp       [rdi],edi
       call      qword ptr [7F2D7B68C5B8]
       nop
M26_L33:
       mov       rdi,7F2D7B6D0430
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-114]
       inc       eax
       mov       [rbp-114],eax
M26_L34:
       mov       eax,[rbp-228]
       dec       eax
       mov       [rbp-228],eax
       cmp       dword ptr [rbp-228],0
       jg        short M26_L35
       lea       rdi,[rbp-228]
       mov       esi,18A
       call      CORINFO_HELP_PATCHPOINT
M26_L35:
       mov       eax,[rbp-114]
       cmp       eax,[rbp-0AC]
       jl        near ptr M26_L32
       cmp       qword ptr [rbp-58],0
       je        short M26_L36
       mov       rdi,7F2D7B6D0434
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-58]
       call      qword ptr [7F2D7B68C3C0]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F2D7B68C3D8]
M26_L36:
       mov       rdi,7F2D7B6D0438
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,310
       pop       rbp
       ret
M26_L37:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-2F8],rax
       cmp       qword ptr [rbp-2F8],0
       je        short M26_L38
       mov       rax,[rbp-2F8]
       mov       [rbp-150],rax
       jmp       short M26_L39
M26_L38:
       mov       rdi,[rbp-40]
       mov       rsi,7F2D7B6C43F8
       call      qword ptr [7F2D7A64F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-150],rax
M26_L39:
       mov       rdi,[rbp-50]
       cmp       [rdi],edi
       call      qword ptr [7F2D7B68C570]
       mov       [rbp-208],rax
       mov       rdi,[rbp-208]
       mov       rsi,7F2D7B6D0440
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-208]
       mov       [rbp-250],rax
       mov       rdi,[rbp-250]
       mov       r11,[rbp-150]
       mov       rax,[rbp-150]
       call      qword ptr [rax]
       mov       [rbp-130],rax
       jmp       near ptr M26_L46
M26_L40:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-300],rax
       cmp       qword ptr [rbp-300],0
       je        short M26_L41
       mov       rax,[rbp-300]
       mov       [rbp-158],rax
       jmp       short M26_L42
M26_L41:
       mov       rdi,[rbp-40]
       mov       rsi,7F2D7B6C4430
       call      qword ptr [7F2D7A64F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-158],rax
M26_L42:
       mov       rax,[rbp-130]
       mov       [rbp-210],rax
       mov       rdi,[rbp-210]
       mov       rsi,7F2D7B6D0548
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-210]
       mov       [rbp-260],rax
       mov       rdi,[rbp-260]
       mov       r11,[rbp-158]
       mov       rax,[rbp-158]
       call      qword ptr [rax]
       mov       [rbp-258],rax
       mov       rax,[rbp-258]
       cmp       [rax],al
       mov       rax,[rbp-258]
       add       rax,58
       mov       [rbp-160],rax
       xor       eax,eax
       mov       [rbp-108],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-308],rax
       cmp       qword ptr [rbp-308],0
       je        short M26_L43
       mov       rax,[rbp-308]
       mov       [rbp-168],rax
       jmp       short M26_L44
M26_L43:
       mov       rdi,[rbp-40]
       mov       rsi,7F2D7B6C4480
       call      qword ptr [7F2D7A64F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-168],rax
M26_L44:
       mov       rdi,[rbp-168]
       mov       rsi,[rbp-160]
       mov       rdx,[rbp-108]
       call      qword ptr [7F2D7B0DE028]
       mov       [rbp-138],rax
       cmp       qword ptr [rbp-138],0
       je        short M26_L45
       mov       rdi,7F2D7B6D0650
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-48]
       mov       rsi,[rbp-138]
       cmp       [rdi],edi
       call      qword ptr [7F2D7B68C5B8]
       jmp       short M26_L46
M26_L45:
       mov       rdi,7F2D7B6D0654
       call      CORINFO_HELP_COUNTPROFILE32
M26_L46:
       mov       eax,[rbp-228]
       dec       eax
       mov       [rbp-228],eax
       cmp       dword ptr [rbp-228],0
       jg        short M26_L47
       lea       rdi,[rbp-228]
       mov       esi,1E9
       call      CORINFO_HELP_PATCHPOINT
M26_L47:
       mov       rax,[rbp-130]
       mov       [rbp-218],rax
       mov       rdi,[rbp-218]
       mov       rsi,7F2D7B6D0660
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-218]
       mov       [rbp-268],rax
       mov       rdi,[rbp-268]
       mov       r11,7F2D796605E8
       call      qword ptr [r11]
       test      eax,eax
       jne       near ptr M26_L40
       call      M26_L56
       nop
       cmp       qword ptr [rbp-58],0
       je        short M26_L48
       mov       rdi,7F2D7B6D087C
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-58]
       call      qword ptr [7F2D7B68C3C0]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F2D7B68C3D8]
M26_L48:
       mov       rdi,7F2D7B6D0880
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,310
       pop       rbp
       ret
M26_L49:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M26_L50:
       push      rax
       movzx     eax,byte ptr [rbp-100]
       test      eax,eax
       je        short M26_L51
       mov       rdi,7F2D7B6D0410
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-0F8]
       call      qword ptr [7F2D7A646808]; System.Threading.Monitor.Exit(System.Object)
M26_L51:
       mov       rdi,7F2D7B6D0414
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
M26_L52:
       push      rax
       movzx     eax,byte ptr [rbp-0C0]
       test      eax,eax
       je        short M26_L53
       mov       rdi,7F2D7B6D041C
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-0B8]
       call      qword ptr [7F2D7A646808]; System.Threading.Monitor.Exit(System.Object)
M26_L53:
       mov       rdi,7F2D7B6D0420
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
       push      rax
       mov       [rbp-1D0],rdi
       mov       rax,[rbp-1D0]
       mov       [rbp-128],rax
       cmp       qword ptr [rbp-58],0
       jne       short M26_L54
       mov       rdi,7F2D7B6D0428
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-128]
       mov       [rbp-58],rax
M26_L54:
       mov       rdi,7F2D7B6D042C
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rax,[M26_L33]
       add       rsp,8
       ret
       push      rax
       mov       [rbp-170],rdi
       mov       rax,[rbp-170]
       mov       [rbp-140],rax
       cmp       qword ptr [rbp-58],0
       jne       short M26_L55
       mov       rdi,7F2D7B6D0658
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-140]
       mov       [rbp-58],rax
M26_L55:
       mov       rdi,7F2D7B6D065C
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rax,[M26_L46]
       add       rsp,8
       ret
M26_L56:
       push      rax
       cmp       qword ptr [rbp-130],0
       je        short M26_L57
       mov       rdi,7F2D7B6D0768
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-130]
       mov       [rbp-220],rax
       mov       rdi,[rbp-220]
       mov       rsi,7F2D7B6D0770
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-220]
       mov       [rbp-270],rax
       mov       rdi,[rbp-270]
       mov       r11,7F2D796605F0
       call      qword ptr [r11]
M26_L57:
       mov       rdi,7F2D7B6D0878
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
; Total bytes of code 3431
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       cmp       qword ptr [rbp-10],0
       jne       short M27_L00
       add       rsp,30
       pop       rbp
       ret
M27_L00:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2D7B0DDC38]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
M27_L01:
       add       rsp,30
       pop       rbp
       ret
       push      rax
       mov       [rbp-28],rdi
       mov       rax,[rbp-28]
       mov       [rbp-20],rax
       mov       rax,[rbp-18]
       cmp       qword ptr [rax],0
       jne       short M27_L02
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
M27_L02:
       lea       rax,[M27_L01]
       add       rsp,8
       ret
; Total bytes of code 114
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rax,[rdi+20]
       mov       ebx,[rax-28]
       cmp       ebx,0FFFFFFFF
       jne       short M28_L00
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
M28_L00:
       call      qword ptr [7F2D7A206AF0]; Precode of System.Threading.Thread.GetThreadStaticsBase()
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M28_L02
       cmp       [rax],edi
       jle       short M28_L04
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M28_L04
M28_L01:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M28_L02:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M28_L03
       movsxd    rcx,ecx
       add       rax,rcx
       jmp       short M28_L01
M28_L03:
       cmp       [rax+4],ecx
       jle       short M28_L04
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M28_L04
       mov       rax,[rdi]
       test      rax,rax
       je        short M28_L04
       jmp       short M28_L01
M28_L04:
       mov       edi,ebx
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
; Total bytes of code 159
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-10]
       mov       rcx,rax
       test      cl,1
       jne       short M29_L00
       ret
M29_L00:
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       jmp       qword ptr [rax]
; Total bytes of code 27
```
```assembly
; System.Threading.Interlocked.Increment(Int32 ByRef)
       mov       eax,1
       lock xadd [rdi],eax
       inc       eax
       ret
; Total bytes of code 12
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetAffinityIndex(UInt32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-18],eax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-14],esi
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+18],0
       jl        short M31_L00
       mov       rax,[rbp-10]
       mov       eax,[rax+18]
       and       eax,[rbp-14]
       add       rsp,20
       pop       rbp
       ret
M31_L00:
       mov       rax,[rbp-10]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       mov       [rbp-18],eax
       call      qword ptr [7F2D7B0DDDE8]
       cmp       eax,8
       jne       short M31_L01
       mov       rax,[rbp-10]
       mov       rcx,[rax+10]
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       mov       esi,[rbp-14]
       mov       edx,[rbp-18]
       call      qword ptr [7F2D7B0DDE00]
       nop
       add       rsp,20
       pop       rbp
       ret
M31_L01:
       mov       eax,[rbp-14]
       xor       edx,edx
       div       dword ptr [rbp-18]
       mov       eax,edx
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 127
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+48]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+58]
       mov       rdi,[rbp-10]
       call      qword ptr [7F2D7B0DDE60]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M32_L00
       mov       rax,[rbp-20]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M32_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+48]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M32_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rax]
       mov       rdi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       mov       rax,[rax+48]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M32_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       xor       ecx,ecx
       mov       [rax],rcx
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+60]
       mov       rax,[rbp-18]
       mov       rdx,[rax+48]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7F2D7B0DDE78]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       rax,[rbp-20]
       cmp       qword ptr [rax],0
       setne     al
       movzx     eax,al
       add       rsp,30
       pop       rbp
       ret
M32_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 221
```
```assembly
; PoolContextProbe+Item..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       dword ptr [rax+8],2A
       mov       rdi,[rbp-8]
       call      qword ptr [7F2D7A64C240]; System.Object..ctor()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-50],rcx
       mov       dword ptr [rbp-70],3E8
M34_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M34_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M34_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7F2D7B0DDE90]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-50]
       mov       [rcx],eax
       mov       rax,[rbp-50]
       cmp       dword ptr [rax],0FFFFFFFF
       jne       short M34_L02
       mov       rdi,7F2D7B4D6A60
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,70
       pop       rbp
       ret
M34_L02:
       mov       rax,[rbp-50]
       mov       eax,[rax]
       mov       rcx,[rbp-48]
       cmp       eax,[rcx+8]
       jae       short M34_L04
       mov       edx,eax
       imul      rdx,10
       lea       rcx,[rcx+rdx+10]
       mov       eax,[rcx+8]
       mov       [rbp-5C],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-5C]
       call      qword ptr [7F2D7B0DDEA8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-68],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-68]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M34_L03
       mov       rdi,7F2D7B4D6A64
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,70
       pop       rbp
       ret
M34_L03:
       mov       rdi,7F2D7B4D6A68
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M34_L00
M34_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 269
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-4C],ecx
       mov       dword ptr [rbp-70],3E8
M35_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M35_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M35_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rax,[rbp-48]
       mov       ecx,[rbp-4C]
       cmp       ecx,[rax+8]
       jae       near ptr M35_L03
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       add       rax,8
       mov       [rbp-68],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7F2D7B0DDE90]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-68]
       mov       [rcx],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-4C]
       call      qword ptr [7F2D7B0DDEA8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-60],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-60]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M35_L02
       mov       rdi,7F2D7B4D7CE0
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,70
       pop       rbp
       ret
M35_L02:
       mov       rdi,7F2D7B4D7CE4
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M35_L00
M35_L03:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 235
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F2D7A1EEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F2D7A1EEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; System.Threading.Monitor.Enter(System.Object, Boolean ByRef)
       push      rbp
       push      r15
       push      rbx
       lea       rbp,[rsp+10]
       mov       r15,rdi
       mov       rbx,rsi
       cmp       byte ptr [rbx],0
       je        short M37_L00
       call      qword ptr [7F2D7A2069F0]
       int       3
M37_L00:
       test      r15,r15
       je        short M37_L02
       mov       rdi,r15
       call      qword ptr [7F2D7A2069B0]
       test      eax,eax
       jne       short M37_L01
       mov       rdi,r15
       call      qword ptr [7F2D7A2069C0]
M37_L01:
       mov       byte ptr [rbx],1
       pop       rbx
       pop       r15
       pop       rbp
       ret
M37_L02:
       xor       edi,edi
       call      qword ptr [7F2D7A201208]
       int       3
; Total bytes of code 71
```
```assembly
; System.Span`1[[System.__Canon, System.Private.CoreLib]].op_Implicit(System.__Canon[])
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7F2D7A1F69B0]
       mov       rdi,rax
       test      rbx,rbx
       je        short M38_L01
       mov       r15,[rbx]
       call      qword ptr [7F2D7A1F8528]
       cmp       r15,rax
       jne       short M38_L02
       lea       rax,[rbx+10]
       mov       edx,[rbx+8]
M38_L00:
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
M38_L01:
       xor       eax,eax
       xor       edx,edx
       jmp       short M38_L00
M38_L02:
       call      qword ptr [7F2D7A204118]
       int       3
; Total bytes of code 77
```
```assembly
; System.WeakReference`1[[System.__Canon, System.Private.CoreLib]]..ctor(System.__Canon)
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       xor       edx,edx
       jmp       qword ptr [rax]
; Total bytes of code 12
```
```assembly
; System.Threading.Monitor.Exit(System.Object)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rbx,rdi
       test      rbx,rbx
       je        short M40_L01
       mov       rdi,rbx
       call      qword ptr [7F2D7A2069F8]
       test      eax,eax
       je        short M40_L00
       mov       rsi,rbx
       mov       edi,eax
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
M40_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M40_L01:
       xor       edi,edi
       call      qword ptr [7F2D7A201208]
       int       3
; Total bytes of code 66
```
```assembly
; System.Object..ctor()
       ret
; Total bytes of code 1
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       eax,[rbp-10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 27
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-1C],edx
       mov       rax,[rbp-18]
       sar       rax,20
       lea       esi,[rax+1]
       mov       rdi,[rbp-10]
       mov       edx,[rbp-1C]
       call      qword ptr [7F2D7AA3E130]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 56
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-10],edx
       movsxd    rax,dword ptr [rbp-0C]
       shl       rax,20
       mov       ecx,[rbp-10]
       or        rax,rcx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 40
```

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: dry-1.9.0(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.9.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.9.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=1, LaunchCount=1, RunStrategy=ColdStart, UnrollFactor=1, WarmupCount=1))

```assembly
; PoolContextProbe.NestedRentReturn()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rdi,[rax+8]
       cmp       [rdi],edi
       call      qword ptr [7FC373ABDBC0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Rent()
       mov       [rbp-10],rax
       mov       rax,[rbp-8]
       mov       rdi,[rax+8]
       cmp       [rdi],edi
       call      qword ptr [7FC373ABDBC0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Rent()
       mov       [rbp-18],rax
       mov       rax,[rbp-10]
       mov       eax,[rax+8]
       mov       rcx,[rbp-18]
       add       eax,[rcx+8]
       mov       [rbp-1C],eax
       mov       rax,[rbp-8]
       mov       rdi,[rax+8]
       mov       rsi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7FC373ABDBD8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Return(System.__Canon)
       mov       rax,[rbp-8]
       mov       rdi,[rax+8]
       mov       rsi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7FC373ABDBD8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Return(System.__Canon)
       mov       eax,[rbp-1C]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 130
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Rent()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-18],rax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       movzx     eax,byte ptr [rax+24]
       test      eax,eax
       je        short M01_L00
       lea       rsi,[rbp-20]
       mov       rdi,[rbp-10]
       call      qword ptr [7FC373ABDBF0]
       nop
       add       rsp,20
       pop       rbp
       ret
M01_L00:
       mov       rdi,[rbp-10]
       call      qword ptr [7FC373ABDC08]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ThrowIfDisposed()
       mov       rdi,[rbp-10]
       call      qword ptr [7FC373ABDC20]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].RentWithoutLifecycle()
       mov       [rbp-18],rax
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+1C],0
       jne       short M01_L01
       mov       rax,[rbp-18]
       add       rsp,20
       pop       rbp
       ret
M01_L01:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7FC373ABDC38]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       call      qword ptr [7FC373ABDC50]
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 139
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Return(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rdi,[rbp-10]
       mov       rsi,7FC368A044E0
       call      qword ptr [7FC373705878]; System.ArgumentNullException.ThrowIfNull(System.Object, System.String)
       mov       rax,[rbp-8]
       movzx     eax,byte ptr [rax+24]
       test      eax,eax
       je        short M02_L00
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FC373ABDF08]
       nop
       add       rsp,10
       pop       rbp
       ret
M02_L00:
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+1C],0
       je        short M02_L01
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FC373ABDC38]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
       add       rsp,10
       pop       rbp
       ret
M02_L01:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FC373ABDF20]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       test      eax,eax
       jne       short M02_L02
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FC373ABDC38]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
       add       rsp,10
       pop       rbp
       ret
M02_L02:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FC373ABDF38]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ReturnWithoutReset(System.__Canon)
       mov       rdi,[rbp-8]
       call      qword ptr [7FC373ABDF50]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ClearIfDisposed()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 172
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ThrowIfDisposed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+1C],0
       je        short M03_L00
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       call      qword ptr [7FC373ABDC50]
M03_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 48
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].RentWithoutLifecycle()
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-18],rax
       xor       eax,eax
       mov       [rbp-1C],eax
       cmp       qword ptr [rbp-18],0
       jne       near ptr M04_L05
       mov       rdi,[rbp-10]
       call      qword ptr [7FC373ABDCC8]
       mov       [rbp-1C],eax
       mov       rdi,[rbp-10]
       mov       esi,[rbp-1C]
       call      qword ptr [7FC373ABDCE0]
       mov       [rbp-30],rax
       mov       rax,[rbp-30]
       mov       rax,[rax]
       mov       [rbp-38],rax
       cmp       qword ptr [rbp-38],0
       je        short M04_L02
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-60],rax
       mov       rax,[rbp-60]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+30]
       mov       [rbp-68],rax
       cmp       qword ptr [rbp-68],0
       je        short M04_L00
       mov       rax,[rbp-68]
       mov       [rbp-58],rax
       jmp       short M04_L01
M04_L00:
       mov       rdi,[rbp-60]
       mov       rsi,7FC373E0FA68
       call      qword ptr [7FC37302F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-58],rax
M04_L01:
       mov       rdi,[rbp-58]
       mov       rsi,[rbp-30]
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-38]
       call      qword ptr [7FC37341E868]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       cmp       rax,[rbp-38]
       je        short M04_L03
M04_L02:
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-40]
       mov       [rbp-50],rax
       jmp       short M04_L04
M04_L03:
       mov       rax,[rbp-38]
       mov       [rbp-50],rax
M04_L04:
       mov       rax,[rbp-50]
       mov       [rbp-28],rax
       jmp       short M04_L06
M04_L05:
       lea       rsi,[rbp-28]
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7FC373ABDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
M04_L06:
       mov       rax,[rbp-28]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-28],0
       jne       short M04_L08
       cmp       qword ptr [rbp-18],0
       je        short M04_L07
       mov       rdi,[rbp-10]
       call      qword ptr [7FC373ABDD10]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].CreateItem()
       nop
       add       rsp,70
       pop       rbp
       ret
M04_L07:
       mov       rdi,[rbp-10]
       mov       esi,[rbp-1C]
       call      qword ptr [7FC373ABDD28]
       mov       [rbp-48],rax
M04_L08:
       mov       rax,[rbp-48]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 330
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7FC37406C5E8]; PoolContextProbe+Policy.Destroy(Item)
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 49
```
```assembly
; System.ArgumentNullException.ThrowIfNull(System.Object, System.String)
       push      rax
       test      rdi,rdi
       je        short M06_L00
       add       rsp,8
       ret
M06_L00:
       mov       rdi,rsi
       call      qword ptr [7FC372BE1208]
       int       3
; Total bytes of code 21
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-30],rax
       mov       rax,[rbp-30]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+38]
       mov       [rbp-38],rax
       cmp       qword ptr [rbp-38],0
       je        short M07_L00
       mov       rax,[rbp-38]
       mov       [rbp-28],rax
       jmp       short M07_L01
M07_L00:
       mov       rdi,[rbp-30]
       mov       rsi,7FC373EC0540
       call      qword ptr [7FC37302F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-28],rax
M07_L01:
       mov       byte ptr [rbp-20],0
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7FC373ABDF68]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItemGuarded(System.__Canon)
       nop
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 124
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ReturnWithoutReset(System.__Canon)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-20],0
       je        short M08_L01
       mov       rdi,[rbp-20]
       mov       rsi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7FC373ABE070]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(System.__Canon)
       test      eax,eax
       jne       short M08_L00
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7FC373ABDC38]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
M08_L00:
       nop
       add       rsp,50
       pop       rbp
       ret
M08_L01:
       mov       rdi,[rbp-10]
       call      qword ptr [7FC373ABDCC8]
       mov       [rbp-24],eax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-48],rax
       mov       rax,[rbp-48]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+40]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       je        short M08_L02
       mov       rax,[rbp-50]
       mov       [rbp-38],rax
       jmp       short M08_L03
M08_L02:
       mov       rdi,[rbp-48]
       mov       rsi,7FC373EC08A8
       call      qword ptr [7FC37302F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-38],rax
M08_L03:
       mov       rdi,[rbp-10]
       mov       esi,[rbp-24]
       call      qword ptr [7FC373ABDCE0]
       mov       [rbp-40],rax
       mov       rsi,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rdx,[rbp-18]
       call      qword ptr [7FC373ABE028]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-30],0
       jne       short M08_L04
       add       rsp,50
       pop       rbp
       ret
M08_L04:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-30]
       mov       ecx,[rbp-24]
       call      qword ptr [7FC373ABE088]
       nop
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 262
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ClearIfDisposed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+1C],0
       je        short M09_L00
       mov       rdi,[rbp-8]
       call      qword ptr [7FC373ABE0D0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
M09_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 41
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7FC372BCEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7FC372BCEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       push      rax
       mov       rax,rdx
       test      rsi,rsi
       je        short M11_L00
       mov       rdx,rcx
       mov       rdi,rsi
       mov       rsi,rax
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       jmp       qword ptr [rax]
M11_L00:
       call      qword ptr [7FC372BE4288]
       int       3
; Total bytes of code 39
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-14],eax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rdi,[rbp-8]
       call      qword ptr [7FC373ABDD40]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-14],eax
       mov       rdi,[rbp-8]
       mov       esi,[rbp-14]
       mov       rdx,[rbp-10]
       call      qword ptr [7FC373ABDD58]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       je        short M12_L00
       mov       eax,1
       add       rsp,20
       pop       rbp
       ret
M12_L00:
       mov       rdi,[rbp-8]
       mov       esi,[rbp-14]
       mov       rdx,[rbp-10]
       call      qword ptr [7FC373ABDD70]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 92
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].CreateItem()
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       call      qword ptr [7FC373ABDED8]; PoolContextProbe+Policy.Create()
       mov       [rbp-18],rax
       mov       rax,[rbp-18]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-18],0
       jne       short M13_L00
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-28],rax
       mov       edi,67
       mov       rsi,7FC3734A56B0
       call      qword ptr [7FC37302EF88]
       mov       [rbp-30],rax
       mov       rsi,[rbp-30]
       mov       rdi,[rbp-28]
       call      qword ptr [7FC373705680]
       mov       rdi,[rbp-28]
       call      CORINFO_HELP_THROW
       int       3
M13_L00:
       mov       rax,[rbp-20]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 147
```
```assembly
; PoolContextProbe+Policy.Destroy(Item)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 24
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItemGuarded(System.__Canon)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7FC373ABDFF8]; PoolContextProbe+Policy.TryReset(Item)
       mov       [rbp-14],eax
       mov       eax,[rbp-14]
       add       rsp,50
       pop       rbp
       ret
       push      rax
       mov       [rbp-38],rdi
       mov       rax,[rbp-38]
       mov       [rbp-28],rax
       mov       rdi,offset MT_System.Exception[]
       mov       esi,2
       call      CORINFO_HELP_NEWARR_1_PTR
       mov       [rbp-40],rax
       mov       rdi,[rbp-40]
       mov       rdx,[rbp-20]
       xor       esi,esi
       call      qword ptr [7FC3730257A0]; System.Runtime.CompilerServices.CastHelpers.StelemRef(System.Object[], IntPtr, System.Object)
       mov       rdi,[rbp-40]
       mov       rdx,[rbp-28]
       mov       esi,1
       call      qword ptr [7FC3730257A0]; System.Runtime.CompilerServices.CastHelpers.StelemRef(System.Object[], IntPtr, System.Object)
       mov       rdi,offset MT_System.AggregateException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-48],rax
       mov       edi,0C1
       mov       rsi,7FC3734A56B0
       call      qword ptr [7FC37302EF88]
       mov       [rbp-50],rax
       mov       rsi,[rbp-50]
       mov       rdi,[rbp-48]
       mov       rdx,[rbp-40]
       call      qword ptr [7FC373ABE010]
       mov       rdi,[rbp-48]
       call      CORINFO_HELP_THROW
       int       3
       push      rax
       mov       [rbp-30],rdi
       mov       rax,[rbp-30]
       mov       [rbp-20],rax
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FC373ABDC38]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 247
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(System.__Canon)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       xor       eax,eax
       mov       [rbp-68],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       dword ptr [rbp-78],3E8
       mov       rdi,[rbp-38]
       call      qword ptr [7FC373ABDD40]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-44],eax
       xor       eax,eax
       mov       [rbp-48],eax
       jmp       near ptr M16_L08
M16_L00:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       ecx,[rbp-44]
       cmp       ecx,[rax+8]
       jae       near ptr M16_L10
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       rax,[rax]
       mov       [rbp-50],rax
       mov       rax,[rbp-50]
       cmp       qword ptr [rax+50],0
       jne       near ptr M16_L03
       mov       rax,[rbp-50]
       cmp       [rax],al
       mov       rax,[rbp-50]
       add       rax,50
       mov       [rbp-68],rax
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-80],rax
       mov       rax,[rbp-80]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+20]
       mov       [rbp-88],rax
       cmp       qword ptr [rbp-88],0
       je        short M16_L01
       mov       rax,[rbp-88]
       mov       [rbp-70],rax
       jmp       short M16_L02
M16_L01:
       mov       rdi,[rbp-80]
       mov       rsi,7FC373E0FCD8
       call      qword ptr [7FC37302F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-70],rax
M16_L02:
       mov       rdi,[rbp-70]
       mov       rsi,[rbp-68]
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-58]
       call      qword ptr [7FC37341E868]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       test      rax,rax
       je        short M16_L05
       mov       rdi,7FC373EB7A70
       call      CORINFO_HELP_COUNTPROFILE32
M16_L03:
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       mov       rsi,[rbp-50]
       mov       rdx,[rbp-40]
       call      qword ptr [7FC373ABE0A0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       je        short M16_L06
M16_L04:
       mov       rdi,7FC373EB7A74
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,90
       pop       rbp
       ret
M16_L05:
       mov       rdi,7FC373EB7A78
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       short M16_L04
M16_L06:
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-5C],eax
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-44],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-5C]
       jne       short M16_L07
       mov       rdi,7FC373EB7A7C
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-44],eax
M16_L07:
       mov       rdi,7FC373EB7A80
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-48]
       inc       eax
       mov       [rbp-48],eax
M16_L08:
       mov       eax,[rbp-78]
       dec       eax
       mov       [rbp-78],eax
       cmp       dword ptr [rbp-78],0
       jg        short M16_L09
       lea       rdi,[rbp-78]
       mov       esi,62
       call      CORINFO_HELP_PATCHPOINT
M16_L09:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-48]
       jg        near ptr M16_L00
       mov       rdi,7FC373EB7A84
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,90
       pop       rbp
       ret
M16_L10:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 495
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       push      rbp
       sub       rsp,0B0
       lea       rbp,[rsp+0B0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       dword ptr [rbp-88],3E8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-98],rax
       mov       rax,[rbp-98]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+48]
       mov       [rbp-0A0],rax
       cmp       qword ptr [rbp-0A0],0
       je        short M17_L00
       mov       rax,[rbp-0A0]
       mov       [rbp-70],rax
       jmp       short M17_L01
M17_L00:
       mov       rdi,[rbp-98]
       mov       rsi,7FC3740A3D78
       call      qword ptr [7FC37302F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-70],rax
M17_L01:
       mov       rax,[rbp-38]
       cmp       [rax],al
       mov       rax,[rbp-38]
       lea       rdi,[rax+28]
       mov       rsi,[rbp-70]
       mov       rdx,[rbp-38]
       call      qword ptr [7FC37406C360]; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       nop
M17_L02:
       mov       rax,[rbp-38]
       mov       rax,[rax+10]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-48],0
       je        near ptr M17_L07
M17_L03:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M17_L04
       lea       rdi,[rbp-88]
       mov       esi,1D
       call      CORINFO_HELP_PATCHPOINT
M17_L04:
       lea       rsi,[rbp-50]
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7FC373ABDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       test      eax,eax
       je        short M17_L05
       mov       rdi,7FC37409D7BC
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-50]
       call      qword ptr [7FC37406C3A8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       jmp       short M17_L03
M17_L05:
       cmp       qword ptr [rbp-40],0
       je        short M17_L06
       mov       rdi,7FC37409D7C0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7FC37406C3C0]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FC37406C3D8]
M17_L06:
       mov       rdi,7FC37409D7C4
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M17_L07:
       xor       eax,eax
       mov       [rbp-54],eax
       jmp       near ptr M17_L12
M17_L08:
       mov       rdi,[rbp-38]
       mov       esi,[rbp-54]
       call      qword ptr [7FC373ABDCE0]
       mov       [rbp-60],rax
       mov       rax,[rbp-60]
       cmp       qword ptr [rax],0
       je        near ptr M17_L11
       mov       rdi,7FC37409D7C8
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-68],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-0A8],rax
       mov       rax,[rbp-0A8]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+40]
       mov       [rbp-0B0],rax
       cmp       qword ptr [rbp-0B0],0
       je        short M17_L09
       mov       rax,[rbp-0B0]
       mov       [rbp-78],rax
       jmp       short M17_L10
M17_L09:
       mov       rdi,[rbp-0A8]
       mov       rsi,7FC373EC08A8
       call      qword ptr [7FC37302F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-78],rax
M17_L10:
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-60]
       mov       rdx,[rbp-68]
       call      qword ptr [7FC373ABE028]
       mov       [rbp-90],rax
       mov       rsi,[rbp-90]
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       call      qword ptr [7FC37406C3A8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
M17_L11:
       mov       rdi,7FC37409D7CC
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-54]
       inc       eax
       mov       [rbp-54],eax
M17_L12:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M17_L13
       lea       rdi,[rbp-88]
       mov       esi,79
       call      CORINFO_HELP_PATCHPOINT
M17_L13:
       mov       rdi,[rbp-38]
       call      qword ptr [7FC37406C3F0]
       cmp       eax,[rbp-54]
       jg        near ptr M17_L08
       cmp       qword ptr [rbp-40],0
       je        short M17_L14
       mov       rdi,7FC37409D7D0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7FC37406C3C0]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FC37406C3D8]
M17_L14:
       mov       rdi,7FC37409D7D4
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
       push      rax
       mov       [rbp-80],rdi
       mov       rdi,7FC37409D7B8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-80]
       mov       [rbp-40],rax
       lea       rax,[M17_L02]
       add       rsp,8
       ret
; Total bytes of code 760
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7FC372BD4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7FC372BCEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7FC372BDF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M18_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M18_L00
       mov       rsi,rax
       call      qword ptr [7FC372BCEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M18_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp-3C],eax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       dword ptr [rbp-48],3E8
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FC373ABDD88]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       eax,[rax+10]
       mov       [rbp-3C],eax
       cmp       dword ptr [rbp-3C],0
       jne       short M19_L02
M19_L00:
       mov       eax,[rbp-48]
       dec       eax
       mov       [rbp-48],eax
       cmp       dword ptr [rbp-48],0
       jg        short M19_L01
       lea       rdi,[rbp-48]
       mov       esi,9
       call      CORINFO_HELP_PATCHPOINT
M19_L01:
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FC373025728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,rax
       call      qword ptr [7FC373ABDDA0]; System.Threading.Interlocked.Increment(Int32 ByRef)
       mov       [rbp-3C],eax
       cmp       dword ptr [rbp-3C],0
       je        short M19_L03
       mov       rdi,7FC373EB6810
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FC373ABDD88]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       ecx,[rbp-3C]
       mov       [rax+10],ecx
M19_L02:
       mov       rdi,7FC373EB6814
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-3C]
       lea       esi,[rax-1]
       mov       rdi,[rbp-38]
       call      qword ptr [7FC373ABDDB8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetAffinityIndex(UInt32)
       nop
       add       rsp,50
       pop       rbp
       ret
M19_L03:
       mov       rdi,7FC373EB6818
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M19_L00
; Total bytes of code 206
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       push      rbp
       sub       rsp,60
       lea       rbp,[rsp+60]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-14],esi
       mov       [rbp-20],rdx
       mov       rax,[rbp-10]
       mov       rax,[rax+8]
       mov       ecx,[rbp-14]
       cmp       ecx,[rax+8]
       jae       near ptr M20_L03
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       rax,[rax]
       mov       [rbp-28],rax
       mov       rax,[rbp-28]
       mov       rax,[rax+50]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-30],0
       je        near ptr M20_L02
       mov       rax,[rbp-28]
       cmp       [rax],al
       mov       rax,[rbp-28]
       add       rax,50
       mov       [rbp-40],rax
       xor       eax,eax
       mov       [rbp-38],rax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-50],rax
       mov       rax,[rbp-50]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+20]
       mov       [rbp-58],rax
       cmp       qword ptr [rbp-58],0
       je        short M20_L00
       mov       rax,[rbp-58]
       mov       [rbp-48],rax
       jmp       short M20_L01
M20_L00:
       mov       rdi,[rbp-50]
       mov       rsi,7FC373E0FCD8
       call      qword ptr [7FC37302F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-48],rax
M20_L01:
       mov       rdi,[rbp-48]
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-38]
       mov       rcx,[rbp-30]
       call      qword ptr [7FC37341E868]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       cmp       rax,[rbp-30]
       jne       short M20_L02
       mov       rdi,[rbp-20]
       mov       rsi,[rbp-30]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       eax,1
       add       rsp,60
       pop       rbp
       ret
M20_L02:
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       mov       rsi,[rbp-28]
       mov       rdx,[rbp-20]
       call      qword ptr [7FC373ABDE48]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       nop
       add       rsp,60
       pop       rbp
       ret
M20_L03:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 273
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       push      rbp
       sub       rsp,60
       lea       rbp,[rsp+60]
       xor       eax,eax
       mov       [rbp-54],rax
       mov       [rbp-4C],eax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-3C],esi
       mov       [rbp-48],rdx
       mov       dword ptr [rbp-60],3E8
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FC373ABDD88]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       eax,[rax+14]
       dec       eax
       mov       [rbp-4C],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-4C]
       jbe       short M21_L02
       mov       eax,[rbp-4C]
       cmp       eax,[rbp-3C]
       je        short M21_L01
       mov       rdi,[rbp-38]
       mov       esi,[rbp-4C]
       mov       rdx,[rbp-48]
       call      qword ptr [7FC373ABDD58]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       je        short M21_L00
       mov       rdi,7FC373EB6AD0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,60
       pop       rbp
       ret
M21_L00:
       mov       rdi,7FC373EB6AD4
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       short M21_L02
M21_L01:
       mov       rdi,7FC373EB6AD8
       call      CORINFO_HELP_COUNTPROFILE32
M21_L02:
       mov       eax,[rbp-3C]
       mov       [rbp-50],eax
       mov       dword ptr [rbp-54],1
       jmp       near ptr M21_L06
M21_L03:
       mov       eax,[rbp-50]
       inc       eax
       mov       [rbp-58],eax
       mov       eax,[rbp-50]
       inc       eax
       mov       [rbp-50],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-58]
       jne       short M21_L04
       mov       rdi,7FC373EB6ADC
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-50],eax
M21_L04:
       mov       rdi,[rbp-38]
       mov       esi,[rbp-50]
       mov       rdx,[rbp-48]
       call      qword ptr [7FC373ABDD58]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       je        short M21_L05
       mov       rdi,7FC373EB6AE0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FC373ABDD88]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       ecx,[rbp-50]
       inc       ecx
       mov       [rax+14],ecx
       mov       eax,1
       add       rsp,60
       pop       rbp
       ret
M21_L05:
       mov       rdi,7FC373EB6AE4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-54]
       inc       eax
       mov       [rbp-54],eax
M21_L06:
       mov       eax,[rbp-60]
       dec       eax
       mov       [rbp-60],eax
       cmp       dword ptr [rbp-60],0
       jg        short M21_L07
       lea       rdi,[rbp-60]
       mov       esi,52
       call      CORINFO_HELP_PATCHPOINT
M21_L07:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-54]
       jg        near ptr M21_L03
       mov       rdi,7FC373EB6AE8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-48]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,60
       pop       rbp
       ret
; Total bytes of code 406
```
```assembly
; PoolContextProbe+Policy.Create()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_PoolContextProbe+Item
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7FC373ABDEF0]; PoolContextProbe+Item..ctor()
       mov       rax,[rbp-10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 59
```
```assembly
; PoolContextProbe+Policy.TryReset(Item)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       eax,1
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 29
```
```assembly
; System.Runtime.CompilerServices.CastHelpers.StelemRef(System.Object[], IntPtr, System.Object)
       push      rbp
       mov       rbp,rsp
       mov       eax,[rdi+8]
       cmp       rax,rsi
       jbe       short M24_L03
       lea       rcx,[rdi+rsi*8+10]
       mov       rsi,[rdi]
       mov       rsi,[rsi+30]
       test      rdx,rdx
       je        short M24_L02
       cmp       rsi,[rdx]
       jne       short M24_L01
M24_L00:
       mov       rsi,rdx
       mov       rdi,rcx
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       pop       rbp
       jmp       qword ptr [rax]
M24_L01:
       mov       rdi,[rdi]
       cmp       rdi,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       je        short M24_L00
       mov       rdi,rcx
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       pop       rbp
       jmp       qword ptr [rax]
M24_L02:
       xor       eax,eax
       mov       [rcx],rax
       pop       rbp
       ret
M24_L03:
       call      qword ptr [7FC372BE96B8]
       int       3
; Total bytes of code 91
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+48]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+60]
       mov       rdi,[rbp-10]
       call      qword ptr [7FC373ABDE60]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M25_L00
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M25_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+48]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M25_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rbp-20]
       mov       rdi,rax
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+58]
       mov       rax,[rbp-18]
       mov       rdx,[rax+48]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7FC373ABDE78]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       eax,1
       add       rsp,30
       pop       rbp
       ret
M25_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 171
```
```assembly
; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       push      rbp
       sub       rsp,310
       lea       rbp,[rsp+310]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-270],xmm8
       mov       rax,0FFFFFFFFFFFFFDF0
M26_L00:
       vmovdqa   xmmword ptr [rbp+rax-50],xmm8
       vmovdqa   xmmword ptr [rbp+rax-40],xmm8
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       add       rax,30
       jne       short M26_L00
       mov       [rbp-50],rax
       mov       [rbp-30],rsi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       dword ptr [rbp-228],3E8
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       jne       short M26_L01
       mov       rdi,7FC3740B00E0
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,310
       pop       rbp
       ret
M26_L01:
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+10]
       mov       [rbp-278],rax
       cmp       qword ptr [rbp-278],0
       je        short M26_L02
       mov       rax,[rbp-278]
       mov       [rbp-148],rax
       jmp       short M26_L03
M26_L02:
       mov       rdi,[rbp-40]
       mov       rsi,7FC3740A43E8
       call      qword ptr [7FC37302F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-148],rax
M26_L03:
       mov       rdi,[rbp-148]
       call      qword ptr [7FC373025728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       movzx     eax,byte ptr [rax]
       test      eax,eax
       je        near ptr M26_L37
       vxorps    ymm0,ymm0,ymm0
       vmovdqu   ymmword ptr [rbp-98],ymm0
       vmovdqu   ymmword ptr [rbp-78],ymm0
       mov       rax,[rbp-50]
       mov       [rbp-0B8],rax
       xor       eax,eax
       mov       [rbp-0C0],eax
       lea       rsi,[rbp-0C0]
       mov       rdi,[rbp-0B8]
       call      qword ptr [7FC373025980]; System.Threading.Monitor.Enter(System.Object, Boolean ByRef)
       mov       rdi,[rbp-50]
       cmp       [rdi],edi
       call      qword ptr [7FC37406C570]
       mov       [rbp-0C8],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-280],rax
       mov       rax,[rbp-280]
       cmp       qword ptr [rax+8],30
       jle       short M26_L04
       mov       rax,[rbp-280]
       mov       rax,[rax+30]
       mov       [rbp-288],rax
       cmp       qword ptr [rbp-288],0
       je        short M26_L04
       mov       rax,[rbp-288]
       mov       [rbp-178],rax
       jmp       short M26_L05
M26_L04:
       mov       rdi,[rbp-40]
       mov       rsi,7FC3740A45E8
       call      qword ptr [7FC37302F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-178],rax
M26_L05:
       mov       rax,[rbp-0C8]
       mov       [rbp-1F0],rax
       mov       rdi,[rbp-1F0]
       mov       rsi,7FC3740B00E8
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-1F0]
       mov       [rbp-230],rax
       mov       rdi,[rbp-230]
       mov       r11,[rbp-178]
       mov       rax,[rbp-178]
       call      qword ptr [rax]
       mov       [rbp-0AC],eax
       cmp       dword ptr [rbp-0AC],8
       jg        near ptr M26_L08
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-290],rax
       mov       rax,[rbp-290]
       cmp       qword ptr [rax+8],58
       jle       short M26_L06
       mov       rax,[rbp-290]
       mov       rax,[rax+58]
       mov       [rbp-298],rax
       cmp       qword ptr [rbp-298],0
       je        short M26_L06
       mov       rax,[rbp-298]
       mov       [rbp-1D8],rax
       jmp       short M26_L07
M26_L06:
       mov       rdi,[rbp-40]
       mov       rsi,7FC3740A4A18
       call      qword ptr [7FC37302F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1D8],rax
M26_L07:
       lea       rsi,[rbp-98]
       mov       rdi,[rbp-1D8]
       mov       edx,8
       call      qword ptr [7FC37406C528]
       mov       [rbp-1E8],rax
       mov       [rbp-1E0],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-1E8]
       vmovdqu   xmmword ptr [rbp-0A8],xmm0
       jmp       near ptr M26_L13
M26_L08:
       mov       rdi,7FC3740B01F0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2A0],rax
       mov       rax,[rbp-2A0]
       cmp       qword ptr [rax+8],38
       jle       short M26_L09
       mov       rax,[rbp-2A0]
       mov       rax,[rax+38]
       mov       [rbp-2A8],rax
       cmp       qword ptr [rbp-2A8],0
       je        short M26_L09
       mov       rax,[rbp-2A8]
       mov       [rbp-180],rax
       jmp       short M26_L10
M26_L09:
       mov       rdi,[rbp-40]
       mov       rsi,7FC3740A4620
       call      qword ptr [7FC37302F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-180],rax
M26_L10:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2B0],rax
       mov       rax,[rbp-2B0]
       cmp       qword ptr [rax+8],40
       jle       short M26_L11
       mov       rax,[rbp-2B0]
       mov       rax,[rax+40]
       mov       [rbp-2B8],rax
       cmp       qword ptr [rbp-2B8],0
       je        short M26_L11
       mov       rax,[rbp-2B8]
       mov       [rbp-188],rax
       jmp       short M26_L12
M26_L11:
       mov       rdi,[rbp-40]
       mov       rsi,7FC3740A46B0
       call      qword ptr [7FC37302F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-188],rax
M26_L12:
       movsxd    rsi,dword ptr [rbp-0AC]
       mov       rdi,[rbp-180]
       call      CORINFO_HELP_NEWARR_1_PTR
       mov       [rbp-238],rax
       mov       rsi,[rbp-238]
       mov       rdi,[rbp-188]
       call      qword ptr [7FC373AB5488]; System.Span`1[[System.__Canon, System.Private.CoreLib]].op_Implicit(System.__Canon[])
       mov       [rbp-198],rax
       mov       [rbp-190],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-198]
       vmovdqu   xmmword ptr [rbp-0A8],xmm0
M26_L13:
       xor       eax,eax
       mov       [rbp-0CC],eax
       jmp       near ptr M26_L17
M26_L14:
       mov       rdi,7FC3740B01F4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2C0],rax
       mov       rax,[rbp-2C0]
       cmp       qword ptr [rax+8],48
       jle       short M26_L15
       mov       rax,[rbp-2C0]
       mov       rax,[rax+48]
       mov       [rbp-2C8],rax
       cmp       qword ptr [rbp-2C8],0
       je        short M26_L15
       mov       rax,[rbp-2C8]
       mov       [rbp-1A0],rax
       jmp       short M26_L16
M26_L15:
       mov       rdi,[rbp-40]
       mov       rsi,7FC3740A46C0
       call      qword ptr [7FC37302F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1A0],rax
M26_L16:
       mov       rax,[rbp-0C8]
       mov       [rbp-1F8],rax
       mov       rdi,[rbp-1F8]
       mov       rsi,7FC3740B01F8
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-1F8]
       mov       [rbp-240],rax
       mov       rdi,[rbp-240]
       mov       r11,[rbp-1A0]
       mov       esi,[rbp-0CC]
       mov       rax,[rbp-1A0]
       call      qword ptr [rax]
       mov       [rbp-0D8],rax
       mov       rax,[rbp-0D8]
       inc       dword ptr [rax+68]
       mov       eax,[rbp-0CC]
       inc       eax
       mov       [rbp-0CC],eax
M26_L17:
       mov       eax,[rbp-228]
       dec       eax
       mov       [rbp-228],eax
       cmp       dword ptr [rbp-228],0
       jg        short M26_L18
       lea       rdi,[rbp-228]
       mov       esi,8C
       call      CORINFO_HELP_PATCHPOINT
M26_L18:
       mov       eax,[rbp-0CC]
       cmp       eax,[rbp-0AC]
       jl        near ptr M26_L14
       call      qword ptr [7FC37406C588]
       xor       eax,eax
       mov       [rbp-0DC],eax
       jmp       near ptr M26_L30
M26_L19:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2D0],rax
       mov       rax,[rbp-2D0]
       cmp       qword ptr [rax+8],48
       jle       short M26_L20
       mov       rax,[rbp-2D0]
       mov       rax,[rax+48]
       mov       [rbp-2D8],rax
       cmp       qword ptr [rbp-2D8],0
       je        short M26_L20
       mov       rax,[rbp-2D8]
       mov       [rbp-1A8],rax
       jmp       short M26_L21
M26_L20:
       mov       rdi,[rbp-40]
       mov       rsi,7FC3740A46C0
       call      qword ptr [7FC37302F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1A8],rax
M26_L21:
       mov       rax,[rbp-0C8]
       mov       [rbp-200],rax
       mov       rdi,[rbp-200]
       mov       rsi,7FC3740B0300
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-200]
       mov       [rbp-248],rax
       mov       rdi,[rbp-248]
       mov       r11,[rbp-1A8]
       mov       esi,[rbp-0DC]
       mov       rax,[rbp-1A8]
       call      qword ptr [rax]
       mov       [rbp-0E8],rax
       mov       rax,[rbp-0E8]
       mov       [rbp-0F8],rax
       xor       eax,eax
       mov       [rbp-100],eax
       lea       rsi,[rbp-100]
       mov       rdi,[rbp-0F8]
       call      qword ptr [7FC373025980]; System.Threading.Monitor.Enter(System.Object, Boolean ByRef)
       mov       rax,[rbp-0E8]
       cmp       [rax],al
       mov       rax,[rbp-0E8]
       add       rax,58
       mov       [rbp-1B0],rax
       xor       eax,eax
       mov       [rbp-108],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-2E0],rax
       cmp       qword ptr [rbp-2E0],0
       je        short M26_L22
       mov       rax,[rbp-2E0]
       mov       [rbp-1B8],rax
       jmp       short M26_L23
M26_L22:
       mov       rdi,[rbp-40]
       mov       rsi,7FC3740A4480
       call      qword ptr [7FC37302F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1B8],rax
M26_L23:
       mov       rdi,[rbp-1B8]
       mov       rsi,[rbp-1B0]
       mov       rdx,[rbp-108]
       call      qword ptr [7FC373ABE028]
       mov       [rbp-0F0],rax
       cmp       qword ptr [rbp-0F0],0
       je        near ptr M26_L27
       mov       rax,[rbp-0E8]
       mov       rax,[rax+60]
       mov       [rbp-110],rax
       cmp       qword ptr [rbp-110],0
       je        short M26_L24
       mov       rdi,7FC3740B0408
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-110]
       mov       rsi,[rbp-0F0]
       cmp       [rdi],edi
       call      qword ptr [7FC37406C5A0]
       jmp       near ptr M26_L27
M26_L24:
       mov       rdi,7FC3740B040C
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2E8],rax
       mov       rax,[rbp-2E8]
       cmp       qword ptr [rax+8],50
       jle       short M26_L25
       mov       rax,[rbp-2E8]
       mov       rax,[rax+50]
       mov       [rbp-2F0],rax
       cmp       qword ptr [rbp-2F0],0
       je        short M26_L25
       mov       rax,[rbp-2F0]
       mov       [rbp-1C8],rax
       jmp       short M26_L26
M26_L25:
       mov       rdi,[rbp-40]
       mov       rsi,7FC3740A4860
       call      qword ptr [7FC37302F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1C8],rax
M26_L26:
       mov       rdi,[rbp-1C8]
       call      CORINFO_HELP_NEWFAST
       mov       [rbp-1C0],rax
       mov       rdi,[rbp-1C0]
       mov       rsi,[rbp-0F0]
       call      qword ptr [7FC373ABE400]; System.WeakReference`1[[System.__Canon, System.Private.CoreLib]]..ctor(System.__Canon)
       mov       rax,[rbp-0E8]
       lea       rdi,[rax+60]
       mov       rsi,[rbp-1C0]
       call      CORINFO_HELP_ASSIGN_REF
M26_L27:
       mov       rax,[rbp-0E8]
       inc       dword ptr [rax+68]
       call      M26_L50
       jmp       short M26_L29
M26_L28:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M26_L29:
       mov       rdi,7FC3740B0418
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-0A0]
       cmp       [rbp-0DC],eax
       jae       short M26_L28
       mov       eax,[rbp-0DC]
       mov       rcx,[rbp-0A8]
       lea       rdi,[rcx+rax*8]
       mov       rsi,[rbp-0F0]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       eax,[rbp-0DC]
       inc       eax
       mov       [rbp-0DC],eax
M26_L30:
       mov       eax,[rbp-228]
       dec       eax
       mov       [rbp-228],eax
       cmp       dword ptr [rbp-228],0
       jg        short M26_L31
       lea       rdi,[rbp-228]
       mov       esi,13A
       call      CORINFO_HELP_PATCHPOINT
M26_L31:
       mov       eax,[rbp-0DC]
       cmp       eax,[rbp-0AC]
       jl        near ptr M26_L19
       call      M26_L52
       nop
       xor       eax,eax
       mov       [rbp-114],eax
       jmp       short M26_L34
M26_L32:
       mov       eax,[rbp-0A0]
       cmp       [rbp-114],eax
       jae       near ptr M26_L49
       mov       eax,[rbp-114]
       mov       rcx,[rbp-0A8]
       mov       rax,[rcx+rax*8]
       mov       [rbp-120],rax
       cmp       qword ptr [rbp-120],0
       je        short M26_L33
       mov       rdi,7FC3740B0424
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-48]
       mov       rsi,[rbp-120]
       cmp       [rdi],edi
       call      qword ptr [7FC37406C5B8]
       nop
M26_L33:
       mov       rdi,7FC3740B0430
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-114]
       inc       eax
       mov       [rbp-114],eax
M26_L34:
       mov       eax,[rbp-228]
       dec       eax
       mov       [rbp-228],eax
       cmp       dword ptr [rbp-228],0
       jg        short M26_L35
       lea       rdi,[rbp-228]
       mov       esi,18A
       call      CORINFO_HELP_PATCHPOINT
M26_L35:
       mov       eax,[rbp-114]
       cmp       eax,[rbp-0AC]
       jl        near ptr M26_L32
       cmp       qword ptr [rbp-58],0
       je        short M26_L36
       mov       rdi,7FC3740B0434
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-58]
       call      qword ptr [7FC37406C3C0]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FC37406C3D8]
M26_L36:
       mov       rdi,7FC3740B0438
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,310
       pop       rbp
       ret
M26_L37:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-2F8],rax
       cmp       qword ptr [rbp-2F8],0
       je        short M26_L38
       mov       rax,[rbp-2F8]
       mov       [rbp-150],rax
       jmp       short M26_L39
M26_L38:
       mov       rdi,[rbp-40]
       mov       rsi,7FC3740A43F8
       call      qword ptr [7FC37302F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-150],rax
M26_L39:
       mov       rdi,[rbp-50]
       cmp       [rdi],edi
       call      qword ptr [7FC37406C570]
       mov       [rbp-208],rax
       mov       rdi,[rbp-208]
       mov       rsi,7FC3740B0440
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-208]
       mov       [rbp-250],rax
       mov       rdi,[rbp-250]
       mov       r11,[rbp-150]
       mov       rax,[rbp-150]
       call      qword ptr [rax]
       mov       [rbp-130],rax
       jmp       near ptr M26_L46
M26_L40:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-300],rax
       cmp       qword ptr [rbp-300],0
       je        short M26_L41
       mov       rax,[rbp-300]
       mov       [rbp-158],rax
       jmp       short M26_L42
M26_L41:
       mov       rdi,[rbp-40]
       mov       rsi,7FC3740A4430
       call      qword ptr [7FC37302F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-158],rax
M26_L42:
       mov       rax,[rbp-130]
       mov       [rbp-210],rax
       mov       rdi,[rbp-210]
       mov       rsi,7FC3740B0548
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-210]
       mov       [rbp-260],rax
       mov       rdi,[rbp-260]
       mov       r11,[rbp-158]
       mov       rax,[rbp-158]
       call      qword ptr [rax]
       mov       [rbp-258],rax
       mov       rax,[rbp-258]
       cmp       [rax],al
       mov       rax,[rbp-258]
       add       rax,58
       mov       [rbp-160],rax
       xor       eax,eax
       mov       [rbp-108],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-308],rax
       cmp       qword ptr [rbp-308],0
       je        short M26_L43
       mov       rax,[rbp-308]
       mov       [rbp-168],rax
       jmp       short M26_L44
M26_L43:
       mov       rdi,[rbp-40]
       mov       rsi,7FC3740A4480
       call      qword ptr [7FC37302F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-168],rax
M26_L44:
       mov       rdi,[rbp-168]
       mov       rsi,[rbp-160]
       mov       rdx,[rbp-108]
       call      qword ptr [7FC373ABE028]
       mov       [rbp-138],rax
       cmp       qword ptr [rbp-138],0
       je        short M26_L45
       mov       rdi,7FC3740B0650
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-48]
       mov       rsi,[rbp-138]
       cmp       [rdi],edi
       call      qword ptr [7FC37406C5B8]
       jmp       short M26_L46
M26_L45:
       mov       rdi,7FC3740B0654
       call      CORINFO_HELP_COUNTPROFILE32
M26_L46:
       mov       eax,[rbp-228]
       dec       eax
       mov       [rbp-228],eax
       cmp       dword ptr [rbp-228],0
       jg        short M26_L47
       lea       rdi,[rbp-228]
       mov       esi,1E9
       call      CORINFO_HELP_PATCHPOINT
M26_L47:
       mov       rax,[rbp-130]
       mov       [rbp-218],rax
       mov       rdi,[rbp-218]
       mov       rsi,7FC3740B0660
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-218]
       mov       [rbp-268],rax
       mov       rdi,[rbp-268]
       mov       r11,7FC3720405E8
       call      qword ptr [r11]
       test      eax,eax
       jne       near ptr M26_L40
       call      M26_L56
       nop
       cmp       qword ptr [rbp-58],0
       je        short M26_L48
       mov       rdi,7FC3740B087C
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-58]
       call      qword ptr [7FC37406C3C0]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FC37406C3D8]
M26_L48:
       mov       rdi,7FC3740B0880
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,310
       pop       rbp
       ret
M26_L49:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M26_L50:
       push      rax
       movzx     eax,byte ptr [rbp-100]
       test      eax,eax
       je        short M26_L51
       mov       rdi,7FC3740B0410
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-0F8]
       call      qword ptr [7FC373026808]; System.Threading.Monitor.Exit(System.Object)
M26_L51:
       mov       rdi,7FC3740B0414
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
M26_L52:
       push      rax
       movzx     eax,byte ptr [rbp-0C0]
       test      eax,eax
       je        short M26_L53
       mov       rdi,7FC3740B041C
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-0B8]
       call      qword ptr [7FC373026808]; System.Threading.Monitor.Exit(System.Object)
M26_L53:
       mov       rdi,7FC3740B0420
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
       push      rax
       mov       [rbp-1D0],rdi
       mov       rax,[rbp-1D0]
       mov       [rbp-128],rax
       cmp       qword ptr [rbp-58],0
       jne       short M26_L54
       mov       rdi,7FC3740B0428
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-128]
       mov       [rbp-58],rax
M26_L54:
       mov       rdi,7FC3740B042C
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rax,[M26_L33]
       add       rsp,8
       ret
       push      rax
       mov       [rbp-170],rdi
       mov       rax,[rbp-170]
       mov       [rbp-140],rax
       cmp       qword ptr [rbp-58],0
       jne       short M26_L55
       mov       rdi,7FC3740B0658
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-140]
       mov       [rbp-58],rax
M26_L55:
       mov       rdi,7FC3740B065C
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rax,[M26_L46]
       add       rsp,8
       ret
M26_L56:
       push      rax
       cmp       qword ptr [rbp-130],0
       je        short M26_L57
       mov       rdi,7FC3740B0768
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-130]
       mov       [rbp-220],rax
       mov       rdi,[rbp-220]
       mov       rsi,7FC3740B0770
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-220]
       mov       [rbp-270],rax
       mov       rdi,[rbp-270]
       mov       r11,7FC3720405F0
       call      qword ptr [r11]
M26_L57:
       mov       rdi,7FC3740B0878
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
; Total bytes of code 3431
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       cmp       qword ptr [rbp-10],0
       jne       short M27_L00
       add       rsp,30
       pop       rbp
       ret
M27_L00:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FC373ABDC38]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
M27_L01:
       add       rsp,30
       pop       rbp
       ret
       push      rax
       mov       [rbp-28],rdi
       mov       rax,[rbp-28]
       mov       [rbp-20],rax
       mov       rax,[rbp-18]
       cmp       qword ptr [rax],0
       jne       short M27_L02
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
M27_L02:
       lea       rax,[M27_L01]
       add       rsp,8
       ret
; Total bytes of code 114
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rax,[rdi+20]
       mov       ebx,[rax-28]
       cmp       ebx,0FFFFFFFF
       jne       short M28_L00
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
M28_L00:
       call      qword ptr [7FC372BE6AF0]; Precode of System.Threading.Thread.GetThreadStaticsBase()
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M28_L02
       cmp       [rax],edi
       jle       short M28_L04
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M28_L04
M28_L01:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M28_L02:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M28_L03
       movsxd    rcx,ecx
       add       rax,rcx
       jmp       short M28_L01
M28_L03:
       cmp       [rax+4],ecx
       jle       short M28_L04
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M28_L04
       mov       rax,[rdi]
       test      rax,rax
       je        short M28_L04
       jmp       short M28_L01
M28_L04:
       mov       edi,ebx
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
; Total bytes of code 159
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-10]
       mov       rcx,rax
       test      cl,1
       jne       short M29_L00
       ret
M29_L00:
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       jmp       qword ptr [rax]
; Total bytes of code 27
```
```assembly
; System.Threading.Interlocked.Increment(Int32 ByRef)
       mov       eax,1
       lock xadd [rdi],eax
       inc       eax
       ret
; Total bytes of code 12
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetAffinityIndex(UInt32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-18],eax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-14],esi
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+18],0
       jl        short M31_L00
       mov       rax,[rbp-10]
       mov       eax,[rax+18]
       and       eax,[rbp-14]
       add       rsp,20
       pop       rbp
       ret
M31_L00:
       mov       rax,[rbp-10]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       mov       [rbp-18],eax
       call      qword ptr [7FC373ABDDE8]
       cmp       eax,8
       jne       short M31_L01
       mov       rax,[rbp-10]
       mov       rcx,[rax+10]
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       mov       esi,[rbp-14]
       mov       edx,[rbp-18]
       call      qword ptr [7FC373ABDE00]
       nop
       add       rsp,20
       pop       rbp
       ret
M31_L01:
       mov       eax,[rbp-14]
       xor       edx,edx
       div       dword ptr [rbp-18]
       mov       eax,edx
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 127
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+48]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+58]
       mov       rdi,[rbp-10]
       call      qword ptr [7FC373ABDE60]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M32_L00
       mov       rax,[rbp-20]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M32_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+48]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M32_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rax]
       mov       rdi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       mov       rax,[rax+48]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M32_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       xor       ecx,ecx
       mov       [rax],rcx
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+60]
       mov       rax,[rbp-18]
       mov       rdx,[rax+48]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7FC373ABDE78]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       rax,[rbp-20]
       cmp       qword ptr [rax],0
       setne     al
       movzx     eax,al
       add       rsp,30
       pop       rbp
       ret
M32_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 221
```
```assembly
; PoolContextProbe+Item..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       dword ptr [rax+8],2A
       mov       rdi,[rbp-8]
       call      qword ptr [7FC37302C240]; System.Object..ctor()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-50],rcx
       mov       dword ptr [rbp-70],3E8
M34_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M34_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M34_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7FC373ABDE90]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-50]
       mov       [rcx],eax
       mov       rax,[rbp-50]
       cmp       dword ptr [rax],0FFFFFFFF
       jne       short M34_L02
       mov       rdi,7FC373EB6A60
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,70
       pop       rbp
       ret
M34_L02:
       mov       rax,[rbp-50]
       mov       eax,[rax]
       mov       rcx,[rbp-48]
       cmp       eax,[rcx+8]
       jae       short M34_L04
       mov       edx,eax
       imul      rdx,10
       lea       rcx,[rcx+rdx+10]
       mov       eax,[rcx+8]
       mov       [rbp-5C],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-5C]
       call      qword ptr [7FC373ABDEA8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-68],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-68]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M34_L03
       mov       rdi,7FC373EB6A64
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,70
       pop       rbp
       ret
M34_L03:
       mov       rdi,7FC373EB6A68
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M34_L00
M34_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 269
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-4C],ecx
       mov       dword ptr [rbp-70],3E8
M35_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M35_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M35_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rax,[rbp-48]
       mov       ecx,[rbp-4C]
       cmp       ecx,[rax+8]
       jae       near ptr M35_L03
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       add       rax,8
       mov       [rbp-68],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7FC373ABDE90]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-68]
       mov       [rcx],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-4C]
       call      qword ptr [7FC373ABDEA8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-60],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-60]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M35_L02
       mov       rdi,7FC373EB7CE0
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,70
       pop       rbp
       ret
M35_L02:
       mov       rdi,7FC373EB7CE4
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M35_L00
M35_L03:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 235
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7FC372BCEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7FC372BCEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; System.Threading.Monitor.Enter(System.Object, Boolean ByRef)
       push      rbp
       push      r15
       push      rbx
       lea       rbp,[rsp+10]
       mov       r15,rdi
       mov       rbx,rsi
       cmp       byte ptr [rbx],0
       je        short M37_L00
       call      qword ptr [7FC372BE69F0]
       int       3
M37_L00:
       test      r15,r15
       je        short M37_L02
       mov       rdi,r15
       call      qword ptr [7FC372BE69B0]
       test      eax,eax
       jne       short M37_L01
       mov       rdi,r15
       call      qword ptr [7FC372BE69C0]
M37_L01:
       mov       byte ptr [rbx],1
       pop       rbx
       pop       r15
       pop       rbp
       ret
M37_L02:
       xor       edi,edi
       call      qword ptr [7FC372BE1208]
       int       3
; Total bytes of code 71
```
```assembly
; System.Span`1[[System.__Canon, System.Private.CoreLib]].op_Implicit(System.__Canon[])
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7FC372BD69B0]
       mov       rdi,rax
       test      rbx,rbx
       je        short M38_L01
       mov       r15,[rbx]
       call      qword ptr [7FC372BD8528]
       cmp       r15,rax
       jne       short M38_L02
       lea       rax,[rbx+10]
       mov       edx,[rbx+8]
M38_L00:
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
M38_L01:
       xor       eax,eax
       xor       edx,edx
       jmp       short M38_L00
M38_L02:
       call      qword ptr [7FC372BE4118]
       int       3
; Total bytes of code 77
```
```assembly
; System.WeakReference`1[[System.__Canon, System.Private.CoreLib]]..ctor(System.__Canon)
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       xor       edx,edx
       jmp       qword ptr [rax]
; Total bytes of code 12
```
```assembly
; System.Threading.Monitor.Exit(System.Object)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rbx,rdi
       test      rbx,rbx
       je        short M40_L01
       mov       rdi,rbx
       call      qword ptr [7FC372BE69F8]
       test      eax,eax
       je        short M40_L00
       mov       rsi,rbx
       mov       edi,eax
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
M40_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M40_L01:
       xor       edi,edi
       call      qword ptr [7FC372BE1208]
       int       3
; Total bytes of code 66
```
```assembly
; System.Object..ctor()
       ret
; Total bytes of code 1
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       eax,[rbp-10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 27
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-1C],edx
       mov       rax,[rbp-18]
       sar       rax,20
       lea       esi,[rax+1]
       mov       rdi,[rbp-10]
       mov       edx,[rbp-1C]
       call      qword ptr [7FC37341E130]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 56
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-10],edx
       movsxd    rax,dword ptr [rbp-0C]
       shl       rax,20
       mov       ecx,[rbp-10]
       or        rax,rcx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 40
```

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: dry-1.9.0(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.9.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.9.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=1, LaunchCount=1, RunStrategy=ColdStart, UnrollFactor=1, WarmupCount=1))

```assembly
; PoolContextProbe.SingleContext()
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_PoolContextProbe
       call      qword ptr [7F40FE625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F3919800400
       mov       rax,[rax]
       mov       [rbp-20],rax
       mov       rdi,offset MT_PoolContextProbe+<>c
       call      qword ptr [7F40FE625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F3919800AB0
       mov       rax,[rax]
       mov       [rbp-18],rax
       mov       rax,[rbp-20]
       mov       [rbp-28],rax
       mov       rax,[rbp-18]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-18],0
       jne       short M00_L00
       mov       rdi,offset MT_System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-48],rax
       mov       rdi,offset MT_PoolContextProbe+<>c
       call      qword ptr [7F40FE625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F3919800AA8
       mov       rax,[rax]
       mov       [rbp-50],rax
       mov       rsi,[rbp-50]
       mov       rdi,[rbp-48]
       mov       rdx,offset PoolContextProbe+<>c.<SingleContext>b__5_0(Kevlar.KevlarContext)
       call      qword ptr [7F40FE626E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,offset MT_PoolContextProbe+<>c
       call      qword ptr [7F40FE625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rbp-48]
       mov       rdi,7F3919800AB0
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-48]
       mov       [rbp-30],rax
M00_L00:
       xor       eax,eax
       mov       [rbp-10],rax
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-30]
       mov       rdx,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F40FF0BE148]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       mov       [rbp-40],rax
       mov       [rbp-38],rdx
       mov       rax,[rbp-40]
       mov       rdx,[rbp-38]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 291
```
```assembly
; BenchmarkDotNet.Helpers.AwaitHelper.GetResult[[System.Int32, System.Private.CoreLib]](System.Threading.Tasks.ValueTask`1<Int32>)
       push      rbp
       sub       rsp,60
       lea       rbp,[rsp+60]
       xor       eax,eax
       mov       [rbp-58],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-10],rdi
       mov       [rbp-8],rsi
       lea       rdi,[rbp-10]
       xor       esi,esi
       call      qword ptr [7F40FF5C6FB8]; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]].ConfigureAwait(Boolean)
       mov       [rbp-40],rax
       mov       [rbp-38],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-40]
       vmovdqu   xmmword ptr [rbp-30],xmm0
       lea       rdi,[rbp-30]
       call      qword ptr [7F40FF5C6FD0]; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1[[System.Int32, System.Private.CoreLib]].GetAwaiter()
       mov       [rbp-50],rax
       mov       [rbp-48],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-50]
       vmovdqu   xmmword ptr [rbp-20],xmm0
       lea       rdi,[rbp-20]
       call      qword ptr [7F40FF5C6FE8]; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[[System.Int32, System.Private.CoreLib]].get_IsCompleted()
       test      eax,eax
       jne       short M01_L00
       call      qword ptr [7F40FF5CDA28]
       mov       [rbp-58],rax
       mov       rdi,[rbp-58]
       mov       rsi,[rbp-20]
       mov       rdx,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F40FF5CD9F8]
M01_L00:
       lea       rdi,[rbp-20]
       call      qword ptr [7F40FF5C7000]; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[[System.Int32, System.Private.CoreLib]].GetResult()
       nop
       add       rsp,60
       pop       rbp
       ret
; Total bytes of code 158
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-18]
       mov       rcx,rax
       test      cl,1
       jne       short M02_L00
       ret
M02_L00:
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       jmp       qword ptr [rax]
; Total bytes of code 27
```
```assembly
; PoolContextProbe+<>c.<SingleContext>b__5_0(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-20],xmm0
       lea       rdi,[rbp-20]
       mov       esi,2A
       call      qword ptr [7F40FF0BEB08]; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]]..ctor(Int32)
       mov       rax,[rbp-20]
       mov       rdx,[rbp-18]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 62
```
```assembly
; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       push      r15
       push      rbx
       push      rax
       mov       rbx,rdi
       mov       r15,rdx
       test      rsi,rsi
       je        short M04_L00
       lea       rdi,[rbx+8]
       call      qword ptr [7F40FE1CEEB8]; CORINFO_HELP_ASSIGN_REF
       mov       [rbx+18],r15
       add       rsp,8
       pop       rbx
       pop       r15
       ret
M04_L00:
       call      qword ptr [7F40FE1E0120]
       int       3
; Total bytes of code 44
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqa   xmmword ptr [rbp-30],xmm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       rdi,[rbp-10]
       mov       rsi,7F40FC208560
       call      qword ptr [7F40FF0BE598]; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F40FE625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F3919800AF0
       mov       rax,[rax]
       mov       [rbp-20],rax
       mov       rax,[rbp-8]
       mov       [rbp-28],rax
       mov       rax,[rbp-10]
       mov       [rbp-30],rax
       mov       rax,[rbp-20]
       mov       [rbp-38],rax
       cmp       qword ptr [rbp-20],0
       jne       near ptr M05_L00
       mov       rdi,offset MT_System.Action<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarProperties>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-80],rax
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F40FE625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F3919800AE8
       mov       rax,[rax]
       mov       [rbp-88],rax
       mov       rsi,[rbp-88]
       mov       rdi,[rbp-80]
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       call      qword ptr [7F40FE626E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F40FE625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rbp-80]
       mov       rdi,7F3919800AF0
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-80]
       mov       [rbp-38],rax
M05_L00:
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F40FE625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F3919800AF8
       mov       rax,[rax]
       mov       [rbp-40],rax
       mov       rax,[rbp-28]
       mov       [rbp-48],rax
       mov       rax,[rbp-30]
       mov       [rbp-50],rax
       mov       rax,[rbp-38]
       mov       [rbp-58],rax
       mov       rax,[rbp-40]
       mov       [rbp-60],rax
       cmp       qword ptr [rbp-40],0
       jne       near ptr M05_L01
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-78],rax
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F40FE625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F3919800AE8
       mov       rax,[rax]
       mov       [rbp-90],rax
       mov       rsi,[rbp-90]
       mov       rdi,[rbp-78]
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F40FE626E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F40FE625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rbp-78]
       mov       rdi,7F3919800AF8
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-78]
       mov       [rbp-60],rax
M05_L01:
       mov       rdi,[rbp-48]
       mov       r9,[rbp-18]
       mov       rdx,[rbp-50]
       mov       rcx,[rbp-58]
       mov       r8,[rbp-60]
       mov       rsi,7F40FF4BC308
       call      qword ptr [7F40FF0BE4C0]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       mov       [rbp-70],rax
       mov       [rbp-68],rdx
       mov       rax,[rbp-70]
       mov       rdx,[rbp-68]
       add       rsp,90
       pop       rbp
       ret
; Total bytes of code 537
```
```assembly
; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]].ConfigureAwait(Boolean)
       mov       rax,[rdi]
       mov       edx,[rdi+8]
       movsx     rcx,word ptr [rdi+0C]
       movzx     edi,sil
       movzx     ecx,cx
       shl       rcx,20
       or        rdx,rcx
       mov       ecx,edi
       shl       rcx,30
       or        rdx,rcx
       ret
; Total bytes of code 35
```
```assembly
; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1[[System.Int32, System.Private.CoreLib]].GetAwaiter()
       sub       rsp,18
       xor       eax,eax
       mov       [rsp+8],rax
       movups    xmm0,[rdi]
       movups    [rsp+8],xmm0
       mov       rax,[rsp+8]
       mov       rdx,[rsp+10]
       add       rsp,18
       ret
; Total bytes of code 34
```
```assembly
; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[[System.Int32, System.Private.CoreLib]].get_IsCompleted()
       push      rbp
       push      r15
       push      rbx
       lea       rbp,[rsp+10]
       mov       rbx,rdi
       mov       r15,[rbx]
       test      r15,r15
       je        short M08_L04
       mov       rdi,r15
       call      qword ptr [7F40FE1DCE98]
       test      rax,rax
       jne       short M08_L03
       movsx     rsi,word ptr [rbx+0C]
       mov       rdi,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       cmp       rdi,[r15]
       je        short M08_L02
       mov       rdi,r15
       lea       r11,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       call      qword ptr [r11]
M08_L00:
       test      eax,eax
       setne     al
       movzx     eax,al
M08_L01:
       pop       rbx
       pop       r15
       pop       rbp
       ret
M08_L02:
       lea       rdi,[r15+40]
       call      qword ptr [7F40FE1EF4C0]
       jmp       short M08_L00
M08_L03:
       test      dword ptr [rax+34],1600000
       setne     al
       movzx     eax,al
       jmp       short M08_L01
M08_L04:
       mov       eax,1
       jmp       short M08_L01
; Total bytes of code 111
```
```assembly
; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[[System.Int32, System.Private.CoreLib]].GetResult()
       push      rbp
       push      r15
       push      r14
       push      rbx
       push      rax
       lea       rbp,[rsp+20]
       mov       rbx,rdi
       mov       r15,[rbx]
       test      r15,r15
       je        short M09_L03
       mov       rdi,r15
       call      qword ptr [7F40FE1DCE98]
       mov       r14,rax
       test      r14,r14
       jne       short M09_L01
       movsx     rsi,word ptr [rbx+0C]
       mov       rdi,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       cmp       rdi,[r15]
       je        short M09_L00
       mov       rdi,r15
       lea       r11,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M09_L00:
       mov       rdi,r15
       call      qword ptr [7F40FE1DF2E8]
       jmp       short M09_L04
M09_L01:
       mov       edi,[r14+34]
       and       edi,11000000
       cmp       edi,1000000
       jne       short M09_L05
M09_L02:
       mov       eax,[r14+38]
       jmp       short M09_L04
M09_L03:
       mov       eax,[rbx+8]
M09_L04:
       add       rsp,8
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M09_L05:
       mov       rdi,r14
       xor       esi,esi
       call      qword ptr [7F40FE1E99B0]
       jmp       short M09_L02
; Total bytes of code 142
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7F40FE1D4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7F40FE1CEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7F40FE1DF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M10_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M10_L00
       mov       rsi,rax
       call      qword ptr [7F40FE1CEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M10_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]]..ctor(Int32)
       mov       [rdi+8],esi
       xor       eax,eax
       mov       [rdi],rax
       mov       byte ptr [rdi+0E],1
       mov       word ptr [rdi+0C],0
       ret
; Total bytes of code 19
```
```assembly
; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       cmp       qword ptr [rbp-8],0
       jne       short M12_L00
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-18],rax
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-10]
       call      qword ptr [7F40FED0E310]
       mov       rdi,[rbp-18]
       call      CORINFO_HELP_THROW
       int       3
M12_L00:
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 80
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 28
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       rax,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdi,[rax+8]
       mov       rax,[rbp-10]
       call      qword ptr [rax+18]
       mov       [rbp-28],rax
       mov       [rbp-20],rdx
       mov       rax,[rbp-28]
       mov       rdx,[rbp-20]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 69
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
M15_L00:
       push      rbp
       sub       rsp,0A0
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-88],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-40],rax
       mov       [rbp-8],rsi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       mov       rdi,[rbp-28]
       mov       rsi,7F40FC208588
       call      qword ptr [7F40FF0BE598]; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       mov       rdi,[rbp-30]
       mov       rsi,7F40FC208560
       call      qword ptr [7F40FF0BE598]; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       mov       rax,[rbp-10]
       mov       rax,[rax+38]
       mov       [rbp-40],rax
       cmp       qword ptr [rbp-40],0
       je        short M15_L01
       mov       rax,[rbp-40]
       mov       rdi,[rax+8]
       mov       rax,[rbp-40]
       call      qword ptr [rax+18]
       mov       [rbp-80],rax
       mov       rdi,[rbp-80]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-20]
       mov       rcx,[rbp-28]
       mov       r8,[rbp-30]
       mov       r9,[rbp-38]
       cmp       [rdi],edi
       call      qword ptr [7F40FF0BE4C0]
       mov       [rbp-78],rax
       mov       [rbp-70],rdx
       mov       rax,[rbp-78]
       mov       rdx,[rbp-70]
       add       rsp,0A0
       pop       rbp
       ret
M15_L01:
       mov       rdi,[rbp-10]
       call      qword ptr [7F40FF0BE640]; Kevlar.Shield.ThrowIfVoidFallbackResultExecution()
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-48],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F40FF0BE658]; Kevlar.Shield.get_TimeOrSystem()
       mov       [rbp-50],rax
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-90],rax
       cmp       qword ptr [rbp-90],0
       je        short M15_L02
       mov       rax,[rbp-90]
       mov       [rbp-58],rax
       jmp       short M15_L03
M15_L02:
       mov       rdi,[rbp-18]
       mov       rsi,7F40FF4C34B8
       call      qword ptr [7F40FE62F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-58],rax
M15_L03:
       mov       rdi,[rbp-10]
       call      qword ptr [7F40FF0BE670]; Kevlar.Shield.get_Name()
       mov       [rbp-88],rax
       mov       rax,[rbp-30]
       mov       [rsp],rax
       mov       rax,[rbp-38]
       mov       [rsp+8],rax
       mov       rcx,[rbp-88]
       mov       rsi,[rbp-48]
       mov       rdx,[rbp-50]
       mov       rdi,[rbp-58]
       mov       r8,[rbp-20]
       mov       r9,[rbp-28]
       call      qword ptr [7F40FF0BE5E0]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       mov       [rbp-68],rax
       mov       [rbp-60],rdx
       mov       rax,[rbp-68]
       mov       rdx,[rbp-60]
       add       rsp,0A0
       pop       rbp
       ret
; Total bytes of code 401
```
```assembly
; Kevlar.Shield.ThrowIfVoidFallbackResultExecution()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       movzx     eax,byte ptr [rax+48]
       test      eax,eax
       je        short M16_L00
       call      qword ptr [7F40FF0BE688]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M16_L00:
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 47
```
```assembly
; Kevlar.Shield.get_TimeOrSystem()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       rdi,[rbp-8]
       call      qword ptr [7F40FF0BE6A0]; Kevlar.Shield.get_CurrentSnapshot()
       mov       rax,[rax+20]
       mov       [rbp-10],rax
       mov       rax,[rbp-10]
       mov       [rbp-18],rax
       cmp       qword ptr [rbp-10],0
       jne       short M17_L00
       call      qword ptr [7F40FF0BE6B8]; System.TimeProvider.get_System()
       mov       [rbp-18],rax
M17_L00:
       mov       rax,[rbp-18]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 77
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F40FE1CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F40FE1CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; Kevlar.Shield.get_Name()
M19_L00:
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+38]
       mov       [rbp-10],rax
       cmp       qword ptr [rbp-10],0
       jne       short M19_L01
       mov       rax,[rbp-8]
       mov       rax,[rax+40]
       add       rsp,10
       pop       rbp
       ret
M19_L01:
       mov       rax,[rbp-10]
       mov       rdi,[rax+8]
       mov       rax,[rbp-10]
       call      qword ptr [rax+18]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F40FF0BE670]
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 86
```
```assembly
; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-50],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-58],rax
       cmp       qword ptr [rbp-58],0
       je        short M20_L00
       mov       rax,[rbp-58]
       mov       [rbp-40],rax
       jmp       short M20_L01
M20_L00:
       mov       rdi,[rbp-10]
       mov       rsi,7F40FF4C3870
       call      qword ptr [7F40FE62F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-40],rax
M20_L01:
       mov       rax,[rbp+10]
       mov       [rsp],rax
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rax,[rbp+18]
       mov       [rsp+10],rax
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-20]
       mov       rcx,[rbp-28]
       mov       r8,[rbp-30]
       mov       r9,[rbp-38]
       call      qword ptr [7F40FF0BE718]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       mov       [rbp-50],rax
       mov       [rbp-48],rdx
       mov       rax,[rbp-50]
       mov       rdx,[rbp-48]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 177
```
```assembly
; Kevlar.Shield.get_CurrentSnapshot()
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+38]
       mov       [rbp-10],rax
       mov       rax,[rbp-10]
       mov       [rbp-18],rax
       cmp       qword ptr [rbp-10],0
       jne       short M21_L00
       xor       eax,eax
       mov       [rbp-20],rax
       jmp       short M21_L01
M21_L00:
       mov       rax,[rbp-18]
       mov       rdi,[rax+8]
       mov       rax,[rbp-18]
       call      qword ptr [rax+18]
       mov       [rbp-20],rax
M21_L01:
       mov       rax,[rbp-20]
       mov       [rbp-28],rax
       cmp       qword ptr [rbp-20],0
       jne       short M21_L02
       mov       rax,[rbp-8]
       mov       [rbp-28],rax
M21_L02:
       mov       rax,[rbp-28]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 121
```
```assembly
; System.TimeProvider.get_System()
       push      rax
       call      qword ptr [7F40FE1CF5B8]
       mov       rax,[rax]
       add       rsp,8
       ret
; Total bytes of code 15
```
```assembly
; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       push      rbp
       sub       rsp,1A0
       lea       rbp,[rsp+1A0]
       xor       eax,eax
       mov       [rbp-148],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-140],xmm8
       mov       rax,0FFFFFFFFFFFFFF10
M23_L00:
       vmovdqa   xmmword ptr [rbp+rax-40],xmm8
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       add       rax,30
       jne       short M23_L00
       mov       [rbp-40],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       call      qword ptr [7F40FF0BE9A0]; Kevlar.Internal.KevlarMetrics.get_DurationEnabled()
       test      eax,eax
       jne       short M23_L01
       xor       eax,eax
       mov       [rbp-88],rax
       jmp       short M23_L02
M23_L01:
       call      qword ptr [7F40FF0BE9B8]
       mov       [rbp-88],rax
M23_L02:
       mov       rax,[rbp-88]
       mov       [rbp-40],rax
       lea       rdi,[rbp+20]
       call      qword ptr [7F40FF0BE9D0]; System.Threading.CancellationToken.get_IsCancellationRequested()
       test      eax,eax
       je        near ptr M23_L06
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-28]
       xor       edx,edx
       call      qword ptr [7F40FF0BE9E8]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       cmp       qword ptr [rbp+18],0
       je        near ptr M23_L05
       mov       rdi,[rbp+20]
       mov       rcx,[rbp-28]
       mov       rdx,[rbp-20]
       xor       esi,esi
       call      qword ptr [7F40FF0BEA00]; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       mov       [rbp-70],rax
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-158],rax
       cmp       qword ptr [rbp-158],0
       je        short M23_L03
       mov       rax,[rbp-158]
       mov       [rbp-120],rax
       jmp       short M23_L04
M23_L03:
       mov       rdi,[rbp-10]
       mov       rsi,7F40FF4C40E0
       call      qword ptr [7F40FE62F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-120],rax
M23_L04:
       mov       rdi,[rbp-70]
       cmp       [rdi],edi
       call      qword ptr [7F40FF0BEA18]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       [rbp-128],rax
       mov       rcx,[rbp-128]
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-30]
       mov       rdi,[rbp-120]
       call      qword ptr [7F40FF0BE8E0]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-70]
       call      qword ptr [7F40FF0BEA30]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
M23_L05:
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-0F8],rax
       mov       rdi,[rbp-0F8]
       mov       rsi,[rbp+20]
       call      qword ptr [7F40FF0BEA48]
       mov       rdi,[rbp-0F8]
       call      qword ptr [7F40FF0BEA60]
       mov       [rbp-108],rax
       mov       [rbp-100],rdx
       mov       rdi,[rbp-108]
       mov       rsi,[rbp-100]
       call      qword ptr [7F40FF0BE970]
       mov       [rbp-118],rax
       mov       [rbp-110],rdx
       mov       rax,[rbp-118]
       mov       rdx,[rbp-110]
       add       rsp,1A0
       pop       rbp
       ret
M23_L06:
       mov       rdi,[rbp+20]
       mov       rcx,[rbp-28]
       mov       rdx,[rbp-20]
       xor       esi,esi
       call      qword ptr [7F40FF0BEA00]; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       mov       [rbp-48],rax
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7F40FF0BEA78]; Kevlar.KevlarContext.get_Properties()
       mov       [rbp-130],rax
       mov       rdx,[rbp-130]
       mov       rsi,[rbp-30]
       mov       rax,[rbp-38]
       mov       rdi,[rax+8]
       mov       rax,[rbp-38]
       call      qword ptr [rax+18]
       nop
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-160],rax
       cmp       qword ptr [rbp-160],0
       je        short M23_L07
       mov       rax,[rbp-160]
       mov       [rbp-90],rax
       jmp       short M23_L08
M23_L07:
       mov       rdi,[rbp-10]
       mov       rsi,7F40FF4C3D08
       call      qword ptr [7F40FE62F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-90],rax
M23_L08:
       lea       rdi,[rbp-68]
       mov       rsi,[rbp-90]
       mov       rdx,[rbp-18]
       mov       rcx,[rbp-30]
       mov       r8,[rbp+10]
       mov       r9,[rbp-48]
       call      qword ptr [7F40FF0BE7F0]; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       lea       rdi,[rbp-68]
       call      qword ptr [7F40FF0BEA90]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_IsCompletedSuccessfully()
       test      eax,eax
       je        near ptr M23_L12
       lea       rdi,[rbp-68]
       call      qword ptr [7F40FF0BEAA8]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Result()
       mov       [rbp-0B8],rax
       mov       [rbp-0B0],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-0B8]
       vmovdqu   xmmword ptr [rbp-80],xmm0
       lea       rdi,[rbp-80]
       call      qword ptr [7F40FF0BEAC0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_IsSuccess()
       mov       [rbp-13C],eax
       mov       edx,[rbp-13C]
       mov       rsi,[rbp-48]
       mov       rdi,[rbp-40]
       call      qword ptr [7F40FF0BEAD8]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-168],rax
       cmp       qword ptr [rbp-168],0
       je        short M23_L09
       mov       rax,[rbp-168]
       mov       [rbp-0C0],rax
       jmp       short M23_L10
M23_L09:
       mov       rdi,[rbp-10]
       mov       rsi,7F40FF4C40E0
       call      qword ptr [7F40FE62F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0C0],rax
M23_L10:
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7F40FF0BEA18]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       [rbp-148],rax
       mov       rcx,[rbp-148]
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-30]
       mov       rdi,[rbp-0C0]
       call      qword ptr [7F40FF0BE8E0]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-48]
       call      qword ptr [7F40FF0BEA30]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       lea       rdi,[rbp-80]
       call      qword ptr [7F40FF0BEAC0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_IsSuccess()
       test      eax,eax
       jne       short M23_L11
       mov       rdi,[rbp-80]
       mov       rsi,[rbp-78]
       call      qword ptr [7F40FF0BE970]
       mov       [rbp-0E0],rax
       mov       [rbp-0D8],rdx
       mov       rax,[rbp-0E0]
       mov       rdx,[rbp-0D8]
       add       rsp,1A0
       pop       rbp
       ret
M23_L11:
       lea       rdi,[rbp-80]
       call      qword ptr [7F40FF0BEAF0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_Result()
       mov       [rbp-14C],eax
       mov       esi,[rbp-14C]
       lea       rdi,[rbp-0D0]
       call      qword ptr [7F40FF0BEB08]; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]]..ctor(Int32)
       mov       rax,[rbp-0D0]
       mov       rdx,[rbp-0C8]
       add       rsp,1A0
       pop       rbp
       ret
M23_L12:
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-170],rax
       cmp       qword ptr [rbp-170],0
       je        short M23_L13
       mov       rax,[rbp-170]
       mov       [rbp-98],rax
       jmp       short M23_L14
M23_L13:
       mov       rdi,[rbp-10]
       mov       rsi,7F40FF4C3EA0
       call      qword ptr [7F40FE62F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-98],rax
M23_L14:
       lea       rdi,[rsp]
       lea       rsi,[rbp-68]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,[rbp-98]
       mov       rsi,[rbp-48]
       mov       rdx,[rbp-30]
       mov       rcx,[rbp+18]
       mov       r8,[rbp-40]
       call      qword ptr [7F40FF0BE898]
       mov       [rbp-0A8],rax
       mov       [rbp-0A0],rdx
       mov       rax,[rbp-0A8]
       mov       rdx,[rbp-0A0]
       add       rsp,1A0
       pop       rbp
       ret
       sub       rsp,28
       mov       [rbp-0E8],rdi
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-48]
       xor       edx,edx
       call      qword ptr [7F40FF0BEAD8]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-178],rax
       cmp       qword ptr [rbp-178],0
       je        short M23_L15
       mov       rax,[rbp-178]
       mov       [rbp-0F0],rax
       jmp       short M23_L16
M23_L15:
       mov       rdi,[rbp-10]
       mov       rsi,7F40FF4C40E0
       call      qword ptr [7F40FE62F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0F0],rax
M23_L16:
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7F40FF0BEA18]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       [rbp-138],rax
       mov       rcx,[rbp-138]
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-30]
       mov       rdi,[rbp-0F0]
       call      qword ptr [7F40FF0BE8E0]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-48]
       call      qword ptr [7F40FF0BEA30]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 1331
```
```assembly
; Kevlar.Internal.KevlarMetrics.get_DurationEnabled()
       push      rbp
       mov       rbp,rsp
       mov       rdi,offset MT_Kevlar.Internal.KevlarMetrics
       call      qword ptr [7F40FE625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F3919800BA0
       mov       rdi,[rax]
       cmp       [rdi],edi
       call      qword ptr [7F40FF0BEB38]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       nop
       pop       rbp
       ret
; Total bytes of code 44
```
```assembly
; System.Threading.CancellationToken.get_IsCancellationRequested()
       cmp       qword ptr [rdi],0
       jne       short M25_L00
       xor       eax,eax
       ret
M25_L00:
       mov       rax,[rdi]
       cmp       dword ptr [rax+20],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 23
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       movzx     edx,byte ptr [rbp-14]
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       xor       ecx,ecx
       call      qword ptr [7F40FF5C7348]; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       movzx     esi,byte ptr [rbp-14]
       mov       rdi,[rbp-10]
       xor       edx,edx
       call      qword ptr [7F40FF5C7360]; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 65
```
```assembly
; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-18],rdx
       mov       [rbp-20],rcx
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      qword ptr [7F40FE625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F39198013C0
       mov       rdi,[rax]
       cmp       [rdi],edi
       call      qword ptr [7F40FF5C6670]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Rent()
       mov       [rbp-28],rax
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F40FF5C6688]; Kevlar.KevlarContext.set_CancellationToken(System.Threading.CancellationToken)
       mov       rdi,[rbp-28]
       mov       esi,[rbp-0C]
       cmp       [rdi],edi
       call      qword ptr [7F40FF5C66A0]; Kevlar.KevlarContext.set_SynchronousExecutionKind(Kevlar.Internal.SynchronousExecutionKind)
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F40FF5C66B8]; Kevlar.KevlarContext.set_TimeProvider(System.TimeProvider)
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F40FF5C66D0]; Kevlar.KevlarContext.set_ShieldName(System.String)
       mov       rdi,[rbp-28]
       mov       esi,0FFFFFFFF
       cmp       [rdi],edi
       call      qword ptr [7F40FF5C66E8]; Kevlar.KevlarContext.set_StrategyIndex(Int32)
       mov       rdi,[rbp-28]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F40FF5C6700]; Kevlar.KevlarContext.set_AttemptNumber(Int32)
       mov       rdi,[rbp-28]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F40FF5C6718]; Kevlar.KevlarContext.set_TelemetryListener(Kevlar.IKevlarTelemetryListener)
       mov       rax,[rbp-28]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 190
```
```assembly
; Kevlar.KevlarContext.get_PropertiesForCompletion()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       movzx     eax,byte ptr [rax+64]
       test      eax,eax
       jne       short M28_L00
       mov       rax,[rbp-8]
       mov       rax,[rax+8]
       add       rsp,10
       pop       rbp
       ret
M28_L00:
       mov       rax,[rbp-8]
       mov       rax,[rax+10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 54
```
```assembly
; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       [rbp-20],rcx
       cmp       qword ptr [rbp-10],0
       je        short M29_L00
       mov       rax,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-20]
       mov       rdi,[rax+8]
       mov       rax,[rbp-10]
       call      qword ptr [rax+18]
M29_L00:
       nop
M29_L01:
       add       rsp,30
       pop       rbp
       ret
       push      rax
       mov       [rbp-28],rdi
       lea       rax,[M29_L01]
       add       rsp,8
       ret
; Total bytes of code 86
```
```assembly
; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,7F39198013C0
       mov       rdi,[rax]
       mov       rsi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F40FF5C7438]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Return(System.__Canon)
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 46
```
```assembly
; Kevlar.KevlarContext.get_Properties()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+8]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 28
```
```assembly
; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,110
       lea       rbp,[rsp+110]
       xor       eax,eax
       mov       [rbp-0D8],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       mov       [rbp-40],rax
       mov       [rbp-8],rsi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-0E0],rax
       cmp       qword ptr [rbp-0E0],0
       je        short M32_L00
       mov       rax,[rbp-0E0]
       mov       [rbp-68],rax
       jmp       short M32_L01
M32_L00:
       mov       rdi,[rbp-18]
       mov       rsi,7F40FF5B6958
       call      qword ptr [7F40FE62F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-68],rax
M32_L01:
       mov       rdi,[rbp-68]
       call      qword ptr [7F40FE625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rax+8]
       mov       [rbp-70],rax
       lea       rax,[rbp-58]
       mov       [rbp-78],rax
       mov       rax,[rbp-20]
       mov       [rbp-80],rax
       mov       rax,[rbp-70]
       mov       [rbp-88],rax
       cmp       qword ptr [rbp-70],0
       jne       near ptr M32_L08
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-0E8],rax
       cmp       qword ptr [rbp-0E8],0
       je        short M32_L02
       mov       rax,[rbp-0E8]
       mov       [rbp-0B8],rax
       jmp       short M32_L03
M32_L02:
       mov       rdi,[rbp-18]
       mov       rsi,7F40FF5B6958
       call      qword ptr [7F40FE62F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0B8],rax
M32_L03:
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+30]
       mov       [rbp-0F0],rax
       cmp       qword ptr [rbp-0F0],0
       je        short M32_L04
       mov       rax,[rbp-0F0]
       mov       [rbp-0C8],rax
       jmp       short M32_L05
M32_L04:
       mov       rdi,[rbp-18]
       mov       rsi,7F40FF5B6C50
       call      qword ptr [7F40FE62F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0C8],rax
M32_L05:
       mov       rdi,[rbp-0C8]
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-0C0],rax
       mov       rdi,[rbp-0B8]
       call      qword ptr [7F40FE625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rax]
       mov       [rbp-0D8],rax
       mov       rsi,[rbp-0D8]
       mov       rdi,[rbp-0C0]
       mov       rdx,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       call      qword ptr [7F40FE626E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-0F8],rax
       cmp       qword ptr [rbp-0F8],0
       je        short M32_L06
       mov       rax,[rbp-0F8]
       mov       [rbp-0D0],rax
       jmp       short M32_L07
M32_L06:
       mov       rdi,[rbp-18]
       mov       rsi,7F40FF5B6958
       call      qword ptr [7F40FE62F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0D0],rax
M32_L07:
       mov       rdi,[rbp-0D0]
       call      qword ptr [7F40FE625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       lea       rdi,[rax+8]
       mov       rsi,[rbp-0C0]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-0C0]
       mov       [rbp-60],rax
       mov       rax,[rbp-60]
       mov       [rbp-88],rax
M32_L08:
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-100],rax
       cmp       qword ptr [rbp-100],0
       je        short M32_L09
       mov       rax,[rbp-100]
       mov       [rbp-0A0],rax
       jmp       short M32_L10
M32_L09:
       mov       rdi,[rbp-18]
       mov       rsi,7F40FF5B69F8
       call      qword ptr [7F40FE62F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0A0],rax
M32_L10:
       lea       rdi,[rbp-98]
       mov       rsi,[rbp-0A0]
       mov       rdx,[rbp-28]
       mov       rcx,[rbp-30]
       call      qword ptr [7F40FF5C6AD8]; Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]]..ctor(System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-108],rax
       cmp       qword ptr [rbp-108],0
       je        short M32_L11
       mov       rax,[rbp-108]
       mov       [rbp-0A8],rax
       jmp       short M32_L12
M32_L11:
       mov       rdi,[rbp-18]
       mov       rsi,7F40FF5B6A70
       call      qword ptr [7F40FE62F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0A8],rax
M32_L12:
       mov       r8,[rbp-98]
       mov       r9,[rbp-90]
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-0A8]
       mov       rdx,[rbp-80]
       mov       rcx,[rbp-88]
       call      qword ptr [7F40FF5C6AF0]; Kevlar.Continuation`2[[System.Int32, System.Private.CoreLib],[Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.StrategyNode, System.Func`3<ContextAsyncCallback`2<System.__Canon,Int32>,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Kevlar.Outcome`1<Int32>>>, ContextAsyncCallback`2<System.__Canon,Int32>)
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-110],rax
       cmp       qword ptr [rbp-110],0
       je        short M32_L13
       mov       rax,[rbp-110]
       mov       [rbp-0B0],rax
       jmp       short M32_L14
M32_L13:
       mov       rdi,[rbp-18]
       mov       rsi,7F40FF5B6A70
       call      qword ptr [7F40FE62F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0B0],rax
M32_L14:
       lea       rdi,[rbp-58]
       mov       rsi,[rbp-10]
       mov       rdx,[rbp-0B0]
       mov       rcx,[rbp-38]
       call      qword ptr [7F40FF5C6B08]; Kevlar.Continuation`2[[System.Int32, System.Private.CoreLib],[Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]].InvokeAsync(Kevlar.KevlarContext)
       mov       rax,[rbp-10]
       add       rsp,110
       pop       rbp
       ret
; Total bytes of code 881
```
```assembly
; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_IsCompletedSuccessfully()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       [rbp-10],rax
       cmp       qword ptr [rbp-10],0
       jne       short M33_L00
       mov       eax,1
       add       rsp,20
       pop       rbp
       ret
M33_L00:
       mov       rsi,[rbp-10]
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F40FE626838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       [rbp-18],rax
       cmp       qword ptr [rbp-18],0
       je        short M33_L01
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F40FF5C72D0]
       nop
       add       rsp,20
       pop       rbp
       ret
M33_L01:
       mov       rax,[rbp-10]
       mov       [rbp-20],rax
       mov       rax,[rbp-8]
       movsx     rsi,word ptr [rax+8]
       mov       rdi,[rbp-20]
       mov       r11,7F40FD640358
       call      qword ptr [r11]
       cmp       eax,1
       sete      al
       movzx     eax,al
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 158
```
```assembly
; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Result()
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       [rbp-10],rax
       cmp       qword ptr [rbp-10],0
       jne       short M34_L00
       mov       rax,[rbp-8]
       vmovdqu   xmm0,xmmword ptr [rax+10]
       vmovdqu   xmmword ptr [rbp-50],xmm0
       mov       rax,[rbp-50]
       mov       rdx,[rbp-48]
       add       rsp,50
       pop       rbp
       ret
M34_L00:
       mov       rsi,[rbp-10]
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F40FE626838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       [rbp-18],rax
       cmp       qword ptr [rbp-18],0
       je        short M34_L01
       mov       rdi,[rbp-18]
       xor       esi,esi
       call      qword ptr [7F40FF5C7300]
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F40FF5C7318]
       mov       [rbp-40],rax
       mov       [rbp-38],rdx
       mov       rax,[rbp-40]
       mov       rdx,[rbp-38]
       add       rsp,50
       pop       rbp
       ret
M34_L01:
       mov       rax,[rbp-10]
       mov       [rbp-20],rax
       mov       rax,[rbp-8]
       movsx     rsi,word ptr [rax+8]
       mov       rdi,[rbp-20]
       mov       r11,7F40FD640360
       call      qword ptr [r11]
       mov       [rbp-30],rax
       mov       [rbp-28],rdx
       mov       rax,[rbp-30]
       mov       rdx,[rbp-28]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 214
```
```assembly
; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_IsSuccess()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       qword ptr [rax],0
       sete      al
       movzx     eax,al
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 34
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       mov       rdi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F40FF5C7330]; Kevlar.KevlarContext.get_ShieldName()
       mov       [rbp-20],rax
       mov       rsi,[rbp-20]
       movzx     edx,byte ptr [rbp-14]
       mov       rdi,[rbp-8]
       mov       rcx,[rbp-10]
       call      qword ptr [7F40FF5C7348]; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       mov       rdi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F40FF5C7330]; Kevlar.KevlarContext.get_ShieldName()
       mov       [rbp-28],rax
       mov       rdi,[rbp-28]
       movzx     esi,byte ptr [rbp-14]
       mov       rdx,[rbp-10]
       call      qword ptr [7F40FF5C7360]; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 111
```
```assembly
; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_Result()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       eax,[rax+8]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 27
```
```assembly
; System.Diagnostics.Metrics.Instrument.get_Enabled()
       mov       rax,[rdi+8]
       cmp       qword ptr [rax+8],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 16
```
```assembly
; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,0F0
       lea       rbp,[rsp+0F0]
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFF40
M39_L00:
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       vmovdqa   xmmword ptr [rax+rbp],xmm8
       add       rax,30
       jne       short M39_L00
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       mov       [rbp-20],rcx
       cmp       qword ptr [rbp-8],0
       je        near ptr M39_L03
       mov       rax,7F3919800BA0
       mov       rdi,[rax]
       cmp       [rdi],edi
       call      qword ptr [7F40FF0BEB38]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M39_L03
       lea       rdi,[rbp-0B0]
       mov       rsi,[rbp-10]
       call      qword ptr [7F40FF5C7390]
       lea       rax,[rbp-0B0]
       mov       [rbp-0C0],rax
       mov       rax,7F40FC20B630
       mov       [rbp-0C8],rax
       movzx     eax,byte ptr [rbp-14]
       test      eax,eax
       jne       short M39_L01
       mov       rax,[rbp-0C0]
       mov       [rbp-0D0],rax
       mov       rax,[rbp-0C8]
       mov       [rbp-0D8],rax
       mov       rax,7F40FC20B678
       mov       [rbp-0E0],rax
       jmp       short M39_L02
M39_L01:
       mov       rax,[rbp-0C0]
       mov       [rbp-0D0],rax
       mov       rax,[rbp-0C8]
       mov       [rbp-0D8],rax
       mov       rax,7F40FC20B6A0
       mov       [rbp-0E0],rax
M39_L02:
       mov       rdi,[rbp-0D0]
       mov       rsi,[rbp-0D8]
       mov       rdx,[rbp-0E0]
       call      qword ptr [7F40FF5C73A8]
       mov       rdi,[rbp-8]
       call      qword ptr [7F40FF5C73C0]
       mov       [rbp-0B8],rax
       lea       rdi,[rbp-0B8]
       call      qword ptr [7F40FF5C73D8]
       vmovsd    qword ptr [rbp-0E8],xmm0
       vmovsd    xmm0,qword ptr [rbp-0E8]
       lea       rsi,[rbp-0B0]
       mov       rax,7F3919800BA0
       mov       rdi,[rax]
       mov       rdx,[rbp-20]
       call      qword ptr [7F40FF5C73F0]
M39_L03:
       nop
       add       rsp,0F0
       pop       rbp
       ret
; Total bytes of code 370
```
```assembly
; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,0D0
       lea       rbp,[rsp+0D0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqa   xmmword ptr [rbp-30],xmm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-18],rdx
       mov       rax,7F3919800B48
       mov       rdi,[rax]
       cmp       [rdi],edi
       call      qword ptr [7F40FF0BEB38]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M40_L02
       lea       rdi,[rbp-0A8]
       mov       rsi,[rbp-8]
       call      qword ptr [7F40FF5C7390]
       lea       rax,[rbp-0A8]
       mov       [rbp-0B0],rax
       mov       rax,7F40FC20B630
       mov       [rbp-0B8],rax
       movzx     eax,byte ptr [rbp-0C]
       test      eax,eax
       jne       short M40_L00
       mov       rax,[rbp-0B0]
       mov       [rbp-0C0],rax
       mov       rax,[rbp-0B8]
       mov       [rbp-0C8],rax
       mov       rax,7F40FC20B678
       mov       [rbp-0D0],rax
       jmp       short M40_L01
M40_L00:
       mov       rax,[rbp-0B0]
       mov       [rbp-0C0],rax
       mov       rax,[rbp-0B8]
       mov       [rbp-0C8],rax
       mov       rax,7F40FC20B6A0
       mov       [rbp-0D0],rax
M40_L01:
       mov       rdi,[rbp-0C0]
       mov       rsi,[rbp-0C8]
       mov       rdx,[rbp-0D0]
       call      qword ptr [7F40FF5C73A8]
       lea       rdx,[rbp-0A8]
       mov       rax,7F3919800B48
       mov       rdi,[rax]
       mov       rcx,[rbp-18]
       mov       esi,1
       call      qword ptr [7F40FF5C7408]
M40_L02:
       nop
       add       rsp,0D0
       pop       rbp
       ret
; Total bytes of code 326
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Rent()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-18],rax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       movzx     eax,byte ptr [rax+24]
       test      eax,eax
       je        short M41_L00
       lea       rsi,[rbp-20]
       mov       rdi,[rbp-10]
       call      qword ptr [7F40FF5C68F8]
       nop
       add       rsp,20
       pop       rbp
       ret
M41_L00:
       mov       rdi,[rbp-10]
       call      qword ptr [7F40FF5C6910]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ThrowIfDisposed()
       mov       rdi,[rbp-10]
       call      qword ptr [7F40FF5C6928]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].RentWithoutLifecycle()
       mov       [rbp-18],rax
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+1C],0
       jne       short M41_L01
       mov       rax,[rbp-18]
       add       rsp,20
       pop       rbp
       ret
M41_L01:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7F40FF5C6940]
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       call      qword ptr [7F40FF5C6958]
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 139
```
```assembly
; Kevlar.KevlarContext.set_CancellationToken(System.Threading.CancellationToken)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       lea       rdi,[rax+68]
       lea       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_BYREF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Kevlar.KevlarContext.set_SynchronousExecutionKind(Kevlar.Internal.SynchronousExecutionKind)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       rax,[rbp-8]
       mov       ecx,[rbp-0C]
       mov       [rax+60],ecx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 33
```
```assembly
; Kevlar.KevlarContext.set_TimeProvider(System.TimeProvider)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       lea       rdi,[rax+38]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Kevlar.KevlarContext.set_ShieldName(System.String)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Kevlar.KevlarContext.set_StrategyIndex(Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       rax,[rbp-8]
       mov       ecx,[rbp-0C]
       mov       [rax+5C],ecx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 33
```
```assembly
; Kevlar.KevlarContext.set_AttemptNumber(Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       rax,[rbp-8]
       mov       ecx,[rbp-0C]
       mov       [rax+58],ecx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 33
```
```assembly
; Kevlar.KevlarContext.set_TelemetryListener(Kevlar.IKevlarTelemetryListener)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       lea       rdi,[rax+40]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Return(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rdi,[rbp-10]
       mov       rsi,7F40FC2044E0
       call      qword ptr [7F40FED05878]; System.ArgumentNullException.ThrowIfNull(System.Object, System.String)
       mov       rax,[rbp-8]
       movzx     eax,byte ptr [rax+24]
       test      eax,eax
       je        short M49_L00
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F40FF5C7450]
       nop
       add       rsp,10
       pop       rbp
       ret
M49_L00:
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+1C],0
       je        short M49_L01
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F40FF5C6940]
       nop
       add       rsp,10
       pop       rbp
       ret
M49_L01:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F40FF5C7468]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       jne       short M49_L02
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F40FF5C6940]
       nop
       add       rsp,10
       pop       rbp
       ret
M49_L02:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F40FF5C7480]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ReturnWithoutReset(System.__Canon)
       mov       rdi,[rbp-8]
       call      qword ptr [7F40FF5C7498]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ClearIfDisposed()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 172
```
```assembly
; Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-28],rdx
       mov       [rbp-20],rcx
       mov       [rbp-30],r8
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-40],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+18]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-48],0
       je        short M50_L00
       mov       rax,[rbp-48]
       mov       [rbp-38],rax
       jmp       short M50_L01
M50_L00:
       mov       rdi,[rbp-40]
       mov       rsi,7F40FF5B7240
       call      qword ptr [7F40FE62F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-38],rax
M50_L01:
       mov       rdx,[rbp-28]
       mov       rcx,[rbp-20]
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-38]
       mov       r8,[rbp-30]
       call      qword ptr [7F40FF5C6BE0]; Kevlar.Internal.ShieldEngine.InvokeWithContextAsync[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]](ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       mov       rax,[rbp-18]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 141
```
```assembly
; Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]]..ctor(System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       [rbp-20],rcx
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-18]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 63
```
```assembly
; Kevlar.Continuation`2[[System.Int32, System.Private.CoreLib],[Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.StrategyNode, System.Func`3<ContextAsyncCallback`2<System.__Canon,Int32>,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Kevlar.Outcome`1<Int32>>>, ContextAsyncCallback`2<System.__Canon,Int32>)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       [rbp-20],rcx
       mov       [rbp-30],r8
       mov       [rbp-28],r9
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-18]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-8]
       lea       rdi,[rax+10]
       lea       rsi,[rbp-30]
       call      CORINFO_HELP_ASSIGN_BYREF
       call      CORINFO_HELP_ASSIGN_BYREF
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 93
```
```assembly
; Kevlar.Continuation`2[[System.Int32, System.Private.CoreLib],[Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]].InvokeAsync(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-68],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       vmovdqa   xmmword ptr [rbp-40],xmm8
       mov       [rbp-30],rax
       mov       [rbp-8],rdx
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       rax,[rbp-10]
       cmp       qword ptr [rax+8],0
       jne       short M53_L00
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-30],rax
       mov       rdi,[rbp-30]
       mov       rsi,7F40FC20B5D0
       call      qword ptr [7F40FED05680]
       mov       rdi,[rbp-30]
       call      qword ptr [7F40FF0BEA60]
       mov       [rbp-40],rax
       mov       [rbp-38],rdx
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-38]
       lea       rdi,[rbp-60]
       call      qword ptr [7F40FF5C6BB0]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.Outcome`1<Int32>)
       mov       rax,[rbp-18]
       vmovdqu   ymm0,ymmword ptr [rbp-60]
       vmovdqu   ymmword ptr [rax],ymm0
       mov       rax,[rbp-18]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
M53_L00:
       mov       rax,[rbp-10]
       cmp       qword ptr [rax],0
       jne       short M53_L01
       mov       rax,[rbp-10]
       mov       rdx,[rax+10]
       mov       rax,[rbp-10]
       mov       rcx,[rax+18]
       mov       rax,[rbp-10]
       mov       rax,[rax+8]
       mov       [rbp-68],rax
       mov       rax,[rbp-68]
       mov       rsi,[rbp-18]
       mov       r8,[rbp-28]
       mov       rdi,[rax+8]
       mov       rax,[rbp-68]
       call      qword ptr [rax+18]
       mov       rax,[rbp-18]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
M53_L01:
       mov       rax,[rbp-10]
       mov       rcx,[rax]
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-20]
       mov       r8,[rbp-28]
       call      qword ptr [7F40FF5C6BC8]
       mov       rax,[rbp-18]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 283
```
```assembly
; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       push      rbp
       mov       rbp,rsp
       test      rsi,rsi
       je        short M54_L02
       mov       rax,[rsi]
       cmp       rax,rdi
       je        short M54_L02
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M54_L02
M54_L00:
       test      rax,rax
       je        short M54_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M54_L02
       test      rax,rax
       je        short M54_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M54_L02
       test      rax,rax
       jne       short M54_L03
M54_L01:
       xor       esi,esi
M54_L02:
       mov       rax,rsi
       pop       rbp
       ret
M54_L03:
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M54_L02
       test      rax,rax
       je        short M54_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M54_L02
       jmp       short M54_L00
; Total bytes of code 91
```
```assembly
; Kevlar.KevlarContext.get_ShieldName()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+30]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 28
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ThrowIfDisposed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+1C],0
       je        short M56_L00
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       call      qword ptr [7F40FF5C6958]
M56_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 48
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].RentWithoutLifecycle()
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-18],rax
       xor       eax,eax
       mov       [rbp-1C],eax
       cmp       qword ptr [rbp-18],0
       jne       near ptr M57_L05
       mov       rdi,[rbp-10]
       call      qword ptr [7F40FF5C6970]
       mov       [rbp-1C],eax
       mov       rdi,[rbp-10]
       mov       esi,[rbp-1C]
       call      qword ptr [7F40FF5C6988]
       mov       [rbp-30],rax
       mov       rax,[rbp-30]
       mov       rax,[rax]
       mov       [rbp-38],rax
       cmp       qword ptr [rbp-38],0
       je        short M57_L02
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-60],rax
       mov       rax,[rbp-60]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+30]
       mov       [rbp-68],rax
       cmp       qword ptr [rbp-68],0
       je        short M57_L00
       mov       rax,[rbp-68]
       mov       [rbp-58],rax
       jmp       short M57_L01
M57_L00:
       mov       rdi,[rbp-60]
       mov       rsi,7F40FF5B5CE0
       call      qword ptr [7F40FE62F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-58],rax
M57_L01:
       mov       rdi,[rbp-58]
       mov       rsi,[rbp-30]
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-38]
       call      qword ptr [7F40FEA1E868]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       cmp       rax,[rbp-38]
       je        short M57_L03
M57_L02:
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-40]
       mov       [rbp-50],rax
       jmp       short M57_L04
M57_L03:
       mov       rax,[rbp-38]
       mov       [rbp-50],rax
M57_L04:
       mov       rax,[rbp-50]
       mov       [rbp-28],rax
       jmp       short M57_L06
M57_L05:
       lea       rsi,[rbp-28]
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F40FF0BDD10]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
M57_L06:
       mov       rax,[rbp-28]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-28],0
       jne       short M57_L08
       cmp       qword ptr [rbp-18],0
       je        short M57_L07
       mov       rdi,[rbp-10]
       call      qword ptr [7F40FF5C69A0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].CreateItem()
       nop
       add       rsp,70
       pop       rbp
       ret
M57_L07:
       mov       rdi,[rbp-10]
       mov       esi,[rbp-1C]
       call      qword ptr [7F40FF5C69B8]
       mov       [rbp-48],rax
M57_L08:
       mov       rax,[rbp-48]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 330
```
```assembly
; System.ArgumentNullException.ThrowIfNull(System.Object, System.String)
       push      rax
       test      rdi,rdi
       je        short M58_L00
       add       rsp,8
       ret
M58_L00:
       mov       rdi,rsi
       call      qword ptr [7F40FE1E1208]
       int       3
; Total bytes of code 21
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-30],rax
       mov       rax,[rbp-30]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+38]
       mov       [rbp-38],rax
       cmp       qword ptr [rbp-38],0
       je        short M59_L00
       mov       rax,[rbp-38]
       mov       [rbp-28],rax
       jmp       short M59_L01
M59_L00:
       mov       rdi,[rbp-30]
       mov       rsi,7F40FF5BA528
       call      qword ptr [7F40FE62F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-28],rax
M59_L01:
       mov       byte ptr [rbp-20],0
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7F40FF5C74B0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItemGuarded(System.__Canon)
       nop
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 124
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ReturnWithoutReset(System.__Canon)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-20],0
       je        short M60_L01
       mov       rdi,[rbp-20]
       mov       rsi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F40FF0BE088]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(System.__Canon)
       test      eax,eax
       jne       short M60_L00
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7F40FF5C6940]
M60_L00:
       nop
       add       rsp,50
       pop       rbp
       ret
M60_L01:
       mov       rdi,[rbp-10]
       call      qword ptr [7F40FF5C6970]
       mov       [rbp-24],eax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-48],rax
       mov       rax,[rbp-48]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+40]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       je        short M60_L02
       mov       rax,[rbp-50]
       mov       [rbp-38],rax
       jmp       short M60_L03
M60_L02:
       mov       rdi,[rbp-48]
       mov       rsi,7F40FF5BBE50
       call      qword ptr [7F40FE62F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-38],rax
M60_L03:
       mov       rdi,[rbp-10]
       mov       esi,[rbp-24]
       call      qword ptr [7F40FF5C6988]
       mov       [rbp-40],rax
       mov       rsi,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rdx,[rbp-18]
       call      qword ptr [7F40FF0BE040]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-30],0
       jne       short M60_L04
       add       rsp,50
       pop       rbp
       ret
M60_L04:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-30]
       mov       ecx,[rbp-24]
       call      qword ptr [7F40FF5C76C0]
       nop
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 262
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ClearIfDisposed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+1C],0
       je        short M61_L00
       mov       rdi,[rbp-8]
       call      qword ptr [7F40FF5C76F0]
M61_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 41
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F40FE1CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F40FE1CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; Kevlar.Internal.ShieldEngine.InvokeWithContextAsync[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]](ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       xor       eax,eax
       mov       [rbp-78],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       mov       [rbp-8],rsi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-28],rdx
       mov       [rbp-20],rcx
       mov       [rbp-30],r8
       lea       rdi,[rbp-68]
       call      qword ptr [7F40FF5C6E08]; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].Create()
       vmovdqu   xmm0,xmmword ptr [rbp-28]
       vmovdqu   xmmword ptr [rbp-50],xmm0
       mov       rax,[rbp-30]
       mov       [rbp-78],rax
       mov       dword ptr [rbp-70],0FFFFFFFF
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-88],rax
       cmp       qword ptr [rbp-88],0
       je        short M63_L00
       mov       rax,[rbp-88]
       mov       [rbp-80],rax
       jmp       short M63_L01
M63_L00:
       mov       rdi,[rbp-18]
       mov       rsi,7F40FF5B7EB8
       call      qword ptr [7F40FE62F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-80],rax
M63_L01:
       lea       rdx,[rbp-78]
       lea       rdi,[rbp-68]
       mov       rsi,[rbp-80]
       call      qword ptr [7F40FF5C6DC0]; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       lea       rdi,[rbp-68]
       mov       rsi,[rbp-10]
       call      qword ptr [7F40FF5C6E20]; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Task()
       mov       rax,[rbp-10]
       add       rsp,90
       pop       rbp
       ret
; Total bytes of code 207
```
```assembly
; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.Outcome`1<Int32>)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-18],rsi
       mov       [rbp-10],rdx
       mov       rax,[rbp-8]
       lea       rdi,[rax+10]
       lea       rsi,[rbp-18]
       call      CORINFO_HELP_ASSIGN_BYREF
       movsq
       mov       rax,[rbp-8]
       xor       ecx,ecx
       mov       [rax],rcx
       mov       rax,[rbp-8]
       mov       byte ptr [rax+0A],1
       mov       rax,[rbp-8]
       mov       word ptr [rax+8],0
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 74
```
```assembly
; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       push      rax
       mov       rax,rdx
       test      rsi,rsi
       je        short M65_L00
       mov       rdx,rcx
       mov       rdi,rsi
       mov       rsi,rax
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       jmp       qword ptr [rax]
M65_L00:
       call      qword ptr [7F40FE1E4288]
       int       3
; Total bytes of code 39
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-14],eax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rdi,[rbp-8]
       call      qword ptr [7F40FF0BDD58]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-14],eax
       mov       rdi,[rbp-8]
       mov       esi,[rbp-14]
       mov       rdx,[rbp-10]
       call      qword ptr [7F40FF0BDD70]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       je        short M66_L00
       mov       eax,1
       add       rsp,20
       pop       rbp
       ret
M66_L00:
       mov       rdi,[rbp-8]
       mov       esi,[rbp-14]
       mov       rdx,[rbp-10]
       call      qword ptr [7F40FF0BDD88]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 92
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].CreateItem()
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       call      qword ptr [7F40FF5C69E8]; Kevlar.KevlarContext+PoolPolicy.Create()
       mov       [rbp-18],rax
       mov       rax,[rbp-18]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-18],0
       jne       short M67_L00
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-28],rax
       mov       edi,67
       mov       rsi,7F40FEAA56C8
       call      qword ptr [7F40FE62EF88]
       mov       [rbp-30],rax
       mov       rsi,[rbp-30]
       mov       rdi,[rbp-28]
       call      qword ptr [7F40FED05680]
       mov       rdi,[rbp-28]
       call      CORINFO_HELP_THROW
       int       3
M67_L00:
       mov       rax,[rbp-20]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 147
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItemGuarded(System.__Canon)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7F40FF5C74E0]; Kevlar.KevlarContext+PoolPolicy.TryReset(Kevlar.KevlarContext)
       mov       [rbp-14],eax
       mov       eax,[rbp-14]
       add       rsp,50
       pop       rbp
       ret
       push      rax
       mov       [rbp-38],rdi
       mov       rax,[rbp-38]
       mov       [rbp-28],rax
       mov       rdi,offset MT_System.Exception[]
       mov       esi,2
       call      CORINFO_HELP_NEWARR_1_PTR
       mov       [rbp-40],rax
       mov       rdi,[rbp-40]
       mov       rdx,[rbp-20]
       xor       esi,esi
       call      qword ptr [7F40FE6257A0]; System.Runtime.CompilerServices.CastHelpers.StelemRef(System.Object[], IntPtr, System.Object)
       mov       rdi,[rbp-40]
       mov       rdx,[rbp-28]
       mov       esi,1
       call      qword ptr [7F40FE6257A0]; System.Runtime.CompilerServices.CastHelpers.StelemRef(System.Object[], IntPtr, System.Object)
       mov       rdi,offset MT_System.AggregateException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-48],rax
       mov       edi,0C1
       mov       rsi,7F40FEAA56C8
       call      qword ptr [7F40FE62EF88]
       mov       [rbp-50],rax
       mov       rsi,[rbp-50]
       mov       rdi,[rbp-48]
       mov       rdx,[rbp-40]
       call      qword ptr [7F40FF0BE028]
       mov       rdi,[rbp-48]
       call      CORINFO_HELP_THROW
       int       3
       push      rax
       mov       [rbp-30],rdi
       mov       rax,[rbp-30]
       mov       [rbp-20],rax
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F40FF5C6940]
       nop
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 247
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(System.__Canon)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       xor       eax,eax
       mov       [rbp-68],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       dword ptr [rbp-78],3E8
       mov       rdi,[rbp-38]
       call      qword ptr [7F40FF0BDD58]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-44],eax
       xor       eax,eax
       mov       [rbp-48],eax
       jmp       near ptr M69_L08
M69_L00:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       ecx,[rbp-44]
       cmp       ecx,[rax+8]
       jae       near ptr M69_L10
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       rax,[rax]
       mov       [rbp-50],rax
       mov       rax,[rbp-50]
       cmp       qword ptr [rax+50],0
       jne       near ptr M69_L03
       mov       rax,[rbp-50]
       cmp       [rax],al
       mov       rax,[rbp-50]
       add       rax,50
       mov       [rbp-68],rax
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-80],rax
       mov       rax,[rbp-80]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+20]
       mov       [rbp-88],rax
       cmp       qword ptr [rbp-88],0
       je        short M69_L01
       mov       rax,[rbp-88]
       mov       [rbp-70],rax
       jmp       short M69_L02
M69_L01:
       mov       rdi,[rbp-80]
       mov       rsi,7F40FF40FCD8
       call      qword ptr [7F40FE62F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-70],rax
M69_L02:
       mov       rdi,[rbp-70]
       mov       rsi,[rbp-68]
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-58]
       call      qword ptr [7F40FEA1E868]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       test      rax,rax
       je        short M69_L05
       mov       rdi,7F40FF4B7A70
       call      CORINFO_HELP_COUNTPROFILE32
M69_L03:
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       mov       rsi,[rbp-50]
       mov       rdx,[rbp-40]
       call      qword ptr [7F40FF0BE0B8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       je        short M69_L06
M69_L04:
       mov       rdi,7F40FF4B7A74
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,90
       pop       rbp
       ret
M69_L05:
       mov       rdi,7F40FF4B7A78
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       short M69_L04
M69_L06:
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-5C],eax
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-44],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-5C]
       jne       short M69_L07
       mov       rdi,7F40FF4B7A7C
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-44],eax
M69_L07:
       mov       rdi,7F40FF4B7A80
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-48]
       inc       eax
       mov       [rbp-48],eax
M69_L08:
       mov       eax,[rbp-78]
       dec       eax
       mov       [rbp-78],eax
       cmp       dword ptr [rbp-78],0
       jg        short M69_L09
       lea       rdi,[rbp-78]
       mov       esi,62
       call      CORINFO_HELP_PATCHPOINT
M69_L09:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-48]
       jg        near ptr M69_L00
       mov       rdi,7F40FF4B7A84
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,90
       pop       rbp
       ret
M69_L10:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 495
```
```assembly
; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].Create()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-20],xmm0
       vmovdqu   xmmword ptr [rbp-18],xmm0
       mov       rax,[rbp-8]
       vmovdqu   xmm0,xmmword ptr [rbp-20]
       vmovdqu   xmmword ptr [rax],xmm0
       mov       rcx,[rbp-10]
       mov       [rax+10],rcx
       mov       rax,[rbp-8]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 75
```
```assembly
; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       mov       [rbp-8],rsi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+10]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-30],0
       je        short M71_L00
       mov       rax,[rbp-30]
       mov       [rbp-28],rax
       jmp       short M71_L01
M71_L00:
       mov       rdi,[rbp-18]
       mov       rsi,7F40FF5B8118
       call      qword ptr [7F40FE62F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-28],rax
M71_L01:
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-20]
       call      qword ptr [7F40FF5C6E50]; System.Runtime.CompilerServices.AsyncMethodBuilderCore.Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 104
```
```assembly
; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Task()
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       rcx,7F39198013E8
       cmp       rax,[rcx]
       jne       short M72_L00
       mov       rax,[rbp-8]
       mov       rsi,[rax+8]
       mov       rax,[rbp-8]
       mov       rdx,[rax+10]
       lea       rdi,[rbp-70]
       call      qword ptr [7F40FF5C6BB0]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.Outcome`1<Int32>)
       mov       rax,[rbp-10]
       vmovdqu   ymm0,ymmword ptr [rbp-70]
       vmovdqu   ymmword ptr [rax],ymm0
       mov       rax,[rbp-10]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
M72_L00:
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       [rbp-20],rax
       mov       rax,[rbp-20]
       mov       [rbp-28],rax
       cmp       qword ptr [rbp-20],0
       jne       short M72_L01
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-50],rax
       mov       rdi,[rbp-50]
       call      qword ptr [7F40FF5C7228]
       mov       rax,[rbp-50]
       mov       [rbp-18],rax
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-50]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       mov       [rbp-28],rax
M72_L01:
       lea       rdi,[rbp-48]
       mov       rsi,[rbp-28]
       call      qword ptr [7F40FF5C7240]
       mov       rax,[rbp-10]
       vmovdqu   ymm0,ymmword ptr [rbp-48]
       vmovdqu   ymmword ptr [rax],ymm0
       mov       rax,[rbp-10]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 236
```

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: dry-1.9.0(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.9.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.9.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=1, LaunchCount=1, RunStrategy=ColdStart, UnrollFactor=1, WarmupCount=1))

```assembly
; PoolContextProbe.NestedContext()
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,7F226D800AC0
       mov       rax,[rax]
       mov       [rbp-18],rax
       mov       rax,7F226D800400
       mov       rax,[rax]
       mov       [rbp-20],rax
       mov       rax,[rbp-18]
       mov       [rbp-28],rax
       cmp       qword ptr [rbp-18],0
       jne       short M00_L00
       mov       rdi,offset MT_System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-40],rax
       mov       rax,7F226D800AA8
       mov       rsi,[rax]
       mov       rdi,[rbp-40]
       mov       rdx,offset PoolContextProbe+<>c.<NestedContext>b__6_0(Kevlar.KevlarContext)
       call      qword ptr [7F2A57626E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rsi,[rbp-40]
       mov       rdi,7F226D800AC0
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-40]
       mov       [rbp-28],rax
M00_L00:
       xor       eax,eax
       mov       [rbp-10],rax
       mov       rdi,[rbp-20]
       mov       rsi,[rbp-28]
       mov       rdx,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F2A580BE148]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       mov       [rbp-38],rax
       mov       [rbp-30],rdx
       mov       rax,[rbp-38]
       mov       rdx,[rbp-30]
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 211
```
```assembly
; BenchmarkDotNet.Helpers.AwaitHelper.GetResult[[System.Int32, System.Private.CoreLib]](System.Threading.Tasks.ValueTask`1<Int32>)
       push      rbp
       sub       rsp,60
       lea       rbp,[rsp+60]
       xor       eax,eax
       mov       [rbp-58],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-10],rdi
       mov       [rbp-8],rsi
       lea       rdi,[rbp-10]
       xor       esi,esi
       call      qword ptr [7F2A585C6FB8]; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]].ConfigureAwait(Boolean)
       mov       [rbp-40],rax
       mov       [rbp-38],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-40]
       vmovdqu   xmmword ptr [rbp-30],xmm0
       lea       rdi,[rbp-30]
       call      qword ptr [7F2A585C6FD0]; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1[[System.Int32, System.Private.CoreLib]].GetAwaiter()
       mov       [rbp-50],rax
       mov       [rbp-48],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-50]
       vmovdqu   xmmword ptr [rbp-20],xmm0
       lea       rdi,[rbp-20]
       call      qword ptr [7F2A585C6FE8]; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[[System.Int32, System.Private.CoreLib]].get_IsCompleted()
       test      eax,eax
       jne       short M01_L00
       call      qword ptr [7F2A585CDA28]
       mov       [rbp-58],rax
       mov       rdi,[rbp-58]
       mov       rsi,[rbp-20]
       mov       rdx,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2A585CD9F8]
M01_L00:
       lea       rdi,[rbp-20]
       call      qword ptr [7F2A585C7000]; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[[System.Int32, System.Private.CoreLib]].GetResult()
       nop
       add       rsp,60
       pop       rbp
       ret
; Total bytes of code 158
```
```assembly
; PoolContextProbe+<>c.<NestedContext>b__6_0(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp-48],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,7F226D800AB8
       mov       rax,[rax]
       mov       [rbp-18],rax
       mov       rax,7F226D800400
       mov       rax,[rax]
       mov       [rbp-20],rax
       mov       rax,[rbp-10]
       mov       [rbp-28],rax
       mov       rax,[rbp-18]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-18],0
       jne       short M02_L00
       mov       rdi,offset MT_System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-48],rax
       mov       rax,7F226D800AA8
       mov       rsi,[rax]
       mov       rdi,[rbp-48]
       mov       rdx,offset PoolContextProbe+<>c.<NestedContext>b__6_1(Kevlar.KevlarContext)
       call      qword ptr [7F2A57626E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rsi,[rbp-48]
       mov       rdi,7F226D800AB8
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-48]
       mov       [rbp-30],rax
M02_L00:
       mov       rdi,[rbp-20]
       mov       rsi,[rbp-28]
       mov       rdx,[rbp-30]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7738]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](Kevlar.KevlarContext, System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
       mov       [rbp-40],rax
       mov       [rbp-38],rdx
       mov       rax,[rbp-40]
       mov       rdx,[rbp-38]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 217
```
```assembly
; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       push      r15
       push      rbx
       push      rax
       mov       rbx,rdi
       mov       r15,rdx
       test      rsi,rsi
       je        short M03_L00
       lea       rdi,[rbx+8]
       call      qword ptr [7F2A571CEEB8]; CORINFO_HELP_ASSIGN_REF
       mov       [rbx+18],r15
       add       rsp,8
       pop       rbx
       pop       r15
       ret
M03_L00:
       call      qword ptr [7F2A571E0120]
       int       3
; Total bytes of code 44
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqa   xmmword ptr [rbp-30],xmm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       rdi,[rbp-10]
       mov       rsi,7F2A54208560
       call      qword ptr [7F2A580BE598]; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F2A57625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F226D800AF0
       mov       rax,[rax]
       mov       [rbp-20],rax
       mov       rax,[rbp-8]
       mov       [rbp-28],rax
       mov       rax,[rbp-10]
       mov       [rbp-30],rax
       mov       rax,[rbp-20]
       mov       [rbp-38],rax
       cmp       qword ptr [rbp-20],0
       jne       near ptr M04_L00
       mov       rdi,offset MT_System.Action<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarProperties>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-80],rax
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F2A57625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F226D800AE8
       mov       rax,[rax]
       mov       [rbp-88],rax
       mov       rsi,[rbp-88]
       mov       rdi,[rbp-80]
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       call      qword ptr [7F2A57626E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F2A57625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rbp-80]
       mov       rdi,7F226D800AF0
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-80]
       mov       [rbp-38],rax
M04_L00:
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F2A57625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F226D800AF8
       mov       rax,[rax]
       mov       [rbp-40],rax
       mov       rax,[rbp-28]
       mov       [rbp-48],rax
       mov       rax,[rbp-30]
       mov       [rbp-50],rax
       mov       rax,[rbp-38]
       mov       [rbp-58],rax
       mov       rax,[rbp-40]
       mov       [rbp-60],rax
       cmp       qword ptr [rbp-40],0
       jne       near ptr M04_L01
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-78],rax
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F2A57625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F226D800AE8
       mov       rax,[rax]
       mov       [rbp-90],rax
       mov       rsi,[rbp-90]
       mov       rdi,[rbp-78]
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F2A57626E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F2A57625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rbp-78]
       mov       rdi,7F226D800AF8
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-78]
       mov       [rbp-60],rax
M04_L01:
       mov       rdi,[rbp-48]
       mov       r9,[rbp-18]
       mov       rdx,[rbp-50]
       mov       rcx,[rbp-58]
       mov       r8,[rbp-60]
       mov       rsi,7F2A584BC308
       call      qword ptr [7F2A580BE4C0]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       mov       [rbp-70],rax
       mov       [rbp-68],rdx
       mov       rax,[rbp-70]
       mov       rdx,[rbp-68]
       add       rsp,90
       pop       rbp
       ret
; Total bytes of code 537
```
```assembly
; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]].ConfigureAwait(Boolean)
       mov       rax,[rdi]
       mov       edx,[rdi+8]
       movsx     rcx,word ptr [rdi+0C]
       movzx     edi,sil
       movzx     ecx,cx
       shl       rcx,20
       or        rdx,rcx
       mov       ecx,edi
       shl       rcx,30
       or        rdx,rcx
       ret
; Total bytes of code 35
```
```assembly
; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1[[System.Int32, System.Private.CoreLib]].GetAwaiter()
       sub       rsp,18
       xor       eax,eax
       mov       [rsp+8],rax
       movups    xmm0,[rdi]
       movups    [rsp+8],xmm0
       mov       rax,[rsp+8]
       mov       rdx,[rsp+10]
       add       rsp,18
       ret
; Total bytes of code 34
```
```assembly
; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[[System.Int32, System.Private.CoreLib]].get_IsCompleted()
       push      rbp
       push      r15
       push      rbx
       lea       rbp,[rsp+10]
       mov       rbx,rdi
       mov       r15,[rbx]
       test      r15,r15
       je        short M07_L04
       mov       rdi,r15
       call      qword ptr [7F2A571DCE98]
       test      rax,rax
       jne       short M07_L03
       movsx     rsi,word ptr [rbx+0C]
       mov       rdi,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       cmp       rdi,[r15]
       je        short M07_L02
       mov       rdi,r15
       lea       r11,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       call      qword ptr [r11]
M07_L00:
       test      eax,eax
       setne     al
       movzx     eax,al
M07_L01:
       pop       rbx
       pop       r15
       pop       rbp
       ret
M07_L02:
       lea       rdi,[r15+40]
       call      qword ptr [7F2A571EF4C0]
       jmp       short M07_L00
M07_L03:
       test      dword ptr [rax+34],1600000
       setne     al
       movzx     eax,al
       jmp       short M07_L01
M07_L04:
       mov       eax,1
       jmp       short M07_L01
; Total bytes of code 111
```
```assembly
; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[[System.Int32, System.Private.CoreLib]].GetResult()
       push      rbp
       push      r15
       push      r14
       push      rbx
       push      rax
       lea       rbp,[rsp+20]
       mov       rbx,rdi
       mov       r15,[rbx]
       test      r15,r15
       je        short M08_L03
       mov       rdi,r15
       call      qword ptr [7F2A571DCE98]
       mov       r14,rax
       test      r14,r14
       jne       short M08_L01
       movsx     rsi,word ptr [rbx+0C]
       mov       rdi,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       cmp       rdi,[r15]
       je        short M08_L00
       mov       rdi,r15
       lea       r11,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M08_L00:
       mov       rdi,r15
       call      qword ptr [7F2A571DF2E8]
       jmp       short M08_L04
M08_L01:
       mov       edi,[r14+34]
       and       edi,11000000
       cmp       edi,1000000
       jne       short M08_L05
M08_L02:
       mov       eax,[r14+38]
       jmp       short M08_L04
M08_L03:
       mov       eax,[rbx+8]
M08_L04:
       add       rsp,8
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M08_L05:
       mov       rdi,r14
       xor       esi,esi
       call      qword ptr [7F2A571E99B0]
       jmp       short M08_L02
; Total bytes of code 142
```
```assembly
; PoolContextProbe+<>c.<NestedContext>b__6_1(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-20],xmm0
       lea       rdi,[rbp-20]
       mov       esi,2A
       call      qword ptr [7F2A580BEB08]; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]]..ctor(Int32)
       mov       rax,[rbp-20]
       mov       rdx,[rbp-18]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 62
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](Kevlar.KevlarContext, System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
M10_L00:
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqa   xmmword ptr [rbp-30],xmm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       rdi,[rbp-18]
       mov       rsi,7F2A54208560
       call      qword ptr [7F2A580BE598]; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       mov       rdi,[rbp-10]
       mov       rsi,7F2A5420B6C8
       call      qword ptr [7F2A580BE598]; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       mov       rax,[rbp-8]
       mov       rax,[rax+38]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-20],0
       je        short M10_L01
       mov       rax,[rbp-20]
       mov       rdi,[rax+8]
       mov       rax,[rbp-20]
       call      qword ptr [rax+18]
       mov       [rbp-88],rax
       mov       rdi,[rbp-88]
       mov       rsi,[rbp-10]
       mov       rdx,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7738]
       mov       [rbp-80],rax
       mov       [rbp-78],rdx
       mov       rax,[rbp-80]
       mov       rdx,[rbp-78]
       add       rsp,90
       pop       rbp
       ret
M10_L01:
       mov       rdi,[rbp-8]
       call      qword ptr [7F2A580BE640]; Kevlar.Shield.ThrowIfVoidFallbackResultExecution()
       mov       rax,[rbp-8]
       mov       rax,[rax+10]
       mov       [rbp-28],rax
       mov       rdi,[rbp-8]
       call      qword ptr [7F2A580BE670]; Kevlar.Shield.get_Name()
       mov       [rbp-38],rax
       mov       rdi,offset MT_Kevlar.Shield+<>c__60<System.Int32>
       call      qword ptr [7F2A57625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F226D801410
       mov       rax,[rax]
       mov       [rbp-30],rax
       mov       rax,[rbp-28]
       mov       [rbp-40],rax
       mov       rax,[rbp-38]
       mov       [rbp-48],rax
       mov       rax,[rbp-18]
       mov       [rbp-50],rax
       mov       rax,[rbp-30]
       mov       [rbp-58],rax
       cmp       qword ptr [rbp-30],0
       jne       near ptr M10_L02
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-70],rax
       mov       rdi,offset MT_Kevlar.Shield+<>c__60<System.Int32>
       call      qword ptr [7F2A57625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F226D801408
       mov       rax,[rax]
       mov       [rbp-90],rax
       mov       rsi,[rbp-90]
       mov       rdi,[rbp-70]
       mov       rdx,offset Kevlar.Shield+<>c__60`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__60_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F2A57626E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,offset MT_Kevlar.Shield+<>c__60<System.Int32>
       call      qword ptr [7F2A57625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rbp-70]
       mov       rdi,7F226D801410
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-70]
       mov       [rbp-58],rax
M10_L02:
       mov       r9,[rbp-10]
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-48]
       mov       rcx,[rbp-50]
       mov       r8,[rbp-58]
       mov       rdi,7F2A58604EB8
       call      qword ptr [7F2A585C7768]; Kevlar.Internal.ShieldEngine.ExecuteWithParentContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.String, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       [rbp-68],rax
       mov       [rbp-60],rdx
       mov       rax,[rbp-68]
       mov       rdx,[rbp-60]
       add       rsp,90
       pop       rbp
       ret
; Total bytes of code 489
```
```assembly
; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       cmp       qword ptr [rbp-8],0
       jne       short M11_L00
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-18],rax
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2A57D0E310]
       mov       rdi,[rbp-18]
       call      CORINFO_HELP_THROW
       int       3
M11_L00:
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 80
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-18]
       mov       rcx,rax
       test      cl,1
       jne       short M12_L00
       ret
M12_L00:
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       jmp       qword ptr [rax]
; Total bytes of code 27
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 28
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       rax,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdi,[rax+8]
       mov       rax,[rbp-10]
       call      qword ptr [rax+18]
       mov       [rbp-28],rax
       mov       [rbp-20],rdx
       mov       rax,[rbp-28]
       mov       rdx,[rbp-20]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 69
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
M15_L00:
       push      rbp
       sub       rsp,0A0
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-88],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-40],rax
       mov       [rbp-8],rsi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       mov       rdi,[rbp-28]
       mov       rsi,7F2A54208588
       call      qword ptr [7F2A580BE598]; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       mov       rdi,[rbp-30]
       mov       rsi,7F2A54208560
       call      qword ptr [7F2A580BE598]; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       mov       rax,[rbp-10]
       mov       rax,[rax+38]
       mov       [rbp-40],rax
       cmp       qword ptr [rbp-40],0
       je        short M15_L01
       mov       rax,[rbp-40]
       mov       rdi,[rax+8]
       mov       rax,[rbp-40]
       call      qword ptr [rax+18]
       mov       [rbp-80],rax
       mov       rdi,[rbp-80]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-20]
       mov       rcx,[rbp-28]
       mov       r8,[rbp-30]
       mov       r9,[rbp-38]
       cmp       [rdi],edi
       call      qword ptr [7F2A580BE4C0]
       mov       [rbp-78],rax
       mov       [rbp-70],rdx
       mov       rax,[rbp-78]
       mov       rdx,[rbp-70]
       add       rsp,0A0
       pop       rbp
       ret
M15_L01:
       mov       rdi,[rbp-10]
       call      qword ptr [7F2A580BE640]; Kevlar.Shield.ThrowIfVoidFallbackResultExecution()
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-48],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F2A580BE658]; Kevlar.Shield.get_TimeOrSystem()
       mov       [rbp-50],rax
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-90],rax
       cmp       qword ptr [rbp-90],0
       je        short M15_L02
       mov       rax,[rbp-90]
       mov       [rbp-58],rax
       jmp       short M15_L03
M15_L02:
       mov       rdi,[rbp-18]
       mov       rsi,7F2A584C34B8
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-58],rax
M15_L03:
       mov       rdi,[rbp-10]
       call      qword ptr [7F2A580BE670]; Kevlar.Shield.get_Name()
       mov       [rbp-88],rax
       mov       rax,[rbp-30]
       mov       [rsp],rax
       mov       rax,[rbp-38]
       mov       [rsp+8],rax
       mov       rcx,[rbp-88]
       mov       rsi,[rbp-48]
       mov       rdx,[rbp-50]
       mov       rdi,[rbp-58]
       mov       r8,[rbp-20]
       mov       r9,[rbp-28]
       call      qword ptr [7F2A580BE5E0]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       mov       [rbp-68],rax
       mov       [rbp-60],rdx
       mov       rax,[rbp-68]
       mov       rdx,[rbp-60]
       add       rsp,0A0
       pop       rbp
       ret
; Total bytes of code 401
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7F2A571D4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7F2A571CEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7F2A571DF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M16_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M16_L00
       mov       rsi,rax
       call      qword ptr [7F2A571CEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M16_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]]..ctor(Int32)
       mov       [rdi+8],esi
       xor       eax,eax
       mov       [rdi],rax
       mov       byte ptr [rdi+0E],1
       mov       word ptr [rdi+0C],0
       ret
; Total bytes of code 19
```
```assembly
; Kevlar.Shield.ThrowIfVoidFallbackResultExecution()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       movzx     eax,byte ptr [rax+48]
       test      eax,eax
       je        short M18_L00
       call      qword ptr [7F2A580BE688]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M18_L00:
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 47
```
```assembly
; Kevlar.Shield.get_Name()
M19_L00:
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+38]
       mov       [rbp-10],rax
       cmp       qword ptr [rbp-10],0
       jne       short M19_L01
       mov       rax,[rbp-8]
       mov       rax,[rax+40]
       add       rsp,10
       pop       rbp
       ret
M19_L01:
       mov       rax,[rbp-10]
       mov       rdi,[rax+8]
       mov       rax,[rbp-10]
       call      qword ptr [rax+18]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F2A580BE670]
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 86
```
```assembly
; Kevlar.Shield+<>c__60`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__60_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       rax,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdi,[rax+8]
       mov       rax,[rbp-10]
       call      qword ptr [rax+18]
       mov       [rbp-28],rax
       mov       [rbp-20],rdx
       mov       rax,[rbp-28]
       mov       rdx,[rbp-20]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 69
```
```assembly
; Kevlar.Internal.ShieldEngine.ExecuteWithParentContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.String, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,130
       lea       rbp,[rsp+130]
       xor       eax,eax
       mov       [rbp-0F8],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0F0],ymm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       mov       [rbp-40],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       call      qword ptr [7F2A580BE9A0]; Kevlar.Internal.KevlarMetrics.get_DurationEnabled()
       test      eax,eax
       jne       short M21_L00
       xor       eax,eax
       mov       [rbp-88],rax
       jmp       short M21_L01
M21_L00:
       call      qword ptr [7F2A580BE9B8]
       mov       [rbp-88],rax
M21_L01:
       mov       rax,[rbp-88]
       mov       [rbp-40],rax
       mov       rdi,[rbp-38]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7960]; Kevlar.KevlarContext.get_CancellationToken()
       mov       [rbp-48],rax
       lea       rdi,[rbp-48]
       call      qword ptr [7F2A580BE9D0]; System.Threading.CancellationToken.get_IsCancellationRequested()
       test      eax,eax
       je        near ptr M21_L02
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-20]
       xor       edx,edx
       call      qword ptr [7F2A580BE9E8]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-0D8],rax
       mov       rdi,[rbp-0D8]
       mov       rsi,[rbp-48]
       call      qword ptr [7F2A580BEA48]
       mov       rdi,[rbp-0D8]
       call      qword ptr [7F2A580BEA60]
       mov       [rbp-0E8],rax
       mov       [rbp-0E0],rdx
       mov       rdi,[rbp-0E8]
       mov       rsi,[rbp-0E0]
       call      qword ptr [7F2A580BE970]
       mov       [rbp-0F8],rax
       mov       [rbp-0F0],rdx
       mov       rax,[rbp-0F8]
       mov       rdx,[rbp-0F0]
       add       rsp,130
       pop       rbp
       ret
M21_L02:
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-20]
       xor       edx,edx
       call      qword ptr [7F2A585C7978]; Kevlar.KevlarContext.RentChild(Kevlar.KevlarContext, System.String, Kevlar.Internal.SynchronousExecutionKind)
       mov       [rbp-50],rax
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-108],rax
       cmp       qword ptr [rbp-108],0
       je        short M21_L03
       mov       rax,[rbp-108]
       mov       [rbp-90],rax
       jmp       short M21_L04
M21_L03:
       mov       rdi,[rbp-10]
       mov       rsi,7F2A585BC668
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-90],rax
M21_L04:
       lea       rdi,[rbp-70]
       mov       rsi,[rbp-90]
       mov       rdx,[rbp-18]
       mov       rcx,[rbp-28]
       mov       r8,[rbp-30]
       mov       r9,[rbp-50]
       call      qword ptr [7F2A580BE7F0]; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       lea       rdi,[rbp-70]
       call      qword ptr [7F2A580BEA90]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_IsCompletedSuccessfully()
       test      eax,eax
       je        near ptr M21_L06
       lea       rdi,[rbp-70]
       call      qword ptr [7F2A580BEAA8]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Result()
       mov       [rbp-0B0],rax
       mov       [rbp-0A8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-0B0]
       vmovdqu   xmmword ptr [rbp-80],xmm0
       lea       rdi,[rbp-80]
       call      qword ptr [7F2A580BEAC0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_IsSuccess()
       mov       [rbp-0FC],eax
       mov       edx,[rbp-0FC]
       mov       rsi,[rbp-20]
       mov       rdi,[rbp-40]
       call      qword ptr [7F2A580BE9E8]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       mov       rdi,[rbp-50]
       mov       rsi,[rbp-38]
       call      qword ptr [7F2A585C7990]; Kevlar.Internal.ShieldEngine.ReturnChildContext(Kevlar.KevlarContext, Kevlar.KevlarContext)
       lea       rdi,[rbp-80]
       call      qword ptr [7F2A580BEAC0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_IsSuccess()
       test      eax,eax
       jne       short M21_L05
       mov       rdi,[rbp-80]
       mov       rsi,[rbp-78]
       call      qword ptr [7F2A580BE970]
       mov       [rbp-0D0],rax
       mov       [rbp-0C8],rdx
       mov       rax,[rbp-0D0]
       mov       rdx,[rbp-0C8]
       add       rsp,130
       pop       rbp
       ret
M21_L05:
       lea       rdi,[rbp-80]
       call      qword ptr [7F2A580BEAF0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_Result()
       mov       [rbp-100],eax
       mov       esi,[rbp-100]
       lea       rdi,[rbp-0C0]
       call      qword ptr [7F2A580BEB08]; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]]..ctor(Int32)
       mov       rax,[rbp-0C0]
       mov       rdx,[rbp-0B8]
       add       rsp,130
       pop       rbp
       ret
M21_L06:
       lea       rdi,[rsp]
       lea       rsi,[rbp-70]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,[rbp-50]
       mov       rsi,[rbp-38]
       mov       rdx,[rbp-40]
       call      qword ptr [7F2A585C78D0]
       mov       [rbp-0A0],rax
       mov       [rbp-98],rdx
       mov       rax,[rbp-0A0]
       mov       rdx,[rbp-98]
       add       rsp,130
       pop       rbp
       ret
; Total bytes of code 773
```
```assembly
; Kevlar.Shield.get_TimeOrSystem()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       rdi,[rbp-8]
       call      qword ptr [7F2A580BE6A0]; Kevlar.Shield.get_CurrentSnapshot()
       mov       rax,[rax+20]
       mov       [rbp-10],rax
       mov       rax,[rbp-10]
       mov       [rbp-18],rax
       cmp       qword ptr [rbp-10],0
       jne       short M22_L00
       call      qword ptr [7F2A580BE6B8]; System.TimeProvider.get_System()
       mov       [rbp-18],rax
M22_L00:
       mov       rax,[rbp-18]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 77
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F2A571CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F2A571CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-50],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-58],rax
       cmp       qword ptr [rbp-58],0
       je        short M24_L00
       mov       rax,[rbp-58]
       mov       [rbp-40],rax
       jmp       short M24_L01
M24_L00:
       mov       rdi,[rbp-10]
       mov       rsi,7F2A584C3870
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-40],rax
M24_L01:
       mov       rax,[rbp+10]
       mov       [rsp],rax
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rax,[rbp+18]
       mov       [rsp+10],rax
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-20]
       mov       rcx,[rbp-28]
       mov       r8,[rbp-30]
       mov       r9,[rbp-38]
       call      qword ptr [7F2A580BE718]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       mov       [rbp-50],rax
       mov       [rbp-48],rdx
       mov       rax,[rbp-50]
       mov       rdx,[rbp-48]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 177
```
```assembly
; Kevlar.Internal.KevlarMetrics.get_DurationEnabled()
       push      rbp
       mov       rbp,rsp
       mov       rdi,offset MT_Kevlar.Internal.KevlarMetrics
       call      qword ptr [7F2A57625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F226D800BA0
       mov       rdi,[rax]
       cmp       [rdi],edi
       call      qword ptr [7F2A580BEB38]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       nop
       pop       rbp
       ret
; Total bytes of code 44
```
```assembly
; Kevlar.KevlarContext.get_CancellationToken()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+68]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 28
```
```assembly
; System.Threading.CancellationToken.get_IsCancellationRequested()
       cmp       qword ptr [rdi],0
       jne       short M27_L00
       xor       eax,eax
       ret
M27_L00:
       mov       rax,[rdi]
       cmp       dword ptr [rax+20],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 23
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       movzx     edx,byte ptr [rbp-14]
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       xor       ecx,ecx
       call      qword ptr [7F2A585C7348]; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       movzx     esi,byte ptr [rbp-14]
       mov       rdi,[rbp-10]
       xor       edx,edx
       call      qword ptr [7F2A585C7360]; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 65
```
```assembly
; Kevlar.KevlarContext.RentChild(Kevlar.KevlarContext, System.String, Kevlar.Internal.SynchronousExecutionKind)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-68],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       mov       rdi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7960]; Kevlar.KevlarContext.get_CancellationToken()
       mov       [rbp-30],rax
       mov       rdi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C79A8]; Kevlar.KevlarContext.get_TimeProvider()
       mov       [rbp-50],rax
       mov       rdx,[rbp-50]
       mov       esi,[rbp-14]
       mov       rdi,[rbp-30]
       mov       rcx,[rbp-10]
       call      qword ptr [7F2A580BEA00]; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       mov       [rbp-20],rax
       mov       rax,[rbp-20]
       mov       [rbp-28],rax
       mov       rax,[rbp-28]
       cmp       qword ptr [rax+18],0
       jne       short M29_L00
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-48],rax
       mov       rdi,[rbp-48]
       call      qword ptr [7F2A585C6A18]; Kevlar.KevlarProperties..ctor()
       mov       rax,[rbp-28]
       lea       rdi,[rax+18]
       mov       rsi,[rbp-48]
       call      CORINFO_HELP_ASSIGN_REF
M29_L00:
       mov       rdi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F2A580BEA78]; Kevlar.KevlarContext.get_Properties()
       mov       [rbp-58],rax
       mov       rdi,[rbp-58]
       mov       rax,[rbp-20]
       mov       rsi,[rax+18]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C79C0]; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       mov       rax,[rbp-20]
       mov       rax,[rax+18]
       mov       [rbp-38],rax
       mov       rdi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F2A580BEA78]; Kevlar.KevlarContext.get_Properties()
       mov       [rbp-60],rax
       mov       rsi,[rbp-60]
       mov       rdi,[rbp-38]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C79C0]; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       mov       rdi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F2A580BEA78]; Kevlar.KevlarContext.get_Properties()
       mov       [rbp-40],rax
       mov       rdi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F2A580BEA78]; Kevlar.KevlarContext.get_Properties()
       mov       [rbp-68],rax
       mov       rsi,[rbp-68]
       mov       rdi,[rbp-40]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C79D8]; Kevlar.KevlarProperties.ShareAdditionalAttemptStateWith(Kevlar.KevlarProperties)
       mov       rax,[rbp-20]
       mov       byte ptr [rax+65],1
       mov       rax,[rbp-20]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 314
```
```assembly
; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,110
       lea       rbp,[rsp+110]
       xor       eax,eax
       mov       [rbp-0D8],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       mov       [rbp-40],rax
       mov       [rbp-8],rsi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-0E0],rax
       cmp       qword ptr [rbp-0E0],0
       je        short M30_L00
       mov       rax,[rbp-0E0]
       mov       [rbp-68],rax
       jmp       short M30_L01
M30_L00:
       mov       rdi,[rbp-18]
       mov       rsi,7F2A585B6958
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-68],rax
M30_L01:
       mov       rdi,[rbp-68]
       call      qword ptr [7F2A57625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rax+8]
       mov       [rbp-70],rax
       lea       rax,[rbp-58]
       mov       [rbp-78],rax
       mov       rax,[rbp-20]
       mov       [rbp-80],rax
       mov       rax,[rbp-70]
       mov       [rbp-88],rax
       cmp       qword ptr [rbp-70],0
       jne       near ptr M30_L08
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-0E8],rax
       cmp       qword ptr [rbp-0E8],0
       je        short M30_L02
       mov       rax,[rbp-0E8]
       mov       [rbp-0B8],rax
       jmp       short M30_L03
M30_L02:
       mov       rdi,[rbp-18]
       mov       rsi,7F2A585B6958
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0B8],rax
M30_L03:
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+30]
       mov       [rbp-0F0],rax
       cmp       qword ptr [rbp-0F0],0
       je        short M30_L04
       mov       rax,[rbp-0F0]
       mov       [rbp-0C8],rax
       jmp       short M30_L05
M30_L04:
       mov       rdi,[rbp-18]
       mov       rsi,7F2A585B6C50
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0C8],rax
M30_L05:
       mov       rdi,[rbp-0C8]
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-0C0],rax
       mov       rdi,[rbp-0B8]
       call      qword ptr [7F2A57625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rax]
       mov       [rbp-0D8],rax
       mov       rsi,[rbp-0D8]
       mov       rdi,[rbp-0C0]
       mov       rdx,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       call      qword ptr [7F2A57626E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-0F8],rax
       cmp       qword ptr [rbp-0F8],0
       je        short M30_L06
       mov       rax,[rbp-0F8]
       mov       [rbp-0D0],rax
       jmp       short M30_L07
M30_L06:
       mov       rdi,[rbp-18]
       mov       rsi,7F2A585B6958
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0D0],rax
M30_L07:
       mov       rdi,[rbp-0D0]
       call      qword ptr [7F2A57625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       lea       rdi,[rax+8]
       mov       rsi,[rbp-0C0]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-0C0]
       mov       [rbp-60],rax
       mov       rax,[rbp-60]
       mov       [rbp-88],rax
M30_L08:
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-100],rax
       cmp       qword ptr [rbp-100],0
       je        short M30_L09
       mov       rax,[rbp-100]
       mov       [rbp-0A0],rax
       jmp       short M30_L10
M30_L09:
       mov       rdi,[rbp-18]
       mov       rsi,7F2A585B69F8
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0A0],rax
M30_L10:
       lea       rdi,[rbp-98]
       mov       rsi,[rbp-0A0]
       mov       rdx,[rbp-28]
       mov       rcx,[rbp-30]
       call      qword ptr [7F2A585C6AD8]; Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]]..ctor(System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-108],rax
       cmp       qword ptr [rbp-108],0
       je        short M30_L11
       mov       rax,[rbp-108]
       mov       [rbp-0A8],rax
       jmp       short M30_L12
M30_L11:
       mov       rdi,[rbp-18]
       mov       rsi,7F2A585B6A70
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0A8],rax
M30_L12:
       mov       r8,[rbp-98]
       mov       r9,[rbp-90]
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-0A8]
       mov       rdx,[rbp-80]
       mov       rcx,[rbp-88]
       call      qword ptr [7F2A585C6AF0]; Kevlar.Continuation`2[[System.Int32, System.Private.CoreLib],[Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.StrategyNode, System.Func`3<ContextAsyncCallback`2<System.__Canon,Int32>,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Kevlar.Outcome`1<Int32>>>, ContextAsyncCallback`2<System.__Canon,Int32>)
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-110],rax
       cmp       qword ptr [rbp-110],0
       je        short M30_L13
       mov       rax,[rbp-110]
       mov       [rbp-0B0],rax
       jmp       short M30_L14
M30_L13:
       mov       rdi,[rbp-18]
       mov       rsi,7F2A585B6A70
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0B0],rax
M30_L14:
       lea       rdi,[rbp-58]
       mov       rsi,[rbp-10]
       mov       rdx,[rbp-0B0]
       mov       rcx,[rbp-38]
       call      qword ptr [7F2A585C6B08]; Kevlar.Continuation`2[[System.Int32, System.Private.CoreLib],[Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]].InvokeAsync(Kevlar.KevlarContext)
       mov       rax,[rbp-10]
       add       rsp,110
       pop       rbp
       ret
; Total bytes of code 881
```
```assembly
; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_IsCompletedSuccessfully()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       [rbp-10],rax
       cmp       qword ptr [rbp-10],0
       jne       short M31_L00
       mov       eax,1
       add       rsp,20
       pop       rbp
       ret
M31_L00:
       mov       rsi,[rbp-10]
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F2A57626838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       [rbp-18],rax
       cmp       qword ptr [rbp-18],0
       je        short M31_L01
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C72D0]
       nop
       add       rsp,20
       pop       rbp
       ret
M31_L01:
       mov       rax,[rbp-10]
       mov       [rbp-20],rax
       mov       rax,[rbp-8]
       movsx     rsi,word ptr [rax+8]
       mov       rdi,[rbp-20]
       mov       r11,7F2A56640358
       call      qword ptr [r11]
       cmp       eax,1
       sete      al
       movzx     eax,al
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 158
```
```assembly
; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Result()
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       [rbp-10],rax
       cmp       qword ptr [rbp-10],0
       jne       short M32_L00
       mov       rax,[rbp-8]
       vmovdqu   xmm0,xmmword ptr [rax+10]
       vmovdqu   xmmword ptr [rbp-50],xmm0
       mov       rax,[rbp-50]
       mov       rdx,[rbp-48]
       add       rsp,50
       pop       rbp
       ret
M32_L00:
       mov       rsi,[rbp-10]
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F2A57626838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       [rbp-18],rax
       cmp       qword ptr [rbp-18],0
       je        short M32_L01
       mov       rdi,[rbp-18]
       xor       esi,esi
       call      qword ptr [7F2A585C7300]
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7318]
       mov       [rbp-40],rax
       mov       [rbp-38],rdx
       mov       rax,[rbp-40]
       mov       rdx,[rbp-38]
       add       rsp,50
       pop       rbp
       ret
M32_L01:
       mov       rax,[rbp-10]
       mov       [rbp-20],rax
       mov       rax,[rbp-8]
       movsx     rsi,word ptr [rax+8]
       mov       rdi,[rbp-20]
       mov       r11,7F2A56640360
       call      qword ptr [r11]
       mov       [rbp-30],rax
       mov       [rbp-28],rdx
       mov       rax,[rbp-30]
       mov       rdx,[rbp-28]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 214
```
```assembly
; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_IsSuccess()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       qword ptr [rax],0
       sete      al
       movzx     eax,al
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 34
```
```assembly
; Kevlar.Internal.ShieldEngine.ReturnChildContext(Kevlar.KevlarContext, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7B70]; Kevlar.KevlarContext.CopyChangesToParent(Kevlar.KevlarContext)
       nop
       call      M34_L00
       nop
       add       rsp,10
       pop       rbp
       ret
M34_L00:
       push      rax
       mov       rdi,[rbp-8]
       call      qword ptr [7F2A580BEA30]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       nop
       add       rsp,8
       ret
; Total bytes of code 64
```
```assembly
; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_Result()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       eax,[rax+8]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 27
```
```assembly
; Kevlar.Shield.get_CurrentSnapshot()
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+38]
       mov       [rbp-10],rax
       mov       rax,[rbp-10]
       mov       [rbp-18],rax
       cmp       qword ptr [rbp-10],0
       jne       short M36_L00
       xor       eax,eax
       mov       [rbp-20],rax
       jmp       short M36_L01
M36_L00:
       mov       rax,[rbp-18]
       mov       rdi,[rax+8]
       mov       rax,[rbp-18]
       call      qword ptr [rax+18]
       mov       [rbp-20],rax
M36_L01:
       mov       rax,[rbp-20]
       mov       [rbp-28],rax
       cmp       qword ptr [rbp-20],0
       jne       short M36_L02
       mov       rax,[rbp-8]
       mov       [rbp-28],rax
M36_L02:
       mov       rax,[rbp-28]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 121
```
```assembly
; System.TimeProvider.get_System()
       push      rax
       call      qword ptr [7F2A571CF5B8]
       mov       rax,[rax]
       add       rsp,8
       ret
; Total bytes of code 15
```
```assembly
; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       push      rbp
       sub       rsp,1A0
       lea       rbp,[rsp+1A0]
       xor       eax,eax
       mov       [rbp-148],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-140],xmm8
       mov       rax,0FFFFFFFFFFFFFF10
M38_L00:
       vmovdqa   xmmword ptr [rbp+rax-40],xmm8
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       add       rax,30
       jne       short M38_L00
       mov       [rbp-40],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       call      qword ptr [7F2A580BE9A0]; Kevlar.Internal.KevlarMetrics.get_DurationEnabled()
       test      eax,eax
       jne       short M38_L01
       xor       eax,eax
       mov       [rbp-88],rax
       jmp       short M38_L02
M38_L01:
       call      qword ptr [7F2A580BE9B8]
       mov       [rbp-88],rax
M38_L02:
       mov       rax,[rbp-88]
       mov       [rbp-40],rax
       lea       rdi,[rbp+20]
       call      qword ptr [7F2A580BE9D0]; System.Threading.CancellationToken.get_IsCancellationRequested()
       test      eax,eax
       je        near ptr M38_L06
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-28]
       xor       edx,edx
       call      qword ptr [7F2A580BE9E8]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       cmp       qword ptr [rbp+18],0
       je        near ptr M38_L05
       mov       rdi,[rbp+20]
       mov       rcx,[rbp-28]
       mov       rdx,[rbp-20]
       xor       esi,esi
       call      qword ptr [7F2A580BEA00]; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       mov       [rbp-70],rax
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-158],rax
       cmp       qword ptr [rbp-158],0
       je        short M38_L03
       mov       rax,[rbp-158]
       mov       [rbp-120],rax
       jmp       short M38_L04
M38_L03:
       mov       rdi,[rbp-10]
       mov       rsi,7F2A584C40E0
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-120],rax
M38_L04:
       mov       rdi,[rbp-70]
       cmp       [rdi],edi
       call      qword ptr [7F2A580BEA18]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       [rbp-128],rax
       mov       rcx,[rbp-128]
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-30]
       mov       rdi,[rbp-120]
       call      qword ptr [7F2A580BE8E0]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-70]
       call      qword ptr [7F2A580BEA30]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
M38_L05:
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-0F8],rax
       mov       rdi,[rbp-0F8]
       mov       rsi,[rbp+20]
       call      qword ptr [7F2A580BEA48]
       mov       rdi,[rbp-0F8]
       call      qword ptr [7F2A580BEA60]
       mov       [rbp-108],rax
       mov       [rbp-100],rdx
       mov       rdi,[rbp-108]
       mov       rsi,[rbp-100]
       call      qword ptr [7F2A580BE970]
       mov       [rbp-118],rax
       mov       [rbp-110],rdx
       mov       rax,[rbp-118]
       mov       rdx,[rbp-110]
       add       rsp,1A0
       pop       rbp
       ret
M38_L06:
       mov       rdi,[rbp+20]
       mov       rcx,[rbp-28]
       mov       rdx,[rbp-20]
       xor       esi,esi
       call      qword ptr [7F2A580BEA00]; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       mov       [rbp-48],rax
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7F2A580BEA78]; Kevlar.KevlarContext.get_Properties()
       mov       [rbp-130],rax
       mov       rdx,[rbp-130]
       mov       rsi,[rbp-30]
       mov       rax,[rbp-38]
       mov       rdi,[rax+8]
       mov       rax,[rbp-38]
       call      qword ptr [rax+18]
       nop
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-160],rax
       cmp       qword ptr [rbp-160],0
       je        short M38_L07
       mov       rax,[rbp-160]
       mov       [rbp-90],rax
       jmp       short M38_L08
M38_L07:
       mov       rdi,[rbp-10]
       mov       rsi,7F2A584C3D08
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-90],rax
M38_L08:
       lea       rdi,[rbp-68]
       mov       rsi,[rbp-90]
       mov       rdx,[rbp-18]
       mov       rcx,[rbp-30]
       mov       r8,[rbp+10]
       mov       r9,[rbp-48]
       call      qword ptr [7F2A580BE7F0]; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       lea       rdi,[rbp-68]
       call      qword ptr [7F2A580BEA90]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_IsCompletedSuccessfully()
       test      eax,eax
       je        near ptr M38_L12
       lea       rdi,[rbp-68]
       call      qword ptr [7F2A580BEAA8]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Result()
       mov       [rbp-0B8],rax
       mov       [rbp-0B0],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-0B8]
       vmovdqu   xmmword ptr [rbp-80],xmm0
       lea       rdi,[rbp-80]
       call      qword ptr [7F2A580BEAC0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_IsSuccess()
       mov       [rbp-13C],eax
       mov       edx,[rbp-13C]
       mov       rsi,[rbp-48]
       mov       rdi,[rbp-40]
       call      qword ptr [7F2A580BEAD8]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-168],rax
       cmp       qword ptr [rbp-168],0
       je        short M38_L09
       mov       rax,[rbp-168]
       mov       [rbp-0C0],rax
       jmp       short M38_L10
M38_L09:
       mov       rdi,[rbp-10]
       mov       rsi,7F2A584C40E0
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0C0],rax
M38_L10:
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7F2A580BEA18]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       [rbp-148],rax
       mov       rcx,[rbp-148]
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-30]
       mov       rdi,[rbp-0C0]
       call      qword ptr [7F2A580BE8E0]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-48]
       call      qword ptr [7F2A580BEA30]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       lea       rdi,[rbp-80]
       call      qword ptr [7F2A580BEAC0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_IsSuccess()
       test      eax,eax
       jne       short M38_L11
       mov       rdi,[rbp-80]
       mov       rsi,[rbp-78]
       call      qword ptr [7F2A580BE970]
       mov       [rbp-0E0],rax
       mov       [rbp-0D8],rdx
       mov       rax,[rbp-0E0]
       mov       rdx,[rbp-0D8]
       add       rsp,1A0
       pop       rbp
       ret
M38_L11:
       lea       rdi,[rbp-80]
       call      qword ptr [7F2A580BEAF0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_Result()
       mov       [rbp-14C],eax
       mov       esi,[rbp-14C]
       lea       rdi,[rbp-0D0]
       call      qword ptr [7F2A580BEB08]; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]]..ctor(Int32)
       mov       rax,[rbp-0D0]
       mov       rdx,[rbp-0C8]
       add       rsp,1A0
       pop       rbp
       ret
M38_L12:
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-170],rax
       cmp       qword ptr [rbp-170],0
       je        short M38_L13
       mov       rax,[rbp-170]
       mov       [rbp-98],rax
       jmp       short M38_L14
M38_L13:
       mov       rdi,[rbp-10]
       mov       rsi,7F2A584C3EA0
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-98],rax
M38_L14:
       lea       rdi,[rsp]
       lea       rsi,[rbp-68]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,[rbp-98]
       mov       rsi,[rbp-48]
       mov       rdx,[rbp-30]
       mov       rcx,[rbp+18]
       mov       r8,[rbp-40]
       call      qword ptr [7F2A580BE898]
       mov       [rbp-0A8],rax
       mov       [rbp-0A0],rdx
       mov       rax,[rbp-0A8]
       mov       rdx,[rbp-0A0]
       add       rsp,1A0
       pop       rbp
       ret
       sub       rsp,28
       mov       [rbp-0E8],rdi
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-48]
       xor       edx,edx
       call      qword ptr [7F2A580BEAD8]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-178],rax
       cmp       qword ptr [rbp-178],0
       je        short M38_L15
       mov       rax,[rbp-178]
       mov       [rbp-0F0],rax
       jmp       short M38_L16
M38_L15:
       mov       rdi,[rbp-10]
       mov       rsi,7F2A584C40E0
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0F0],rax
M38_L16:
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7F2A580BEA18]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       [rbp-138],rax
       mov       rcx,[rbp-138]
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-30]
       mov       rdi,[rbp-0F0]
       call      qword ptr [7F2A580BE8E0]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-48]
       call      qword ptr [7F2A580BEA30]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 1331
```
```assembly
; System.Diagnostics.Metrics.Instrument.get_Enabled()
       mov       rax,[rdi+8]
       cmp       qword ptr [rax+8],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 16
```
```assembly
; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,0F0
       lea       rbp,[rsp+0F0]
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFF40
M40_L00:
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       vmovdqa   xmmword ptr [rax+rbp],xmm8
       add       rax,30
       jne       short M40_L00
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       mov       [rbp-20],rcx
       cmp       qword ptr [rbp-8],0
       je        near ptr M40_L03
       mov       rax,7F226D800BA0
       mov       rdi,[rax]
       cmp       [rdi],edi
       call      qword ptr [7F2A580BEB38]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M40_L03
       lea       rdi,[rbp-0B0]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2A585C7390]
       lea       rax,[rbp-0B0]
       mov       [rbp-0C0],rax
       mov       rax,7F2A5420B630
       mov       [rbp-0C8],rax
       movzx     eax,byte ptr [rbp-14]
       test      eax,eax
       jne       short M40_L01
       mov       rax,[rbp-0C0]
       mov       [rbp-0D0],rax
       mov       rax,[rbp-0C8]
       mov       [rbp-0D8],rax
       mov       rax,7F2A5420B678
       mov       [rbp-0E0],rax
       jmp       short M40_L02
M40_L01:
       mov       rax,[rbp-0C0]
       mov       [rbp-0D0],rax
       mov       rax,[rbp-0C8]
       mov       [rbp-0D8],rax
       mov       rax,7F2A5420B6A0
       mov       [rbp-0E0],rax
M40_L02:
       mov       rdi,[rbp-0D0]
       mov       rsi,[rbp-0D8]
       mov       rdx,[rbp-0E0]
       call      qword ptr [7F2A585C73A8]
       mov       rdi,[rbp-8]
       call      qword ptr [7F2A585C73C0]
       mov       [rbp-0B8],rax
       lea       rdi,[rbp-0B8]
       call      qword ptr [7F2A585C73D8]
       vmovsd    qword ptr [rbp-0E8],xmm0
       vmovsd    xmm0,qword ptr [rbp-0E8]
       lea       rsi,[rbp-0B0]
       mov       rax,7F226D800BA0
       mov       rdi,[rax]
       mov       rdx,[rbp-20]
       call      qword ptr [7F2A585C73F0]
M40_L03:
       nop
       add       rsp,0F0
       pop       rbp
       ret
; Total bytes of code 370
```
```assembly
; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,0D0
       lea       rbp,[rsp+0D0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqa   xmmword ptr [rbp-30],xmm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-18],rdx
       mov       rax,7F226D800B48
       mov       rdi,[rax]
       cmp       [rdi],edi
       call      qword ptr [7F2A580BEB38]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M41_L02
       lea       rdi,[rbp-0A8]
       mov       rsi,[rbp-8]
       call      qword ptr [7F2A585C7390]
       lea       rax,[rbp-0A8]
       mov       [rbp-0B0],rax
       mov       rax,7F2A5420B630
       mov       [rbp-0B8],rax
       movzx     eax,byte ptr [rbp-0C]
       test      eax,eax
       jne       short M41_L00
       mov       rax,[rbp-0B0]
       mov       [rbp-0C0],rax
       mov       rax,[rbp-0B8]
       mov       [rbp-0C8],rax
       mov       rax,7F2A5420B678
       mov       [rbp-0D0],rax
       jmp       short M41_L01
M41_L00:
       mov       rax,[rbp-0B0]
       mov       [rbp-0C0],rax
       mov       rax,[rbp-0B8]
       mov       [rbp-0C8],rax
       mov       rax,7F2A5420B6A0
       mov       [rbp-0D0],rax
M41_L01:
       mov       rdi,[rbp-0C0]
       mov       rsi,[rbp-0C8]
       mov       rdx,[rbp-0D0]
       call      qword ptr [7F2A585C73A8]
       lea       rdx,[rbp-0A8]
       mov       rax,7F226D800B48
       mov       rdi,[rax]
       mov       rcx,[rbp-18]
       mov       esi,1
       call      qword ptr [7F2A585C7408]
M41_L02:
       nop
       add       rsp,0D0
       pop       rbp
       ret
; Total bytes of code 326
```
```assembly
; Kevlar.KevlarContext.get_TimeProvider()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+38]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 28
```
```assembly
; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-18],rdx
       mov       [rbp-20],rcx
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      qword ptr [7F2A57625710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F226D8013C0
       mov       rdi,[rax]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C6670]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Rent()
       mov       [rbp-28],rax
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C6688]; Kevlar.KevlarContext.set_CancellationToken(System.Threading.CancellationToken)
       mov       rdi,[rbp-28]
       mov       esi,[rbp-0C]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C66A0]; Kevlar.KevlarContext.set_SynchronousExecutionKind(Kevlar.Internal.SynchronousExecutionKind)
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C66B8]; Kevlar.KevlarContext.set_TimeProvider(System.TimeProvider)
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C66D0]; Kevlar.KevlarContext.set_ShieldName(System.String)
       mov       rdi,[rbp-28]
       mov       esi,0FFFFFFFF
       cmp       [rdi],edi
       call      qword ptr [7F2A585C66E8]; Kevlar.KevlarContext.set_StrategyIndex(Int32)
       mov       rdi,[rbp-28]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F2A585C6700]; Kevlar.KevlarContext.set_AttemptNumber(Int32)
       mov       rdi,[rbp-28]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F2A585C6718]; Kevlar.KevlarContext.set_TelemetryListener(Kevlar.IKevlarTelemetryListener)
       mov       rax,[rbp-28]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 190
```
```assembly
; Kevlar.KevlarProperties..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F2A585C6A30]; Kevlar.KevlarProperties+AdditionalAttemptState..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-8]
       call      qword ptr [7F2A5762C240]; System.Object..ctor()
       mov       rax,[rbp-8]
       mov       rsi,[rax+8]
       mov       rax,[rbp-8]
       lea       rdi,[rax+28]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 104
```
```assembly
; Kevlar.KevlarContext.get_Properties()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+8]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 28
```
```assembly
; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,0C0
       lea       rbp,[rsp+0C0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0C0],ymm8
       vmovdqu   ymmword ptr [rbp-0A0],ymm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rsi
       mov       dword ptr [rbp-0B0],3E8
       mov       rdi,[rbp-30]
       call      qword ptr [7F2A585C7A20]; Kevlar.KevlarProperties.get_SuppressAdditionalAttempts()
       test      eax,eax
       je        short M46_L00
       mov       rdi,7F2A58606ED0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-38]
       mov       esi,1
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7A38]
M46_L00:
       mov       rax,[rbp-30]
       cmp       qword ptr [rax+10],0
       jne       short M46_L01
       mov       rdi,7F2A58606ED4
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0C0
       pop       rbp
       ret
M46_L01:
       mov       rax,[rbp-30]
       mov       rax,[rax+10]
       mov       [rbp-0A0],rax
       mov       rdi,[rbp-0A0]
       mov       rsi,7F2A58606ED8
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0A0]
       mov       [rbp-0B8],rax
       mov       rdi,[rbp-0B8]
       mov       rax,[rbp-30]
       mov       rdx,[rax+38]
       mov       rax,[rbp-30]
       mov       rcx,[rax+40]
       mov       rsi,[rbp-38]
       mov       rax,[rbp-0B8]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
       mov       rax,[rbp-30]
       cmp       qword ptr [rax+18],0
       je        near ptr M46_L05
       lea       rsi,[rbp-68]
       mov       rax,[rbp-30]
       mov       rdi,[rax+18]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7A68]
       nop
       jmp       near ptr M46_L03
M46_L02:
       mov       rdi,7F2A58606FE0
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rsi,[rbp-80]
       lea       rdi,[rbp-68]
       mov       rdx,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2A585C7A80]
       lea       rdi,[rbp-80]
       mov       rsi,offset MT_System.Collections.Generic.KeyValuePair<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>
       call      qword ptr [7F2A585C7A98]
       mov       [rbp-98],rax
       lea       rdi,[rbp-80]
       mov       rsi,offset MT_System.Collections.Generic.KeyValuePair<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>
       call      qword ptr [7F2A585C7AB0]
       mov       [rbp-90],rax
       mov       [rbp-88],rdx
       mov       rax,[rbp-98]
       mov       [rbp-0A8],rax
       mov       rdi,[rbp-0A8]
       mov       rsi,7F2A58606FE8
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0A8]
       mov       [rbp-0C0],rax
       mov       rdi,[rbp-0C0]
       mov       rdx,[rbp-90]
       mov       rcx,[rbp-88]
       mov       rsi,[rbp-38]
       mov       rax,[rbp-0C0]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
M46_L03:
       mov       eax,[rbp-0B0]
       dec       eax
       mov       [rbp-0B0],eax
       cmp       dword ptr [rbp-0B0],0
       jg        short M46_L04
       lea       rdi,[rbp-0B0]
       mov       esi,5C
       call      CORINFO_HELP_PATCHPOINT
M46_L04:
       lea       rdi,[rbp-68]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2A585C7AC8]
       test      eax,eax
       jne       near ptr M46_L02
       mov       rdi,7F2A586070F0
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       call      M46_L06
       nop
M46_L05:
       mov       rdi,7F2A586070F8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0C0
       pop       rbp
       ret
M46_L06:
       push      rax
       mov       rdi,7F2A586070F4
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdi,[rbp-68]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2A585C7AE0]
       nop
       add       rsp,8
       ret
; Total bytes of code 638
```
```assembly
; Kevlar.KevlarProperties.ShareAdditionalAttemptStateWith(Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-10]
       mov       rdi,[rax+28]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7B10]; Kevlar.KevlarProperties+AdditionalAttemptState.AddReference()
       mov       rax,[rbp-10]
       mov       rsi,[rax+28]
       mov       rax,[rbp-8]
       lea       rdi,[rax+28]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 62
```
```assembly
; Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-28],rdx
       mov       [rbp-20],rcx
       mov       [rbp-30],r8
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-40],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+18]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-48],0
       je        short M48_L00
       mov       rax,[rbp-48]
       mov       [rbp-38],rax
       jmp       short M48_L01
M48_L00:
       mov       rdi,[rbp-40]
       mov       rsi,7F2A585B7240
       call      qword ptr [7F2A5762F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-38],rax
M48_L01:
       mov       rdx,[rbp-28]
       mov       rcx,[rbp-20]
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-38]
       mov       r8,[rbp-30]
       call      qword ptr [7F2A585C6BE0]; Kevlar.Internal.ShieldEngine.InvokeWithContextAsync[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]](ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       mov       rax,[rbp-18]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 141
```
```assembly
; Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]]..ctor(System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       [rbp-20],rcx
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-18]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 63
```
```assembly
; Kevlar.Continuation`2[[System.Int32, System.Private.CoreLib],[Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.StrategyNode, System.Func`3<ContextAsyncCallback`2<System.__Canon,Int32>,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Kevlar.Outcome`1<Int32>>>, ContextAsyncCallback`2<System.__Canon,Int32>)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       [rbp-20],rcx
       mov       [rbp-30],r8
       mov       [rbp-28],r9
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-18]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-8]
       lea       rdi,[rax+10]
       lea       rsi,[rbp-30]
       call      CORINFO_HELP_ASSIGN_BYREF
       call      CORINFO_HELP_ASSIGN_BYREF
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 93
```
```assembly
; Kevlar.Continuation`2[[System.Int32, System.Private.CoreLib],[Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]].InvokeAsync(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-68],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       vmovdqa   xmmword ptr [rbp-40],xmm8
       mov       [rbp-30],rax
       mov       [rbp-8],rdx
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       rax,[rbp-10]
       cmp       qword ptr [rax+8],0
       jne       short M51_L00
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-30],rax
       mov       rdi,[rbp-30]
       mov       rsi,7F2A5420B5D0
       call      qword ptr [7F2A57D05680]
       mov       rdi,[rbp-30]
       call      qword ptr [7F2A580BEA60]
       mov       [rbp-40],rax
       mov       [rbp-38],rdx
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-38]
       lea       rdi,[rbp-60]
       call      qword ptr [7F2A585C6BB0]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.Outcome`1<Int32>)
       mov       rax,[rbp-18]
       vmovdqu   ymm0,ymmword ptr [rbp-60]
       vmovdqu   ymmword ptr [rax],ymm0
       mov       rax,[rbp-18]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
M51_L00:
       mov       rax,[rbp-10]
       cmp       qword ptr [rax],0
       jne       short M51_L01
       mov       rax,[rbp-10]
       mov       rdx,[rax+10]
       mov       rax,[rbp-10]
       mov       rcx,[rax+18]
       mov       rax,[rbp-10]
       mov       rax,[rax+8]
       mov       [rbp-68],rax
       mov       rax,[rbp-68]
       mov       rsi,[rbp-18]
       mov       r8,[rbp-28]
       mov       rdi,[rax+8]
       mov       rax,[rbp-68]
       call      qword ptr [rax+18]
       mov       rax,[rbp-18]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
M51_L01:
       mov       rax,[rbp-10]
       mov       rcx,[rax]
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-20]
       mov       r8,[rbp-28]
       call      qword ptr [7F2A585C6BC8]
       mov       rax,[rbp-18]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 283
```
```assembly
; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       push      rbp
       mov       rbp,rsp
       test      rsi,rsi
       je        short M52_L02
       mov       rax,[rsi]
       cmp       rax,rdi
       je        short M52_L02
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M52_L02
M52_L00:
       test      rax,rax
       je        short M52_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M52_L02
       test      rax,rax
       je        short M52_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M52_L02
       test      rax,rax
       jne       short M52_L03
M52_L01:
       xor       esi,esi
M52_L02:
       mov       rax,rsi
       pop       rbp
       ret
M52_L03:
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M52_L02
       test      rax,rax
       je        short M52_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M52_L02
       jmp       short M52_L00
; Total bytes of code 91
```
```assembly
; Kevlar.KevlarContext.CopyChangesToParent(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp-38],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       mov       rax,[rax+20]
       mov       [rbp-18],rax
       xor       eax,eax
       mov       [rbp-20],eax
       lea       rsi,[rbp-20]
       mov       rdi,[rbp-18]
       call      qword ptr [7F2A57625980]; System.Threading.Monitor.Enter(System.Object, Boolean ByRef)
       mov       rdi,[rbp-8]
       call      qword ptr [7F2A580BEA18]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       [rbp-28],rax
       mov       rax,[rbp-8]
       mov       rax,[rax+18]
       mov       [rbp-30],rax
       mov       rdi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F2A580BEA78]; Kevlar.KevlarContext.get_Properties()
       mov       [rbp-38],rax
       mov       rdx,[rbp-38]
       mov       rsi,[rbp-30]
       mov       rdi,[rbp-28]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7B88]; Kevlar.KevlarProperties.ApplyChangesSince(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       nop
       call      M53_L00
       nop
       add       rsp,40
       pop       rbp
       ret
M53_L00:
       push      rax
       movzx     eax,byte ptr [rbp-20]
       test      eax,eax
       je        short M53_L01
       mov       rdi,[rbp-18]
       call      qword ptr [7F2A57626808]; System.Threading.Monitor.Exit(System.Object)
M53_L01:
       nop
       add       rsp,8
       ret
; Total bytes of code 165
```
```assembly
; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,7F226D8013C0
       mov       rdi,[rax]
       mov       rsi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7438]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Return(System.__Canon)
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 46
```
```assembly
; Kevlar.KevlarContext.get_PropertiesForCompletion()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       movzx     eax,byte ptr [rax+64]
       test      eax,eax
       jne       short M55_L00
       mov       rax,[rbp-8]
       mov       rax,[rax+8]
       add       rsp,10
       pop       rbp
       ret
M55_L00:
       mov       rax,[rbp-8]
       mov       rax,[rax+10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 54
```
```assembly
; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       [rbp-20],rcx
       cmp       qword ptr [rbp-10],0
       je        short M56_L00
       mov       rax,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-20]
       mov       rdi,[rax+8]
       mov       rax,[rbp-10]
       call      qword ptr [rax+18]
M56_L00:
       nop
M56_L01:
       add       rsp,30
       pop       rbp
       ret
       push      rax
       mov       [rbp-28],rdi
       lea       rax,[M56_L01]
       add       rsp,8
       ret
; Total bytes of code 86
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       mov       rdi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7330]; Kevlar.KevlarContext.get_ShieldName()
       mov       [rbp-20],rax
       mov       rsi,[rbp-20]
       movzx     edx,byte ptr [rbp-14]
       mov       rdi,[rbp-8]
       mov       rcx,[rbp-10]
       call      qword ptr [7F2A585C7348]; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       mov       rdi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7330]; Kevlar.KevlarContext.get_ShieldName()
       mov       [rbp-28],rax
       mov       rdi,[rbp-28]
       movzx     esi,byte ptr [rbp-14]
       mov       rdx,[rbp-10]
       call      qword ptr [7F2A585C7360]; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 111
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Rent()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-18],rax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       movzx     eax,byte ptr [rax+24]
       test      eax,eax
       je        short M58_L00
       lea       rsi,[rbp-20]
       mov       rdi,[rbp-10]
       call      qword ptr [7F2A585C68F8]
       nop
       add       rsp,20
       pop       rbp
       ret
M58_L00:
       mov       rdi,[rbp-10]
       call      qword ptr [7F2A585C6910]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ThrowIfDisposed()
       mov       rdi,[rbp-10]
       call      qword ptr [7F2A585C6928]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].RentWithoutLifecycle()
       mov       [rbp-18],rax
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+1C],0
       jne       short M58_L01
       mov       rax,[rbp-18]
       add       rsp,20
       pop       rbp
       ret
M58_L01:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7F2A585C6940]
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       call      qword ptr [7F2A585C6958]
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 139
```
```assembly
; Kevlar.KevlarContext.set_CancellationToken(System.Threading.CancellationToken)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       lea       rdi,[rax+68]
       lea       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_BYREF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Kevlar.KevlarContext.set_SynchronousExecutionKind(Kevlar.Internal.SynchronousExecutionKind)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       rax,[rbp-8]
       mov       ecx,[rbp-0C]
       mov       [rax+60],ecx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 33
```
```assembly
; Kevlar.KevlarContext.set_TimeProvider(System.TimeProvider)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       lea       rdi,[rax+38]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Kevlar.KevlarContext.set_ShieldName(System.String)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Kevlar.KevlarContext.set_StrategyIndex(Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       rax,[rbp-8]
       mov       ecx,[rbp-0C]
       mov       [rax+5C],ecx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 33
```
```assembly
; Kevlar.KevlarContext.set_AttemptNumber(Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       rax,[rbp-8]
       mov       ecx,[rbp-0C]
       mov       [rax+58],ecx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 33
```
```assembly
; Kevlar.KevlarContext.set_TelemetryListener(Kevlar.IKevlarTelemetryListener)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       lea       rdi,[rax+40]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       dword ptr [rax+8],1
       mov       rdi,[rbp-8]
       call      qword ptr [7F2A5762C240]; System.Object..ctor()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; System.Object..ctor()
       ret
; Total bytes of code 1
```
```assembly
; Kevlar.KevlarProperties.get_SuppressAdditionalAttempts()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rdi,[rax+28]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7AF8]; Kevlar.KevlarProperties+AdditionalAttemptState.get_IsSuppressed()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 37
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState.AddReference()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       call      qword ptr [7F2A580BDDB8]; System.Threading.Interlocked.Increment(Int32 ByRef)
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 41
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F2A571CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F2A571CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; Kevlar.Internal.ShieldEngine.InvokeWithContextAsync[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]](ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       xor       eax,eax
       mov       [rbp-78],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       mov       [rbp-8],rsi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-28],rdx
       mov       [rbp-20],rcx
       mov       [rbp-30],r8
       lea       rdi,[rbp-68]
       call      qword ptr [7F2A585C6E08]; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].Create()
       vmovdqu   xmm0,xmmword ptr [rbp-28]
       vmovdqu   xmmword ptr [rbp-50],xmm0
       mov       rax,[rbp-30]
       mov       [rbp-78],rax
       mov       dword ptr [rbp-70],0FFFFFFFF
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-88],rax
       cmp       qword ptr [rbp-88],0
       je        short M71_L00
       mov       rax,[rbp-88]
       mov       [rbp-80],rax
       jmp       short M71_L01
M71_L00:
       mov       rdi,[rbp-18]
       mov       rsi,7F2A585B7EB8
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-80],rax
M71_L01:
       lea       rdx,[rbp-78]
       lea       rdi,[rbp-68]
       mov       rsi,[rbp-80]
       call      qword ptr [7F2A585C6DC0]; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       lea       rdi,[rbp-68]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2A585C6E20]; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Task()
       mov       rax,[rbp-10]
       add       rsp,90
       pop       rbp
       ret
; Total bytes of code 207
```
```assembly
; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.Outcome`1<Int32>)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-18],rsi
       mov       [rbp-10],rdx
       mov       rax,[rbp-8]
       lea       rdi,[rax+10]
       lea       rsi,[rbp-18]
       call      CORINFO_HELP_ASSIGN_BYREF
       movsq
       mov       rax,[rbp-8]
       xor       ecx,ecx
       mov       [rax],rcx
       mov       rax,[rbp-8]
       mov       byte ptr [rax+0A],1
       mov       rax,[rbp-8]
       mov       word ptr [rax+8],0
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 74
```
```assembly
; System.Threading.Monitor.Enter(System.Object, Boolean ByRef)
       push      rbp
       push      r15
       push      rbx
       lea       rbp,[rsp+10]
       mov       r15,rdi
       mov       rbx,rsi
       cmp       byte ptr [rbx],0
       je        short M73_L00
       call      qword ptr [7F2A571E69F0]
       int       3
M73_L00:
       test      r15,r15
       je        short M73_L02
       mov       rdi,r15
       call      qword ptr [7F2A571E69B0]
       test      eax,eax
       jne       short M73_L01
       mov       rdi,r15
       call      qword ptr [7F2A571E69C0]
M73_L01:
       mov       byte ptr [rbx],1
       pop       rbx
       pop       r15
       pop       rbp
       ret
M73_L02:
       xor       edi,edi
       call      qword ptr [7F2A571E1208]
       int       3
; Total bytes of code 71
```
```assembly
; Kevlar.KevlarProperties.ApplyChangesSince(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       rdi,[rbp-8]
       call      qword ptr [7F2A585C7A20]; Kevlar.KevlarProperties.get_SuppressAdditionalAttempts()
       test      eax,eax
       je        short M74_L00
       mov       rdi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7A20]; Kevlar.KevlarProperties.get_SuppressAdditionalAttempts()
       test      eax,eax
       jne       short M74_L00
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7A20]; Kevlar.KevlarProperties.get_SuppressAdditionalAttempts()
       test      eax,eax
       jne       short M74_L00
       mov       rdi,[rbp-18]
       mov       esi,1
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7A38]
M74_L00:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-8]
       mov       rdx,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7BA0]; Kevlar.KevlarProperties.RemoveMissingValuesFrom(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       mov       rdx,[rbp-18]
       call      qword ptr [7F2A585C7BB8]; Kevlar.KevlarProperties.CopyChangedValuesTo(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 130
```
```assembly
; System.Threading.Monitor.Exit(System.Object)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rbx,rdi
       test      rbx,rbx
       je        short M75_L01
       mov       rdi,rbx
       call      qword ptr [7F2A571E69F8]
       test      eax,eax
       je        short M75_L00
       mov       rsi,rbx
       mov       edi,eax
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
M75_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M75_L01:
       xor       edi,edi
       call      qword ptr [7F2A571E1208]
       int       3
; Total bytes of code 66
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Return(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rdi,[rbp-10]
       mov       rsi,7F2A542044E0
       call      qword ptr [7F2A57D05878]; System.ArgumentNullException.ThrowIfNull(System.Object, System.String)
       mov       rax,[rbp-8]
       movzx     eax,byte ptr [rax+24]
       test      eax,eax
       je        short M76_L00
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2A585C7450]
       nop
       add       rsp,10
       pop       rbp
       ret
M76_L00:
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+1C],0
       je        short M76_L01
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2A585C6940]
       nop
       add       rsp,10
       pop       rbp
       ret
M76_L01:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2A585C7468]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       jne       short M76_L02
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2A585C6940]
       nop
       add       rsp,10
       pop       rbp
       ret
M76_L02:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2A585C7480]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ReturnWithoutReset(System.__Canon)
       mov       rdi,[rbp-8]
       call      qword ptr [7F2A585C7498]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ClearIfDisposed()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 172
```
```assembly
; Kevlar.KevlarContext.get_ShieldName()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+30]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 28
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ThrowIfDisposed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+1C],0
       je        short M78_L00
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       call      qword ptr [7F2A585C6958]
M78_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 48
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].RentWithoutLifecycle()
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-18],rax
       xor       eax,eax
       mov       [rbp-1C],eax
       cmp       qword ptr [rbp-18],0
       jne       near ptr M79_L05
       mov       rdi,[rbp-10]
       call      qword ptr [7F2A585C6970]
       mov       [rbp-1C],eax
       mov       rdi,[rbp-10]
       mov       esi,[rbp-1C]
       call      qword ptr [7F2A585C6988]
       mov       [rbp-30],rax
       mov       rax,[rbp-30]
       mov       rax,[rax]
       mov       [rbp-38],rax
       cmp       qword ptr [rbp-38],0
       je        short M79_L02
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-60],rax
       mov       rax,[rbp-60]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+30]
       mov       [rbp-68],rax
       cmp       qword ptr [rbp-68],0
       je        short M79_L00
       mov       rax,[rbp-68]
       mov       [rbp-58],rax
       jmp       short M79_L01
M79_L00:
       mov       rdi,[rbp-60]
       mov       rsi,7F2A585B5CE0
       call      qword ptr [7F2A5762F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-58],rax
M79_L01:
       mov       rdi,[rbp-58]
       mov       rsi,[rbp-30]
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-38]
       call      qword ptr [7F2A57A1E868]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       cmp       rax,[rbp-38]
       je        short M79_L03
M79_L02:
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-40]
       mov       [rbp-50],rax
       jmp       short M79_L04
M79_L03:
       mov       rax,[rbp-38]
       mov       [rbp-50],rax
M79_L04:
       mov       rax,[rbp-50]
       mov       [rbp-28],rax
       jmp       short M79_L06
M79_L05:
       lea       rsi,[rbp-28]
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2A580BDD10]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
M79_L06:
       mov       rax,[rbp-28]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-28],0
       jne       short M79_L08
       cmp       qword ptr [rbp-18],0
       je        short M79_L07
       mov       rdi,[rbp-10]
       call      qword ptr [7F2A585C69A0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].CreateItem()
       nop
       add       rsp,70
       pop       rbp
       ret
M79_L07:
       mov       rdi,[rbp-10]
       mov       esi,[rbp-1C]
       call      qword ptr [7F2A585C69B8]
       mov       [rbp-48],rax
M79_L08:
       mov       rax,[rbp-48]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 330
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState.get_IsSuppressed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+0C],0
       setne     al
       movzx     eax,al
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 34
```
```assembly
; System.Threading.Interlocked.Increment(Int32 ByRef)
       mov       eax,1
       lock xadd [rdi],eax
       inc       eax
       ret
; Total bytes of code 12
```
```assembly
; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].Create()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-20],xmm0
       vmovdqu   xmmword ptr [rbp-18],xmm0
       mov       rax,[rbp-8]
       vmovdqu   xmm0,xmmword ptr [rbp-20]
       vmovdqu   xmmword ptr [rax],xmm0
       mov       rcx,[rbp-10]
       mov       [rax+10],rcx
       mov       rax,[rbp-8]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 75
```
```assembly
; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       mov       [rbp-8],rsi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+10]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-30],0
       je        short M83_L00
       mov       rax,[rbp-30]
       mov       [rbp-28],rax
       jmp       short M83_L01
M83_L00:
       mov       rdi,[rbp-18]
       mov       rsi,7F2A585B8118
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-28],rax
M83_L01:
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-20]
       call      qword ptr [7F2A585C6E50]; System.Runtime.CompilerServices.AsyncMethodBuilderCore.Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 104
```
```assembly
; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Task()
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       rcx,7F226D8013E8
       cmp       rax,[rcx]
       jne       short M84_L00
       mov       rax,[rbp-8]
       mov       rsi,[rax+8]
       mov       rax,[rbp-8]
       mov       rdx,[rax+10]
       lea       rdi,[rbp-70]
       call      qword ptr [7F2A585C6BB0]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.Outcome`1<Int32>)
       mov       rax,[rbp-10]
       vmovdqu   ymm0,ymmword ptr [rbp-70]
       vmovdqu   ymmword ptr [rax],ymm0
       mov       rax,[rbp-10]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
M84_L00:
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       [rbp-20],rax
       mov       rax,[rbp-20]
       mov       [rbp-28],rax
       cmp       qword ptr [rbp-20],0
       jne       short M84_L01
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-50],rax
       mov       rdi,[rbp-50]
       call      qword ptr [7F2A585C7228]
       mov       rax,[rbp-50]
       mov       [rbp-18],rax
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-50]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       mov       [rbp-28],rax
M84_L01:
       lea       rdi,[rbp-48]
       mov       rsi,[rbp-28]
       call      qword ptr [7F2A585C7240]
       mov       rax,[rbp-10]
       vmovdqu   ymm0,ymmword ptr [rbp-48]
       vmovdqu   ymmword ptr [rax],ymm0
       mov       rax,[rbp-10]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 236
```
```assembly
; Kevlar.KevlarProperties.RemoveMissingValuesFrom(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,0B0
       lea       rbp,[rsp+0B0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0A0],ymm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-30],rdi
       mov       [rbp-38],rsi
       mov       [rbp-40],rdx
       mov       dword ptr [rbp-0A8],3E8
       mov       rax,[rbp-30]
       mov       rsi,[rax+38]
       mov       rax,[rbp-30]
       mov       rdx,[rax+40]
       mov       rax,[rbp-30]
       mov       rdi,[rax+10]
       mov       rcx,[rbp-38]
       mov       r8,[rbp-40]
       call      qword ptr [7F2A585C7BD0]; Kevlar.KevlarProperties.RemoveMissingValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       mov       rax,[rbp-30]
       cmp       qword ptr [rax+18],0
       jne       short M85_L00
       mov       rdi,7F2A586078F8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M85_L00:
       lea       rsi,[rbp-70]
       mov       rax,[rbp-30]
       mov       rdi,[rax+18]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7A68]
       nop
       jmp       near ptr M85_L02
M85_L01:
       mov       rdi,7F2A586078FC
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rsi,[rbp-88]
       lea       rdi,[rbp-70]
       mov       rdx,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2A585C7A80]
       lea       rdi,[rbp-88]
       mov       rsi,offset MT_System.Collections.Generic.KeyValuePair<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>
       call      qword ptr [7F2A585C7A98]
       mov       [rbp-0A0],rax
       lea       rdi,[rbp-88]
       mov       rsi,offset MT_System.Collections.Generic.KeyValuePair<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>
       call      qword ptr [7F2A585C7AB0]
       mov       [rbp-98],rax
       mov       [rbp-90],rdx
       mov       rsi,[rbp-98]
       mov       rdx,[rbp-90]
       mov       rdi,[rbp-0A0]
       mov       rcx,[rbp-38]
       mov       r8,[rbp-40]
       call      qword ptr [7F2A585C7BD0]; Kevlar.KevlarProperties.RemoveMissingValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
M85_L02:
       mov       eax,[rbp-0A8]
       dec       eax
       mov       [rbp-0A8],eax
       cmp       dword ptr [rbp-0A8],0
       jg        short M85_L03
       lea       rdi,[rbp-0A8]
       mov       esi,47
       call      CORINFO_HELP_PATCHPOINT
M85_L03:
       lea       rdi,[rbp-70]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2A585C7AC8]
       test      eax,eax
       jne       near ptr M85_L01
       call      M85_L04
       nop
       mov       rdi,7F2A58607904
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M85_L04:
       push      rax
       mov       rdi,7F2A58607900
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdi,[rbp-70]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2A585C7AE0]
       nop
       add       rsp,8
       ret
; Total bytes of code 446
```
```assembly
; Kevlar.KevlarProperties.CopyChangedValuesTo(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,0B0
       lea       rbp,[rsp+0B0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0A0],ymm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-30],rdi
       mov       [rbp-38],rsi
       mov       [rbp-40],rdx
       mov       dword ptr [rbp-0A8],3E8
       mov       rax,[rbp-30]
       mov       rsi,[rax+38]
       mov       rax,[rbp-30]
       mov       rdx,[rax+40]
       mov       rax,[rbp-30]
       mov       rdi,[rax+10]
       mov       rcx,[rbp-38]
       mov       r8,[rbp-40]
       call      qword ptr [7F2A585C7C48]; Kevlar.KevlarProperties.CopyChangedValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       mov       rax,[rbp-30]
       cmp       qword ptr [rax+18],0
       jne       short M86_L00
       mov       rdi,7F2A58607990
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M86_L00:
       lea       rsi,[rbp-70]
       mov       rax,[rbp-30]
       mov       rdi,[rax+18]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7A68]
       nop
       jmp       near ptr M86_L02
M86_L01:
       mov       rdi,7F2A58607994
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rsi,[rbp-88]
       lea       rdi,[rbp-70]
       mov       rdx,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2A585C7A80]
       lea       rdi,[rbp-88]
       mov       rsi,offset MT_System.Collections.Generic.KeyValuePair<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>
       call      qword ptr [7F2A585C7A98]
       mov       [rbp-0A0],rax
       lea       rdi,[rbp-88]
       mov       rsi,offset MT_System.Collections.Generic.KeyValuePair<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>
       call      qword ptr [7F2A585C7AB0]
       mov       [rbp-98],rax
       mov       [rbp-90],rdx
       mov       rsi,[rbp-98]
       mov       rdx,[rbp-90]
       mov       rdi,[rbp-0A0]
       mov       rcx,[rbp-38]
       mov       r8,[rbp-40]
       call      qword ptr [7F2A585C7C48]; Kevlar.KevlarProperties.CopyChangedValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
M86_L02:
       mov       eax,[rbp-0A8]
       dec       eax
       mov       [rbp-0A8],eax
       cmp       dword ptr [rbp-0A8],0
       jg        short M86_L03
       lea       rdi,[rbp-0A8]
       mov       esi,47
       call      CORINFO_HELP_PATCHPOINT
M86_L03:
       lea       rdi,[rbp-70]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2A585C7AC8]
       test      eax,eax
       jne       near ptr M86_L01
       call      M86_L04
       nop
       mov       rdi,7F2A5860799C
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M86_L04:
       push      rax
       mov       rdi,7F2A58607998
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdi,[rbp-70]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2A585C7AE0]
       nop
       add       rsp,8
       ret
; Total bytes of code 446
```
```assembly
; System.ArgumentNullException.ThrowIfNull(System.Object, System.String)
       push      rax
       test      rdi,rdi
       je        short M87_L00
       add       rsp,8
       ret
M87_L00:
       mov       rdi,rsi
       call      qword ptr [7F2A571E1208]
       int       3
; Total bytes of code 21
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-30],rax
       mov       rax,[rbp-30]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+38]
       mov       [rbp-38],rax
       cmp       qword ptr [rbp-38],0
       je        short M88_L00
       mov       rax,[rbp-38]
       mov       [rbp-28],rax
       jmp       short M88_L01
M88_L00:
       mov       rdi,[rbp-30]
       mov       rsi,7F2A585BA528
       call      qword ptr [7F2A5762F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-28],rax
M88_L01:
       mov       byte ptr [rbp-20],0
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7F2A585C74B0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItemGuarded(System.__Canon)
       nop
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 124
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ReturnWithoutReset(System.__Canon)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-20],0
       je        short M89_L01
       mov       rdi,[rbp-20]
       mov       rsi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2A580BE088]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(System.__Canon)
       test      eax,eax
       jne       short M89_L00
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7F2A585C6940]
M89_L00:
       nop
       add       rsp,50
       pop       rbp
       ret
M89_L01:
       mov       rdi,[rbp-10]
       call      qword ptr [7F2A585C6970]
       mov       [rbp-24],eax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-48],rax
       mov       rax,[rbp-48]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+40]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       je        short M89_L02
       mov       rax,[rbp-50]
       mov       [rbp-38],rax
       jmp       short M89_L03
M89_L02:
       mov       rdi,[rbp-48]
       mov       rsi,7F2A585BBE50
       call      qword ptr [7F2A5762F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-38],rax
M89_L03:
       mov       rdi,[rbp-10]
       mov       esi,[rbp-24]
       call      qword ptr [7F2A585C6988]
       mov       [rbp-40],rax
       mov       rsi,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rdx,[rbp-18]
       call      qword ptr [7F2A580BE040]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-30],0
       jne       short M89_L04
       add       rsp,50
       pop       rbp
       ret
M89_L04:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-30]
       mov       ecx,[rbp-24]
       call      qword ptr [7F2A585C76C0]
       nop
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 262
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ClearIfDisposed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+1C],0
       je        short M90_L00
       mov       rdi,[rbp-8]
       call      qword ptr [7F2A585C76F0]
M90_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 41
```
```assembly
; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       push      rax
       mov       rax,rdx
       test      rsi,rsi
       je        short M91_L00
       mov       rdx,rcx
       mov       rdi,rsi
       mov       rsi,rax
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       jmp       qword ptr [rax]
M91_L00:
       call      qword ptr [7F2A571E4288]
       int       3
; Total bytes of code 39
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-14],eax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rdi,[rbp-8]
       call      qword ptr [7F2A580BDD58]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-14],eax
       mov       rdi,[rbp-8]
       mov       esi,[rbp-14]
       mov       rdx,[rbp-10]
       call      qword ptr [7F2A580BDD70]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       je        short M92_L00
       mov       eax,1
       add       rsp,20
       pop       rbp
       ret
M92_L00:
       mov       rdi,[rbp-8]
       mov       esi,[rbp-14]
       mov       rdx,[rbp-10]
       call      qword ptr [7F2A580BDD88]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 92
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].CreateItem()
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       call      qword ptr [7F2A585C69E8]; Kevlar.KevlarContext+PoolPolicy.Create()
       mov       [rbp-18],rax
       mov       rax,[rbp-18]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-18],0
       jne       short M93_L00
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-28],rax
       mov       edi,67
       mov       rsi,7F2A57AA56C8
       call      qword ptr [7F2A5762EF88]
       mov       [rbp-30],rax
       mov       rsi,[rbp-30]
       mov       rdi,[rbp-28]
       call      qword ptr [7F2A57D05680]
       mov       rdi,[rbp-28]
       call      CORINFO_HELP_THROW
       int       3
M93_L00:
       mov       rax,[rbp-20]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 147
```
```assembly
; System.Runtime.CompilerServices.AsyncMethodBuilderCore.Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       push      rbp
       sub       rsp,0A0
       lea       rbp,[rsp+0A0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       rax,[rbp-18]
       vmovdqu   ymm0,ymmword ptr [rax]
       vmovdqu   ymmword ptr [rbp-80],ymm0
       vmovdqu   ymm0,ymmword ptr [rax+20]
       vmovdqu   ymmword ptr [rbp-60],ymm0
       mov       rcx,[rax+40]
       mov       [rbp-40],rcx
       call      qword ptr [7F2A585C6EE0]; System.Threading.Thread.get_CurrentThread()
       mov       [rbp-20],rax
       mov       rax,[rbp-20]
       mov       rax,[rax+8]
       mov       [rbp-28],rax
       mov       rax,[rbp-20]
       mov       rax,[rax+10]
       mov       [rbp-30],rax
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+10]
       mov       [rbp-98],rax
       cmp       qword ptr [rbp-98],0
       je        short M94_L00
       mov       rax,[rbp-98]
       mov       [rbp-88],rax
       jmp       short M94_L01
M94_L00:
       mov       rdi,[rbp-10]
       mov       rsi,7F2A585B82A0
       call      qword ptr [7F2A5762F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-88],rax
M94_L01:
       mov       rax,[rbp-88]
       mov       [rbp-90],rax
       mov       rdi,[rbp-18]
       mov       rax,[rbp-90]
       call      rax
       nop
       call      M94_L02
       nop
       vzeroupper
       add       rsp,0A0
       pop       rbp
       ret
M94_L02:
       push      rax
       mov       rax,[rbp-20]
       mov       rax,[rax+10]
       cmp       rax,[rbp-30]
       je        short M94_L03
       mov       rax,[rbp-20]
       lea       rdi,[rax+10]
       mov       rsi,[rbp-30]
       call      CORINFO_HELP_ASSIGN_REF
M94_L03:
       mov       rax,[rbp-20]
       mov       rax,[rax+8]
       mov       [rbp-38],rax
       mov       rax,[rbp-28]
       cmp       rax,[rbp-38]
       je        short M94_L04
       mov       rdi,[rbp-20]
       mov       rsi,[rbp-28]
       mov       rdx,[rbp-38]
       call      qword ptr [7F2A585C6EF8]
M94_L04:
       nop
       vzeroupper
       add       rsp,8
       ret
; Total bytes of code 318
```
```assembly
; Kevlar.KevlarProperties.RemoveMissingValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       [rbp-38],rax
       mov       [rbp-8],rdi
       mov       [rbp-18],rsi
       mov       [rbp-10],rdx
       mov       [rbp-20],rcx
       mov       [rbp-28],r8
       cmp       qword ptr [rbp-8],0
       je        near ptr M95_L01
       mov       rdi,[rbp-8]
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       je        short M95_L01
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-10]
       mov       rdi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7C00]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-30],0
       je        short M95_L00
       mov       rdi,[rbp-30]
       mov       rax,[rbp-30]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       jne       short M95_L01
M95_L00:
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-10]
       mov       rdi,[rbp-28]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7C00]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       [rbp-38],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-8]
       call      qword ptr [7F2A585C7C18]
       test      eax,eax
       je        short M95_L01
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-10]
       mov       rdi,[rbp-28]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7C30]
M95_L01:
       nop
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 195
```
```assembly
; Kevlar.KevlarProperties.CopyChangedValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       [rbp-38],rax
       mov       [rbp-8],rdi
       mov       [rbp-18],rsi
       mov       [rbp-10],rdx
       mov       [rbp-20],rcx
       mov       [rbp-28],r8
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-10]
       mov       rdi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7C00]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-8],0
       je        short M96_L00
       mov       rdi,[rbp-8]
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       je        short M96_L00
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-30]
       call      qword ptr [7F2A585C7C18]
       test      eax,eax
       jne       short M96_L00
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-10]
       mov       rdi,[rbp-28]
       cmp       [rdi],edi
       call      qword ptr [7F2A585C7C00]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       [rbp-38],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-30]
       call      qword ptr [7F2A585C7C18]
       test      eax,eax
       je        short M96_L00
       mov       rdx,[rbp-18]
       mov       rcx,[rbp-10]
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-28]
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
M96_L00:
       nop
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 190
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItemGuarded(System.__Canon)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2A585C74E0]; Kevlar.KevlarContext+PoolPolicy.TryReset(Kevlar.KevlarContext)
       mov       [rbp-14],eax
       mov       eax,[rbp-14]
       add       rsp,50
       pop       rbp
       ret
       push      rax
       mov       [rbp-38],rdi
       mov       rax,[rbp-38]
       mov       [rbp-28],rax
       mov       rdi,offset MT_System.Exception[]
       mov       esi,2
       call      CORINFO_HELP_NEWARR_1_PTR
       mov       [rbp-40],rax
       mov       rdi,[rbp-40]
       mov       rdx,[rbp-20]
       xor       esi,esi
       call      qword ptr [7F2A576257A0]; System.Runtime.CompilerServices.CastHelpers.StelemRef(System.Object[], IntPtr, System.Object)
       mov       rdi,[rbp-40]
       mov       rdx,[rbp-28]
       mov       esi,1
       call      qword ptr [7F2A576257A0]; System.Runtime.CompilerServices.CastHelpers.StelemRef(System.Object[], IntPtr, System.Object)
       mov       rdi,offset MT_System.AggregateException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-48],rax
       mov       edi,0C1
       mov       rsi,7F2A57AA56C8
       call      qword ptr [7F2A5762EF88]
       mov       [rbp-50],rax
       mov       rsi,[rbp-50]
       mov       rdi,[rbp-48]
       mov       rdx,[rbp-40]
       call      qword ptr [7F2A580BE028]
       mov       rdi,[rbp-48]
       call      CORINFO_HELP_THROW
       int       3
       push      rax
       mov       [rbp-30],rdi
       mov       rax,[rbp-30]
       mov       [rbp-20],rax
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2A585C6940]
       nop
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 247
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(System.__Canon)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       xor       eax,eax
       mov       [rbp-68],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       dword ptr [rbp-78],3E8
       mov       rdi,[rbp-38]
       call      qword ptr [7F2A580BDD58]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-44],eax
       xor       eax,eax
       mov       [rbp-48],eax
       jmp       near ptr M98_L08
M98_L00:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       ecx,[rbp-44]
       cmp       ecx,[rax+8]
       jae       near ptr M98_L10
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       rax,[rax]
       mov       [rbp-50],rax
       mov       rax,[rbp-50]
       cmp       qword ptr [rax+50],0
       jne       near ptr M98_L03
       mov       rax,[rbp-50]
       cmp       [rax],al
       mov       rax,[rbp-50]
       add       rax,50
       mov       [rbp-68],rax
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-80],rax
       mov       rax,[rbp-80]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+20]
       mov       [rbp-88],rax
       cmp       qword ptr [rbp-88],0
       je        short M98_L01
       mov       rax,[rbp-88]
       mov       [rbp-70],rax
       jmp       short M98_L02
M98_L01:
       mov       rdi,[rbp-80]
       mov       rsi,7F2A5840FCD8
       call      qword ptr [7F2A5762F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-70],rax
M98_L02:
       mov       rdi,[rbp-70]
       mov       rsi,[rbp-68]
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-58]
       call      qword ptr [7F2A57A1E868]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       test      rax,rax
       je        short M98_L05
       mov       rdi,7F2A584B7A70
       call      CORINFO_HELP_COUNTPROFILE32
M98_L03:
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       mov       rsi,[rbp-50]
       mov       rdx,[rbp-40]
       call      qword ptr [7F2A580BE0B8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       je        short M98_L06
M98_L04:
       mov       rdi,7F2A584B7A74
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,90
       pop       rbp
       ret
M98_L05:
       mov       rdi,7F2A584B7A78
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       short M98_L04
M98_L06:
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-5C],eax
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-44],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-5C]
       jne       short M98_L07
       mov       rdi,7F2A584B7A7C
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-44],eax
M98_L07:
       mov       rdi,7F2A584B7A80
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-48]
       inc       eax
       mov       [rbp-48],eax
M98_L08:
       mov       eax,[rbp-78]
       dec       eax
       mov       [rbp-78],eax
       cmp       dword ptr [rbp-78],0
       jg        short M98_L09
       lea       rdi,[rbp-78]
       mov       esi,62
       call      CORINFO_HELP_PATCHPOINT
M98_L09:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-48]
       jg        near ptr M98_L00
       mov       rdi,7F2A584B7A84
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,90
       pop       rbp
       ret
M98_L10:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 495
```

