```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.45GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]    : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  dry-1.9.0 : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

Job=dry-1.9.0  EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.9.0,DOTNET_TieredPGO=1  Arguments=/p:ReservoirVersion=1.9.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll  
IterationCount=1  LaunchCount=1  RunStrategy=ColdStart  
UnrollFactor=1  WarmupCount=1  

```
| Method           | Mean     | Error | Code Size | Allocated |
|----------------- |---------:|------:|----------:|----------:|
| SingleRentReturn | 173.5 μs |    NA |   9,707 B |         - |
| NestedRentReturn | 173.1 μs |    NA |   9,758 B |         - |
| SingleContext    | 456.6 μs |    NA |  10,800 B |         - |
| NestedContext    | 449.6 μs |    NA |  15,700 B |         - |
