## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: C-baseline(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.4.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.4.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=10, LaunchCount=3, WarmupCount=5))

```assembly
; PoolContextProbe.SingleRentReturn()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       rbx,rdi
       mov       r15,[rbx+8]
       cmp       dword ptr [r15+1C],0
       jne       near ptr M00_L12
M00_L00:
       mov       r14,[r15+10]
       xor       r13d,r13d
       test      r14,r14
       je        near ptr M00_L13
       mov       rdi,7F2E61AA0D68
       mov       rax,7F2E62333820
       call      rax
       add       rax,4C
       mov       r12d,[rax+10]
       test      r12d,r12d
       je        near ptr M00_L21
M00_L01:
       dec       r12d
       mov       eax,[r14+18]
       test      eax,eax
       jl        near ptr M00_L22
       and       r12d,eax
M00_L02:
       xor       eax,eax
       mov       [rbp-34],eax
       mov       rdi,[r14+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M00_L26
M00_L03:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M00_L42
       mov       edx,r12d
       mov       rcx,[rdi+rdx*8+10]
       mov       [rbp-40],rcx
       mov       r8,[rcx+10]
       mov       [rbp-48],r8
       test      r8,r8
       je        near ptr M00_L24
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M00_L39
       mov       rdx,r8
       xor       esi,esi
       call      00007F2E61874060
       mov       rcx,[rbp-48]
       cmp       rax,rcx
       jne       near ptr M00_L23
       mov       r8,rcx
       mov       [rbp-30],r8
M00_L04:
       mov       r12,[rbp-30]
       cmp       qword ptr [rbp-30],0
       je        near ptr M00_L27
M00_L05:
       xor       edi,edi
       mov       [rbp-30],rdi
       cmp       dword ptr [r15+1C],0
       jne       near ptr M00_L29
M00_L06:
       mov       r15d,[r12+8]
       mov       rbx,[rbx+8]
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M00_L11
       mov       rdi,rbx
       mov       rsi,r12
       call      qword ptr [7F2DE3ECDE30]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       test      eax,eax
       je        near ptr M00_L11
       mov       r14,[rbx+10]
       test      r14,r14
       je        near ptr M00_L34
       mov       rdi,7F2E61AA0D68
       mov       rax,7F2E62333820
       call      rax
       add       rax,4C
       mov       r13d,[rax+10]
       test      r13d,r13d
       je        near ptr M00_L30
M00_L07:
       dec       r13d
       mov       eax,[r14+18]
       test      eax,eax
       jl        near ptr M00_L31
       and       r13d,eax
M00_L08:
       xor       eax,eax
       mov       [rbp-38],eax
       mov       rdi,[r14+8]
       cmp       dword ptr [rdi+8],0
       jle       short M00_L10
M00_L09:
       mov       rdi,[r14+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M00_L42
       mov       esi,r13d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-50],rcx
       cmp       [rcx],cl
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M00_L39
       mov       rsi,r12
       xor       edx,edx
       call      00007F2E61874060
       test      rax,rax
       jne       near ptr M00_L32
M00_L10:
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M00_L41
M00_L11:
       mov       eax,r15d
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M00_L12:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7F2DE3ECDBA8]
       jmp       near ptr M00_L00
M00_L13:
       mov       rdi,7F2E61AA0D68
       mov       rax,7F2E62333820
       call      rax
       add       rax,44
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M00_L15
M00_L14:
       mov       rdi,7F2DE244B1E8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M00_L14
       mov       [rax+10],edi
M00_L15:
       dec       edi
       imul      edi,9E3779B9
       mov       edx,[r15+18]
       test      edx,edx
       jge       short M00_L16
       mov       r13d,edi
       mov       esi,[r15+20]
       imul      r13,rsi
       shr       r13,20
       jmp       short M00_L17
M00_L16:
       mov       r13d,edi
       and       r13d,edx
M00_L17:
       mov       rdi,[r15+8]
       lea       edx,[r13*8]
       cmp       edx,[rdi+8]
       jae       near ptr M00_L42
       lea       rdi,[rdi+rdx*8+10]
       mov       r12,[rdi]
       test      r12,r12
       je        short M00_L18
       mov       rdx,r12
       xor       esi,esi
       call      00007F2E61874060
       cmp       rax,r12
       je        short M00_L19
M00_L18:
       xor       edi,edi
       jmp       short M00_L20
M00_L19:
       mov       rdi,r12
M00_L20:
       mov       [rbp-30],rdi
       jmp       near ptr M00_L04
M00_L21:
       mov       rdi,7F2DE244B178
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M00_L21
       mov       rdi,7F2E61AA0D68
       mov       rax,7F2E62333820
       call      rax
       add       rax,4C
       mov       [rax+10],r12d
       jmp       near ptr M00_L01
M00_L22:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
       jmp       near ptr M00_L02
M00_L23:
       mov       rcx,[rbp-40]
M00_L24:
       lea       rdx,[rbp-30]
       mov       rsi,rcx
       mov       rdi,offset MT_Reservoir.StripedObjectStore<PoolContextProbe+Item>
       call      qword ptr [7F2DE3ECDCE0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       near ptr M00_L04
       inc       r12d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r12d
       jne       short M00_L25
       xor       r12d,r12d
M00_L25:
       mov       eax,[rbp-34]
       inc       eax
       mov       rdi,[r14+8]
       cmp       [rdi+8],eax
       mov       [rbp-34],eax
       jg        near ptr M00_L03
M00_L26:
       xor       edi,edi
       mov       [rbp-30],rdi
       jmp       near ptr M00_L04
M00_L27:
       test      r14,r14
       je        short M00_L28
       mov       rdi,offset MT_PoolContextProbe+Item
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       dword ptr [r12+8],2A
       jmp       near ptr M00_L05
M00_L28:
       mov       rdi,r15
       mov       esi,r13d
       call      qword ptr [7F2DE3ECDC80]
       mov       r12,rax
       jmp       near ptr M00_L05
M00_L29:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7F2DE3ECDBA8]
       mov       r12,rax
       jmp       near ptr M00_L06
M00_L30:
       mov       rdi,7F2DE244B178
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M00_L30
       mov       rdi,7F2E61AA0D68
       mov       rax,7F2E62333820
       call      rax
       add       rax,4C
       mov       [rax+10],r13d
       jmp       near ptr M00_L07
M00_L31:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r14+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
       jmp       near ptr M00_L08
M00_L32:
       mov       rdx,r12
       mov       rsi,[rbp-50]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<PoolContextProbe+Item>
       call      qword ptr [7F2DE3ECDF20]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       near ptr M00_L10
       inc       r13d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r13d
       jne       short M00_L33
       xor       r13d,r13d
M00_L33:
       mov       eax,[rbp-38]
       inc       eax
       mov       rdi,[r14+8]
       cmp       [rdi+8],eax
       mov       [rbp-38],eax
       jg        near ptr M00_L09
       jmp       near ptr M00_L10
M00_L34:
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M00_L36
M00_L35:
       mov       rdi,7F2DE244B1E8
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M00_L35
       mov       [rax+10],edi
M00_L36:
       dec       edi
       imul      r14d,edi,9E3779B9
       cmp       dword ptr [rbx+18],0
       jge       short M00_L37
       mov       r13d,r14d
       mov       r14d,[rbx+20]
       imul      r14,r13
       shr       r14,20
       jmp       short M00_L38
M00_L37:
       and       r14d,[rbx+18]
M00_L38:
       mov       rdi,[rbx+8]
       lea       esi,[r14*8]
       cmp       esi,[rdi+8]
       jae       short M00_L42
       lea       esi,[r14*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M00_L40
M00_L39:
       call      qword ptr [7F2DE4476100]
       int       3
M00_L40:
       mov       rsi,r12
       call      00007F2E61874040
       test      rax,rax
       je        near ptr M00_L10
       mov       rdi,rbx
       mov       rsi,r12
       mov       rdx,rax
       mov       ecx,r14d
       call      qword ptr [7F2DE3ECDF08]
       jmp       near ptr M00_L10
M00_L41:
       mov       rdi,rbx
       call      qword ptr [7F2DE3ECDF50]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       jmp       near ptr M00_L11
M00_L42:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 1269
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       cmp       [rdi],dil
       mov       eax,1
       add       rsp,10
       pop       rbp
       ret
       push      rax
       mov       rdi,[rbp-8]
       cmp       [rdi],dil
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 42
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+18]
       mov       rdi,[rbp-10]
       call      qword ptr [7F2DE3ECDD88]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M02_L00
       mov       rax,[rbp-20]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M02_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M02_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rax]
       mov       rdi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M02_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       xor       ecx,ecx
       mov       [rax],rcx
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+20]
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7F2DE3ECDDA0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       rax,[rbp-20]
       cmp       qword ptr [rax],0
       setne     al
       movzx     eax,al
       add       rsp,30
       pop       rbp
       ret
M02_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 221
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+20]
       mov       rdi,[rbp-10]
       call      qword ptr [7F2DE3ECDD88]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M03_L00
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M03_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M03_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rbp-20]
       mov       rdi,rax
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+18]
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7F2DE3ECDDA0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       eax,1
       add       rsp,30
       pop       rbp
       ret
M03_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 171
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       push      rbp
       sub       rsp,0B0
       lea       rbp,[rsp+0B0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       dword ptr [rbp-88],3E8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-98],rax
       mov       rax,[rbp-98]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+40]
       mov       [rbp-0A0],rax
       cmp       qword ptr [rbp-0A0],0
       je        short M04_L00
       mov       rax,[rbp-0A0]
       mov       [rbp-68],rax
       jmp       short M04_L01
M04_L00:
       mov       rdi,[rbp-98]
       mov       rsi,7F2DE4559980
       call      qword ptr [7F2DE343F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-68],rax
M04_L01:
       mov       rax,[rbp-38]
       cmp       [rax],al
       mov       rax,[rbp-38]
       lea       rdi,[rax+28]
       mov       rsi,[rbp-68]
       mov       rdx,[rbp-38]
       call      qword ptr [7F2DE4476268]; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       nop
M04_L02:
       mov       rax,[rbp-38]
       mov       rax,[rax+10]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-48],0
       je        near ptr M04_L07
M04_L03:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M04_L04
       lea       rdi,[rbp-88]
       mov       esi,1D
       call      CORINFO_HELP_PATCHPOINT
M04_L04:
       lea       rsi,[rbp-50]
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7F2DE3ECDC50]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       test      eax,eax
       je        short M04_L05
       mov       rdi,7F2DE45735E4
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-50]
       call      qword ptr [7F2DE453C0D8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       jmp       short M04_L03
M04_L05:
       cmp       qword ptr [rbp-40],0
       je        short M04_L06
       mov       rdi,7F2DE45735E8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7F2DE453C0F0]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F2DE453C108]
M04_L06:
       mov       rdi,7F2DE45735EC
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M04_L07:
       xor       eax,eax
       mov       [rbp-54],eax
       jmp       near ptr M04_L11
M04_L08:
       mov       rdi,7F2DE45735F0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-38]
       mov       esi,[rbp-54]
       call      qword ptr [7F2DE3ECDC38]
       mov       [rbp-70],rax
       xor       eax,eax
       mov       [rbp-60],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-0A8],rax
       mov       rax,[rbp-0A8]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+38]
       mov       [rbp-0B0],rax
       cmp       qword ptr [rbp-0B0],0
       je        short M04_L09
       mov       rax,[rbp-0B0]
       mov       [rbp-78],rax
       jmp       short M04_L10
M04_L09:
       mov       rdi,[rbp-0A8]
       mov       rsi,7F2DE42D0280
       call      qword ptr [7F2DE343F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-78],rax
M04_L10:
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-70]
       mov       rdx,[rbp-60]
       call      qword ptr [7F2DE3ECDEA8]
       mov       [rbp-90],rax
       mov       rsi,[rbp-90]
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       call      qword ptr [7F2DE453C0D8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       mov       eax,[rbp-54]
       inc       eax
       mov       [rbp-54],eax
M04_L11:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M04_L12
       lea       rdi,[rbp-88]
       mov       esi,67
       call      CORINFO_HELP_PATCHPOINT
M04_L12:
       mov       rdi,[rbp-38]
       call      qword ptr [7F2DE453C120]
       cmp       eax,[rbp-54]
       jg        near ptr M04_L08
       cmp       qword ptr [rbp-40],0
       je        short M04_L13
       mov       rdi,7F2DE45735F4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7F2DE453C0F0]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F2DE453C108]
M04_L13:
       mov       rdi,7F2DE45735F8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
       push      rax
       mov       [rbp-80],rdi
       mov       rdi,7F2DE45735E0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-80]
       mov       [rbp-40],rax
       lea       rax,[M04_L02]
       add       rsp,8
       ret
; Total bytes of code 731
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-50],rcx
       mov       dword ptr [rbp-70],3E8
M05_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M05_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M05_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7F2DE3ECDDB8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-50]
       mov       [rcx],eax
       mov       rax,[rbp-50]
       cmp       dword ptr [rax],0FFFFFFFF
       jne       short M05_L02
       mov       rdi,7F2DE42C5E00
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,70
       pop       rbp
       ret
M05_L02:
       mov       rax,[rbp-50]
       mov       eax,[rax]
       mov       rcx,[rbp-48]
       cmp       eax,[rcx+8]
       jae       short M05_L04
       mov       edx,eax
       imul      rdx,10
       lea       rcx,[rcx+rdx+10]
       mov       eax,[rcx+8]
       mov       [rbp-5C],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-5C]
       call      qword ptr [7F2DE3ECDDD0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-68],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-68]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M05_L03
       mov       rdi,7F2DE42C5E04
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,70
       pop       rbp
       ret
M05_L03:
       mov       rdi,7F2DE42C5E08
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M05_L00
M05_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 269
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-4C],ecx
       mov       dword ptr [rbp-70],3E8
M06_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M06_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M06_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rax,[rbp-48]
       mov       ecx,[rbp-4C]
       cmp       ecx,[rax+8]
       jae       near ptr M06_L03
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       add       rax,8
       mov       [rbp-68],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7F2DE3ECDDB8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-68]
       mov       [rcx],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-4C]
       call      qword ptr [7F2DE3ECDDD0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-60],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-60]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M06_L02
       mov       rdi,7F2DE42C62F8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,70
       pop       rbp
       ret
M06_L02:
       mov       rdi,7F2DE42C62FC
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M06_L00
M06_L03:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 235
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F2DE2FDEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F2DE2FDEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       push      rbp
       sub       rsp,110
       lea       rbp,[rsp+110]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0F0],ymm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       xor       eax,eax
       mov       [rbp-50],rax
       mov       [rbp-30],rsi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       dword ptr [rbp-0C8],3E8
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       jne       short M08_L00
       mov       rdi,7F2DE4574D88
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,110
       pop       rbp
       ret
M08_L00:
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+10]
       mov       [rbp-0F8],rax
       cmp       qword ptr [rbp-0F8],0
       je        short M08_L01
       mov       rax,[rbp-0F8]
       mov       [rbp-80],rax
       jmp       short M08_L02
M08_L01:
       mov       rdi,[rbp-40]
       mov       rsi,7F2DE4559F40
       call      qword ptr [7F2DE343F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-80],rax
M08_L02:
       mov       rdi,[rbp-50]
       cmp       [rdi],edi
       call      qword ptr [7F2DE453C1E0]
       mov       [rbp-0A8],rax
       mov       rdi,[rbp-0A8]
       mov       rsi,7F2DE4574D90
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0A8]
       mov       [rbp-0D0],rax
       mov       rdi,[rbp-0D0]
       mov       r11,[rbp-80]
       mov       rax,[rbp-80]
       call      qword ptr [rax]
       mov       [rbp-60],rax
       jmp       near ptr M08_L09
M08_L03:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-100],rax
       cmp       qword ptr [rbp-100],0
       je        short M08_L04
       mov       rax,[rbp-100]
       mov       [rbp-88],rax
       jmp       short M08_L05
M08_L04:
       mov       rdi,[rbp-40]
       mov       rsi,7F2DE4559F78
       call      qword ptr [7F2DE343F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-88],rax
M08_L05:
       mov       rax,[rbp-60]
       mov       [rbp-0B0],rax
       mov       rdi,[rbp-0B0]
       mov       rsi,7F2DE4574E98
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0B0]
       mov       [rbp-0E0],rax
       mov       rdi,[rbp-0E0]
       mov       r11,[rbp-88]
       mov       rax,[rbp-88]
       call      qword ptr [rax]
       mov       [rbp-0D8],rax
       mov       rax,[rbp-0D8]
       cmp       [rax],al
       mov       rax,[rbp-0D8]
       add       rax,8
       mov       [rbp-90],rax
       xor       eax,eax
       mov       [rbp-70],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-108],rax
       cmp       qword ptr [rbp-108],0
       je        short M08_L06
       mov       rax,[rbp-108]
       mov       [rbp-98],rax
       jmp       short M08_L07
M08_L06:
       mov       rdi,[rbp-40]
       mov       rsi,7F2DE4559FC8
       call      qword ptr [7F2DE343F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-98],rax
M08_L07:
       mov       rdi,[rbp-98]
       mov       rsi,[rbp-90]
       mov       rdx,[rbp-70]
       call      qword ptr [7F2DE3ECDEA8]
       mov       [rbp-68],rax
       cmp       qword ptr [rbp-68],0
       je        short M08_L08
       mov       rdi,7F2DE4574FA0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-48]
       mov       rsi,[rbp-68]
       cmp       [rdi],edi
       call      qword ptr [7F2DE453C1F8]
       jmp       short M08_L09
M08_L08:
       mov       rdi,7F2DE4574FA4
       call      CORINFO_HELP_COUNTPROFILE32
M08_L09:
       mov       eax,[rbp-0C8]
       dec       eax
       mov       [rbp-0C8],eax
       cmp       dword ptr [rbp-0C8],0
       jg        short M08_L10
       lea       rdi,[rbp-0C8]
       mov       esi,57
       call      CORINFO_HELP_PATCHPOINT
M08_L10:
       mov       rax,[rbp-60]
       mov       [rbp-0B8],rax
       mov       rdi,[rbp-0B8]
       mov       rsi,7F2DE4574FB0
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0B8]
       mov       [rbp-0E8],rax
       mov       rdi,[rbp-0E8]
       mov       r11,7F2DE2450880
       call      qword ptr [r11]
       test      eax,eax
       jne       near ptr M08_L03
       call      M08_L13
       nop
       cmp       qword ptr [rbp-58],0
       je        short M08_L11
       mov       rdi,7F2DE45751CC
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-58]
       call      qword ptr [7F2DE453C0F0]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F2DE453C108]
M08_L11:
       mov       rdi,7F2DE45751D0
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,110
       pop       rbp
       ret
       push      rax
       mov       [rbp-0A0],rdi
       mov       rax,[rbp-0A0]
       mov       [rbp-78],rax
       cmp       qword ptr [rbp-58],0
       jne       short M08_L12
       mov       rdi,7F2DE4574FA8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-78]
       mov       [rbp-58],rax
M08_L12:
       mov       rdi,7F2DE4574FAC
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rax,[M08_L09]
       add       rsp,8
       ret
M08_L13:
       push      rax
       cmp       qword ptr [rbp-60],0
       je        short M08_L14
       mov       rdi,7F2DE45750B8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-60]
       mov       [rbp-0C0],rax
       mov       rdi,[rbp-0C0]
       mov       rsi,7F2DE45750C0
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0C0]
       mov       [rbp-0F0],rax
       mov       rdi,[rbp-0F0]
       mov       r11,7F2DE2450888
       call      qword ptr [r11]
M08_L14:
       mov       rdi,7F2DE45751C8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
; Total bytes of code 999
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,18
       lea       rbp,[rsp+40]
       mov       [rbp-30],rdi
       mov       rbx,rdi
       mov       r15,rsi
       mov       rdi,rbx
       call      qword ptr [7F2DE3ECDCC8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       r14d,eax
       xor       r13d,r13d
       mov       rdi,[rbx+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M09_L05
M09_L00:
       mov       rdi,[rbx+8]
       cmp       r14d,[rdi+8]
       jae       near ptr M09_L06
       mov       edx,r14d
       mov       r12,[rdi+rdx*8+10]
       mov       rax,[r12+10]
       mov       [rbp-38],rax
       test      rax,rax
       je        short M09_L02
       lea       rdi,[r12+10]
       test      rdi,rdi
       je        short M09_L04
       mov       rdx,rax
       xor       esi,esi
       call      00007F2E61874060
       mov       rcx,[rbp-38]
       cmp       rax,rcx
       jne       short M09_L02
       mov       rax,rcx
       mov       rdi,r15
       mov       rsi,rax
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
M09_L01:
       mov       eax,1
       add       rsp,18
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M09_L02:
       mov       rdi,[rbx]
       mov       rsi,r12
       mov       rdx,r15
       call      qword ptr [7F2DE3ECDCE0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M09_L01
       inc       r14d
       mov       rdi,[rbx+8]
       cmp       [rdi+8],r14d
       jne       short M09_L03
       xor       r14d,r14d
M09_L03:
       inc       r13d
       mov       rdi,[rbx+8]
       cmp       [rdi+8],r13d
       jg        near ptr M09_L00
       jmp       short M09_L05
M09_L04:
       call      qword ptr [7F2DE4476100]
       int       3
M09_L05:
       xor       eax,eax
       mov       [r15],rax
       add       rsp,18
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M09_L06:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 244
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       cmp       qword ptr [rbp-10],0
       jne       short M10_L00
       add       rsp,30
       pop       rbp
       ret
M10_L00:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2DE3ECDB90]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
M10_L01:
       add       rsp,30
       pop       rbp
       ret
       push      rax
       mov       [rbp-28],rdi
       mov       rax,[rbp-28]
       mov       [rbp-20],rax
       mov       rax,[rbp-18]
       cmp       qword ptr [rax],0
       jne       short M10_L02
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
M10_L02:
       lea       rax,[M10_L01]
       add       rsp,8
       ret
; Total bytes of code 114
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       eax,[rbp-10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 27
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-1C],edx
       mov       rax,[rbp-18]
       sar       rax,20
       lea       esi,[rax+1]
       mov       rdi,[rbp-10]
       mov       edx,[rbp-1C]
       call      qword ptr [7F2DE382E0D0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 56
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7F2DE2FE4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7F2DE2FDEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7F2DE2FEF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M13_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M13_L00
       mov       rsi,rax
       call      qword ptr [7F2DE2FDEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M13_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F2DE2FDEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F2DE2FDEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rdi
       mov       rdi,[rbx]
       call      qword ptr [7F2DE3ECDCF8]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       r15d,[rax+10]
       test      r15d,r15d
       je        short M15_L02
M15_L00:
       dec       r15d
       mov       eax,[rbx+18]
       test      eax,eax
       jl        short M15_L03
       and       eax,r15d
M15_L01:
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
M15_L02:
       mov       rdi,[rbx]
       call      qword ptr [7F2DE3435728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       edi,1
       mov       r15d,edi
       lock xadd [rax],r15d
       inc       r15d
       je        short M15_L02
       mov       rdi,[rbx]
       call      qword ptr [7F2DE3ECDCF8]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       [rax+10],r15d
       jmp       short M15_L00
M15_L03:
       mov       rax,[rbx+8]
       mov       eax,[rax+8]
       mov       ecx,r15d
       imul      rcx,[rbx+10]
       shr       rcx,20
       inc       rcx
       imul      rax,rcx
       shr       rax,20
       jmp       short M15_L01
; Total bytes of code 134
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2DE453C210]; PoolContextProbe+Policy.Destroy(Item)
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 49
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-10],edx
       movsxd    rax,dword ptr [rbp-0C]
       shl       rax,20
       mov       ecx,[rbp-10]
       or        rax,rcx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 40
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rax,[rdi+20]
       mov       ebx,[rax-28]
       cmp       ebx,0FFFFFFFF
       je        near ptr M18_L04
       mov       rdi,7F2E61AA0D68
       mov       rax,7F2E62333820
       call      rax
       add       rax,8
       add       rax,0FFFFFFFFFFFFFFF8
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M18_L01
       cmp       [rax],edi
       jle       short M18_L03
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M18_L03
M18_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M18_L01:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M18_L02
       movsxd    rdi,ecx
       add       rax,rdi
       jmp       short M18_L00
M18_L02:
       cmp       [rax+4],ecx
       jle       short M18_L03
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M18_L03
       mov       rax,[rdi]
       test      rax,rax
       je        short M18_L03
       jmp       short M18_L00
M18_L03:
       mov       edi,ebx
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7F2DE4476238]
M18_L04:
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7F2DE3ECDD40]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 179
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-10]
       mov       rcx,rax
       test      cl,1
       jne       short M19_L00
       ret
M19_L00:
       jmp       qword ptr [7F2DE382EA00]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 23
```
```assembly
; PoolContextProbe+Policy.Destroy(Item)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 24
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       rsi,rdi
       lea       rdi,[rbp-30]
       mov       [rbp-94],rdi
       mov       [rbp-9C],rsi
       xor       edx,edx
       mov       [rbp-8C],edx
       lea       rdi,[rbp-88]
       call      qword ptr [7F2DE2FDEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       edx,[rbp-8C]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7F2DE2FDEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,[rbp-30]
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 131
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbx
       sub       rsp,10
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rbx,rdi
       mov       rdi,rbx
       call      qword ptr [7F2DE2FF9718]; Precode of System.Runtime.CompilerServices.InitHelpers.InitClassSlow(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rbx+20]
       mov       rax,[rax-10]
       mov       [rsp+8],rax
       mov       rax,[rsp+8]
       and       rax,0FFFFFFFFFFFFFFFE
       xor       ecx,ecx
       mov       [rsp+8],rcx
       add       rsp,10
       pop       rbx
       ret
; Total bytes of code 59
```

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: C-baseline(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.4.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.4.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=10, LaunchCount=3, WarmupCount=5))

```assembly
; PoolContextProbe.NestedRentReturn()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,0C8
       lea       rbp,[rsp+0F0]
       mov       rbx,rdi
       mov       r15,[rbx+8]
       cmp       dword ptr [r15+1C],0
       jne       near ptr M00_L36
M00_L00:
       mov       r14,[r15+10]
       xor       r13d,r13d
       test      r14,r14
       je        near ptr M00_L37
       mov       rdi,7F371EEA0D68
       mov       rax,7F371F819820
       call      rax
       add       rax,4C
       mov       r12d,[rax+10]
       test      r12d,r12d
       je        near ptr M00_L45
M00_L01:
       dec       r12d
       mov       eax,[r14+18]
       test      eax,eax
       jl        near ptr M00_L46
       and       r12d,eax
M00_L02:
       xor       eax,eax
M00_L03:
       mov       rdi,[r14+8]
       mov       [rbp-2C],eax
       cmp       [rdi+8],eax
       jle       near ptr M00_L50
       cmp       r12d,[rdi+8]
       jae       near ptr M00_L99
       mov       edx,r12d
       mov       rcx,[rdi+rdx*8+10]
       mov       [rbp-0B0],rcx
       mov       r8,[rcx+10]
       mov       [rbp-0B8],r8
       test      r8,r8
       je        near ptr M00_L28
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M00_L96
       mov       rdx,r8
       xor       esi,esi
       call      00007F371EC74060
       mov       rdi,[rbp-0B8]
       cmp       rax,rdi
       mov       rcx,[rbp-0B0]
       jne       near ptr M00_L28
       mov       r8,rdi
       mov       rdx,r8
M00_L04:
       test      rdx,rdx
       je        near ptr M00_L51
M00_L05:
       cmp       dword ptr [r15+1C],0
       jne       near ptr M00_L53
       mov       r15,rdx
M00_L06:
       mov       r14,[rbx+8]
       cmp       dword ptr [r14+1C],0
       jne       near ptr M00_L54
M00_L07:
       mov       r13,[r14+10]
       xor       r12d,r12d
       test      r13,r13
       je        near ptr M00_L55
       mov       rdi,7F371EEA0D68
       mov       rax,7F371F819820
       call      rax
       add       rax,4C
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M00_L63
M00_L08:
       dec       eax
       mov       ecx,[r13+18]
       test      ecx,ecx
       jl        near ptr M00_L64
       and       ecx,eax
M00_L09:
       mov       eax,ecx
       xor       ecx,ecx
M00_L10:
       mov       rdi,[r13+8]
       mov       [rbp-40],ecx
       cmp       [rdi+8],ecx
       jle       near ptr M00_L68
       cmp       eax,[rdi+8]
       jae       near ptr M00_L99
       mov       [rbp-3C],eax
       mov       edx,eax
       mov       r8,[rdi+rdx*8+10]
       mov       [rbp-0C8],r8
       mov       r9,[r8+10]
       mov       [rbp-0D0],r9
       test      r9,r9
       je        near ptr M00_L32
       lea       rdi,[r8+10]
       test      rdi,rdi
       je        near ptr M00_L96
       mov       rdx,r9
       xor       esi,esi
       call      00007F371EC74060
       mov       rdi,[rbp-0D0]
       cmp       rax,rdi
       mov       r8,[rbp-0C8]
       jne       near ptr M00_L32
       mov       r9,rdi
       mov       rdx,r9
M00_L11:
       test      rdx,rdx
       je        near ptr M00_L69
M00_L12:
       cmp       dword ptr [r14+1C],0
       jne       near ptr M00_L71
       mov       r14,rdx
M00_L13:
       mov       r13d,[r15+8]
       add       r13d,[r14+8]
       mov       r12,[rbx+8]
       cmp       dword ptr [r12+1C],0
       jne       near ptr M00_L20
       mov       rdi,r12
       mov       rsi,r14
       call      qword ptr [7F36A12CDE30]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       test      eax,eax
       je        near ptr M00_L20
       mov       rax,[r12+10]
       mov       [rbp-0D8],rax
       test      rax,rax
       je        near ptr M00_L78
       mov       rdi,7F371EEA0D68
       mov       rcx,7F371F819820
       call      rcx
       add       rax,4C
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M00_L72
M00_L14:
       dec       eax
       mov       rcx,[rbp-0D8]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M00_L73
       and       r8d,eax
M00_L15:
       mov       eax,r8d
       xor       r8d,r8d
       mov       [rbp-58],r8d
       mov       rdi,[rcx+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M00_L77
M00_L16:
       mov       rdi,[rcx+8]
       cmp       eax,[rdi+8]
       jae       near ptr M00_L99
       mov       [rbp-54],eax
       mov       esi,eax
       mov       r9,[rdi+rsi*8+10]
       mov       [rbp-0E0],r9
       cmp       [r9],r9b
       lea       rdi,[r9+10]
       test      rdi,rdi
       je        near ptr M00_L96
       mov       rsi,r14
       xor       edx,edx
       call      00007F371EC74060
       test      rax,rax
       je        near ptr M00_L19
       mov       rcx,[rbp-0E0]
       lea       rdi,[rcx+20]
       mov       rsi,[rcx+8]
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       je        near ptr M00_L75
M00_L17:
       cmp       edx,[rsi+8]
       jae       near ptr M00_L99
       mov       r8d,edx
       shl       r8,4
       mov       [rbp-0A0],r8
       mov       r9d,[rsi+r8+18]
       mov       r10,rax
       sar       r10,20
       inc       r10d
       movsxd    r10,r10d
       shl       r10,20
       or        r9,r10
       mov       [rbp-68],rax
       lock cmpxchg [rdi],r9
       cmp       rax,[rbp-68]
       jne       near ptr M00_L74
       mov       rdi,[rcx+8]
       mov       [rbp-60],edx
       cmp       edx,[rdi+8]
       jae       near ptr M00_L99
       lea       rdi,[rdi+r8+10]
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       mov       r14,[rbp-0E0]
       lea       rdi,[r14+18]
       mov       rcx,[r14+8]
       mov       r14d,[rbp-60]
M00_L18:
       mov       rax,[rdi]
       mov       [rbp-70],rax
       cmp       r14d,[rcx+8]
       jae       near ptr M00_L99
       mov       r8,[rbp-0A0]
       mov       [rcx+r8+18],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       esi,r14d
       or        rdx,rsi
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-70]
       jne       short M00_L18
M00_L19:
       cmp       dword ptr [r12+1C],0
       jne       near ptr M00_L83
M00_L20:
       mov       rbx,[rbx+8]
       cmp       [rbx],bl
       test      r15,r15
       je        near ptr M00_L84
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M00_L27
       mov       rdi,rbx
       mov       rsi,r15
       call      qword ptr [7F36A12CDE30]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       test      eax,eax
       je        near ptr M00_L27
       mov       r14,[rbx+10]
       test      r14,r14
       je        near ptr M00_L91
       mov       rdi,7F371EEA0D68
       mov       rax,7F371F819820
       call      rax
       add       rax,4C
       mov       r12d,[rax+10]
       test      r12d,r12d
       je        near ptr M00_L85
M00_L21:
       dec       r12d
       mov       eax,[r14+18]
       test      eax,eax
       jl        near ptr M00_L86
       and       r12d,eax
M00_L22:
       xor       eax,eax
       mov       [rbp-78],eax
       mov       rdi,[r14+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M00_L90
M00_L23:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M00_L99
       mov       esi,r12d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-0E8],rcx
       cmp       [rcx],cl
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M00_L96
       mov       rsi,r15
       xor       edx,edx
       call      00007F371EC74060
       test      rax,rax
       je        near ptr M00_L26
       mov       rcx,[rbp-0E8]
       lea       rdi,[rcx+20]
       mov       rsi,[rcx+8]
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       je        near ptr M00_L88
       mov       r8d,[rsi+8]
M00_L24:
       cmp       edx,[rsi+8]
       jae       near ptr M00_L99
       mov       r8d,edx
       shl       r8,4
       mov       [rbp-0A8],r8
       mov       r9d,[rsi+r8+18]
       mov       r10,rax
       sar       r10,20
       inc       r10d
       movsxd    r10,r10d
       shl       r10,20
       or        r9,r10
       mov       [rbp-88],rax
       lock cmpxchg [rdi],r9
       cmp       rax,[rbp-88]
       jne       near ptr M00_L87
       mov       rdi,[rcx+8]
       mov       [rbp-7C],edx
       cmp       edx,[rdi+8]
       jae       near ptr M00_L99
       lea       rdi,[rdi+r8+10]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       r15,[rbp-0E8]
       lea       rdi,[r15+18]
       mov       rcx,[r15+8]
       mov       r15d,[rbp-7C]
M00_L25:
       mov       rax,[rdi]
       mov       [rbp-90],rax
       cmp       r15d,[rcx+8]
       jae       near ptr M00_L99
       mov       r14,[rbp-0A8]
       mov       [rcx+r14+18],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       esi,r15d
       or        rdx,rsi
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-90]
       jne       short M00_L25
M00_L26:
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M00_L98
M00_L27:
       mov       eax,r13d
       add       rsp,0C8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M00_L28:
       lea       rdi,[rcx+18]
       mov       rdx,[rcx+8]
       mov       rsi,[rdi]
       mov       r8d,esi
       cmp       r8d,0FFFFFFFF
       je        near ptr M00_L48
       mov       r9d,[rdx+8]
M00_L29:
       cmp       r8d,r9d
       jae       near ptr M00_L99
       mov       r10d,r8d
       shl       r10,4
       mov       r11d,[rdx+r10+18]
       mov       rax,rsi
       sar       rax,20
       inc       eax
       cdqe
       shl       rax,20
       or        r11,rax
       mov       rax,rsi
       lock cmpxchg [rdi],r11
       cmp       rax,rsi
       jne       near ptr M00_L47
       mov       rax,[rcx+8]
       mov       rdi,rax
       mov       edx,[rdi+8]
       cmp       r8d,edx
       jae       near ptr M00_L99
       mov       rdx,[rdi+r10+10]
       lea       rdi,[rax+r10+10]
       xor       eax,eax
       mov       [rdi],rax
       add       rcx,20
M00_L30:
       mov       rax,[rcx]
       mov       [rbp-38],rax
       mov       [rdi+8],eax
       mov       rsi,rax
       sar       rsi,20
       inc       esi
       movsxd    rsi,esi
       shl       rsi,20
       mov       r9d,r8d
       or        rsi,r9
       lock cmpxchg [rcx],rsi
       cmp       rax,[rbp-38]
       jne       short M00_L30
       test      rdx,rdx
       jne       near ptr M00_L04
       jmp       near ptr M00_L48
M00_L31:
       mov       rdi,7F369F84B1E8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M00_L31
       jmp       near ptr M00_L38
M00_L32:
       lea       rdi,[r8+18]
       mov       rdx,[r8+8]
       mov       rsi,[rdi]
       mov       r9d,esi
       cmp       r9d,0FFFFFFFF
       je        near ptr M00_L66
       mov       r10d,[rdx+8]
       mov       [rbp-94],r10d
M00_L33:
       cmp       r9d,r10d
       jae       near ptr M00_L99
       mov       r11d,r9d
       shl       r11,4
       mov       ecx,[rdx+r11+18]
       mov       r10,rsi
       sar       r10,20
       inc       r10d
       movsxd    r10,r10d
       shl       r10,20
       or        rcx,r10
       mov       rax,rsi
       lock cmpxchg [rdi],rcx
       cmp       rax,rsi
       jne       near ptr M00_L65
       mov       rax,[r8+8]
       mov       rdi,rax
       mov       ecx,[rdi+8]
       cmp       r9d,ecx
       jae       near ptr M00_L99
       mov       rdx,[rdi+r11+10]
       cmp       r9d,ecx
       jae       near ptr M00_L99
       lea       rdi,[rax+r11+10]
       xor       eax,eax
       mov       [rdi],rax
       add       r8,20
M00_L34:
       mov       rax,[r8]
       mov       [rbp-50],rax
       mov       [rdi+8],eax
       mov       rcx,rax
       sar       rcx,20
       inc       ecx
       movsxd    rcx,ecx
       shl       rcx,20
       mov       esi,r9d
       or        rcx,rsi
       lock cmpxchg [r8],rcx
       cmp       rax,[rbp-50]
       jne       short M00_L34
       test      rdx,rdx
       jne       near ptr M00_L11
       jmp       near ptr M00_L66
M00_L35:
       mov       rdi,7F369F84B1E8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M00_L35
       jmp       near ptr M00_L56
M00_L36:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7F36A12CDBA8]
       jmp       near ptr M00_L00
M00_L37:
       mov       rdi,7F371EEA0D68
       mov       rax,7F371F819820
       call      rax
       add       rax,44
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M00_L39
       jmp       near ptr M00_L31
M00_L38:
       mov       [rax+10],edi
M00_L39:
       dec       edi
       imul      edi,9E3779B9
       mov       edx,[r15+18]
       test      edx,edx
       jge       short M00_L40
       mov       r13d,edi
       mov       esi,[r15+20]
       imul      r13,rsi
       shr       r13,20
       jmp       short M00_L41
M00_L40:
       mov       r13d,edi
       and       r13d,edx
M00_L41:
       mov       rdi,[r15+8]
       lea       edx,[r13*8]
       cmp       edx,[rdi+8]
       jae       near ptr M00_L99
       lea       rdi,[rdi+rdx*8+10]
       mov       r12,[rdi]
       test      r12,r12
       je        short M00_L42
       mov       rdx,r12
       xor       esi,esi
       call      00007F371EC74060
       cmp       rax,r12
       je        short M00_L43
M00_L42:
       xor       edx,edx
       jmp       short M00_L44
M00_L43:
       mov       rdx,r12
M00_L44:
       jmp       near ptr M00_L04
M00_L45:
       mov       rdi,7F369F84B178
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M00_L45
       mov       rdi,7F371EEA0D68
       mov       rax,7F371F819820
       call      rax
       add       rax,4C
       mov       [rax+10],r12d
       jmp       near ptr M00_L01
M00_L46:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
       jmp       near ptr M00_L02
M00_L47:
       mov       rsi,[rdi]
       mov       r8d,esi
       cmp       r8d,0FFFFFFFF
       jne       near ptr M00_L29
M00_L48:
       inc       r12d
       mov       rdx,[r14+8]
       cmp       [rdx+8],r12d
       jne       short M00_L49
       xor       r12d,r12d
M00_L49:
       mov       eax,[rbp-2C]
       inc       eax
       jmp       near ptr M00_L03
M00_L50:
       xor       edx,edx
       jmp       near ptr M00_L04
M00_L51:
       test      r14,r14
       je        short M00_L52
       mov       rdi,offset MT_PoolContextProbe+Item
       call      CORINFO_HELP_NEWSFAST
       mov       rdx,rax
       mov       dword ptr [rdx+8],2A
       jmp       near ptr M00_L05
M00_L52:
       mov       rdi,r15
       mov       esi,r13d
       call      qword ptr [7F36A12CDC80]
       mov       rdx,rax
       jmp       near ptr M00_L05
M00_L53:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7F36A12CDBA8]
       mov       r15,rax
       jmp       near ptr M00_L06
M00_L54:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7F36A12CDBA8]
       jmp       near ptr M00_L07
M00_L55:
       mov       rdi,7F371EEA0D68
       mov       rax,7F371F819820
       call      rax
       add       rax,44
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M00_L57
       jmp       near ptr M00_L35
M00_L56:
       mov       [rax+10],edi
M00_L57:
       dec       edi
       imul      edi,9E3779B9
       mov       edx,[r14+18]
       test      edx,edx
       jge       short M00_L58
       mov       r12d,edi
       mov       esi,[r14+20]
       imul      r12,rsi
       shr       r12,20
       jmp       short M00_L59
M00_L58:
       mov       r12d,edi
       and       r12d,edx
M00_L59:
       mov       rdi,[r14+8]
       lea       edx,[r12*8]
       cmp       edx,[rdi+8]
       jae       near ptr M00_L99
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       rdx,rax
       mov       [rbp-0C0],rdx
       test      rdx,rdx
       je        short M00_L60
       xor       esi,esi
       call      00007F371EC74060
       mov       rdi,[rbp-0C0]
       cmp       rax,rdi
       je        short M00_L61
M00_L60:
       xor       edx,edx
       jmp       short M00_L62
M00_L61:
       mov       rdx,rdi
M00_L62:
       jmp       near ptr M00_L11
M00_L63:
       mov       rax,7F369F84B178
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-44],eax
       test      eax,eax
       je        short M00_L63
       mov       rdi,7F371EEA0D68
       mov       rcx,7F371F819820
       call      rcx
       add       rax,4C
       mov       ecx,[rbp-44]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M00_L08
M00_L64:
       mov       rcx,[r13+8]
       mov       edi,[rcx+8]
       mov       ecx,eax
       imul      rcx,[r13+10]
       shr       rcx,20
       inc       rcx
       imul      rcx,rdi
       shr       rcx,20
       mov       eax,ecx
       mov       ecx,eax
       jmp       near ptr M00_L09
M00_L65:
       mov       rsi,[rdi]
       mov       r9d,esi
       cmp       r9d,0FFFFFFFF
       mov       r10d,[rbp-94]
       jne       near ptr M00_L33
M00_L66:
       mov       eax,[rbp-3C]
       inc       eax
       mov       edx,eax
       mov       rdi,[r13+8]
       cmp       [rdi+8],edx
       jne       short M00_L67
       xor       edx,edx
       xor       edi,edi
       mov       edx,edi
M00_L67:
       mov       ecx,[rbp-40]
       inc       ecx
       mov       eax,edx
       jmp       near ptr M00_L10
M00_L68:
       xor       edx,edx
       jmp       near ptr M00_L11
M00_L69:
       test      r13,r13
       je        short M00_L70
       mov       rdi,offset MT_PoolContextProbe+Item
       call      CORINFO_HELP_NEWSFAST
       mov       rdx,rax
       mov       dword ptr [rdx+8],2A
       jmp       near ptr M00_L12
M00_L70:
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7F36A12CDC80]
       mov       rdx,rax
       jmp       near ptr M00_L12
M00_L71:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7F36A12CDBA8]
       mov       r14,rax
       jmp       near ptr M00_L13
M00_L72:
       mov       rax,7F369F84B178
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-5C],eax
       test      eax,eax
       je        short M00_L72
       mov       rdi,7F371EEA0D68
       mov       rcx,7F371F819820
       call      rcx
       add       rax,4C
       mov       ecx,[rbp-5C]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M00_L14
M00_L73:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M00_L15
M00_L74:
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       jne       near ptr M00_L17
M00_L75:
       mov       eax,[rbp-54]
       inc       eax
       mov       ecx,eax
       mov       rdx,[rbp-0D8]
       mov       r8,[rdx+8]
       cmp       [r8+8],ecx
       jne       short M00_L76
       xor       ecx,ecx
       xor       edi,edi
       mov       ecx,edi
M00_L76:
       mov       edi,[rbp-58]
       inc       edi
       cmp       [r8+8],edi
       mov       [rbp-58],edi
       mov       eax,ecx
       jle       short M00_L77
       mov       rcx,rdx
       jmp       near ptr M00_L16
M00_L77:
       cmp       [r12],r12b
       jmp       near ptr M00_L19
M00_L78:
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M00_L80
M00_L79:
       mov       rdi,7F369F84B1E8
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M00_L79
       mov       [rax+10],edi
M00_L80:
       dec       edi
       imul      edi,9E3779B9
       cmp       dword ptr [r12+18],0
       jge       short M00_L81
       mov       eax,edi
       mov       ecx,[r12+20]
       imul      rax,rcx
       shr       rax,20
       jmp       short M00_L82
M00_L81:
       mov       eax,edi
       and       eax,[r12+18]
M00_L82:
       mov       rdi,[r12+8]
       lea       esi,[rax*8]
       cmp       esi,[rdi+8]
       jae       near ptr M00_L99
       mov       [rbp-74],eax
       lea       esi,[rax*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       je        near ptr M00_L96
       mov       rsi,r14
       call      00007F371EC74040
       test      rax,rax
       je        near ptr M00_L19
       mov       rdi,r12
       mov       rsi,r14
       mov       rdx,rax
       mov       ecx,[rbp-74]
       call      qword ptr [7F36A12CDF08]
       jmp       near ptr M00_L19
M00_L83:
       mov       rdi,r12
       call      qword ptr [7F36A12CDF50]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       jmp       near ptr M00_L20
M00_L84:
       mov       edi,29
       mov       rsi,7F36A0CB54D8
       call      qword ptr [7F36A083EF88]
       mov       rdi,rax
       call      qword ptr [7F36A1876280]
       int       3
M00_L85:
       mov       rdi,7F369F84B178
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M00_L85
       mov       rdi,7F371EEA0D68
       mov       rax,7F371F819820
       call      rax
       add       rax,4C
       mov       [rax+10],r12d
       jmp       near ptr M00_L21
M00_L86:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
       jmp       near ptr M00_L22
M00_L87:
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       jne       near ptr M00_L24
M00_L88:
       inc       r12d
       mov       rcx,[r14+8]
       cmp       [rcx+8],r12d
       jne       short M00_L89
       xor       r12d,r12d
M00_L89:
       mov       eax,[rbp-78]
       inc       eax
       cmp       [rcx+8],eax
       mov       [rbp-78],eax
       jg        near ptr M00_L23
M00_L90:
       cmp       [rbx],bl
       jmp       near ptr M00_L26
M00_L91:
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M00_L93
M00_L92:
       mov       rdi,7F369F84B1E8
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M00_L92
       mov       [rax+10],edi
M00_L93:
       dec       edi
       imul      r14d,edi,9E3779B9
       cmp       dword ptr [rbx+18],0
       jge       short M00_L94
       mov       r12d,r14d
       mov       r14d,[rbx+20]
       imul      r14,r12
       shr       r14,20
       jmp       short M00_L95
M00_L94:
       and       r14d,[rbx+18]
M00_L95:
       mov       rdi,[rbx+8]
       lea       esi,[r14*8]
       cmp       esi,[rdi+8]
       jae       short M00_L99
       lea       esi,[r14*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M00_L97
M00_L96:
       call      qword ptr [7F36A1876268]
       int       3
M00_L97:
       mov       rsi,r15
       call      00007F371EC74040
       test      rax,rax
       je        near ptr M00_L26
       mov       rdi,rbx
       mov       rsi,r15
       mov       rdx,rax
       mov       ecx,r14d
       call      qword ptr [7F36A12CDF08]
       jmp       near ptr M00_L26
M00_L98:
       mov       rdi,rbx
       call      qword ptr [7F36A12CDF50]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       jmp       near ptr M00_L27
M00_L99:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 3353
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       cmp       [rdi],dil
       mov       eax,1
       add       rsp,10
       pop       rbp
       ret
       push      rax
       mov       rdi,[rbp-8]
       cmp       [rdi],dil
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 42
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       push      rbp
       sub       rsp,0B0
       lea       rbp,[rsp+0B0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       dword ptr [rbp-88],3E8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-98],rax
       mov       rax,[rbp-98]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+40]
       mov       [rbp-0A0],rax
       cmp       qword ptr [rbp-0A0],0
       je        short M02_L00
       mov       rax,[rbp-0A0]
       mov       [rbp-68],rax
       jmp       short M02_L01
M02_L00:
       mov       rdi,[rbp-98]
       mov       rsi,7F36A194B608
       call      qword ptr [7F36A083F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-68],rax
M02_L01:
       mov       rax,[rbp-38]
       cmp       [rax],al
       mov       rax,[rbp-38]
       lea       rdi,[rax+28]
       mov       rsi,[rbp-68]
       mov       rdx,[rbp-38]
       call      qword ptr [7F36A18762B0]; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       nop
M02_L02:
       mov       rax,[rbp-38]
       mov       rax,[rax+10]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-48],0
       je        near ptr M02_L07
M02_L03:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M02_L04
       lea       rdi,[rbp-88]
       mov       esi,1D
       call      CORINFO_HELP_PATCHPOINT
M02_L04:
       lea       rsi,[rbp-50]
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7F36A12CDC50]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       test      eax,eax
       je        short M02_L05
       mov       rdi,7F36A197616C
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-50]
       call      qword ptr [7F36A193C378]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       jmp       short M02_L03
M02_L05:
       cmp       qword ptr [rbp-40],0
       je        short M02_L06
       mov       rdi,7F36A1976170
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7F36A193C390]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F36A193C3A8]
M02_L06:
       mov       rdi,7F36A1976174
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M02_L07:
       xor       eax,eax
       mov       [rbp-54],eax
       jmp       near ptr M02_L11
M02_L08:
       mov       rdi,7F36A1976178
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-38]
       mov       esi,[rbp-54]
       call      qword ptr [7F36A12CDC38]
       mov       [rbp-70],rax
       xor       eax,eax
       mov       [rbp-60],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-0A8],rax
       mov       rax,[rbp-0A8]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+38]
       mov       [rbp-0B0],rax
       cmp       qword ptr [rbp-0B0],0
       je        short M02_L09
       mov       rax,[rbp-0B0]
       mov       [rbp-78],rax
       jmp       short M02_L10
M02_L09:
       mov       rdi,[rbp-0A8]
       mov       rsi,7F36A16D0280
       call      qword ptr [7F36A083F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-78],rax
M02_L10:
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-70]
       mov       rdx,[rbp-60]
       call      qword ptr [7F36A12CDEA8]
       mov       [rbp-90],rax
       mov       rsi,[rbp-90]
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       call      qword ptr [7F36A193C378]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       mov       eax,[rbp-54]
       inc       eax
       mov       [rbp-54],eax
M02_L11:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M02_L12
       lea       rdi,[rbp-88]
       mov       esi,67
       call      CORINFO_HELP_PATCHPOINT
M02_L12:
       mov       rdi,[rbp-38]
       call      qword ptr [7F36A193C3C0]
       cmp       eax,[rbp-54]
       jg        near ptr M02_L08
       cmp       qword ptr [rbp-40],0
       je        short M02_L13
       mov       rdi,7F36A197617C
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7F36A193C390]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F36A193C3A8]
M02_L13:
       mov       rdi,7F36A1976180
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
       push      rax
       mov       [rbp-80],rdi
       mov       rdi,7F36A1976168
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-80]
       mov       [rbp-40],rax
       lea       rax,[M02_L02]
       add       rsp,8
       ret
; Total bytes of code 731
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F36A03DEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F36A03DEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       push      rbp
       sub       rsp,110
       lea       rbp,[rsp+110]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0F0],ymm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       xor       eax,eax
       mov       [rbp-50],rax
       mov       [rbp-30],rsi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       dword ptr [rbp-0C8],3E8
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       jne       short M04_L00
       mov       rdi,7F36A1977910
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,110
       pop       rbp
       ret
M04_L00:
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+10]
       mov       [rbp-0F8],rax
       cmp       qword ptr [rbp-0F8],0
       je        short M04_L01
       mov       rax,[rbp-0F8]
       mov       [rbp-80],rax
       jmp       short M04_L02
M04_L01:
       mov       rdi,[rbp-40]
       mov       rsi,7F36A194BBC8
       call      qword ptr [7F36A083F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-80],rax
M04_L02:
       mov       rdi,[rbp-50]
       cmp       [rdi],edi
       call      qword ptr [7F36A193C480]
       mov       [rbp-0A8],rax
       mov       rdi,[rbp-0A8]
       mov       rsi,7F36A1977918
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0A8]
       mov       [rbp-0D0],rax
       mov       rdi,[rbp-0D0]
       mov       r11,[rbp-80]
       mov       rax,[rbp-80]
       call      qword ptr [rax]
       mov       [rbp-60],rax
       jmp       near ptr M04_L09
M04_L03:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-100],rax
       cmp       qword ptr [rbp-100],0
       je        short M04_L04
       mov       rax,[rbp-100]
       mov       [rbp-88],rax
       jmp       short M04_L05
M04_L04:
       mov       rdi,[rbp-40]
       mov       rsi,7F36A194BC00
       call      qword ptr [7F36A083F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-88],rax
M04_L05:
       mov       rax,[rbp-60]
       mov       [rbp-0B0],rax
       mov       rdi,[rbp-0B0]
       mov       rsi,7F36A1977A20
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0B0]
       mov       [rbp-0E0],rax
       mov       rdi,[rbp-0E0]
       mov       r11,[rbp-88]
       mov       rax,[rbp-88]
       call      qword ptr [rax]
       mov       [rbp-0D8],rax
       mov       rax,[rbp-0D8]
       cmp       [rax],al
       mov       rax,[rbp-0D8]
       add       rax,8
       mov       [rbp-90],rax
       xor       eax,eax
       mov       [rbp-70],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-108],rax
       cmp       qword ptr [rbp-108],0
       je        short M04_L06
       mov       rax,[rbp-108]
       mov       [rbp-98],rax
       jmp       short M04_L07
M04_L06:
       mov       rdi,[rbp-40]
       mov       rsi,7F36A194BC50
       call      qword ptr [7F36A083F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-98],rax
M04_L07:
       mov       rdi,[rbp-98]
       mov       rsi,[rbp-90]
       mov       rdx,[rbp-70]
       call      qword ptr [7F36A12CDEA8]
       mov       [rbp-68],rax
       cmp       qword ptr [rbp-68],0
       je        short M04_L08
       mov       rdi,7F36A1977B28
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-48]
       mov       rsi,[rbp-68]
       cmp       [rdi],edi
       call      qword ptr [7F36A193C498]
       jmp       short M04_L09
M04_L08:
       mov       rdi,7F36A1977B2C
       call      CORINFO_HELP_COUNTPROFILE32
M04_L09:
       mov       eax,[rbp-0C8]
       dec       eax
       mov       [rbp-0C8],eax
       cmp       dword ptr [rbp-0C8],0
       jg        short M04_L10
       lea       rdi,[rbp-0C8]
       mov       esi,57
       call      CORINFO_HELP_PATCHPOINT
M04_L10:
       mov       rax,[rbp-60]
       mov       [rbp-0B8],rax
       mov       rdi,[rbp-0B8]
       mov       rsi,7F36A1977B38
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0B8]
       mov       [rbp-0E8],rax
       mov       rdi,[rbp-0E8]
       mov       r11,7F369F850880
       call      qword ptr [r11]
       test      eax,eax
       jne       near ptr M04_L03
       call      M04_L13
       nop
       cmp       qword ptr [rbp-58],0
       je        short M04_L11
       mov       rdi,7F36A1977D54
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-58]
       call      qword ptr [7F36A193C390]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F36A193C3A8]
M04_L11:
       mov       rdi,7F36A1977D58
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,110
       pop       rbp
       ret
       push      rax
       mov       [rbp-0A0],rdi
       mov       rax,[rbp-0A0]
       mov       [rbp-78],rax
       cmp       qword ptr [rbp-58],0
       jne       short M04_L12
       mov       rdi,7F36A1977B30
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-78]
       mov       [rbp-58],rax
M04_L12:
       mov       rdi,7F36A1977B34
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rax,[M04_L09]
       add       rsp,8
       ret
M04_L13:
       push      rax
       cmp       qword ptr [rbp-60],0
       je        short M04_L14
       mov       rdi,7F36A1977C40
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-60]
       mov       [rbp-0C0],rax
       mov       rdi,[rbp-0C0]
       mov       rsi,7F36A1977C48
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0C0]
       mov       [rbp-0F0],rax
       mov       rdi,[rbp-0F0]
       mov       r11,7F369F850888
       call      qword ptr [r11]
M04_L14:
       mov       rdi,7F36A1977D50
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
; Total bytes of code 999
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,38
       lea       rbp,[rsp+60]
       mov       [rbp-30],rdi
       mov       rbx,rdi
       mov       r15,rsi
       mov       rdi,rbx
       call      qword ptr [7F36A12CDCC8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       r14d,eax
       xor       r13d,r13d
M05_L00:
       mov       rdi,[rbx+8]
       cmp       [rdi+8],r13d
       jle       near ptr M05_L10
       cmp       r14d,[rdi+8]
       jae       near ptr M05_L11
       mov       edx,r14d
       mov       r12,[rdi+rdx*8+10]
       mov       rax,[r12+10]
       mov       [rbp-58],rax
       test      rax,rax
       je        short M05_L02
       lea       rdi,[r12+10]
       test      rdi,rdi
       je        near ptr M05_L09
       mov       rdx,rax
       xor       esi,esi
       call      00007F371EC74060
       mov       rcx,[rbp-58]
       cmp       rax,rcx
       jne       short M05_L02
       mov       rax,rcx
       mov       rdi,r15
       mov       rsi,rax
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
M05_L01:
       mov       eax,1
       add       rsp,38
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M05_L02:
       lea       rdi,[r12+18]
       mov       rsi,[r12+8]
       mov       rax,[rdi]
       mov       ecx,eax
       cmp       ecx,0FFFFFFFF
       je        near ptr M05_L06
       mov       edx,[rsi+8]
M05_L03:
       cmp       ecx,edx
       jae       near ptr M05_L11
       mov       r8d,ecx
       shl       r8,4
       mov       [rbp-50],r8
       mov       r9d,[rsi+r8+18]
       mov       r10,rax
       sar       r10,20
       inc       r10d
       movsxd    r10,r10d
       shl       r10,20
       or        r9,r10
       mov       [rbp-40],rax
       lock cmpxchg [rdi],r9
       cmp       rax,[rbp-40]
       jne       short M05_L05
       mov       rdi,[r12+8]
       mov       [rbp-34],ecx
       cmp       ecx,[rdi+8]
       jae       near ptr M05_L11
       mov       rsi,[rdi+r8+10]
       mov       rdi,r15
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[r12+8]
       mov       edi,[rbp-34]
       cmp       edi,[rax+8]
       jae       near ptr M05_L11
       mov       rsi,[rbp-50]
       lea       rsi,[rax+rsi+10]
       xor       eax,eax
       mov       [rsi],rax
       add       r12,20
M05_L04:
       mov       rax,[r12]
       mov       [rbp-48],rax
       mov       [rsi+8],eax
       mov       rcx,rax
       sar       rcx,20
       inc       ecx
       movsxd    rcx,ecx
       shl       rcx,20
       mov       edx,edi
       or        rcx,rdx
       lock cmpxchg [r12],rcx
       cmp       rax,[rbp-48]
       jne       short M05_L04
       cmp       qword ptr [r15],0
       je        short M05_L07
       jmp       near ptr M05_L01
M05_L05:
       mov       rax,[rdi]
       mov       ecx,eax
       cmp       ecx,0FFFFFFFF
       jne       near ptr M05_L03
M05_L06:
       xor       edi,edi
       mov       [r15],rdi
M05_L07:
       inc       r14d
       mov       rdi,[rbx+8]
       cmp       [rdi+8],r14d
       jne       short M05_L08
       xor       r14d,r14d
M05_L08:
       inc       r13d
       jmp       near ptr M05_L00
M05_L09:
       call      qword ptr [7F36A1876268]
       int       3
M05_L10:
       xor       eax,eax
       mov       [r15],rax
       add       rsp,38
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M05_L11:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 439
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       cmp       qword ptr [rbp-10],0
       jne       short M06_L00
       add       rsp,30
       pop       rbp
       ret
M06_L00:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F36A12CDB90]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
M06_L01:
       add       rsp,30
       pop       rbp
       ret
       push      rax
       mov       [rbp-28],rdi
       mov       rax,[rbp-28]
       mov       [rbp-20],rax
       mov       rax,[rbp-18]
       cmp       qword ptr [rax],0
       jne       short M06_L02
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
M06_L02:
       lea       rax,[M06_L01]
       add       rsp,8
       ret
; Total bytes of code 114
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7F36A03E4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7F36A03DEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7F36A03EF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M07_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M07_L00
       mov       rsi,rax
       call      qword ptr [7F36A03DEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M07_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F36A03DEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F36A03DEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rdi
       mov       rdi,[rbx]
       call      qword ptr [7F36A12CDCF8]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       r15d,[rax+10]
       test      r15d,r15d
       je        short M09_L02
M09_L00:
       dec       r15d
       mov       eax,[rbx+18]
       test      eax,eax
       jl        short M09_L03
       and       eax,r15d
M09_L01:
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
M09_L02:
       mov       rdi,[rbx]
       call      qword ptr [7F36A0835728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       edi,1
       mov       r15d,edi
       lock xadd [rax],r15d
       inc       r15d
       je        short M09_L02
       mov       rdi,[rbx]
       call      qword ptr [7F36A12CDCF8]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       [rax+10],r15d
       jmp       short M09_L00
M09_L03:
       mov       rax,[rbx+8]
       mov       eax,[rax+8]
       mov       ecx,r15d
       imul      rcx,[rbx+10]
       shr       rcx,20
       inc       rcx
       imul      rax,rcx
       shr       rax,20
       jmp       short M09_L01
; Total bytes of code 134
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7F36A193C4B0]; PoolContextProbe+Policy.Destroy(Item)
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 49
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rax,[rdi+20]
       mov       ebx,[rax-28]
       cmp       ebx,0FFFFFFFF
       je        near ptr M11_L04
       mov       rdi,7F371EEA0D68
       mov       rax,7F371F819820
       call      rax
       add       rax,8
       add       rax,0FFFFFFFFFFFFFFF8
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M11_L01
       cmp       [rax],edi
       jle       short M11_L03
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M11_L03
M11_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M11_L01:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M11_L02
       movsxd    rdi,ecx
       add       rax,rdi
       jmp       short M11_L00
M11_L02:
       cmp       [rax+4],ecx
       jle       short M11_L03
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M11_L03
       mov       rax,[rdi]
       test      rax,rax
       je        short M11_L03
       jmp       short M11_L00
M11_L03:
       mov       edi,ebx
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7F36A1876238]
M11_L04:
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7F36A12CDD40]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 179
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-10]
       mov       rcx,rax
       test      cl,1
       jne       short M12_L00
       ret
M12_L00:
       jmp       qword ptr [7F36A0C2EA00]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 23
```
```assembly
; PoolContextProbe+Policy.Destroy(Item)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 24
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       rsi,rdi
       lea       rdi,[rbp-30]
       mov       [rbp-94],rdi
       mov       [rbp-9C],rsi
       xor       edx,edx
       mov       [rbp-8C],edx
       lea       rdi,[rbp-88]
       call      qword ptr [7F36A03DEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       edx,[rbp-8C]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7F36A03DEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,[rbp-30]
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 131
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbx
       sub       rsp,10
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rbx,rdi
       mov       rdi,rbx
       call      qword ptr [7F36A03F9718]; Precode of System.Runtime.CompilerServices.InitHelpers.InitClassSlow(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rbx+20]
       mov       rax,[rax-10]
       mov       [rsp+8],rax
       mov       rax,[rsp+8]
       and       rax,0FFFFFFFFFFFFFFFE
       xor       ecx,ecx
       mov       [rsp+8],rcx
       add       rsp,10
       pop       rbx
       ret
; Total bytes of code 59
```

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: C-baseline(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.4.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.4.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=10, LaunchCount=3, WarmupCount=5))

```assembly
; PoolContextProbe.SingleContext()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,48
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-48],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-40],xmm8
       mov       [rbp-30],rax
       mov       rdi,7F7495800AB0
       mov       rbx,[rdi]
       mov       rdi,7F7495800400
       mov       r15,[rdi]
       test      rbx,rbx
       je        near ptr M00_L04
M00_L00:
       mov       rdi,7F7495800AF0
       mov       r14,[rdi]
       test      r14,r14
       je        near ptr M00_L05
M00_L01:
       mov       rdi,7F7495800AF8
       mov       r13,[rdi]
       test      r13,r13
       je        near ptr M00_L06
M00_L02:
       mov       rax,[r15+38]
       test      rax,rax
       jne       near ptr M00_L07
       cmp       byte ptr [r15+48],0
       jne       near ptr M00_L08
       mov       r12,[r15+10]
       xor       edi,edi
       test      rdi,rdi
       cmove     rdi,r15
       mov       rdi,[rdi+20]
       mov       rax,7F7495800B00
       test      rdi,rdi
       cmove     rdi,[rax]
       mov       [rbp-50],rdi
       mov       rax,[r15+38]
       test      rax,rax
       jne       near ptr M00_L09
       mov       rdi,[rbp-50]
       mov       rcx,[r15+40]
M00_L03:
       mov       [rsp],r13
       xor       esi,esi
       mov       [rsp+8],rsi
       mov       [rsp+10],rsi
       mov       rsi,r12
       mov       rdx,rdi
       mov       r8,rbx
       mov       r9,r14
       mov       rdi,7F7C7E8DCB40
       call      qword ptr [7F7C7E4DE598]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       mov       [rbp-48],rax
       mov       [rbp-40],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-48]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       mov       rax,[rbp-38]
       mov       rdx,[rbp-30]
       add       rsp,48
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M00_L04:
       mov       rdi,offset MT_System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rsi,7F7495800AA8
       mov       rsi,[rsi]
       mov       rdi,rbx
       mov       rdx,offset PoolContextProbe+<>c.<SingleContext>b__5_0(Kevlar.KevlarContext)
       call      qword ptr [7F7C7DA46E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F7495800AB0
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L00
M00_L05:
       mov       rdi,offset MT_System.Action<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarProperties>
       call      CORINFO_HELP_NEWSFAST
       mov       r14,rax
       mov       rsi,7F7495800AE8
       mov       rsi,[rsi]
       mov       rdi,r14
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       call      qword ptr [7F7C7DA46E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F7495800AF0
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L01
M00_L06:
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r13,rax
       mov       rsi,7F7495800AE8
       mov       rsi,[rsi]
       mov       rdi,r13
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F7C7DA46E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F7495800AF8
       mov       rsi,r13
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L02
M00_L07:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       r8,r13
       mov       rdx,rbx
       mov       rcx,r14
       mov       rsi,7F7C7E8DB1D0
       xor       r9d,r9d
       cmp       [rdi],edi
       add       rsp,48
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F7C7E4DE340]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
M00_L08:
       call      qword ptr [7F7C7E4DE508]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M00_L09:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F7C7E4DE4F0]; Kevlar.Shield.get_Name()
       mov       rcx,rax
       mov       rdi,[rbp-50]
       jmp       near ptr M00_L03
; Total bytes of code 604
```
```assembly
; BenchmarkDotNet.Helpers.AwaitHelper.GetResult[[System.Int32, System.Private.CoreLib]](System.Threading.Tasks.ValueTask`1<Int32>)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp-48],rax
       mov       [rbp-40],rax
       mov       [rbp-38],rdi
       mov       [rbp-30],rsi
       mov       rbx,rdi
       mov       r15d,esi
       movsx     r14,word ptr [rbp-2C]
       test      rbx,rbx
       je        near ptr M01_L11
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<System.Int32>
       call      qword ptr [7F7C7DA46838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r13,rax
       mov       rax,r13
       test      rax,rax
       jne       near ptr M01_L05
       mov       rdi,offset MT_Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource
       cmp       [rbx],rdi
       je        short M01_L02
       mov       rdi,rbx
       mov       esi,r14d
       mov       r11,7F7C7CA60570
       call      qword ptr [r11]
M01_L00:
       test      eax,eax
       je        near ptr M01_L15
M01_L01:
       test      r13,r13
       jne       near ptr M01_L09
       mov       rdi,offset MT_Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource
       cmp       [rbx],rdi
       je        short M01_L06
       mov       rdi,rbx
       mov       esi,r14d
       mov       r11,7F7C7CA60578
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M01_L02:
       lea       rsi,[rbx+40]
       movsx     rdi,word ptr [rsi+28]
       cmp       r14d,edi
       jne       near ptr M01_L12
       cmp       qword ptr [rsi],0
       jne       near ptr M01_L13
M01_L03:
       xor       r12d,r12d
M01_L04:
       mov       eax,r12d
       jmp       short M01_L00
M01_L05:
       test      dword ptr [rax+34],1600000
       jne       short M01_L01
       jmp       near ptr M01_L15
M01_L06:
       mov       [rbp-50],rbx
       lea       rdi,[rbx+40]
       movsx     rsi,word ptr [rdi+28]
       cmp       r14d,esi
       jne       short M01_L07
       cmp       byte ptr [rdi+2A],0
       je        short M01_L07
       cmp       qword ptr [rdi+18],0
       jne       short M01_L07
       mov       r15,[rdi+20]
       jmp       short M01_L08
M01_L07:
       call      qword ptr [7F7C7EA86448]
       int       3
M01_L08:
       lea       r13,[rbx+40]
       inc       esi
       mov       [r13+28],si
       xor       edi,edi
       mov       [r13],rdi
       mov       [r13+8],rdi
       mov       [r13+10],rdi
       mov       [r13+18],rdi
       mov       [r13+20],rdi
       mov       byte ptr [r13+2A],0
       mov       rdi,[rbx+8]
       lea       rdi,[rdi+20]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M01_L11
M01_L09:
       mov       edi,[r13+34]
       and       edi,11000000
       cmp       edi,1000000
       jne       near ptr M01_L16
M01_L10:
       mov       r15d,[r13+38]
M01_L11:
       mov       eax,r15d
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M01_L12:
       call      qword ptr [7F7C7EA863D0]
       int       3
M01_L13:
       cmp       byte ptr [rsi+2A],0
       je        near ptr M01_L03
       cmp       qword ptr [rsi+18],0
       je        short M01_L14
       mov       rsi,[rsi+18]
       mov       rsi,[rsi+8]
       mov       rdi,offset MT_System.OperationCanceledException
       call      qword ptr [7F7C7DA46838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r12d,3
       mov       ecx,2
       test      rax,rax
       cmove     r12d,ecx
       jmp       near ptr M01_L04
M01_L14:
       mov       r12d,1
       jmp       near ptr M01_L04
M01_L15:
       mov       [rbp-48],rbx
       mov       [rbp-40],r15d
       mov       [rbp-3C],r14w
       call      qword ptr [7F7C7E9EFA50]
       mov       rdi,rax
       mov       rsi,[rbp-48]
       mov       rdx,[rbp-40]
       cmp       [rdi],edi
       call      qword ptr [7F7C7E9EFA20]
       jmp       near ptr M01_L01
M01_L16:
       mov       rdi,r13
       xor       esi,esi
       call      qword ptr [7F7C7EA86430]
       jmp       near ptr M01_L10
       push      rax
       mov       rsi,[rbp-50]
       lea       r13,[rsi+40]
       inc       word ptr [r13+28]
       xor       edi,edi
       mov       [r13],rdi
       mov       [r13+8],rdi
       mov       [r13+10],rdi
       mov       [r13+18],rdi
       mov       [r13+20],rdi
       mov       byte ptr [r13+2A],0
       mov       rdi,[rsi+8]
       lea       rdi,[rdi+20]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,8
       ret
; Total bytes of code 585
```
```assembly
; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,278
       vzeroupper
       lea       rbp,[rsp+2A0]
       xor       eax,eax
       mov       [rbp-218],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-210],xmm8
       vmovdqa   xmmword ptr [rbp-200],xmm8
       mov       rax,0FFFFFFFFFFFFFE50
M02_L00:
       vmovdqa   xmmword ptr [rbp+rax-40],xmm8
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       add       rax,30
       jne       short M02_L00
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-220],r8
       mov       r13,rsi
       mov       r14,rdx
       mov       rbx,rcx
       mov       r15,r9
       mov       r12,[rbp+20]
       mov       rax,7F7495800BA0
       mov       rax,[rax]
       mov       rax,[rax+8]
       cmp       qword ptr [rax+8],0
       jne       near ptr M02_L24
       xor       edi,edi
M02_L01:
       mov       [rbp-40],rdi
       test      r12,r12
       jne       near ptr M02_L25
M02_L02:
       mov       rdi,7F74958013C0
       mov       rax,[rdi]
       mov       [rbp-280],rax
       mov       rcx,rax
       mov       [rbp-240],rcx
       cmp       dword ptr [rcx+1C],0
       jne       near ptr M02_L46
M02_L03:
       mov       rcx,[rbp-240]
       mov       rdx,[rcx+10]
       mov       [rbp-250],rdx
       xor       esi,esi
       mov       [rbp-98],esi
       test      rdx,rdx
       je        near ptr M02_L47
       mov       rdi,7F7CFC0A0D68
       mov       r8,7F7CFCA0E820
       call      r8
       add       rax,48
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M02_L54
M02_L04:
       dec       eax
       mov       rcx,[rbp-250]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M02_L55
       and       r8d,eax
M02_L05:
       mov       eax,r8d
       xor       r8d,r8d
       mov       [rbp-0AC],r8d
       mov       rdi,[rcx+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M02_L58
M02_L06:
       mov       rdi,[rcx+8]
       cmp       eax,[rdi+8]
       jae       near ptr M02_L89
       mov       [rbp-0A8],eax
       mov       edx,eax
       mov       r9,[rdi+rdx*8+10]
       mov       [rbp-260],r9
       mov       r10,[r9+10]
       mov       [rbp-268],r10
       test      r10,r10
       je        near ptr M02_L56
       lea       rdi,[r9+10]
       test      rdi,rdi
       je        near ptr M02_L82
       mov       rdx,r10
       xor       esi,esi
       call      00007F7CFBE74060
       mov       rcx,[rbp-268]
       cmp       rax,rcx
       mov       r9,[rbp-260]
       jne       near ptr M02_L56
       mov       r10,rcx
       mov       [rbp-0A0],r10
M02_L07:
       mov       rax,[rbp-0A0]
       cmp       qword ptr [rbp-0A0],0
       je        near ptr M02_L59
M02_L08:
       xor       edi,edi
       mov       [rbp-0A0],rdi
       mov       rcx,[rbp-240]
       cmp       dword ptr [rcx+1C],0
       jne       near ptr M02_L61
       mov       rdx,rax
M02_L09:
       mov       [rbp-238],rdx
       lea       rdi,[rdx+68]
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       xor       edi,edi
       mov       r12,[rbp-238]
       mov       [r12+60],edi
       lea       rdi,[r12+38]
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r12+30]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       mov       rsi,0FFFFFFFF00000000
       mov       [r12+58],rsi
       xor       esi,esi
       mov       [r12+40],rsi
       mov       [rbp-228],r12
       mov       rdx,[r12+8]
       mov       rsi,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       cmp       [r15+18],rsi
       je        short M02_L10
       mov       rsi,[rbp-220]
       mov       rdi,[r15+8]
       call      qword ptr [r15+18]
       nop
M02_L10:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M02_L22
M02_L11:
       lea       rdi,[rbp-60]
       mov       rdx,r13
       mov       rcx,[rbp-220]
       mov       r8,[rbp+10]
       mov       r9,r12
       call      qword ptr [7F7C7E4DE670]; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       rbx,[rbp-60]
       test      rbx,rbx
       jne       near ptr M02_L62
       mov       r14,[rbp-50]
       mov       r15d,[rbp-48]
M02_L12:
       test      r14,r14
       sete      bl
       movzx     ebx,bl
       mov       r13,[r12+30]
       cmp       qword ptr [rbp-40],0
       jne       near ptr M02_L67
M02_L13:
       mov       rsi,[r12+30]
       mov       rdi,7F7495800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M02_L68
M02_L14:
       cmp       byte ptr [r12+64],0
       jne       near ptr M02_L69
       mov       rbx,[r12+8]
M02_L15:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rax,[rsi+28]
       test      rax,rax
       je        near ptr M02_L23
       mov       rdi,rax
M02_L16:
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-220]
       mov       rcx,rbx
       call      qword ptr [7F7C7E4DE760]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rbx,[rbp-280]
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M02_L70
       mov       rdi,rbx
       mov       rsi,r12
       call      qword ptr [7F7C7E9E72B8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       je        near ptr M02_L71
       mov       r12,[rbx+10]
       test      r12,r12
       je        near ptr M02_L77
       mov       rdi,7F7CFC0A0D68
       mov       rax,7F7CFCA0E820
       call      rax
       add       rax,48
       mov       r13d,[rax+10]
       test      r13d,r13d
       je        near ptr M02_L72
M02_L17:
       dec       r13d
       mov       eax,[r12+18]
       test      eax,eax
       jl        near ptr M02_L73
       and       r13d,eax
M02_L18:
       xor       eax,eax
       mov       [rbp-1DC],eax
       mov       rdi,[r12+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M02_L76
M02_L19:
       mov       rdi,[r12+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M02_L89
       mov       esi,r13d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-278],rcx
       cmp       [rcx],cl
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M02_L82
       mov       rsi,[rbp-228]
       xor       edx,edx
       call      00007F7CFBE74060
       test      rax,rax
       jne       near ptr M02_L74
M02_L20:
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M02_L84
M02_L21:
       test      r14,r14
       jne       near ptr M02_L85
       xor       eax,eax
       mov       edx,r15d
       mov       rdi,1000000000000
       or        rdx,rdi
       add       rsp,278
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L22:
       mov       rsi,7F7C7E8E36D8
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M02_L11
M02_L23:
       mov       rsi,7F7C7E8E3AB0
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M02_L16
M02_L24:
       call      00007F7C7DA38AE0
       mov       rdi,rax
       jmp       near ptr M02_L01
M02_L25:
       cmp       dword ptr [r12+20],0
       je        near ptr M02_L02
       mov       rsi,rbx
       xor       edx,edx
       call      qword ptr [7F7C7E4DE868]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       cmp       qword ptr [rbp+18],0
       je        near ptr M02_L45
       mov       rdi,r12
       mov       rcx,rbx
       mov       rdx,r14
       xor       esi,esi
       call      qword ptr [7F7C7E4DE880]; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       mov       rbx,rax
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       r15,[rsi+28]
       test      r15,r15
       je        short M02_L26
       jmp       short M02_L27
M02_L26:
       mov       rsi,7F7C7E8E3AB0
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r15,rax
M02_L27:
       mov       rdi,rbx
       cmp       [rdi],edi
       call      qword ptr [7F7C7E4DE898]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       rcx,rax
       mov       rdi,r15
       mov       rdx,[rbp-220]
       mov       rsi,[rbp+18]
       call      qword ptr [7F7C7E4DE760]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,7F74958013C0
       mov       rdi,[rdi]
       mov       r15,rdi
       cmp       dword ptr [r15+1C],0
       je        short M02_L28
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F7C7CA60590
       call      qword ptr [r11]
       jmp       near ptr M02_L45
M02_L28:
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7F7C7E9E72B8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       jne       short M02_L29
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F7C7CA60598
       call      qword ptr [r11]
       jmp       near ptr M02_L45
M02_L29:
       mov       r14,[r15+10]
       test      r14,r14
       je        near ptr M02_L39
       mov       edi,48
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M02_L31
M02_L30:
       mov       rdi,7F7C7CA5B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M02_L30
       mov       edi,48
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M02_L31:
       dec       r13d
       cmp       dword ptr [r14+18],0
       jl        short M02_L32
       and       r13d,[r14+18]
       jmp       short M02_L33
M02_L32:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r14+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
M02_L33:
       xor       eax,eax
       jmp       short M02_L36
M02_L34:
       mov       rdi,[r14+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M02_L89
       mov       esi,r13d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-230],rcx
       cmp       [rcx],cl
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M02_L82
       mov       rsi,rbx
       xor       edx,edx
       call      00007F7CFBE74060
       test      rax,rax
       je        short M02_L37
       mov       rdx,rbx
       mov       rsi,[rbp-230]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F7C7E4DDF38]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M02_L37
       inc       r13d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r13d
       jne       short M02_L35
       xor       r13d,r13d
M02_L35:
       mov       eax,[rbp-94]
       inc       eax
M02_L36:
       mov       rdi,[r14+8]
       mov       [rbp-94],eax
       cmp       [rdi+8],eax
       jg        short M02_L34
       jmp       short M02_L38
M02_L37:
       cmp       dword ptr [r15+1C],0
       je        near ptr M02_L45
       jmp       near ptr M02_L44
M02_L38:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F7C7CA605A0
       call      qword ptr [r11]
       jmp       short M02_L37
M02_L39:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r14d,[rax+10]
       test      r14d,r14d
       jne       short M02_L41
M02_L40:
       mov       rdi,7F7C7CA5B1F8
       mov       eax,1
       mov       r14d,eax
       lock xadd [rdi],r14d
       inc       r14d
       je        short M02_L40
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r14d
M02_L41:
       dec       r14d
       imul      r14d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M02_L42
       mov       r13d,r14d
       mov       r14d,[r15+20]
       imul      r14,r13
       shr       r14,20
       jmp       short M02_L43
M02_L42:
       and       r14d,[r15+18]
M02_L43:
       mov       rdi,[r15+8]
       lea       esi,[r14*8]
       cmp       esi,[rdi+8]
       jae       near ptr M02_L89
       lea       esi,[r14*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       je        near ptr M02_L82
       mov       rsi,rbx
       call      00007F7CFBE74040
       test      rax,rax
       je        near ptr M02_L37
       mov       rdi,r15
       mov       rsi,rbx
       mov       rdx,rax
       mov       ecx,r14d
       call      qword ptr [7F7C7E9E74F8]
       jmp       near ptr M02_L37
M02_L44:
       mov       rdi,r15
       call      qword ptr [7F7C7E9E7528]
M02_L45:
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rdi,rbx
       call      qword ptr [7F7C7EA86E80]
       lea       rdi,[rbx+70]
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,rbx
       call      qword ptr [7F7C7E4DE8E0]
       mov       rdi,rax
       mov       esi,edx
       call      qword ptr [7F7C7E4DE7F0]
       mov       [rbp-208],rax
       mov       [rbp-200],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-208]
       vmovdqu   xmmword ptr [rbp-90],xmm0
       mov       rax,[rbp-90]
       mov       rdx,[rbp-88]
       add       rsp,278
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L46:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F7C7E9E67C0]
       jmp       near ptr M02_L03
M02_L47:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M02_L49
M02_L48:
       mov       rax,7F7C7CA5B1F8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-0A4],eax
       test      eax,eax
       je        short M02_L48
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rbp-0A4]
       mov       [rax+10],edi
       mov       eax,edi
M02_L49:
       dec       eax
       imul      edi,eax,9E3779B9
       mov       rax,[rbp-240]
       cmp       dword ptr [rax+18],0
       jge       short M02_L50
       mov       esi,edi
       mov       edx,[rax+20]
       imul      rsi,rdx
       shr       rsi,20
       jmp       short M02_L51
M02_L50:
       and       edi,[rax+18]
       mov       esi,edi
M02_L51:
       mov       ecx,esi
       mov       rdi,[rax+8]
       lea       edx,[rcx*8]
       cmp       edx,[rdi+8]
       jae       near ptr M02_L89
       mov       [rbp-98],ecx
       lea       edx,[rcx*8]
       lea       rdi,[rdi+rdx*8+10]
       mov       r8,[rdi]
       mov       [rbp-258],r8
       test      r8,r8
       je        short M02_L52
       mov       rdx,r8
       xor       esi,esi
       call      00007F7CFBE74060
       mov       rdi,[rbp-258]
       cmp       rax,rdi
       je        short M02_L53
M02_L52:
       xor       edi,edi
M02_L53:
       mov       [rbp-0A0],rdi
       jmp       near ptr M02_L07
M02_L54:
       mov       rax,7F7C7CA5B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-0B0],eax
       test      eax,eax
       je        short M02_L54
       mov       rdi,7F7CFC0A0D68
       mov       rcx,7F7CFCA0E820
       call      rcx
       add       rax,48
       mov       ecx,[rbp-0B0]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M02_L04
M02_L55:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M02_L05
M02_L56:
       lea       rdx,[rbp-0A0]
       mov       rsi,r9
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F7C7E4DDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       near ptr M02_L07
       mov       eax,[rbp-0A8]
       inc       eax
       mov       edi,eax
       mov       rax,[rbp-250]
       mov       rcx,[rax+8]
       cmp       [rcx+8],edi
       jne       short M02_L57
       xor       edi,edi
M02_L57:
       mov       r8d,[rbp-0AC]
       inc       r8d
       mov       rcx,[rax+8]
       cmp       [rcx+8],r8d
       mov       [rbp-0AC],r8d
       mov       eax,edi
       mov       rcx,[rbp-250]
       jg        near ptr M02_L06
M02_L58:
       xor       edi,edi
       mov       [rbp-0A0],rdi
       jmp       near ptr M02_L07
M02_L59:
       cmp       qword ptr [rbp-250],0
       je        short M02_L60
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-270],rax
       mov       rdi,rax
       call      qword ptr [7F7C7E9E6868]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-270]
       jmp       near ptr M02_L08
M02_L60:
       mov       rdi,[rbp-240]
       mov       esi,[rbp-98]
       call      qword ptr [7F7C7E9E6820]
       jmp       near ptr M02_L08
M02_L61:
       mov       [rbp-248],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-240]
       mov       dil,[rdi+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-248]
       mov       r11,7F7C7CA605A8
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F7C7E9E67C0]
       mov       rdx,rax
       jmp       near ptr M02_L09
M02_L62:
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F7C7DA46838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       test      rax,rax
       je        short M02_L63
       mov       rdi,rax
       call      qword ptr [7F7C7E9E7138]
       jmp       short M02_L64
M02_L63:
       mov       rdi,rbx
       movsx     rsi,word ptr [rbp-58]
       mov       r11,7F7C7CA605B0
       call      qword ptr [r11]
       cmp       eax,1
       sete      al
       movzx     eax,al
M02_L64:
       test      eax,eax
       je        near ptr M02_L86
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F7C7DA46838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r15,rax
       test      r15,r15
       je        short M02_L66
       mov       edi,[r15+34]
       and       edi,11000000
       cmp       edi,1000000
       je        short M02_L65
       mov       rdi,r15
       xor       esi,esi
       call      qword ptr [7F7C7EA86430]
M02_L65:
       mov       r14,[r15+38]
       mov       r15d,[r15+40]
       jmp       near ptr M02_L12
M02_L66:
       mov       rdi,rbx
       movsx     rsi,word ptr [rbp-58]
       mov       r11,7F7C7CA605B8
       call      qword ptr [r11]
       mov       r14,rax
       mov       r15d,edx
       jmp       near ptr M02_L12
M02_L67:
       mov       rdi,7F7495800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F7C7E4DE9B8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M02_L13
       lea       rdi,[rbp-140]
       mov       rsi,r13
       call      qword ptr [7F7C7E9E71F8]
       mov       rdx,7F7C7860B6A8
       mov       rdi,7F7C7860B680
       test      ebx,ebx
       cmove     rdx,rdi
       lea       rdi,[rbp-140]
       mov       rsi,7F7C7860B638
       call      qword ptr [7F7C7E9E7210]
       call      00007F7C7DA38AE0
       mov       rsi,rax
       mov       rdi,[rbp-40]
       call      qword ptr [7F7C7EA868E0]
       mov       [rbp-148],rax
       lea       rdi,[rbp-148]
       call      qword ptr [7F7C7E9E7240]
       mov       rdi,7F7495800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-140]
       mov       rdx,r12
       call      qword ptr [7F7C7E9E7258]
       jmp       near ptr M02_L13
M02_L68:
       lea       rdi,[rbp-1D8]
       call      qword ptr [7F7C7E9E71F8]
       mov       rdx,7F7C7860B6A8
       mov       rdi,7F7C7860B680
       test      ebx,ebx
       cmove     rdx,rdi
       lea       rdi,[rbp-1D8]
       mov       rsi,7F7C7860B638
       call      qword ptr [7F7C7E9E7210]
       mov       rdi,7F7495800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-1D8]
       mov       rcx,r12
       mov       esi,1
       call      qword ptr [7F7C7E9E7270]
       jmp       near ptr M02_L14
M02_L69:
       mov       rbx,[r12+10]
       jmp       near ptr M02_L15
M02_L70:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F7C7CA605C0
       call      qword ptr [r11]
       jmp       near ptr M02_L21
M02_L71:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F7C7CA605C8
       call      qword ptr [r11]
       jmp       near ptr M02_L21
M02_L72:
       mov       rdi,7F7C7CA5B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M02_L72
       mov       rdi,7F7CFC0A0D68
       mov       rax,7F7CFCA0E820
       call      rax
       add       rax,48
       mov       [rax+10],r13d
       jmp       near ptr M02_L17
M02_L73:
       mov       rdi,[r12+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r12+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
       jmp       near ptr M02_L18
M02_L74:
       mov       rdx,[rbp-228]
       mov       rsi,[rbp-278]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F7C7E4DDF38]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       near ptr M02_L20
       inc       r13d
       mov       rdi,[r12+8]
       cmp       [rdi+8],r13d
       jne       short M02_L75
       xor       r13d,r13d
M02_L75:
       mov       eax,[rbp-1DC]
       inc       eax
       mov       rdi,[r12+8]
       cmp       [rdi+8],eax
       mov       [rbp-1DC],eax
       jg        near ptr M02_L19
M02_L76:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-228]
       mov       r11,7F7C7CA605D0
       call      qword ptr [r11]
       jmp       near ptr M02_L20
M02_L77:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M02_L79
M02_L78:
       mov       rdi,7F7C7CA5B1F8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M02_L78
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M02_L79:
       dec       r13d
       imul      r13d,9E3779B9
       cmp       dword ptr [rbx+18],0
       jge       short M02_L80
       mov       r12d,r13d
       mov       r13d,[rbx+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M02_L81
M02_L80:
       and       r13d,[rbx+18]
M02_L81:
       mov       rdi,[rbx+8]
       lea       esi,[r13*8]
       cmp       esi,[rdi+8]
       jae       near ptr M02_L89
       lea       esi,[r13*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M02_L83
M02_L82:
       call      qword ptr [7F7C7EA86340]
       int       3
M02_L83:
       mov       rsi,[rbp-228]
       call      00007F7CFBE74040
       test      rax,rax
       je        near ptr M02_L20
       mov       rdi,rbx
       mov       rsi,[rbp-228]
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7F7C7E9E74F8]
       jmp       near ptr M02_L20
M02_L84:
       mov       rdi,rbx
       call      qword ptr [7F7C7E9E7528]
       jmp       near ptr M02_L21
M02_L85:
       mov       rdi,r14
       mov       esi,r15d
       call      qword ptr [7F7C7E4DE7F0]
       mov       [rbp-218],rax
       mov       [rbp-210],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-218]
       vmovdqu   xmmword ptr [rbp-80],xmm0
       mov       rax,[rbp-80]
       mov       rdx,[rbp-78]
       add       rsp,278
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L86:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rax,[rsi+20]
       test      rax,rax
       je        short M02_L87
       mov       rdi,rax
       jmp       short M02_L88
M02_L87:
       mov       rsi,7F7C7E8E3870
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M02_L88:
       mov       [rbp-1F8],rdi
       lea       rdi,[rsp]
       lea       rsi,[rbp-60]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,[rbp-1F8]
       mov       rsi,r12
       mov       rdx,[rbp-220]
       mov       rcx,[rbp+18]
       mov       r8,[rbp-40]
       call      qword ptr [7F7C7E4DE718]
       mov       [rbp-1F0],rax
       mov       [rbp-1E8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-1F0]
       vmovdqu   xmmword ptr [rbp-70],xmm0
       mov       rax,[rbp-70]
       mov       rdx,[rbp-68]
       add       rsp,278
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L89:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
       sub       rsp,28
       vzeroupper
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-228]
       xor       edx,edx
       call      qword ptr [7F7C7E4DE958]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       r13,[rsi+28]
       test      r13,r13
       je        short M02_L90
       jmp       short M02_L91
M02_L90:
       mov       rsi,7F7C7E8E3AB0
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r13,rax
M02_L91:
       mov       rdi,[rbp-228]
       cmp       [rdi],edi
       call      qword ptr [7F7C7E4DE898]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       rcx,rax
       mov       rdi,r13
       mov       rdx,[rbp-220]
       mov       rsi,[rbp+18]
       call      qword ptr [7F7C7E4DE760]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-228]
       call      qword ptr [7F7C7E4DE8B0]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 3969
```
```assembly
; PoolContextProbe+<>c.<SingleContext>b__5_0(Kevlar.KevlarContext)
       xor       eax,eax
       mov       rdx,100000000002A
       ret
; Total bytes of code 13
```
```assembly
; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       push      r15
       push      r14
       push      rbx
       mov       rbx,rdi
       mov       r15,rsi
       mov       r14,rdx
       test      r15,r15
       je        short M04_L00
       mov       rdi,7F7C7EAF2584
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdi,[rbx+8]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       [rbx+18],r14
       pop       rbx
       pop       r14
       pop       r15
       ret
M04_L00:
       mov       rdi,7F7C7EAF2580
       call      CORINFO_HELP_COUNTPROFILE32
       call      qword ptr [7F7C7EA8DE48]
       int       3
; Total bytes of code 78
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       ret
; Total bytes of code 1
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       rcx,rsi
       mov       rsi,rdx
       mov       rax,offset PoolContextProbe+<>c.<SingleContext>b__5_0(Kevlar.KevlarContext)
       cmp       [rcx+18],rax
       jne       short M06_L00
       xor       eax,eax
       mov       rdx,100000000002A
       ret
M06_L00:
       mov       rdi,[rcx+8]
       jmp       qword ptr [rcx+18]
; Total bytes of code 43
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
M07_L00:
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,58
       lea       rbp,[rsp+80]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       mov       [rbp-30],rsi
       mov       rbx,rsi
       mov       r13,rdx
       mov       r15,rcx
       mov       r14,r8
       mov       r12,r9
       test      r15,r15
       je        near ptr M07_L06
       test      r14,r14
       je        near ptr M07_L07
       mov       rax,[rdi+38]
       test      rax,rax
       jne       near ptr M07_L08
       cmp       byte ptr [rdi+48],0
       jne       near ptr M07_L09
       mov       rax,[rdi+10]
       mov       [rbp-58],rax
       xor       ecx,ecx
       test      rcx,rcx
       cmove     rcx,rdi
       mov       rcx,[rcx+20]
       mov       rdx,7F7495800B00
       test      rcx,rcx
       cmove     rcx,[rdx]
       mov       [rbp-60],rcx
       mov       rdx,[rdi+38]
       test      rdx,rdx
       jne       near ptr M07_L10
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rdi+40]
M07_L01:
       mov       rdi,[rbx+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        short M07_L04
M07_L02:
       mov       rdx,[rdi+18]
       mov       rdx,[rdx+18]
       test      rdx,rdx
       je        near ptr M07_L05
       mov       rdi,rdx
       mov       [rbp-68],rsi
M07_L03:
       mov       [rsp],r14
       xor       edx,edx
       mov       [rsp+8],rdx
       mov       [rsp+10],r12
       mov       rsi,rax
       mov       rdx,rcx
       mov       rcx,[rbp-68]
       mov       r8,r13
       mov       r9,r15
       call      qword ptr [7F7C7E4DE598]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       mov       [rbp-50],rax
       mov       [rbp-48],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-50]
       vmovdqu   xmmword ptr [rbp-40],xmm0
       mov       rax,[rbp-40]
       mov       rdx,[rbp-38]
       add       rsp,58
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M07_L04:
       mov       [rbp-60],rcx
       mov       [rbp-68],rsi
       mov       rdi,rbx
       mov       rsi,7F7C7E8E2E88
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rbp-68]
       jmp       near ptr M07_L02
M07_L05:
       mov       [rbp-60],rcx
       mov       [rbp-68],rsi
       mov       rsi,7F7C7E8E3240
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       jmp       near ptr M07_L03
M07_L06:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,92C
       mov       rsi,7F7C7E50D998
       call      qword ptr [7F7C7DA4EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F7C7E12E2B0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M07_L07:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,902
       mov       rsi,7F7C7E50D998
       call      qword ptr [7F7C7DA4EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F7C7E12E2B0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M07_L08:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       rsi,rbx
       mov       rdx,r13
       mov       rcx,r15
       mov       r8,r14
       mov       r9,r12
       cmp       [rdi],edi
       add       rsp,58
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F7C7E4DE340]
M07_L09:
       call      qword ptr [7F7C7E4DE508]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M07_L10:
       mov       rdi,[rdx+8]
       call      qword ptr [rdx+18]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F7C7E4DE4F0]; Kevlar.Shield.get_Name()
       mov       [rbp-68],rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rbp-68]
       jmp       near ptr M07_L01
; Total bytes of code 583
```
```assembly
; Kevlar.Shield.get_Name()
       push      rbp
       mov       rbp,rsp
M08_L00:
       mov       rax,[rdi+38]
       test      rax,rax
       jne       short M08_L01
       mov       rax,[rdi+40]
       pop       rbp
       ret
M08_L01:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       jmp       short M08_L00
; Total bytes of code 31
```
```assembly
; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       push      rbp
       mov       rbp,rsp
       test      rsi,rsi
       je        short M09_L02
       mov       rax,[rsi]
       cmp       rax,rdi
       je        short M09_L02
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
M09_L00:
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       jne       short M09_L03
M09_L01:
       xor       esi,esi
M09_L02:
       mov       rax,rsi
       pop       rbp
       ret
M09_L03:
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       jmp       short M09_L00
; Total bytes of code 91
```
```assembly
; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,128
       lea       rbp,[rsp+150]
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFF10
M10_L00:
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       add       rax,30
       jne       short M10_L00
       mov       [rbp-30],rsi
       mov       [rbp-128],r8
       mov       rbx,rdi
       mov       r15,rsi
       mov       r13,rdx
       mov       r12,rcx
       mov       r14,r9
       mov       rdi,[r15+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M10_L19
M10_L01:
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rax+8]
       test      rax,rax
       je        near ptr M10_L24
M10_L02:
       mov       [rbp-50],r13
       mov       [rbp-48],rax
       mov       [rbp-40],r12
       mov       r13,[rbp-128]
       mov       [rbp-38],r13
       mov       rdi,[r15+18]
       mov       rdx,[rdi+28]
       test      rdx,rdx
       je        near ptr M10_L20
M10_L03:
       mov       rax,[rbp-48]
       test      rax,rax
       je        near ptr M10_L31
       cmp       qword ptr [rbp-50],0
       jne       near ptr M10_L36
       mov       rdi,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       cmp       [rax+18],rdi
       jne       near ptr M10_L35
       mov       rdi,[rax+8]
       mov       r15,[rbp-40]
       mov       r13,[rbp-38]
       mov       rdi,[rdi]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M10_L21
M10_L04:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0B0],xmm0
       vmovdqu   xmmword ptr [rbp-0A8],xmm0
       mov       [rbp-98],r15
       mov       [rbp-90],r13
       mov       [rbp-0C0],r14
       mov       dword ptr [rbp-0B8],0FFFFFFFF
       mov       rdi,[rsi+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M10_L22
M10_L05:
       mov       rsi,[rdi+18]
       mov       r14,[rsi+10]
       test      r14,r14
       je        near ptr M10_L23
M10_L06:
       mov       rdi,7F7CFC0A0D68
       mov       rax,7F7CFCA0E820
       call      rax
       cmp       dword ptr [rax],4
       jle       near ptr M10_L32
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        near ptr M10_L32
M10_L07:
       mov       r15,[rax+10]
       test      r15,r15
       jne       short M10_L08
       call      qword ptr [7F7C7E12C3F0]; System.Threading.Thread.InitializeCurrentThread()
       mov       r15,rax
M10_L08:
       mov       [rbp-138],r15
       mov       rsi,[r15+8]
       mov       [rbp-140],rsi
       mov       rsi,[r15+10]
       mov       [rbp-148],rsi
       mov       rdi,[r14+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M10_L10
M10_L09:
       lea       rdi,[rbp-0C0]
       call      rax
       jmp       short M10_L11
M10_L10:
       mov       rdi,r14
       mov       rsi,7F7C7E9D8060
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M10_L09
M10_L11:
       mov       rsi,[rbp-148]
       cmp       rsi,[r15+10]
       je        short M10_L12
       lea       rdi,[r15+10]
       call      CORINFO_HELP_ASSIGN_REF
M10_L12:
       mov       rdi,[r15+8]
       mov       r14,rdi
       mov       rsi,[rbp-140]
       cmp       rsi,r14
       je        short M10_L14
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      r14,r14
       je        short M10_L13
       cmp       qword ptr [r14+10],0
       jne       near ptr M10_L18
M10_L13:
       cmp       qword ptr [rbp-140],0
       jne       near ptr M10_L17
M10_L14:
       mov       rdi,[rbp-0B0]
       mov       rax,7F74958013E8
       cmp       rdi,[rax]
       jne       near ptr M10_L33
       vmovdqu   xmm0,xmmword ptr [rbp-0A8]
       vmovdqu   xmmword ptr [rbp-110],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-120]
       vmovdqu   ymmword ptr [rbp-0E0],ymm0
       xor       r15d,r15d
M10_L15:
       vmovdqu   ymm0,ymmword ptr [rbp-0E0]
       vmovdqu   ymmword ptr [rbp-78],ymm0
       xor       r14d,r14d
       mov       r13d,1
M10_L16:
       mov       [rbp-78],r15
       vmovdqu   ymm0,ymmword ptr [rbp-78]
       vmovdqu   ymmword ptr [rbx],ymm0
       mov       [rbx+8],r14w
       mov       [rbx+0A],r13b
       mov       rax,rbx
       vzeroupper
       add       rsp,128
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M10_L17:
       mov       rsi,[rbp-140]
       cmp       qword ptr [rsi+10],0
       je        near ptr M10_L14
M10_L18:
       mov       rdi,r14
       mov       rsi,[rbp-140]
       call      qword ptr [7F7C7EA86670]
       jmp       near ptr M10_L14
M10_L19:
       mov       rdi,r15
       mov       rsi,7F7C7E9D6718
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M10_L01
M10_L20:
       mov       rdi,r15
       mov       rsi,7F7C7E9D6830
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdx,rax
       jmp       near ptr M10_L03
M10_L21:
       mov       rsi,7F7C7E9D7000
       call      qword ptr [7F7C7DA4F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M10_L04
M10_L22:
       mov       rdi,rsi
       mov       rsi,7F7C7E9D7C78
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M10_L05
M10_L23:
       mov       rsi,7F7C7E9D7ED8
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r14,rax
       jmp       near ptr M10_L06
M10_L24:
       mov       rdi,[r15+18]
       mov       rax,[rdi+18]
       test      rax,rax
       je        short M10_L25
       mov       [rbp-58],rax
       jmp       short M10_L26
M10_L25:
       mov       rdi,r15
       mov       rsi,7F7C7E9D6718
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-58],rax
M10_L26:
       mov       rdi,[r15+18]
       mov       rdi,[rdi+30]
       test      rdi,rdi
       je        short M10_L27
       jmp       short M10_L28
M10_L27:
       mov       rdi,r15
       mov       rsi,7F7C7E9D6A10
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M10_L28:
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-130],rax
       mov       rdi,[rbp-58]
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rax]
       mov       rdi,[rbp-130]
       mov       rdx,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       call      qword ptr [7F7C7DA46E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,[r15+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        short M10_L29
       jmp       short M10_L30
M10_L29:
       mov       rdi,r15
       mov       rsi,7F7C7E9D6718
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M10_L30:
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       lea       rdi,[rax+8]
       mov       rsi,[rbp-130]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-130]
       jmp       near ptr M10_L02
M10_L31:
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       mov       rsi,7F7C7860B5D8
       call      qword ptr [7F7C7E125608]
       mov       rdi,r15
       call      qword ptr [7F7C7E4DE8E0]
       xor       r15d,r15d
       xor       r14d,r14d
       mov       r13d,1
       mov       [rbp-68],rax
       mov       [rbp-60],edx
       jmp       near ptr M10_L16
M10_L32:
       mov       edi,4
       call      qword ptr [7F7C7EA86478]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       near ptr M10_L07
M10_L33:
       mov       r15,[rbp-0B0]
       test      r15,r15
       jne       short M10_L34
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       call      qword ptr [7F7C7EA86688]
       mov       [rbp-0B0],r15
M10_L34:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0F0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-100]
       vmovdqu   ymmword ptr [rbp-0E0],ymm0
       jmp       near ptr M10_L15
M10_L35:
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-38]
       lea       rsi,[rbp-78]
       mov       r8,r14
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       jmp       short M10_L37
M10_L36:
       lea       rdi,[rbp-50]
       lea       rsi,[rbp-78]
       mov       rcx,[rbp-50]
       mov       r8,r14
       call      qword ptr [7F7C7E9E6A30]
M10_L37:
       mov       r15,[rbp-78]
       movsx     r14,word ptr [rbp-70]
       movzx     r13d,byte ptr [rbp-6E]
       jmp       near ptr M10_L16
       push      rax
       mov       rsi,[rbp-148]
       mov       rax,[rbp-138]
       cmp       rsi,[rax+10]
       je        short M10_L38
       lea       rdi,[rax+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-138]
M10_L38:
       mov       rbx,[rax+8]
       mov       rsi,[rbp-140]
       cmp       rsi,rbx
       je        short M10_L41
       lea       rdi,[rax+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      rbx,rbx
       je        short M10_L39
       cmp       qword ptr [rbx+10],0
       jne       short M10_L40
M10_L39:
       cmp       qword ptr [rbp-140],0
       je        short M10_L41
       mov       rsi,[rbp-140]
       cmp       qword ptr [rsi+10],0
       je        short M10_L41
M10_L40:
       mov       rdi,rbx
       mov       rsi,[rbp-140]
       call      qword ptr [7F7C7EA86670]
M10_L41:
       nop
       vzeroupper
       add       rsp,8
       ret
; Total bytes of code 1394
```
```assembly
; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       push      rbp
       mov       rbp,rsp
       mov       rax,rsi
       test      rax,rax
       je        short M11_L00
       mov       rsi,rdx
       mov       rdx,rcx
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       nop
M11_L00:
       pop       rbp
       ret
       push      rax
       lea       rax,[M11_L00]
       add       rsp,8
       ret
; Total bytes of code 41
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-38],rax
       mov       [rbp-50],rax
       mov       [rbp-30],rdi
       mov       [rbp-68],rdi
       mov       [rbp-70],rsi
       cmp       [rdi],dil
       xor       eax,eax
       mov       [rsi+68],rax
       mov       [rsi+60],eax
       mov       [rsi+30],rax
       mov       rax,0FFFFFFFF00000000
       mov       [rsi+58],rax
       xor       eax,eax
       mov       [rsi+40],rax
       mov       [rsi+48],rax
       mov       [rsi+50],rax
       mov       rax,[rsi+28]
       test      rax,rax
       jne       near ptr M12_L07
M12_L00:
       mov       rax,7F7495800B00
       mov       rsi,[rax]
       mov       rbx,[rbp-70]
       lea       rdi,[rbx+38]
       call      CORINFO_HELP_ASSIGN_REF
       mov       r15,[rbx+8]
       xor       edi,edi
       mov       [r15+20],rdi
       cmp       byte ptr [r15+34],0
       jne       near ptr M12_L08
M12_L01:
       mov       rdi,[r15+28]
       mov       rax,[r15+8]
       cmp       rdi,rax
       jne       near ptr M12_L09
       cmp       dword ptr [rax+8],1
       jne       near ptr M12_L10
M12_L02:
       mov       rdi,[r15+8]
       xor       eax,eax
       mov       [rdi+0C],eax
       mov       [rdi+10],eax
       mov       rdi,[rbx+8]
       cmp       [rdi],edi
       call      qword ptr [7F7C7E9E7378]; Kevlar.KevlarProperties.Clear()
       cmp       qword ptr [rbx+10],0
       jne       near ptr M12_L37
M12_L03:
       mov       r15,[rbx+18]
       test      r15,r15
       je        short M12_L06
       cmp       byte ptr [r15+34],0
       jne       near ptr M12_L38
M12_L04:
       mov       rdi,[r15+28]
       mov       rax,[r15+8]
       cmp       rdi,rax
       jne       near ptr M12_L39
       cmp       dword ptr [rax+8],1
       jne       near ptr M12_L40
M12_L05:
       mov       rdi,[r15+8]
       xor       eax,eax
       mov       [rdi+0C],eax
       mov       [rdi+10],eax
       mov       rdi,[rbx+18]
       cmp       [rdi],edi
       call      qword ptr [7F7C7E9E7378]; Kevlar.KevlarProperties.Clear()
M12_L06:
       mov       word ptr [rbx+64],0
       jmp       near ptr M12_L69
M12_L07:
       mov       rdi,rax
       call      qword ptr [7F7C7EA1EA88]
       jmp       near ptr M12_L00
M12_L08:
       mov       rdi,[r15+28]
       cmp       [rdi],edi
       call      qword ptr [7F7C7E9E7390]
       mov       byte ptr [r15+34],0
       jmp       near ptr M12_L01
M12_L09:
       mov       rdi,[r15+28]
       call      qword ptr [7F7C7E9E73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       jmp       near ptr M12_L36
M12_L10:
       mov       rdi,[r15+8]
       call      qword ptr [7F7C7E9E73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F74958013D0
       mov       r14,[rdi]
       cmp       dword ptr [r14+1C],0
       je        short M12_L11
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F7C7EA865F8]
M12_L11:
       mov       r13,[r14+10]
       xor       r12d,r12d
       test      r13,r13
       jne       near ptr M12_L18
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M12_L13
M12_L12:
       mov       rdi,7F7C7CA5B1E0
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M12_L12
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M12_L13:
       dec       r12d
       imul      edi,r12d,9E3779B9
       cmp       dword ptr [r14+18],0
       jge       short M12_L14
       mov       r12d,edi
       mov       edx,[r14+20]
       imul      r12,rdx
       shr       r12,20
       jmp       short M12_L15
M12_L14:
       and       edi,[r14+18]
       mov       r12d,edi
M12_L15:
       mov       rdi,[r14+8]
       lea       edx,[r12*8]
       cmp       edx,[rdi+8]
       jae       near ptr M12_L65
       lea       edx,[r12*8]
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       [rbp-78],rax
       test      rax,rax
       je        short M12_L16
       mov       rdx,rax
       xor       esi,esi
       call      00007F7CFBE74060
       mov       rdi,[rbp-78]
       cmp       rax,rdi
       je        short M12_L17
M12_L16:
       xor       edi,edi
M12_L17:
       mov       [rbp-38],rdi
       jmp       near ptr M12_L29
M12_L18:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L20
M12_L19:
       mov       rax,7F7C7CA5B1E8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-44],eax
       test      eax,eax
       je        short M12_L19
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-44]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L20:
       dec       eax
       cmp       dword ptr [r13+18],0
       jl        short M12_L21
       and       eax,[r13+18]
       jmp       short M12_L22
M12_L21:
       mov       rdi,[r13+8]
       mov       edi,[rdi+8]
       mov       eax,eax
       imul      rax,[r13+10]
       shr       rax,20
       inc       rax
       imul      rax,rdi
       shr       rax,20
M12_L22:
       xor       ecx,ecx
       jmp       near ptr M12_L26
M12_L23:
       mov       rdi,[r13+8]
       cmp       eax,[rdi+8]
       jae       near ptr M12_L65
       mov       [rbp-3C],eax
       mov       edx,eax
       mov       r8,[rdi+rdx*8+10]
       mov       [rbp-80],r8
       mov       r9,[r8+10]
       mov       [rbp-88],r9
       test      r9,r9
       je        short M12_L24
       lea       rdi,[r8+10]
       test      rdi,rdi
       je        near ptr M12_L57
       mov       rdx,r9
       xor       esi,esi
       call      00007F7CFBE74060
       mov       rcx,[rbp-88]
       cmp       rax,rcx
       mov       r8,[rbp-80]
       je        short M12_L27
M12_L24:
       lea       rdx,[rbp-38]
       mov       rsi,r8
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F7C7E4DDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M12_L29
       mov       eax,[rbp-3C]
       inc       eax
       mov       edi,eax
       mov       rsi,[r13+8]
       cmp       [rsi+8],edi
       jne       short M12_L25
       xor       edi,edi
M12_L25:
       mov       ecx,[rbp-40]
       inc       ecx
       mov       eax,edi
M12_L26:
       mov       rdi,[r13+8]
       mov       [rbp-40],ecx
       cmp       [rdi+8],ecx
       jg        near ptr M12_L23
       jmp       short M12_L28
M12_L27:
       mov       r9,rcx
       mov       [rbp-38],r9
       jmp       short M12_L29
M12_L28:
       xor       edi,edi
       mov       [rbp-38],rdi
M12_L29:
       mov       rax,[rbp-38]
       cmp       qword ptr [rbp-38],0
       jne       short M12_L30
       test      r13,r13
       je        short M12_L31
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       dword ptr [r12+8],1
       jmp       short M12_L33
M12_L30:
       mov       r13,rax
       jmp       short M12_L32
M12_L31:
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7F7C7EA86610]
       mov       r13,rax
M12_L32:
       mov       r12,r13
M12_L33:
       xor       edi,edi
       mov       [rbp-38],rdi
       cmp       dword ptr [r14+1C],0
       jne       short M12_L34
       mov       rsi,r12
       jmp       short M12_L35
M12_L34:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F7C7CA60550
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F7C7EA865F8]
       mov       rsi,rax
M12_L35:
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
M12_L36:
       mov       rsi,[r15+8]
       lea       rdi,[r15+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M12_L02
M12_L37:
       mov       rdi,[rbx+10]
       cmp       [rdi],edi
       call      qword ptr [7F7C7E9E7360]; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       mov       rdi,[rbx+10]
       cmp       [rdi],edi
       call      qword ptr [7F7C7E9E7378]; Kevlar.KevlarProperties.Clear()
       jmp       near ptr M12_L03
M12_L38:
       mov       rdi,[r15+28]
       cmp       [rdi],edi
       call      qword ptr [7F7C7E9E7390]
       mov       byte ptr [r15+34],0
       jmp       near ptr M12_L04
M12_L39:
       mov       rdi,[r15+28]
       call      qword ptr [7F7C7E9E73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       jmp       near ptr M12_L68
M12_L40:
       mov       rdi,[r15+8]
       call      qword ptr [7F7C7E9E73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F74958013D0
       mov       r14,[rdi]
       cmp       dword ptr [r14+1C],0
       je        short M12_L41
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F7C7EA865F8]
M12_L41:
       mov       r13,[r14+10]
       xor       r12d,r12d
       test      r13,r13
       jne       near ptr M12_L48
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M12_L43
M12_L42:
       mov       rdi,7F7C7CA5B1E0
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M12_L42
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M12_L43:
       dec       r12d
       imul      edi,r12d,9E3779B9
       cmp       dword ptr [r14+18],0
       jge       short M12_L44
       mov       r12d,edi
       mov       edx,[r14+20]
       imul      r12,rdx
       shr       r12,20
       jmp       short M12_L45
M12_L44:
       and       edi,[r14+18]
       mov       r12d,edi
M12_L45:
       mov       rdi,[r14+8]
       lea       edx,[r12*8]
       cmp       edx,[rdi+8]
       jae       near ptr M12_L65
       lea       edx,[r12*8]
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       [rbp-90],rax
       test      rax,rax
       je        short M12_L46
       mov       rdx,rax
       xor       esi,esi
       call      00007F7CFBE74060
       mov       rdi,[rbp-90]
       cmp       rax,rdi
       je        short M12_L47
M12_L46:
       xor       edi,edi
M12_L47:
       mov       [rbp-50],rdi
       jmp       near ptr M12_L60
M12_L48:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L50
M12_L49:
       mov       rax,7F7C7CA5B1E8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-5C],eax
       test      eax,eax
       je        short M12_L49
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-5C]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L50:
       dec       eax
       cmp       dword ptr [r13+18],0
       jl        short M12_L51
       and       eax,[r13+18]
       jmp       short M12_L52
M12_L51:
       mov       rdi,[r13+8]
       mov       edi,[rdi+8]
       mov       eax,eax
       imul      rax,[r13+10]
       shr       rax,20
       inc       rax
       imul      rax,rdi
       shr       rax,20
M12_L52:
       xor       ecx,ecx
       jmp       near ptr M12_L56
M12_L53:
       mov       rdi,[r13+8]
       cmp       eax,[rdi+8]
       jae       near ptr M12_L65
       mov       [rbp-54],eax
       mov       esi,eax
       mov       r8,[rdi+rsi*8+10]
       mov       [rbp-98],r8
       mov       r9,[r8+10]
       mov       [rbp-0A0],r9
       test      r9,r9
       je        short M12_L54
       lea       rdi,[r8+10]
       test      rdi,rdi
       je        short M12_L57
       xor       esi,esi
       mov       rdx,r9
       call      00007F7CFBE74060
       mov       rcx,[rbp-0A0]
       cmp       rax,rcx
       mov       r8,[rbp-98]
       je        short M12_L58
M12_L54:
       lea       rdx,[rbp-50]
       mov       rsi,r8
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F7C7E4DDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M12_L60
       mov       eax,[rbp-54]
       inc       eax
       mov       rcx,[r13+8]
       cmp       [rcx+8],eax
       jne       short M12_L55
       xor       eax,eax
M12_L55:
       mov       ecx,[rbp-58]
       inc       ecx
M12_L56:
       mov       rdi,[r13+8]
       mov       [rbp-58],ecx
       cmp       [rdi+8],ecx
       jg        near ptr M12_L53
       jmp       short M12_L59
M12_L57:
       call      qword ptr [7F7C7EA86340]
       int       3
M12_L58:
       mov       r9,rcx
       mov       [rbp-50],r9
       jmp       short M12_L60
M12_L59:
       xor       edi,edi
       mov       [rbp-50],rdi
M12_L60:
       mov       rax,[rbp-50]
       cmp       qword ptr [rbp-50],0
       jne       short M12_L61
       test      r13,r13
       je        short M12_L62
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       dword ptr [r12+8],1
       jmp       short M12_L64
M12_L61:
       mov       r13,rax
       jmp       short M12_L63
M12_L62:
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7F7C7EA86610]
       mov       r13,rax
M12_L63:
       mov       r12,r13
M12_L64:
       xor       edi,edi
       mov       [rbp-50],rdi
       cmp       dword ptr [r14+1C],0
       jne       short M12_L66
       mov       rsi,r12
       jmp       short M12_L67
M12_L65:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M12_L66:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F7C7CA60558
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F7C7EA865F8]
       mov       rsi,rax
M12_L67:
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
M12_L68:
       mov       rsi,[r15+8]
       lea       rdi,[r15+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M12_L05
M12_L69:
       mov       eax,1
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
       push      rax
       mov       rdi,[rbp-68]
       mov       rsi,[rdi]
       mov       rax,[rsi+30]
       mov       rax,[rax]
       mov       rbx,[rax+40]
       test      rbx,rbx
       je        short M12_L70
       jmp       short M12_L71
M12_L70:
       mov       rdi,rsi
       mov       rsi,7F7C7EA694F0
       call      qword ptr [7F7C7DA4F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rbx,rax
M12_L71:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-68]
       mov       r11b,[rdi+30]
       mov       [rax+8],r11b
       mov       rdi,rax
       mov       r11,rbx
       mov       rsi,[rbp-70]
       call      qword ptr [rbx]
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 1961
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F7C7D5EEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F7C7D5EEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       movzx     edx,byte ptr [rbp-14]
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       xor       ecx,ecx
       call      qword ptr [7F7C7E9E71B0]; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       movzx     esi,byte ptr [rbp-14]
       mov       rdi,[rbp-10]
       xor       edx,edx
       call      qword ptr [7F7C7E9E71C8]; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 65
```
```assembly
; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,58
       lea       rbp,[rsp+80]
       xor       eax,eax
       mov       [rbp-38],rax
       mov       r13,rdi
       mov       r14d,esi
       mov       rbx,rdx
       mov       r15,rcx
       mov       rdi,7F74958013C0
       mov       r12,[rdi]
       cmp       dword ptr [r12+1C],0
       jne       near ptr M15_L07
M15_L00:
       mov       rax,[r12+10]
       mov       [rbp-58],rax
       xor       ecx,ecx
       mov       [rbp-2C],ecx
       test      rax,rax
       je        near ptr M15_L08
       mov       rdi,7F7CFC0A0D68
       mov       rdx,7F7CFCA0E820
       call      rdx
       add       rax,48
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M15_L15
M15_L01:
       dec       eax
       mov       rcx,[rbp-58]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M15_L16
       and       r8d,eax
M15_L02:
       mov       eax,r8d
       xor       r8d,r8d
       mov       [rbp-44],r8d
       mov       rdi,[rcx+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M15_L20
M15_L03:
       mov       rdi,[rcx+8]
       cmp       eax,[rdi+8]
       jae       near ptr M15_L24
       mov       [rbp-40],eax
       mov       esi,eax
       mov       r9,[rdi+rsi*8+10]
       mov       [rbp-68],r9
       mov       r10,[r9+10]
       mov       [rbp-70],r10
       test      r10,r10
       je        near ptr M15_L17
       lea       rdi,[r9+10]
       test      rdi,rdi
       je        near ptr M15_L19
       xor       esi,esi
       mov       rdx,r10
       call      00007F7CFBE74060
       mov       rcx,[rbp-70]
       cmp       rax,rcx
       mov       r9,[rbp-68]
       jne       near ptr M15_L17
       mov       r10,rcx
       mov       [rbp-38],r10
M15_L04:
       mov       rax,[rbp-38]
       cmp       qword ptr [rbp-38],0
       je        near ptr M15_L21
M15_L05:
       xor       edi,edi
       mov       [rbp-38],rdi
       cmp       dword ptr [r12+1C],0
       jne       near ptr M15_L23
       mov       r12,rax
M15_L06:
       lea       rdi,[r12+68]
       mov       rsi,r13
       call      CORINFO_HELP_ASSIGN_REF
       mov       [r12+60],r14d
       lea       rdi,[r12+38]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r12+30]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,0FFFFFFFF00000000
       mov       [r12+58],rax
       xor       eax,eax
       mov       [r12+40],rax
       mov       rax,r12
       add       rsp,58
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M15_L07:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F7C7E9E67C0]
       jmp       near ptr M15_L00
M15_L08:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M15_L10
M15_L09:
       mov       rax,7F7C7CA5B1F8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-3C],eax
       test      eax,eax
       je        short M15_L09
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rbp-3C]
       mov       [rax+10],edi
       mov       eax,edi
M15_L10:
       dec       eax
       imul      edi,eax,9E3779B9
       cmp       dword ptr [r12+18],0
       jge       short M15_L11
       mov       ecx,edi
       mov       edx,[r12+20]
       imul      rcx,rdx
       shr       rcx,20
       jmp       short M15_L12
M15_L11:
       and       edi,[r12+18]
       mov       ecx,edi
M15_L12:
       mov       eax,ecx
       mov       rdi,[r12+8]
       lea       edx,[rax*8]
       cmp       edx,[rdi+8]
       jae       near ptr M15_L24
       mov       [rbp-2C],eax
       lea       edx,[rax*8]
       lea       rdi,[rdi+rdx*8+10]
       mov       rcx,[rdi]
       mov       [rbp-60],rcx
       test      rcx,rcx
       je        short M15_L13
       mov       rdx,rcx
       xor       esi,esi
       call      00007F7CFBE74060
       mov       rdi,[rbp-60]
       cmp       rax,rdi
       je        short M15_L14
M15_L13:
       xor       edi,edi
M15_L14:
       mov       [rbp-38],rdi
       jmp       near ptr M15_L04
M15_L15:
       mov       rax,7F7C7CA5B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-48],eax
       test      eax,eax
       je        short M15_L15
       mov       rdi,7F7CFC0A0D68
       mov       rcx,7F7CFCA0E820
       call      rcx
       add       rax,48
       mov       ecx,[rbp-48]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M15_L01
M15_L16:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M15_L02
M15_L17:
       lea       rdx,[rbp-38]
       mov       rsi,r9
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F7C7E4DDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       near ptr M15_L04
       mov       eax,[rbp-40]
       inc       eax
       mov       rcx,[rbp-58]
       mov       rdx,[rcx+8]
       cmp       [rdx+8],eax
       jne       short M15_L18
       xor       eax,eax
M15_L18:
       mov       r8d,[rbp-44]
       inc       r8d
       cmp       [rdx+8],r8d
       mov       [rbp-44],r8d
       mov       rcx,[rbp-58]
       jg        near ptr M15_L03
       jmp       short M15_L20
M15_L19:
       call      qword ptr [7F7C7EA86340]
       int       3
M15_L20:
       xor       edi,edi
       mov       [rbp-38],rdi
       jmp       near ptr M15_L04
M15_L21:
       cmp       qword ptr [rbp-58],0
       je        short M15_L22
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-78],rax
       mov       rdi,rax
       call      qword ptr [7F7C7E9E6868]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-78]
       jmp       near ptr M15_L05
M15_L22:
       mov       rdi,r12
       mov       esi,[rbp-2C]
       call      qword ptr [7F7C7E9E6820]
       jmp       near ptr M15_L05
M15_L23:
       mov       [rbp-50],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r12+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-50]
       mov       r11,7F7C7CA605D8
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F7C7E9E67C0]
       mov       r12,rax
       jmp       near ptr M15_L06
M15_L24:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 932
```
```assembly
; Kevlar.KevlarContext.get_PropertiesForCompletion()
       cmp       byte ptr [rdi+64],0
       jne       short M16_L00
       mov       rax,[rdi+8]
       ret
M16_L00:
       mov       rax,[rdi+10]
       ret
; Total bytes of code 16
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+20]
       mov       rdi,[rbp-10]
       call      qword ptr [7F7C7E4DDDA0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M17_L00
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M17_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M17_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rbp-20]
       mov       rdi,rax
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+18]
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7F7C7E4DDDB8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       eax,1
       add       rsp,30
       pop       rbp
       ret
M17_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 171
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+18]
       mov       rdi,[rbp-10]
       call      qword ptr [7F7C7E4DDDA0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M18_L00
       mov       rax,[rbp-20]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M18_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M18_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rax]
       mov       rdi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M18_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       xor       ecx,ecx
       mov       [rax],rcx
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+20]
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7F7C7E4DDDB8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       rax,[rbp-20]
       cmp       qword ptr [rax],0
       setne     al
       movzx     eax,al
       add       rsp,30
       pop       rbp
       ret
M18_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 221
```
```assembly
; Kevlar.KevlarContext..ctor()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F7C7E9E6880]; Kevlar.KevlarProperties..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,offset MT_System.Object
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-18],rax
       mov       rdi,[rbp-18]
       call      qword ptr [7F7C7DA4C240]; System.Object..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+20]
       mov       rsi,[rbp-18]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-8]
       mov       dword ptr [rax+5C],0FFFFFFFF
       call      qword ptr [7F7C7E4DE538]; System.TimeProvider.get_System()
       mov       rcx,[rbp-8]
       lea       rdi,[rcx+38]
       mov       rsi,rax
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-8]
       call      qword ptr [7F7C7DA4C240]; System.Object..ctor()
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 166
```
```assembly
; System.Diagnostics.Metrics.Instrument.get_Enabled()
       mov       rax,[rdi+8]
       cmp       qword ptr [rax+8],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 16
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,130
       vzeroupper
       lea       rbp,[rsp+150]
       xor       eax,eax
       mov       [rbp-148],rax
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFEE0
M21_L00:
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       vmovdqa   xmmword ptr [rax+rbp],xmm8
       add       rax,30
       jne       short M21_L00
       mov       r15,rdi
       mov       rbx,rsi
       mov       r14d,edx
       mov       r13,[rbx+30]
       xor       edi,edi
       mov       [rbp-0B8],rdi
       test      r15,r15
       jne       short M21_L03
M21_L01:
       mov       rsi,[rbx+30]
       mov       rdi,7F7495800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M21_L04
M21_L02:
       add       rsp,130
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M21_L03:
       mov       rdi,7F7495800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F7C7E4DE9B8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        short M21_L01
       lea       rdi,[rbp-0B0]
       mov       rsi,r13
       call      qword ptr [7F7C7E9E71F8]
       mov       rdx,7F7C7860B6A8
       mov       rdi,7F7C7860B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-0B0]
       mov       rsi,7F7C7860B638
       call      qword ptr [7F7C7E9E7210]
       call      00007F7C7DA38AE0
       mov       rsi,rax
       mov       rdi,r15
       call      qword ptr [7F7C7EA868E0]
       mov       [rbp-0B8],rax
       lea       rdi,[rbp-0B8]
       call      qword ptr [7F7C7E9E7240]
       mov       rdi,7F7495800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-0B0]
       mov       rdx,rbx
       call      qword ptr [7F7C7E9E7258]
       jmp       near ptr M21_L01
M21_L04:
       lea       rdi,[rbp-148]
       call      qword ptr [7F7C7E9E71F8]
       mov       rdx,7F7C7860B6A8
       mov       rdi,7F7C7860B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-148]
       mov       rsi,7F7C7860B638
       call      qword ptr [7F7C7E9E7210]
       mov       rdi,7F7495800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-148]
       mov       rcx,rbx
       mov       esi,1
       call      qword ptr [7F7C7E9E7270]
       jmp       near ptr M21_L02
; Total bytes of code 410
```
```assembly
; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       push      rax
       lea       rbp,[rsp+30]
       mov       rbx,rdi
       mov       rdi,7F74958013C0
       mov       r15,[rdi]
       test      rbx,rbx
       je        near ptr M22_L04
       cmp       dword ptr [r15+1C],0
       jne       near ptr M22_L05
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7F7C7E9E72B8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       je        near ptr M22_L06
       mov       r14,[r15+10]
       test      r14,r14
       je        near ptr M22_L12
       mov       rdi,7F7CFC0A0D68
       mov       rax,7F7CFCA0E820
       call      rax
       add       rax,48
       mov       r13d,[rax+10]
       test      r13d,r13d
       je        near ptr M22_L07
M22_L00:
       dec       r13d
       mov       r12d,[r14+18]
       test      r12d,r12d
       jl        near ptr M22_L08
       and       r12d,r13d
M22_L01:
       xor       r13d,r13d
       mov       rdi,[r14+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M22_L11
M22_L02:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M22_L20
       mov       esi,r12d
       mov       rax,[rdi+rsi*8+10]
       mov       [rbp-30],rax
       cmp       [rax],al
       lea       rdi,[rax+10]
       test      rdi,rdi
       je        near ptr M22_L17
       mov       rsi,rbx
       xor       edx,edx
       call      00007F7CFBE74060
       test      rax,rax
       jne       near ptr M22_L09
M22_L03:
       cmp       dword ptr [r15+1C],0
       jne       near ptr M22_L19
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M22_L04:
       mov       edi,29
       mov       rsi,7F7C7DEC54F0
       call      qword ptr [7F7C7DA4EF88]
       mov       rdi,rax
       call      qword ptr [7F7C7EA864A8]
       int       3
M22_L05:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F7C7CA60538
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M22_L06:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F7C7CA60540
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M22_L07:
       mov       rdi,7F7C7CA5B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M22_L07
       mov       rdi,7F7CFC0A0D68
       mov       rax,7F7CFCA0E820
       call      rax
       add       rax,48
       mov       [rax+10],r13d
       jmp       near ptr M22_L00
M22_L08:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r13d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
       jmp       near ptr M22_L01
M22_L09:
       mov       rdx,rbx
       mov       rsi,[rbp-30]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F7C7E4DDF38]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       near ptr M22_L03
       inc       r12d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r12d
       jne       short M22_L10
       xor       r12d,r12d
M22_L10:
       inc       r13d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r13d
       jg        near ptr M22_L02
M22_L11:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F7C7CA60548
       call      qword ptr [r11]
       jmp       near ptr M22_L03
M22_L12:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r14d,[rax+10]
       test      r14d,r14d
       jne       short M22_L14
M22_L13:
       mov       rdi,7F7C7CA5B1F8
       mov       eax,1
       mov       r14d,eax
       lock xadd [rdi],r14d
       inc       r14d
       je        short M22_L13
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r14d
M22_L14:
       dec       r14d
       imul      r14d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M22_L15
       mov       r13d,r14d
       mov       r12d,[r15+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M22_L16
M22_L15:
       and       r14d,[r15+18]
       mov       r13d,r14d
M22_L16:
       mov       rdi,[r15+8]
       lea       esi,[r13*8]
       cmp       esi,[rdi+8]
       jae       short M22_L20
       lea       esi,[r13*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M22_L18
M22_L17:
       call      qword ptr [7F7C7EA86340]
       int       3
M22_L18:
       mov       rsi,rbx
       call      00007F7CFBE74040
       test      rax,rax
       je        near ptr M22_L03
       mov       rdi,r15
       mov       rsi,rbx
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7F7C7E9E74F8]
       jmp       near ptr M22_L03
M22_L19:
       mov       rdi,r15
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F7C7E9E7528]
M22_L20:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 811
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-18]
       mov       rcx,rax
       test      cl,1
       jne       short M23_L00
       ret
M23_L00:
       jmp       qword ptr [7F7C7DA45C20]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 23
```
```assembly
; Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,0D0
       lea       rbp,[rsp+0F0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       xor       eax,eax
       mov       [rbp-30],rax
       mov       [rbp-28],rdi
       mov       [rbp-0D8],rdi
       mov       rbx,rsi
       mov       r14,rdx
       mov       r13,rcx
       mov       r15,r8
       mov       rsi,[rdi]
       mov       rax,[rsi+30]
       mov       rax,[rax]
       mov       rax,[rax+18]
       test      rax,rax
       je        near ptr M24_L14
M24_L00:
       mov       [rbp-48],r14
       mov       [rbp-40],r13
       mov       [rbp-70],r15
       mov       dword ptr [rbp-68],0FFFFFFFF
       mov       rsi,[rax+18]
       mov       rcx,[rsi+18]
       test      rcx,rcx
       je        near ptr M24_L15
M24_L01:
       mov       rsi,[rcx+18]
       mov       r15,[rsi+10]
       test      r15,r15
       je        near ptr M24_L16
M24_L02:
       mov       rdi,7F7CFC0A0D68
       mov       rax,7F7CFCA0E820
       call      rax
       cmp       dword ptr [rax],4
       jle       near ptr M24_L17
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        near ptr M24_L17
M24_L03:
       mov       r14,[rax+10]
       test      r14,r14
       jne       short M24_L04
       call      qword ptr [7F7C7E12C3F0]; System.Threading.Thread.InitializeCurrentThread()
       mov       r14,rax
M24_L04:
       mov       [rbp-0E0],r14
       mov       rsi,[r14+8]
       mov       [rbp-0E8],rsi
       mov       rsi,[r14+10]
       mov       [rbp-0F0],rsi
       mov       rdi,[r15+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M24_L06
M24_L05:
       lea       rdi,[rbp-70]
       call      rax
       jmp       short M24_L07
M24_L06:
       mov       rdi,r15
       mov       rsi,7F7C7E9D8060
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M24_L05
M24_L07:
       mov       rsi,[rbp-0F0]
       cmp       rsi,[r14+10]
       je        short M24_L08
       lea       rdi,[r14+10]
       call      CORINFO_HELP_ASSIGN_REF
M24_L08:
       mov       rdi,[r14+8]
       mov       r15,rdi
       mov       rsi,[rbp-0E8]
       cmp       rsi,r15
       je        short M24_L10
       lea       rdi,[r14+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      r15,r15
       je        short M24_L09
       cmp       qword ptr [r15+10],0
       jne       near ptr M24_L13
M24_L09:
       cmp       qword ptr [rbp-0E8],0
       jne       short M24_L12
M24_L10:
       mov       rdi,[rbp-60]
       mov       rax,7F74958013E8
       cmp       rdi,[rax]
       jne       near ptr M24_L18
       vmovdqu   xmm0,xmmword ptr [rbp-58]
       vmovdqu   xmmword ptr [rbp-0C0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-0D0]
       vmovdqu   ymmword ptr [rbp-90],ymm0
       xor       r15d,r15d
M24_L11:
       mov       [rbp-90],r15
       vmovdqu   ymm0,ymmword ptr [rbp-90]
       vmovdqu   ymmword ptr [rbx],ymm0
       mov       word ptr [rbx+8],0
       mov       byte ptr [rbx+0A],1
       mov       rax,rbx
       vzeroupper
       add       rsp,0D0
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M24_L12:
       mov       rsi,[rbp-0E8]
       cmp       qword ptr [rsi+10],0
       je        short M24_L10
M24_L13:
       mov       rdi,r15
       mov       rsi,[rbp-0E8]
       call      qword ptr [7F7C7EA86670]
       jmp       near ptr M24_L10
M24_L14:
       mov       rdi,rsi
       mov       rsi,7F7C7E9D7000
       call      qword ptr [7F7C7DA4F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       jmp       near ptr M24_L00
M24_L15:
       mov       rdi,rax
       mov       rsi,7F7C7E9D7C78
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rcx,rdi
       jmp       near ptr M24_L01
M24_L16:
       mov       rdi,rcx
       mov       rsi,7F7C7E9D7ED8
       call      qword ptr [7F7C7DA4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r15,rax
       jmp       near ptr M24_L02
M24_L17:
       mov       edi,4
       call      qword ptr [7F7C7EA86478]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       near ptr M24_L03
M24_L18:
       mov       r15,[rbp-60]
       test      r15,r15
       jne       short M24_L19
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       call      qword ptr [7F7C7EA86688]
       mov       [rbp-60],r15
M24_L19:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0A0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-0B0]
       vmovdqu   ymmword ptr [rbp-90],ymm0
       jmp       near ptr M24_L11
       push      rax
       mov       rsi,[rbp-0F0]
       mov       rax,[rbp-0E0]
       cmp       rsi,[rax+10]
       je        short M24_L20
       lea       rdi,[rax+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-0E0]
M24_L20:
       mov       rbx,[rax+8]
       mov       rsi,[rbp-0E8]
       cmp       rsi,rbx
       je        short M24_L23
       lea       rdi,[rax+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      rbx,rbx
       je        short M24_L21
       cmp       qword ptr [rbx+10],0
       jne       short M24_L22
M24_L21:
       cmp       qword ptr [rbp-0E8],0
       je        short M24_L23
       mov       rsi,[rbp-0E8]
       cmp       qword ptr [rsi+10],0
       je        short M24_L23
M24_L22:
       mov       rdi,rbx
       mov       rsi,[rbp-0E8]
       call      qword ptr [7F7C7EA86670]
M24_L23:
       nop
       vzeroupper
       add       rsp,8
       ret
; Total bytes of code 814
```
```assembly
; System.Threading.Thread.InitializeCurrentThread()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,68
       lea       rbp,[rsp+90]
       xor       eax,eax
       mov       [rbp-30],rax
       lea       rdi,[rbp-30]
       mov       [rbp-90],rdi
       lea       rdi,[rbp-88]
       call      qword ptr [7F7C7D5EEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-90]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7F7C7D5EEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rbx,[rbp-30]
       call      qword ptr [7F7C7D5F0B98]
       lea       rdi,[rax+10]
       mov       rsi,[rbp-30]
       call      qword ptr [7F7C7D5EEEB8]; CORINFO_HELP_ASSIGN_REF
       mov       rax,rbx
       add       rsp,68
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 123
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F7C7D5EEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F7C7D5EEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       ebx,edi
       call      qword ptr [7F7C7D606AF0]; Precode of System.Threading.Thread.GetThreadStaticsBase()
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M27_L01
       cmp       [rax],edi
       jle       short M27_L03
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M27_L03
M27_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M27_L01:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M27_L02
       movsxd    rcx,ecx
       add       rax,rcx
       jmp       short M27_L00
M27_L02:
       cmp       [rax+4],ecx
       jle       short M27_L03
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M27_L03
       mov       rax,[rdi]
       test      rax,rax
       je        short M27_L03
       jmp       short M27_L00
M27_L03:
       mov       edi,ebx
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
; Total bytes of code 133
```
```assembly
; Kevlar.KevlarProperties.Clear()
       push      rbp
       push      rbx
       sub       rsp,18
       lea       rbp,[rsp+20]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       rbx,rdi
       cmp       qword ptr [rbx+10],0
       jne       short M28_L01
M28_L00:
       add       rsp,18
       pop       rbx
       pop       rbp
       ret
M28_L01:
       xor       edi,edi
       mov       [rbx+30],edi
       mov       rdi,[rbx+18]
       test      rdi,rdi
       je        short M28_L02
       mov       eax,[rdi+38]
       sub       eax,[rdi+40]
       cmp       eax,20
       jl        short M28_L02
       xor       edi,edi
       mov       [rbx+38],rdi
       mov       [rbx+40],rdi
       mov       [rbx+10],rdi
       mov       [rbx+18],rdi
       jmp       short M28_L00
M28_L02:
       mov       rdi,[rbx+10]
       mov       rax,[rdi]
       mov       rax,[rax+40]
       call      qword ptr [rax+28]
       cmp       qword ptr [rbx+18],0
       je        short M28_L00
       mov       rdi,[rbx+18]
       cmp       [rdi],edi
       call      qword ptr [7F7C7E9E7480]
       mov       rdi,rax
       lea       rsi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F7C7E9E7498]
       jmp       short M28_L04
M28_L03:
       mov       rdi,[rbp-18]
       mov       rax,[rbp-18]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+28]
M28_L04:
       lea       rdi,[rbp-20]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+ValueCollection+Enumerator
       call      qword ptr [7F7C7E9E74C8]
       test      eax,eax
       jne       short M28_L03
       jmp       near ptr M28_L00
; Total bytes of code 186
```
```assembly
; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F7C7E9E7AC8]; Kevlar.KevlarProperties+AdditionalAttemptState.ReleaseReference()
       test      eax,eax
       je        short M29_L00
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      qword ptr [7F7C7DA45710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F74958013D0
       mov       rax,[rax]
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F7C7E9E7AE0]
M29_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 92
```
```assembly
; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       rbx,rdi
       cmp       byte ptr [rbx+34],0
       jne       short M30_L04
M30_L00:
       mov       rdi,[rbx+28]
       mov       rax,[rbx+8]
       cmp       rdi,rax
       jne       short M30_L02
       cmp       dword ptr [rax+8],1
       jne       short M30_L05
M30_L01:
       mov       rax,[rbx+8]
       xor       ecx,ecx
       mov       [rax+0C],ecx
       mov       [rax+10],ecx
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M30_L02:
       mov       rdi,[rbx+28]
       call      qword ptr [7F7C7E9E73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
M30_L03:
       mov       rsi,[rbx+8]
       lea       rdi,[rbx+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M30_L01
M30_L04:
       mov       rdi,[rbx+28]
       cmp       [rdi],edi
       call      qword ptr [7F7C7E9E7390]
       mov       byte ptr [rbx+34],0
       jmp       short M30_L00
M30_L05:
       mov       rdi,[rbx+8]
       call      qword ptr [7F7C7E9E73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F74958013D0
       mov       r15,[rdi]
       cmp       dword ptr [r15+1C],0
       je        short M30_L06
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F7C7EA865F8]
M30_L06:
       mov       r14,[r15+10]
       xor       r13d,r13d
       test      r14,r14
       jne       near ptr M30_L13
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M30_L08
M30_L07:
       mov       rdi,7F7C7CA5B1E0
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M30_L07
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M30_L08:
       dec       r13d
       imul      edi,r13d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M30_L09
       mov       r13d,edi
       mov       edx,[r15+20]
       imul      r13,rdx
       shr       r13,20
       jmp       short M30_L10
M30_L09:
       and       edi,[r15+18]
       mov       r13d,edi
M30_L10:
       mov       rdi,[r15+8]
       lea       edx,[r13*8]
       cmp       edx,[rdi+8]
       jae       near ptr M30_L31
       lea       edx,[r13*8]
       lea       rdi,[rdi+rdx*8+10]
       mov       r12,[rdi]
       test      r12,r12
       je        short M30_L11
       mov       rdx,r12
       xor       esi,esi
       call      00007F7CFBE74060
       cmp       rax,r12
       je        short M30_L12
M30_L11:
       xor       r12d,r12d
M30_L12:
       mov       [rbp-30],r12
       jmp       near ptr M30_L25
M30_L13:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M30_L15
M30_L14:
       mov       rdi,7F7C7CA5B1E8
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M30_L14
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M30_L15:
       dec       r12d
       cmp       dword ptr [r14+18],0
       jl        short M30_L16
       and       r12d,[r14+18]
       jmp       short M30_L17
M30_L16:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
M30_L17:
       xor       eax,eax
       jmp       short M30_L21
M30_L18:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M30_L31
       mov       esi,r12d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-40],rcx
       mov       r8,[rcx+10]
       mov       [rbp-48],r8
       test      r8,r8
       je        short M30_L19
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        short M30_L22
       xor       esi,esi
       mov       rdx,r8
       call      00007F7CFBE74060
       mov       rcx,[rbp-48]
       cmp       rax,rcx
       je        short M30_L23
       mov       rcx,[rbp-40]
M30_L19:
       lea       rdx,[rbp-30]
       mov       rsi,rcx
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F7C7E4DDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M30_L25
       inc       r12d
       mov       rax,[r14+8]
       cmp       [rax+8],r12d
       jne       short M30_L20
       xor       r12d,r12d
M30_L20:
       mov       eax,[rbp-34]
       inc       eax
M30_L21:
       mov       rdi,[r14+8]
       mov       [rbp-34],eax
       cmp       [rdi+8],eax
       jg        near ptr M30_L18
       jmp       short M30_L24
M30_L22:
       call      qword ptr [7F7C7EA86340]
       int       3
M30_L23:
       mov       r8,rcx
       mov       [rbp-30],r8
       jmp       short M30_L25
M30_L24:
       xor       edi,edi
       mov       [rbp-30],rdi
M30_L25:
       mov       r12,[rbp-30]
       cmp       qword ptr [rbp-30],0
       jne       short M30_L27
       test      r14,r14
       je        short M30_L26
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       r14,rax
       mov       dword ptr [r14+8],1
       jmp       short M30_L28
M30_L26:
       mov       rdi,r15
       mov       esi,r13d
       call      qword ptr [7F7C7EA86610]
       mov       r12,rax
M30_L27:
       mov       r14,r12
M30_L28:
       xor       edi,edi
       mov       [rbp-30],rdi
       cmp       dword ptr [r15+1C],0
       jne       short M30_L29
       mov       rsi,r14
       jmp       short M30_L30
M30_L29:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F7C7CA60500
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F7C7EA865F8]
       mov       rsi,rax
M30_L30:
       lea       rdi,[rbx+8]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M30_L03
M30_L31:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 802
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7F7C7D5F4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7F7C7D5EEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7F7C7D5FF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M31_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M31_L00
       mov       rsi,rax
       call      qword ptr [7F7C7D5EEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M31_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,0A0
       vzeroupper
       lea       rbp,[rsp+0C0]
       xor       eax,eax
       mov       [rbp-0B8],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqa   xmmword ptr [rbp-30],xmm8
       mov       rbx,rdi
       mov       r15,rsi
       mov       r13d,edx
       mov       r14,rcx
       test      rbx,rbx
       jne       short M32_L01
M32_L00:
       add       rsp,0A0
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M32_L01:
       mov       rdi,7F7495800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F7C7E4DE9B8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        short M32_L00
       lea       rdi,[rbp-0B0]
       mov       rsi,r15
       call      qword ptr [7F7C7E9E71F8]
       mov       rdx,7F7C7860B6A8
       mov       rdi,7F7C7860B680
       test      r13b,r13b
       cmove     rdx,rdi
       lea       rdi,[rbp-0B0]
       mov       rsi,7F7C7860B638
       call      qword ptr [7F7C7E9E7210]
       call      00007F7C7DA38AE0
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F7C7EA868E0]
       mov       [rbp-0B8],rax
       lea       rdi,[rbp-0B8]
       call      qword ptr [7F7C7E9E7240]
       mov       rdi,7F7495800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-0B0]
       mov       rdx,r14
       call      qword ptr [7F7C7E9E7258]
       jmp       near ptr M32_L00
; Total bytes of code 264
```
```assembly
; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,90
       lea       rbp,[rsp+0A0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0A0],ymm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       mov       rax,rdi
       mov       r15d,esi
       mov       rbx,rdx
       mov       rdi,7F7495800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       short M33_L01
M33_L00:
       add       rsp,90
       pop       rbx
       pop       r15
       pop       rbp
       ret
M33_L01:
       lea       rdi,[rbp-0A0]
       mov       rsi,rax
       call      qword ptr [7F7C7E9E71F8]
       mov       rdx,7F7C7860B6A8
       mov       rdi,7F7C7860B680
       test      r15b,r15b
       cmove     rdx,rdi
       lea       rdi,[rbp-0A0]
       mov       rsi,7F7C7860B638
       call      qword ptr [7F7C7E9E7210]
       mov       rdi,7F7495800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-0A0]
       mov       rcx,rbx
       mov       esi,1
       call      qword ptr [7F7C7E9E7270]
       jmp       short M33_L00
; Total bytes of code 199
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-50],rcx
       mov       dword ptr [rbp-70],3E8
M34_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M34_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M34_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7F7C7E4DDDD0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-50]
       mov       [rcx],eax
       mov       rax,[rbp-50]
       cmp       dword ptr [rax],0FFFFFFFF
       jne       short M34_L02
       mov       rdi,7F7C7E8D66B0
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,70
       pop       rbp
       ret
M34_L02:
       mov       rax,[rbp-50]
       mov       eax,[rax]
       mov       rcx,[rbp-48]
       cmp       eax,[rcx+8]
       jae       short M34_L04
       mov       edx,eax
       imul      rdx,10
       lea       rcx,[rcx+rdx+10]
       mov       eax,[rcx+8]
       mov       [rbp-5C],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-5C]
       call      qword ptr [7F7C7E4DDDE8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-68],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-68]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M34_L03
       mov       rdi,7F7C7E8D66B4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,70
       pop       rbp
       ret
M34_L03:
       mov       rdi,7F7C7E8D66B8
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M34_L00
M34_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 269
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-4C],ecx
       mov       dword ptr [rbp-70],3E8
M35_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M35_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M35_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rax,[rbp-48]
       mov       ecx,[rbp-4C]
       cmp       ecx,[rax+8]
       jae       near ptr M35_L03
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       add       rax,8
       mov       [rbp-68],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7F7C7E4DDDD0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-68]
       mov       [rcx],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-4C]
       call      qword ptr [7F7C7E4DDDE8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-60],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-60]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M35_L02
       mov       rdi,7F7C7E8D6BA8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,70
       pop       rbp
       ret
M35_L02:
       mov       rdi,7F7C7E8D6BAC
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M35_L00
M35_L03:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 235
```
```assembly
; Kevlar.KevlarProperties..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F7C7E9E6898]; Kevlar.KevlarProperties+AdditionalAttemptState..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-8]
       call      qword ptr [7F7C7DA4C240]; System.Object..ctor()
       mov       rax,[rbp-8]
       mov       rsi,[rax+8]
       mov       rax,[rbp-8]
       lea       rdi,[rax+28]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 104
```
```assembly
; System.Object..ctor()
       ret
; Total bytes of code 1
```
```assembly
; System.TimeProvider.get_System()
       mov       rax,7F7495800B00
       mov       rax,[rax]
       ret
; Total bytes of code 14
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbx
       sub       rsp,10
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rbx,rdi
       mov       rdi,rbx
       call      qword ptr [7F7C7D609718]; Precode of System.Runtime.CompilerServices.InitHelpers.InitClassSlow(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rbx+20]
       mov       rax,[rax-18]
       mov       [rsp+8],rax
       mov       rax,[rsp+8]
       and       rax,0FFFFFFFFFFFFFFFE
       xor       ecx,ecx
       mov       [rsp+8],rcx
       add       rsp,10
       pop       rbx
       ret
; Total bytes of code 59
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState.ReleaseReference()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       call      qword ptr [7F7C7E9E7AF8]; System.Threading.Interlocked.Decrement(Int32 ByRef)
       test      eax,eax
       sete      al
       movzx     eax,al
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 48
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       eax,[rbp-10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 27
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-1C],edx
       mov       rax,[rbp-18]
       sar       rax,20
       lea       esi,[rax+1]
       mov       rdi,[rbp-10]
       mov       edx,[rbp-1C]
       call      qword ptr [7F7C7DE3E0D0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 56
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       dword ptr [rax+8],1
       mov       rdi,[rbp-8]
       call      qword ptr [7F7C7DA4C240]; System.Object..ctor()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; System.Threading.Interlocked.Decrement(Int32 ByRef)
       mov       eax,0FFFFFFFF
       lock xadd [rdi],eax
       dec       eax
       ret
; Total bytes of code 12
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-10],edx
       movsxd    rax,dword ptr [rbp-0C]
       shl       rax,20
       mov       ecx,[rbp-10]
       or        rax,rcx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 40
```

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: C-baseline(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.4.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.4.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=10, LaunchCount=3, WarmupCount=5))

```assembly
; PoolContextProbe.NestedContext()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,48
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-48],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-40],xmm8
       mov       [rbp-30],rax
       mov       rdi,7F9275800AC0
       mov       rbx,[rdi]
       mov       rdi,7F9275800400
       mov       r15,[rdi]
       test      rbx,rbx
       je        near ptr M00_L04
M00_L00:
       mov       rdi,7F9275800AF0
       mov       r14,[rdi]
       test      r14,r14
       je        near ptr M00_L05
M00_L01:
       mov       rdi,7F9275800AF8
       mov       r13,[rdi]
       test      r13,r13
       je        near ptr M00_L06
M00_L02:
       mov       rax,[r15+38]
       test      rax,rax
       jne       near ptr M00_L07
       cmp       byte ptr [r15+48],0
       jne       near ptr M00_L08
       mov       r12,[r15+10]
       xor       edi,edi
       test      rdi,rdi
       cmove     rdi,r15
       mov       rdi,[rdi+20]
       mov       rax,7F9275800B00
       test      rdi,rdi
       cmove     rdi,[rax]
       mov       [rbp-50],rdi
       mov       rax,[r15+38]
       test      rax,rax
       jne       near ptr M00_L09
       mov       rdi,[rbp-50]
       mov       rcx,[r15+40]
M00_L03:
       mov       [rsp],r13
       xor       esi,esi
       mov       [rsp+8],rsi
       mov       [rsp+10],rsi
       mov       rsi,r12
       mov       rdx,rdi
       mov       r8,rbx
       mov       r9,r14
       mov       rdi,7F9A5BCDCB40
       call      qword ptr [7F9A5B8DE598]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       mov       [rbp-48],rax
       mov       [rbp-40],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-48]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       mov       rax,[rbp-38]
       mov       rdx,[rbp-30]
       add       rsp,48
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M00_L04:
       mov       rdi,offset MT_System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rsi,7F9275800AA8
       mov       rsi,[rsi]
       mov       rdi,rbx
       mov       rdx,offset PoolContextProbe+<>c.<NestedContext>b__6_0(Kevlar.KevlarContext)
       call      qword ptr [7F9A5AE46E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F9275800AC0
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L00
M00_L05:
       mov       rdi,offset MT_System.Action<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarProperties>
       call      CORINFO_HELP_NEWSFAST
       mov       r14,rax
       mov       rsi,7F9275800AE8
       mov       rsi,[rsi]
       mov       rdi,r14
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       call      qword ptr [7F9A5AE46E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F9275800AF0
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L01
M00_L06:
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r13,rax
       mov       rsi,7F9275800AE8
       mov       rsi,[rsi]
       mov       rdi,r13
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F9A5AE46E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F9275800AF8
       mov       rsi,r13
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L02
M00_L07:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       r8,r13
       mov       rdx,rbx
       mov       rcx,r14
       mov       rsi,7F9A5BCDB1D0
       xor       r9d,r9d
       cmp       [rdi],edi
       add       rsp,48
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F9A5B8DE340]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
M00_L08:
       call      qword ptr [7F9A5B8DE508]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M00_L09:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F9A5B8DE4F0]; Kevlar.Shield.get_Name()
       mov       rcx,rax
       mov       rdi,[rbp-50]
       jmp       near ptr M00_L03
; Total bytes of code 604
```
```assembly
; BenchmarkDotNet.Helpers.AwaitHelper.GetResult[[System.Int32, System.Private.CoreLib]](System.Threading.Tasks.ValueTask`1<Int32>)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp-48],rax
       mov       [rbp-40],rax
       mov       [rbp-38],rdi
       mov       [rbp-30],rsi
       mov       rbx,rdi
       mov       r15d,esi
       movsx     r14,word ptr [rbp-2C]
       test      rbx,rbx
       je        near ptr M01_L11
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<System.Int32>
       call      qword ptr [7F9A5AE46838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r13,rax
       mov       rax,r13
       test      rax,rax
       jne       near ptr M01_L05
       mov       rdi,offset MT_Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource
       cmp       [rbx],rdi
       je        short M01_L02
       mov       rdi,rbx
       mov       esi,r14d
       mov       r11,7F9A59E60698
       call      qword ptr [r11]
M01_L00:
       test      eax,eax
       je        near ptr M01_L15
M01_L01:
       test      r13,r13
       jne       near ptr M01_L09
       mov       rdi,offset MT_Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource
       cmp       [rbx],rdi
       je        short M01_L06
       mov       rdi,rbx
       mov       esi,r14d
       mov       r11,7F9A59E606A0
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M01_L02:
       lea       rsi,[rbx+40]
       movsx     rdi,word ptr [rsi+28]
       cmp       r14d,edi
       jne       near ptr M01_L12
       cmp       qword ptr [rsi],0
       jne       near ptr M01_L13
M01_L03:
       xor       r12d,r12d
M01_L04:
       mov       eax,r12d
       jmp       short M01_L00
M01_L05:
       test      dword ptr [rax+34],1600000
       jne       short M01_L01
       jmp       near ptr M01_L15
M01_L06:
       mov       [rbp-50],rbx
       lea       rdi,[rbx+40]
       movsx     rsi,word ptr [rdi+28]
       cmp       r14d,esi
       jne       short M01_L07
       cmp       byte ptr [rdi+2A],0
       je        short M01_L07
       cmp       qword ptr [rdi+18],0
       jne       short M01_L07
       mov       r15,[rdi+20]
       jmp       short M01_L08
M01_L07:
       call      qword ptr [7F9A5BE86448]
       int       3
M01_L08:
       lea       r13,[rbx+40]
       inc       esi
       mov       [r13+28],si
       xor       edi,edi
       mov       [r13],rdi
       mov       [r13+8],rdi
       mov       [r13+10],rdi
       mov       [r13+18],rdi
       mov       [r13+20],rdi
       mov       byte ptr [r13+2A],0
       mov       rdi,[rbx+8]
       lea       rdi,[rdi+20]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M01_L11
M01_L09:
       mov       edi,[r13+34]
       and       edi,11000000
       cmp       edi,1000000
       jne       near ptr M01_L16
M01_L10:
       mov       r15d,[r13+38]
M01_L11:
       mov       eax,r15d
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M01_L12:
       call      qword ptr [7F9A5BE863D0]
       int       3
M01_L13:
       cmp       byte ptr [rsi+2A],0
       je        near ptr M01_L03
       cmp       qword ptr [rsi+18],0
       je        short M01_L14
       mov       rsi,[rsi+18]
       mov       rsi,[rsi+8]
       mov       rdi,offset MT_System.OperationCanceledException
       call      qword ptr [7F9A5AE46838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r12d,3
       mov       ecx,2
       test      rax,rax
       cmove     r12d,ecx
       jmp       near ptr M01_L04
M01_L14:
       mov       r12d,1
       jmp       near ptr M01_L04
M01_L15:
       mov       [rbp-48],rbx
       mov       [rbp-40],r15d
       mov       [rbp-3C],r14w
       call      qword ptr [7F9A5BDEFB40]
       mov       rdi,rax
       mov       rsi,[rbp-48]
       mov       rdx,[rbp-40]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDEFB10]
       jmp       near ptr M01_L01
M01_L16:
       mov       rdi,r13
       xor       esi,esi
       call      qword ptr [7F9A5BE86430]
       jmp       near ptr M01_L10
       push      rax
       mov       rsi,[rbp-50]
       lea       r13,[rsi+40]
       inc       word ptr [r13+28]
       xor       edi,edi
       mov       [r13],rdi
       mov       [r13+8],rdi
       mov       [r13+10],rdi
       mov       [r13+18],rdi
       mov       [r13+20],rdi
       mov       byte ptr [r13+2A],0
       mov       rdi,[rsi+8]
       lea       rdi,[rdi+20]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,8
       ret
; Total bytes of code 585
```
```assembly
; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,298
       vzeroupper
       lea       rbp,[rsp+2C0]
       xor       eax,eax
       mov       [rbp-228],rax
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFE20
M02_L00:
       vmovdqa   xmmword ptr [rbp+rax-40],xmm8
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       add       rax,30
       jne       short M02_L00
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-238],r8
       mov       r13,rsi
       mov       r14,rdx
       mov       rbx,rcx
       mov       r15,r9
       mov       r12,[rbp+20]
       mov       rax,7F9275800BA0
       mov       rax,[rax]
       mov       rax,[rax+8]
       cmp       qword ptr [rax+8],0
       jne       near ptr M02_L31
       xor       edi,edi
M02_L01:
       mov       [rbp-40],rdi
       test      r12,r12
       jne       near ptr M02_L32
M02_L02:
       mov       rdi,7F92758013C0
       mov       rax,[rdi]
       mov       [rbp-298],rax
       mov       rcx,rax
       mov       [rbp-258],rcx
       cmp       dword ptr [rcx+1C],0
       jne       near ptr M02_L53
M02_L03:
       mov       rcx,[rbp-258]
       mov       rdx,[rcx+10]
       mov       [rbp-268],rdx
       xor       esi,esi
       mov       [rbp-98],esi
       test      rdx,rdx
       je        near ptr M02_L54
       mov       rdi,7F9AD94A0D68
       mov       r8,7F9AD9D06820
       call      r8
       add       rax,48
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M02_L63
M02_L04:
       dec       eax
       mov       rcx,[rbp-268]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M02_L64
       and       r8d,eax
M02_L05:
       mov       eax,r8d
       xor       r8d,r8d
M02_L06:
       mov       rdi,[rcx+8]
       mov       [rbp-0A0],r8d
       cmp       [rdi+8],r8d
       jle       near ptr M02_L68
       cmp       eax,[rdi+8]
       jae       near ptr M02_L100
       mov       [rbp-9C],eax
       mov       edx,eax
       mov       r9,[rdi+rdx*8+10]
       mov       [rbp-278],r9
       mov       r10,[r9+10]
       mov       [rbp-280],r10
       test      r10,r10
       jne       near ptr M02_L30
M02_L07:
       lea       rdi,[r9+18]
       mov       rdx,[r9+8]
       mov       rsi,[rdi]
       mov       r10d,esi
       cmp       r10d,0FFFFFFFF
       je        near ptr M02_L66
M02_L08:
       cmp       r10d,[rdx+8]
       jae       near ptr M02_L100
       mov       r11d,r10d
       shl       r11,4
       mov       r8d,[rdx+r11+18]
       mov       rax,rsi
       sar       rax,20
       inc       eax
       cdqe
       shl       rax,20
       or        r8,rax
       mov       rax,rsi
       lock cmpxchg [rdi],r8
       cmp       rax,rsi
       jne       near ptr M02_L65
       mov       rax,[r9+8]
       mov       rdi,rax
       cmp       r10d,[rdi+8]
       jae       near ptr M02_L100
       mov       rdx,[rdi+r11+10]
       cmp       r10d,[rax+8]
       jae       near ptr M02_L100
       lea       rdi,[rax+r11+10]
       xor       eax,eax
       mov       [rdi],rax
       add       r9,20
M02_L09:
       mov       rax,[r9]
       mov       [rbp-0B0],rax
       mov       [rdi+8],eax
       mov       rsi,rax
       sar       rsi,20
       inc       esi
       movsxd    rsi,esi
       shl       rsi,20
       mov       r8d,r10d
       or        rsi,r8
       lock cmpxchg [r9],rsi
       cmp       rax,[rbp-0B0]
       jne       short M02_L09
       test      rdx,rdx
       je        near ptr M02_L66
       mov       rax,[rbp-258]
M02_L10:
       test      rdx,rdx
       je        near ptr M02_L69
M02_L11:
       mov       rcx,rdx
M02_L12:
       cmp       dword ptr [rax+1C],0
       jne       near ptr M02_L71
       mov       rdx,rcx
M02_L13:
       mov       [rbp-250],rdx
       lea       rdi,[rdx+68]
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       xor       edi,edi
       mov       r12,[rbp-250]
       mov       [r12+60],edi
       lea       rdi,[r12+38]
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r12+30]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       mov       rsi,0FFFFFFFF00000000
       mov       [r12+58],rsi
       xor       esi,esi
       mov       [r12+40],rsi
       mov       [rbp-240],r12
       mov       rdx,[r12+8]
       mov       rsi,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       cmp       [r15+18],rsi
       je        short M02_L14
       mov       rsi,[rbp-238]
       mov       rdi,[r15+8]
       call      qword ptr [r15+18]
       nop
M02_L14:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M02_L28
M02_L15:
       lea       rdi,[rbp-60]
       mov       rdx,r13
       mov       rcx,[rbp-238]
       mov       r8,[rbp+10]
       mov       r9,r12
       call      qword ptr [7F9A5B8DE670]; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       rbx,[rbp-60]
       test      rbx,rbx
       jne       near ptr M02_L72
       mov       r14,[rbp-50]
       mov       r15d,[rbp-48]
M02_L16:
       test      r14,r14
       sete      bl
       movzx     ebx,bl
       mov       r13,[r12+30]
       cmp       qword ptr [rbp-40],0
       jne       near ptr M02_L77
M02_L17:
       mov       rsi,[r12+30]
       mov       rdi,7F9275800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M02_L78
M02_L18:
       cmp       byte ptr [r12+64],0
       jne       near ptr M02_L79
       mov       rbx,[r12+8]
M02_L19:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rax,[rsi+28]
       test      rax,rax
       je        near ptr M02_L29
       mov       rdi,rax
M02_L20:
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-238]
       mov       rcx,rbx
       call      qword ptr [7F9A5B8DE760]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rbx,[rbp-298]
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M02_L80
       mov       rdi,rbx
       mov       rsi,r12
       call      qword ptr [7F9A5BDE72B8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       je        near ptr M02_L81
       mov       r12,[rbx+10]
       test      r12,r12
       je        near ptr M02_L88
       mov       rdi,7F9AD94A0D68
       mov       rax,7F9AD9D06820
       call      rax
       add       rax,48
       mov       r13d,[rax+10]
       test      r13d,r13d
       je        near ptr M02_L82
M02_L21:
       dec       r13d
       mov       eax,[r12+18]
       test      eax,eax
       jl        near ptr M02_L83
       and       r13d,eax
M02_L22:
       xor       eax,eax
       mov       [rbp-1DC],eax
       mov       rdi,[r12+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M02_L87
M02_L23:
       mov       rdi,[r12+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M02_L100
       mov       esi,r13d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-290],rcx
       cmp       [rcx],cl
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M02_L93
       mov       rsi,[rbp-240]
       xor       edx,edx
       call      00007F9AD9274060
       test      rax,rax
       je        near ptr M02_L26
       mov       rcx,[rbp-290]
       lea       rdi,[rcx+20]
       mov       rsi,[rcx+8]
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       je        near ptr M02_L85
       mov       r8d,[rsi+8]
M02_L24:
       cmp       edx,[rsi+8]
       jae       near ptr M02_L100
       mov       r8d,edx
       shl       r8,4
       mov       [rbp-230],r8
       mov       r9d,[rsi+r8+18]
       mov       r10,rax
       sar       r10,20
       inc       r10d
       movsxd    r10,r10d
       shl       r10,20
       or        r9,r10
       mov       [rbp-1E8],rax
       lock cmpxchg [rdi],r9
       cmp       rax,[rbp-1E8]
       jne       near ptr M02_L84
       mov       rdi,[rcx+8]
       mov       [rbp-1E0],edx
       cmp       edx,[rdi+8]
       jae       near ptr M02_L100
       lea       rdi,[rdi+r8+10]
       mov       rsi,[rbp-240]
       call      CORINFO_HELP_ASSIGN_REF
       mov       r13,[rbp-290]
       lea       rdi,[r13+18]
       mov       rcx,[r13+8]
       mov       r13d,[rbp-1E0]
M02_L25:
       mov       rax,[rdi]
       mov       [rbp-1F0],rax
       cmp       r13d,[rcx+8]
       jae       near ptr M02_L100
       mov       r12,[rbp-230]
       mov       [rcx+r12+18],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       esi,r13d
       or        rdx,rsi
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-1F0]
       jne       short M02_L25
M02_L26:
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M02_L95
M02_L27:
       test      r14,r14
       jne       near ptr M02_L96
       xor       eax,eax
       mov       edx,r15d
       mov       rdi,1000000000000
       or        rdx,rdi
       add       rsp,298
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L28:
       mov       rsi,7F9A5BCE36D8
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M02_L15
M02_L29:
       mov       rsi,7F9A5BCE3AB0
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M02_L20
M02_L30:
       lea       rdi,[r9+10]
       test      rdi,rdi
       je        near ptr M02_L93
       mov       rdx,r10
       xor       esi,esi
       call      00007F9AD9274060
       mov       rdi,[rbp-280]
       cmp       rax,rdi
       mov       r9,[rbp-278]
       jne       near ptr M02_L07
       mov       r10,rdi
       mov       rdx,r10
       mov       rax,[rbp-258]
       jmp       near ptr M02_L10
M02_L31:
       call      00007F9A5AE38AE0
       mov       rdi,rax
       jmp       near ptr M02_L01
M02_L32:
       cmp       dword ptr [r12+20],0
       je        near ptr M02_L02
       mov       rsi,rbx
       xor       edx,edx
       call      qword ptr [7F9A5B8DE868]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       cmp       qword ptr [rbp+18],0
       je        near ptr M02_L52
       mov       rdi,r12
       mov       rcx,rbx
       mov       rdx,r14
       xor       esi,esi
       call      qword ptr [7F9A5B8DE880]; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       mov       rbx,rax
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       r15,[rsi+28]
       test      r15,r15
       je        short M02_L33
       jmp       short M02_L34
M02_L33:
       mov       rsi,7F9A5BCE3AB0
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r15,rax
M02_L34:
       mov       rdi,rbx
       cmp       [rdi],edi
       call      qword ptr [7F9A5B8DE898]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       rcx,rax
       mov       rdi,r15
       mov       rdx,[rbp-238]
       mov       rsi,[rbp+18]
       call      qword ptr [7F9A5B8DE760]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,7F92758013C0
       mov       rdi,[rdi]
       mov       r15,rdi
       cmp       dword ptr [r15+1C],0
       je        short M02_L35
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F9A59E606B8
       call      qword ptr [r11]
       jmp       near ptr M02_L52
M02_L35:
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7F9A5BDE72B8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       jne       short M02_L36
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F9A59E606C0
       call      qword ptr [r11]
       jmp       near ptr M02_L52
M02_L36:
       mov       r14,[r15+10]
       test      r14,r14
       je        near ptr M02_L46
       mov       edi,48
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M02_L38
M02_L37:
       mov       rdi,7F9A59E5B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M02_L37
       mov       edi,48
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M02_L38:
       dec       r13d
       cmp       dword ptr [r14+18],0
       jl        short M02_L39
       and       r13d,[r14+18]
       jmp       short M02_L40
M02_L39:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r14+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
M02_L40:
       xor       eax,eax
       jmp       short M02_L43
M02_L41:
       mov       rdi,[r14+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M02_L100
       mov       esi,r13d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-248],rcx
       cmp       [rcx],cl
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M02_L93
       mov       rsi,rbx
       xor       edx,edx
       call      00007F9AD9274060
       test      rax,rax
       je        short M02_L44
       mov       rdx,rbx
       mov       rsi,[rbp-248]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F9A5B8DDF38]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M02_L44
       inc       r13d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r13d
       jne       short M02_L42
       xor       r13d,r13d
M02_L42:
       mov       eax,[rbp-94]
       inc       eax
M02_L43:
       mov       rdi,[r14+8]
       mov       [rbp-94],eax
       cmp       [rdi+8],eax
       jg        short M02_L41
       jmp       short M02_L45
M02_L44:
       cmp       dword ptr [r15+1C],0
       je        near ptr M02_L52
       jmp       near ptr M02_L51
M02_L45:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F9A59E606C8
       call      qword ptr [r11]
       jmp       short M02_L44
M02_L46:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L48
M02_L47:
       mov       rdi,7F9A59E5B1F8
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M02_L47
       mov       [rax+10],edi
M02_L48:
       dec       edi
       imul      r14d,edi,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M02_L49
       mov       r13d,r14d
       mov       r14d,[r15+20]
       imul      r14,r13
       shr       r14,20
       jmp       short M02_L50
M02_L49:
       and       r14d,[r15+18]
M02_L50:
       mov       rdi,[r15+8]
       lea       esi,[r14*8]
       cmp       esi,[rdi+8]
       jae       near ptr M02_L100
       lea       esi,[r14*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       je        near ptr M02_L93
       mov       rsi,rbx
       call      00007F9AD9274040
       test      rax,rax
       je        near ptr M02_L44
       mov       rdi,r15
       mov       rsi,rbx
       mov       rdx,rax
       mov       ecx,r14d
       call      qword ptr [7F9A5BDE74F8]
       jmp       near ptr M02_L44
M02_L51:
       mov       rdi,r15
       call      qword ptr [7F9A5BDE7528]
M02_L52:
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rdi,rbx
       call      qword ptr [7F9A5BE87108]
       lea       rdi,[rbx+70]
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,rbx
       call      qword ptr [7F9A5B8DE8E0]
       mov       rdi,rax
       mov       esi,edx
       call      qword ptr [7F9A5B8DE7F0]
       mov       [rbp-218],rax
       mov       [rbp-210],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-218]
       vmovdqu   xmmword ptr [rbp-90],xmm0
       mov       rax,[rbp-90]
       mov       rdx,[rbp-88]
       add       rsp,298
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L53:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F9A5BDE67C0]
       jmp       near ptr M02_L03
M02_L54:
       mov       rdi,7F9AD94A0D68
       mov       rsi,7F9AD9D06820
       call      rsi
       add       rax,3C
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L56
M02_L55:
       mov       rdi,7F9A59E5B1F8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M02_L55
       mov       [rax+10],edi
M02_L56:
       dec       edi
       imul      edi,9E3779B9
       mov       rax,[rbp-258]
       mov       edx,[rax+18]
       test      edx,edx
       jge       short M02_L57
       mov       esi,edi
       mov       ecx,[rax+20]
       imul      rsi,rcx
       shr       rsi,20
       jmp       short M02_L58
M02_L57:
       mov       esi,edi
       and       esi,edx
M02_L58:
       mov       ecx,esi
       mov       rdi,[rax+8]
       mov       [rbp-98],ecx
       lea       edx,[rcx*8]
       cmp       edx,[rdi+8]
       jae       near ptr M02_L100
       lea       rdi,[rdi+rdx*8+10]
       mov       r8,[rdi]
       mov       rdx,r8
       mov       [rbp-270],rdx
       test      rdx,rdx
       je        short M02_L60
       xor       esi,esi
       call      00007F9AD9274060
       mov       rdi,[rbp-270]
       cmp       rax,rdi
       mov       rax,[rbp-258]
       je        short M02_L61
M02_L59:
       xor       edx,edx
       jmp       short M02_L62
M02_L60:
       mov       rax,[rbp-258]
       jmp       short M02_L59
M02_L61:
       mov       rdx,rdi
M02_L62:
       jmp       near ptr M02_L10
M02_L63:
       mov       rax,7F9A59E5B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-0A4],eax
       test      eax,eax
       je        short M02_L63
       mov       rdi,7F9AD94A0D68
       mov       rcx,7F9AD9D06820
       call      rcx
       add       rax,48
       mov       ecx,[rbp-0A4]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M02_L04
M02_L64:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M02_L05
M02_L65:
       mov       rsi,[rdi]
       mov       r10d,esi
       cmp       r10d,0FFFFFFFF
       jne       near ptr M02_L08
M02_L66:
       mov       eax,[rbp-9C]
       inc       eax
       mov       edx,eax
       mov       rcx,[rbp-268]
       mov       rdi,[rcx+8]
       cmp       [rdi+8],edx
       jne       short M02_L67
       xor       edx,edx
       xor       edi,edi
       mov       edx,edi
M02_L67:
       mov       r8d,[rbp-0A0]
       inc       r8d
       mov       eax,edx
       mov       rcx,[rbp-268]
       jmp       near ptr M02_L06
M02_L68:
       xor       edx,edx
       mov       rax,[rbp-258]
       jmp       near ptr M02_L10
M02_L69:
       cmp       qword ptr [rbp-268],0
       je        short M02_L70
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       rcx,rax
       mov       [rbp-288],rcx
       mov       rdi,rcx
       call      qword ptr [7F9A5BDE6868]; Kevlar.KevlarContext..ctor()
       mov       rcx,[rbp-288]
       mov       rax,rcx
       mov       rcx,rax
       mov       rax,[rbp-258]
       jmp       near ptr M02_L12
M02_L70:
       mov       rdi,rax
       mov       esi,[rbp-98]
       call      qword ptr [7F9A5BDE6820]
       mov       rdx,rax
       mov       rax,[rbp-258]
       jmp       near ptr M02_L11
M02_L71:
       mov       [rbp-260],rcx
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-258]
       mov       dil,[rdi+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-260]
       mov       r11,7F9A59E606D0
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F9A5BDE67C0]
       mov       rdx,rax
       jmp       near ptr M02_L13
M02_L72:
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F9A5AE46838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       test      rax,rax
       je        short M02_L73
       mov       rdi,rax
       call      qword ptr [7F9A5BDE7138]
       jmp       short M02_L74
M02_L73:
       mov       rdi,rbx
       movsx     rsi,word ptr [rbp-58]
       mov       r11,7F9A59E606D8
       call      qword ptr [r11]
       cmp       eax,1
       sete      al
       movzx     eax,al
M02_L74:
       test      eax,eax
       je        near ptr M02_L97
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F9A5AE46838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r15,rax
       test      r15,r15
       je        short M02_L76
       mov       edi,[r15+34]
       and       edi,11000000
       cmp       edi,1000000
       je        short M02_L75
       mov       rdi,r15
       xor       esi,esi
       call      qword ptr [7F9A5BE86430]
M02_L75:
       mov       r14,[r15+38]
       mov       r15d,[r15+40]
       jmp       near ptr M02_L16
M02_L76:
       mov       rdi,rbx
       movsx     rsi,word ptr [rbp-58]
       mov       r11,7F9A59E606E0
       call      qword ptr [r11]
       mov       r14,rax
       mov       r15d,edx
       jmp       near ptr M02_L16
M02_L77:
       mov       rdi,7F9275800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F9A5B8DE9B8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M02_L17
       lea       rdi,[rbp-140]
       mov       rsi,r13
       call      qword ptr [7F9A5BDE71F8]
       mov       rdx,7F9A58A0B6A8
       mov       rdi,7F9A58A0B680
       test      ebx,ebx
       cmove     rdx,rdi
       lea       rdi,[rbp-140]
       mov       rsi,7F9A58A0B638
       call      qword ptr [7F9A5BDE7210]
       call      00007F9A5AE38AE0
       mov       rsi,rax
       mov       rdi,[rbp-40]
       call      qword ptr [7F9A5BE86CD0]
       mov       [rbp-148],rax
       lea       rdi,[rbp-148]
       call      qword ptr [7F9A5BDE7240]
       mov       rdi,7F9275800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-140]
       mov       rdx,r12
       call      qword ptr [7F9A5BDE7258]
       jmp       near ptr M02_L17
M02_L78:
       lea       rdi,[rbp-1D8]
       call      qword ptr [7F9A5BDE71F8]
       mov       rdx,7F9A58A0B6A8
       mov       rdi,7F9A58A0B680
       test      ebx,ebx
       cmove     rdx,rdi
       lea       rdi,[rbp-1D8]
       mov       rsi,7F9A58A0B638
       call      qword ptr [7F9A5BDE7210]
       mov       rdi,7F9275800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-1D8]
       mov       rcx,r12
       mov       esi,1
       call      qword ptr [7F9A5BDE7270]
       jmp       near ptr M02_L18
M02_L79:
       mov       rbx,[r12+10]
       jmp       near ptr M02_L19
M02_L80:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F9A59E606E8
       call      qword ptr [r11]
       jmp       near ptr M02_L27
M02_L81:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F9A59E606F0
       call      qword ptr [r11]
       jmp       near ptr M02_L27
M02_L82:
       mov       rdi,7F9A59E5B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M02_L82
       mov       rdi,7F9AD94A0D68
       mov       rax,7F9AD9D06820
       call      rax
       add       rax,48
       mov       [rax+10],r13d
       jmp       near ptr M02_L21
M02_L83:
       mov       rdi,[r12+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r12+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
       jmp       near ptr M02_L22
M02_L84:
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       jne       near ptr M02_L24
M02_L85:
       inc       r13d
       mov       rcx,[r12+8]
       cmp       [rcx+8],r13d
       jne       short M02_L86
       xor       r13d,r13d
M02_L86:
       mov       eax,[rbp-1DC]
       inc       eax
       cmp       [rcx+8],eax
       mov       [rbp-1DC],eax
       jg        near ptr M02_L23
M02_L87:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-240]
       mov       r11,7F9A59E606F8
       call      qword ptr [r11]
       jmp       near ptr M02_L26
M02_L88:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L90
M02_L89:
       mov       rdi,7F9A59E5B1F8
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M02_L89
       mov       [rax+10],edi
M02_L90:
       dec       edi
       imul      r13d,edi,9E3779B9
       cmp       dword ptr [rbx+18],0
       jge       short M02_L91
       mov       r12d,r13d
       mov       r13d,[rbx+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M02_L92
M02_L91:
       and       r13d,[rbx+18]
M02_L92:
       mov       rdi,[rbx+8]
       lea       esi,[r13*8]
       cmp       esi,[rdi+8]
       jae       near ptr M02_L100
       lea       esi,[r13*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M02_L94
M02_L93:
       call      qword ptr [7F9A5BE86478]
       int       3
M02_L94:
       mov       rsi,[rbp-240]
       call      00007F9AD9274040
       test      rax,rax
       je        near ptr M02_L26
       mov       rdi,rbx
       mov       rsi,[rbp-240]
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7F9A5BDE74F8]
       jmp       near ptr M02_L26
M02_L95:
       mov       rdi,rbx
       call      qword ptr [7F9A5BDE7528]
       jmp       near ptr M02_L27
M02_L96:
       mov       rdi,r14
       mov       esi,r15d
       call      qword ptr [7F9A5B8DE7F0]
       mov       [rbp-228],rax
       mov       [rbp-220],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-228]
       vmovdqu   xmmword ptr [rbp-80],xmm0
       mov       rax,[rbp-80]
       mov       rdx,[rbp-78]
       add       rsp,298
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L97:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rax,[rsi+20]
       test      rax,rax
       je        short M02_L98
       mov       rdi,rax
       jmp       short M02_L99
M02_L98:
       mov       rsi,7F9A5BCE3870
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M02_L99:
       mov       [rbp-208],rdi
       lea       rdi,[rsp]
       lea       rsi,[rbp-60]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,[rbp-208]
       mov       rsi,r12
       mov       rdx,[rbp-238]
       mov       rcx,[rbp+18]
       mov       r8,[rbp-40]
       call      qword ptr [7F9A5B8DE718]
       mov       [rbp-200],rax
       mov       [rbp-1F8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-200]
       vmovdqu   xmmword ptr [rbp-70],xmm0
       mov       rax,[rbp-70]
       mov       rdx,[rbp-68]
       add       rsp,298
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L100:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
       sub       rsp,28
       vzeroupper
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-240]
       xor       edx,edx
       call      qword ptr [7F9A5B8DE958]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       r13,[rsi+28]
       test      r13,r13
       je        short M02_L101
       jmp       short M02_L102
M02_L101:
       mov       rsi,7F9A5BCE3AB0
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r13,rax
M02_L102:
       mov       rdi,[rbp-240]
       cmp       [rdi],edi
       call      qword ptr [7F9A5B8DE898]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       rcx,rax
       mov       rdi,r13
       mov       rdx,[rbp-238]
       mov       rsi,[rbp+18]
       call      qword ptr [7F9A5B8DE760]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-240]
       call      qword ptr [7F9A5B8DE8B0]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 4286
```
```assembly
; PoolContextProbe+<>c.<NestedContext>b__6_0(Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,378
       vzeroupper
       lea       rbp,[rsp+3A0]
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFD60
M03_L00:
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       add       rax,30
       jne       short M03_L00
       mov       [rbp-30],rax
       mov       rbx,rsi
       mov       rdi,7F9275800AB8
       mov       r15,[rdi]
       mov       rdi,7F9275800400
       mov       r14,[rdi]
       test      r15,r15
       je        near ptr M03_L58
M03_L01:
       mov       r13,rbx
       test      r13,r13
       je        near ptr M03_L59
       mov       rax,[r14+38]
       test      rax,rax
       jne       near ptr M03_L60
       cmp       byte ptr [r14+48],0
       jne       near ptr M03_L61
       mov       rbx,[r14+10]
       mov       r14,[r14+40]
       mov       rdi,7F9275801410
       mov       r12,[rdi]
       test      r12,r12
       je        near ptr M03_L62
M03_L02:
       mov       [rbp-2D8],r14
       mov       rcx,7F9275800BA0
       mov       rcx,[rcx]
       mov       rcx,[rcx+8]
       cmp       qword ptr [rcx+8],0
       jne       near ptr M03_L63
       xor       edi,edi
M03_L03:
       mov       [rbp-50],rdi
       mov       rdx,[r13+68]
       mov       [rbp-368],rdx
       test      rdx,rdx
       jne       near ptr M03_L64
M03_L04:
       mov       r14,[r13+68]
       mov       rdx,[r13+38]
       mov       [rbp-2F0],rdx
       mov       rdi,7F92758013C0
       mov       rsi,[rdi]
       mov       [rbp-300],rsi
       cmp       dword ptr [rsi+1C],0
       jne       near ptr M03_L65
M03_L05:
       mov       rsi,[rbp-300]
       mov       r8,[rsi+10]
       mov       [rbp-310],r8
       xor       r9d,r9d
       mov       [rbp-74],r9d
       test      r8,r8
       je        near ptr M03_L66
       mov       rdi,7F9AD94A0D68
       mov       r10,7F9AD9D06820
       call      r10
       add       rax,48
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M03_L75
M03_L06:
       dec       eax
       mov       rcx,[rbp-310]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M03_L76
       and       r8d,eax
M03_L07:
       mov       eax,r8d
       xor       r8d,r8d
M03_L08:
       mov       rdi,[rcx+8]
       mov       [rbp-7C],r8d
       cmp       [rdi+8],r8d
       jle       near ptr M03_L81
       cmp       eax,[rdi+8]
       jae       near ptr M03_L104
       mov       [rbp-78],eax
       mov       esi,eax
       mov       r9,[rdi+rsi*8+10]
       mov       [rbp-320],r9
       mov       r10,[r9+10]
       mov       [rbp-328],r10
       test      r10,r10
       jne       near ptr M03_L52
M03_L09:
       lea       r10,[r9+18]
       mov       rdx,[r9+8]
       mov       rdi,[r10]
       mov       esi,edi
       cmp       esi,0FFFFFFFF
       je        near ptr M03_L78
M03_L10:
       cmp       esi,[rdx+8]
       jae       near ptr M03_L104
       mov       r11d,esi
       shl       r11,4
       mov       r8d,[rdx+r11+18]
       mov       rax,rdi
       sar       rax,20
       inc       eax
       cdqe
       shl       rax,20
       or        r8,rax
       mov       rax,rdi
       lock cmpxchg [r10],r8
       cmp       rax,rdi
       jne       near ptr M03_L77
       mov       rax,[r9+8]
       mov       rdx,rax
       cmp       esi,[rdx+8]
       jae       near ptr M03_L104
       mov       rdx,[rdx+r11+10]
       cmp       esi,[rax+8]
       jae       near ptr M03_L104
       lea       rdi,[rax+r11+10]
       xor       eax,eax
       mov       [rdi],rax
       add       r9,20
M03_L11:
       mov       rax,[r9]
       mov       [rbp-88],rax
       mov       [rdi+8],eax
       mov       r8,rax
       sar       r8,20
       inc       r8d
       movsxd    r8,r8d
       shl       r8,20
       mov       r10d,esi
       or        r8,r10
       lock cmpxchg [r9],r8
       cmp       rax,[rbp-88]
       jne       short M03_L11
       test      rdx,rdx
       je        near ptr M03_L78
       mov       rax,[rbp-300]
M03_L12:
       test      rdx,rdx
       je        near ptr M03_L82
M03_L13:
       mov       rcx,rdx
M03_L14:
       cmp       dword ptr [rax+1C],0
       jne       near ptr M03_L84
       mov       rdx,rcx
M03_L15:
       mov       [rbp-2F8],rdx
       lea       rdi,[rdx+68]
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       xor       edi,edi
       mov       r14,[rbp-2F8]
       mov       [r14+60],edi
       lea       rdi,[r14+38]
       mov       rsi,[rbp-2F0]
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r14+30]
       mov       rsi,[rbp-2D8]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,0FFFFFFFF00000000
       mov       [r14+58],rdi
       xor       edi,edi
       mov       [r14+40],rdi
       cmp       qword ptr [r14+18],0
       je        near ptr M03_L85
M03_L16:
       mov       rdi,[r13+8]
       mov       rsi,[r14+18]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE77F8]; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       mov       rdi,[r14+18]
       mov       rsi,[r14+8]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE77F8]; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       mov       rdi,[r14+8]
       mov       rsi,[r13+8]
       cmp       [rdi],dil
       mov       rax,[rsi+28]
       add       rax,8
       lock inc  dword ptr [rax]
       mov       rsi,[rsi+28]
       lea       rdi,[rdi+28]
       call      CORINFO_HELP_ASSIGN_REF
       mov       byte ptr [r14+65],1
       mov       [rbp-2E0],r14
       mov       rdi,7F92758013E0
       mov       rax,[rdi]
       test      rax,rax
       je        near ptr M03_L86
M03_L17:
       mov       [rbp-0A8],rbx
       mov       [rbp-0A0],rax
       mov       [rbp-98],r15
       mov       [rbp-90],r12
       cmp       qword ptr [rbp-0A0],0
       je        near ptr M03_L87
       cmp       qword ptr [rbp-0A8],0
       jne       near ptr M03_L93
       mov       rbx,[rbp-0A0]
       mov       rdi,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       cmp       [rbx+18],rdi
       jne       near ptr M03_L92
       mov       rdi,[rbx+8]
       mov       rbx,[rbp-98]
       mov       r15,[rbp-90]
       mov       rdi,[rdi]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M03_L53
M03_L18:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-100],xmm0
       vmovdqu   xmmword ptr [rbp-0F8],xmm0
       mov       [rbp-0E8],rbx
       mov       [rbp-0E0],r15
       mov       [rbp-110],r14
       mov       dword ptr [rbp-108],0FFFFFFFF
       mov       rdi,[rsi+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M03_L54
M03_L19:
       mov       rsi,[rdi+18]
       mov       rbx,[rsi+10]
       test      rbx,rbx
       je        near ptr M03_L55
M03_L20:
       mov       rdi,7F9AD94A0D68
       mov       rax,7F9AD9D06820
       call      rax
       cmp       dword ptr [rax],4
       jle       near ptr M03_L88
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        near ptr M03_L88
M03_L21:
       mov       r15,[rax+10]
       test      r15,r15
       jne       short M03_L22
       call      qword ptr [7F9A5B52C3F0]; System.Threading.Thread.InitializeCurrentThread()
       mov       r15,rax
M03_L22:
       mov       [rbp-340],r15
       mov       rsi,[r15+8]
       mov       [rbp-348],rsi
       mov       rsi,[r15+10]
       mov       [rbp-350],rsi
       mov       rdi,[rbx+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M03_L24
M03_L23:
       lea       rdi,[rbp-110]
       call      rax
       jmp       short M03_L25
M03_L24:
       mov       rdi,rbx
       mov       rsi,7F9A5BDD8060
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M03_L23
M03_L25:
       mov       rsi,[rbp-350]
       cmp       rsi,[r15+10]
       je        short M03_L26
       lea       rdi,[r15+10]
       call      CORINFO_HELP_ASSIGN_REF
M03_L26:
       mov       rdi,[r15+8]
       mov       rbx,rdi
       mov       rsi,[rbp-348]
       cmp       rsi,rbx
       je        short M03_L28
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      rbx,rbx
       je        short M03_L27
       cmp       qword ptr [rbx+10],0
       jne       near ptr M03_L57
M03_L27:
       cmp       qword ptr [rbp-348],0
       jne       near ptr M03_L56
M03_L28:
       mov       rdi,[rbp-100]
       mov       rax,7F92758013E8
       cmp       rdi,[rax]
       jne       near ptr M03_L89
       mov       rbx,[rbp-0F8]
       mov       r15d,[rbp-0F0]
       xor       r12d,r12d
M03_L29:
       xor       eax,eax
       mov       ecx,1
M03_L30:
       test      r12,r12
       jne       near ptr M03_L95
M03_L31:
       test      rbx,rbx
       sete      r12b
       movzx     r12d,r12b
       xor       edi,edi
       mov       [rbp-1A8],rdi
       cmp       qword ptr [rbp-50],0
       jne       near ptr M03_L100
M03_L32:
       mov       rdi,7F9275800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M03_L101
M03_L33:
       mov       rdi,[r14+20]
       mov       [rbp-358],rdi
       xor       edi,edi
       mov       [rbp-23C],edi
       cmp       qword ptr [rbp-358],0
       je        near ptr M03_L39
       mov       rdi,[rbp-358]
       call      00007F9AD90E6020
       test      eax,eax
       je        short M03_L40
M03_L34:
       mov       dword ptr [rbp-23C],1
       cmp       byte ptr [r14+64],0
       jne       short M03_L41
       mov       r12,[r14+8]
M03_L35:
       mov       r14,[r14+18]
       mov       r13,[r13+8]
       mov       rdi,[r12+28]
       cmp       dword ptr [rdi+0C],0
       jne       short M03_L42
M03_L36:
       mov       rax,[r14+10]
       mov       [rbp-360],rax
       mov       rcx,[r14+38]
       mov       [rbp-370],rcx
       mov       rdx,[r14+40]
       mov       [rbp-378],rdx
       test      rax,rax
       jne       short M03_L43
M03_L37:
       cmp       qword ptr [r14+18],0
       jne       near ptr M03_L45
M03_L38:
       mov       rdi,r12
       mov       rsi,r14
       mov       rdx,r13
       call      qword ptr [7F9A5BDE79F0]; Kevlar.KevlarProperties.CopyChangedValuesTo(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       jmp       near ptr M03_L48
M03_L39:
       xor       edi,edi
       call      qword ptr [7F9A5BE864C0]
       int       3
M03_L40:
       mov       rdi,[rbp-358]
       call      qword ptr [7F9A5BE864F0]; System.Threading.Monitor.Enter_Slowpath(System.Object)
       jmp       near ptr M03_L34
M03_L41:
       mov       r12,[r14+10]
       jmp       short M03_L35
M03_L42:
       mov       rdi,[r14+28]
       cmp       dword ptr [rdi+0C],0
       jne       short M03_L36
       mov       rdi,[r13+28]
       cmp       dword ptr [rdi+0C],0
       jne       short M03_L36
       mov       rdi,[r13+28]
       mov       esi,1
       cmp       [rdi],edi
       call      qword ptr [7F9A5BE86A18]
       jmp       near ptr M03_L36
M03_L43:
       mov       rdi,rax
       mov       rsi,[rax]
       mov       rsi,[rsi+40]
       call      qword ptr [rsi+20]
       test      eax,eax
       je        short M03_L37
       mov       rsi,[rbp-370]
       mov       rdx,[rbp-378]
       mov       rdi,r12
       call      qword ptr [7F9A5BDE7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       test      rax,rax
       je        short M03_L44
       mov       rdi,rax
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       jne       near ptr M03_L37
M03_L44:
       mov       rsi,[rbp-370]
       mov       rdx,[rbp-378]
       mov       rdi,r13
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,[rbp-360]
       call      qword ptr [7F9A5BDE7A50]
       test      eax,eax
       je        near ptr M03_L37
       mov       rsi,[rbp-370]
       mov       rdx,[rbp-378]
       mov       rdi,r13
       call      qword ptr [7F9A5BDE7A68]
       jmp       near ptr M03_L37
M03_L45:
       mov       rdi,[r14+18]
       lea       rsi,[rbp-270]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE78A0]
       jmp       short M03_L47
M03_L46:
       mov       rdi,[rbp-258]
       vmovdqu   xmm0,xmmword ptr [rbp-258]
       vmovdqu   xmmword ptr [rbp-288],xmm0
       mov       rsi,[rbp-248]
       mov       [rbp-278],rsi
       mov       rsi,[rbp-280]
       mov       rdx,[rbp-278]
       mov       rcx,r12
       mov       r8,r13
       call      qword ptr [7F9A5BDE7A08]; Kevlar.KevlarProperties.RemoveMissingValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
M03_L47:
       lea       rdi,[rbp-270]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F9A5BDE7900]
       test      eax,eax
       jne       short M03_L46
       jmp       near ptr M03_L38
M03_L48:
       mov       rdi,[rbp-358]
       call      00007F9AD90E6790
       test      eax,eax
       je        short M03_L49
       mov       edi,eax
       mov       rsi,[rbp-358]
       call      qword ptr [7F9A5BE86508]
       nop
M03_L49:
       mov       rdi,7F92758013C0
       mov       rdi,[rdi]
       mov       rsi,[rbp-2E0]
       call      qword ptr [7F9A5BDE72A0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Return(System.__Canon)
       test      rbx,rbx
       jne       near ptr M03_L102
       xor       edi,edi
       mov       [rbp-48],rdi
       mov       [rbp-40],r15d
       mov       word ptr [rbp-3C],0
       mov       byte ptr [rbp-3A],1
M03_L50:
       vmovdqu   xmm0,xmmword ptr [rbp-48]
       vmovdqu   xmmword ptr [rbp-38],xmm0
M03_L51:
       mov       rax,[rbp-38]
       mov       rdx,[rbp-30]
       add       rsp,378
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M03_L52:
       lea       rdi,[r9+10]
       test      rdi,rdi
       je        near ptr M03_L80
       xor       esi,esi
       mov       rdx,r10
       call      00007F9AD9274060
       mov       r10,[rbp-328]
       cmp       rax,r10
       mov       r9,[rbp-320]
       jne       near ptr M03_L09
       mov       rdx,r10
       mov       rax,[rbp-300]
       jmp       near ptr M03_L12
M03_L53:
       mov       rsi,7F9A5BDD7000
       call      qword ptr [7F9A5AE4F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M03_L18
M03_L54:
       mov       rdi,rsi
       mov       rsi,7F9A5BDD7C78
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M03_L19
M03_L55:
       mov       rsi,7F9A5BDD7ED8
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rbx,rax
       jmp       near ptr M03_L20
M03_L56:
       mov       rsi,[rbp-348]
       cmp       qword ptr [rsi+10],0
       je        near ptr M03_L28
M03_L57:
       mov       rdi,rbx
       mov       rsi,[rbp-348]
       call      qword ptr [7F9A5BE86A60]
       jmp       near ptr M03_L28
M03_L58:
       mov       rdi,offset MT_System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rsi,7F9275800AA8
       mov       rsi,[rsi]
       mov       rdi,r15
       mov       rdx,offset PoolContextProbe+<>c.<NestedContext>b__6_1(Kevlar.KevlarContext)
       call      qword ptr [7F9A5AE46E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F9275800AB8
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M03_L01
M03_L59:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,910
       mov       rsi,7F9A5B90D998
       call      qword ptr [7F9A5AE4EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F9A5B52E2B0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M03_L60:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       rsi,rbx
       mov       rdx,r15
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7570]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](Kevlar.KevlarContext, System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
       mov       [rbp-2D0],rax
       mov       [rbp-2C8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-2D0]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       jmp       near ptr M03_L51
M03_L61:
       call      qword ptr [7F9A5B8DE508]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M03_L62:
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       rsi,7F9275801408
       mov       rsi,[rsi]
       mov       rdi,r12
       mov       rdx,offset Kevlar.Shield+<>c__60`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__60_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F9A5AE46E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F9275801410
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M03_L02
M03_L63:
       call      00007F9A5AE38AE0
       mov       rdi,rax
       jmp       near ptr M03_L03
M03_L64:
       cmp       dword ptr [rdx+20],0
       je        near ptr M03_L04
       mov       rsi,r14
       xor       edx,edx
       call      qword ptr [7F9A5B8DE868]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rdi,rbx
       call      qword ptr [7F9A5BE87108]
       lea       rdi,[rbx+70]
       mov       rsi,[rbp-368]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,rbx
       call      qword ptr [7F9A5B8DE8E0]
       mov       rdi,rax
       mov       esi,edx
       call      qword ptr [7F9A5B8DE7F0]
       mov       [rbp-2C0],rax
       mov       [rbp-2B8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-2C0]
       vmovdqu   xmmword ptr [rbp-48],xmm0
       jmp       near ptr M03_L50
M03_L65:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F9A5BDE67C0]
       jmp       near ptr M03_L05
M03_L66:
       mov       rdi,7F9AD94A0D68
       mov       r9,7F9AD9D06820
       call      r9
       add       rax,3C
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M03_L68
M03_L67:
       mov       rdi,7F9A59E5B1F8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M03_L67
       mov       [rax+10],edi
M03_L68:
       dec       edi
       imul      edi,9E3779B9
       mov       rax,[rbp-300]
       mov       edx,[rax+18]
       test      edx,edx
       jge       short M03_L69
       mov       r9d,edi
       mov       esi,[rax+20]
       imul      r9,rsi
       shr       r9,20
       jmp       short M03_L70
M03_L69:
       mov       r9d,edi
       and       r9d,edx
M03_L70:
       mov       ecx,r9d
       mov       rdi,[rax+8]
       mov       [rbp-74],ecx
       lea       edx,[rcx*8]
       cmp       edx,[rdi+8]
       jae       near ptr M03_L104
       lea       rdi,[rdi+rdx*8+10]
       mov       r8,[rdi]
       mov       rdx,r8
       mov       [rbp-318],rdx
       test      rdx,rdx
       je        short M03_L72
       xor       esi,esi
       call      00007F9AD9274060
       mov       rdi,[rbp-318]
       cmp       rax,rdi
       mov       rax,[rbp-300]
       je        short M03_L73
M03_L71:
       xor       edx,edx
       jmp       short M03_L74
M03_L72:
       mov       rax,[rbp-300]
       jmp       short M03_L71
M03_L73:
       mov       rdx,rdi
M03_L74:
       jmp       near ptr M03_L12
M03_L75:
       mov       rax,7F9A59E5B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-80],eax
       test      eax,eax
       je        short M03_L75
       mov       rdi,7F9AD94A0D68
       mov       rcx,7F9AD9D06820
       call      rcx
       add       rax,48
       mov       ecx,[rbp-80]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M03_L06
M03_L76:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M03_L07
M03_L77:
       mov       rdi,[r10]
       mov       esi,edi
       cmp       esi,0FFFFFFFF
       jne       near ptr M03_L10
M03_L78:
       mov       eax,[rbp-78]
       inc       eax
       mov       edx,eax
       mov       rcx,[rbp-310]
       mov       rax,[rcx+8]
       cmp       [rax+8],edx
       jne       short M03_L79
       xor       edx,edx
M03_L79:
       mov       r8d,[rbp-7C]
       inc       r8d
       mov       eax,edx
       mov       rcx,[rbp-310]
       jmp       near ptr M03_L08
M03_L80:
       call      qword ptr [7F9A5BE86478]
       int       3
M03_L81:
       xor       edx,edx
       mov       rax,[rbp-300]
       jmp       near ptr M03_L12
M03_L82:
       cmp       qword ptr [rbp-310],0
       je        short M03_L83
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       rcx,rax
       mov       [rbp-330],rcx
       mov       rdi,rcx
       call      qword ptr [7F9A5BDE6868]; Kevlar.KevlarContext..ctor()
       mov       rcx,[rbp-330]
       mov       rax,rcx
       mov       rcx,rax
       mov       rax,[rbp-300]
       jmp       near ptr M03_L14
M03_L83:
       mov       rdi,rax
       mov       esi,[rbp-74]
       call      qword ptr [7F9A5BDE6820]
       mov       rdx,rax
       mov       rax,[rbp-300]
       jmp       near ptr M03_L13
M03_L84:
       mov       [rbp-308],rcx
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-300]
       mov       dil,[rdi+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-308]
       mov       r11,7F9A59E605E8
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F9A5BDE67C0]
       mov       rdx,rax
       jmp       near ptr M03_L15
M03_L85:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-2E8],rax
       mov       rdi,rax
       call      qword ptr [7F9A5BDE6880]; Kevlar.KevlarProperties..ctor()
       lea       rdi,[r14+18]
       mov       rsi,[rbp-2E8]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M03_L16
M03_L86:
       mov       rdi,offset MT_System.Func<Kevlar.Internal.ShieldEngine+ContextAsyncCallback<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, System.Int32>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<Kevlar.Outcome<System.Int32>>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-338],rax
       mov       rsi,7F92758013D8
       mov       rsi,[rsi]
       mov       rdi,rax
       mov       rdx,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       call      qword ptr [7F9A5AE46E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F92758013E0
       mov       rsi,[rbp-338]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-338]
       jmp       near ptr M03_L17
M03_L87:
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       rdi,r12
       mov       rsi,7F9A58A0B5D8
       call      qword ptr [7F9A5B525608]
       mov       rdi,r12
       call      qword ptr [7F9A5B8DE8E0]
       mov       ecx,edx
       xor       r12d,r12d
       xor       ebx,ebx
       mov       [rbp-28C],ebx
       mov       dword ptr [rbp-290],1
       mov       rbx,rax
       mov       r15d,ecx
       mov       eax,[rbp-28C]
       mov       ecx,[rbp-290]
       jmp       near ptr M03_L30
M03_L88:
       mov       edi,4
       call      qword ptr [7F9A5BE86490]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       near ptr M03_L21
M03_L89:
       mov       r12,[rbp-100]
       test      r12,r12
       jne       short M03_L90
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       rdi,r12
       call      qword ptr [7F9A5BE86A78]
       mov       [rbp-100],r12
M03_L90:
       test      r12,r12
       jne       short M03_L91
       mov       edi,9
       call      qword ptr [7F9A5AE4FAE0]
       int       3
M03_L91:
       xor       ebx,ebx
       xor       r15d,r15d
       jmp       near ptr M03_L29
M03_L92:
       mov       rdx,[rbp-98]
       mov       rcx,[rbp-90]
       lea       rsi,[rbp-0C8]
       mov       r8,r14
       mov       rdi,[rbx+8]
       call      qword ptr [rbx+18]
       jmp       short M03_L94
M03_L93:
       lea       rdi,[rbp-0A8]
       lea       rsi,[rbp-0C8]
       mov       r8,r14
       mov       rcx,[rbp-0A8]
       mov       rdx,offset MT_Kevlar.Continuation<System.Int32, Kevlar.Internal.ShieldEngine+ContextAsyncCallback<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, System.Int32>>
       call      qword ptr [7F9A5BDE6A30]
M03_L94:
       mov       r12,[rbp-0C8]
       movsx     rax,word ptr [rbp-0C0]
       mov       ebx,eax
       movzx     ecx,byte ptr [rbp-0BE]
       mov       r15d,ecx
       mov       rdi,[rbp-0B8]
       mov       rax,rdi
       mov       edi,[rbp-0B0]
       mov       ecx,edi
       mov       rdx,rax
       mov       eax,ebx
       mov       rbx,rdx
       mov       edx,ecx
       mov       ecx,r15d
       mov       r15d,edx
       jmp       near ptr M03_L30
M03_L95:
       mov       [rbp-28C],eax
       mov       [rbp-290],ecx
       mov       rsi,r12
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F9A5AE46838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       test      rax,rax
       je        short M03_L96
       mov       rdi,rax
       call      qword ptr [7F9A5BDE7138]
       jmp       short M03_L97
M03_L96:
       mov       rdi,r12
       mov       esi,[rbp-28C]
       mov       r11,7F9A59E605F0
       call      qword ptr [r11]
       cmp       eax,1
       sete      al
       movzx     eax,al
M03_L97:
       test      eax,eax
       je        near ptr M03_L103
       mov       rsi,r12
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F9A5AE46838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       rbx,rax
       test      rbx,rbx
       je        short M03_L99
       mov       edi,[rbx+34]
       and       edi,11000000
       cmp       edi,1000000
       je        short M03_L98
       mov       rdi,rbx
       xor       esi,esi
       call      qword ptr [7F9A5BE86430]
M03_L98:
       mov       rdi,[rbx+38]
       mov       r15d,[rbx+40]
       mov       rbx,rdi
       jmp       near ptr M03_L31
M03_L99:
       mov       rdi,r12
       mov       esi,[rbp-28C]
       mov       r11,7F9A59E605F8
       call      qword ptr [r11]
       mov       rbx,rax
       mov       r15d,edx
       jmp       near ptr M03_L31
M03_L100:
       mov       rdi,7F9275800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F9A5B8DE9B8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M03_L32
       lea       rdi,[rbp-1A0]
       mov       rsi,[rbp-2D8]
       call      qword ptr [7F9A5BDE71F8]
       mov       rdx,7F9A58A0B6A8
       mov       rdi,7F9A58A0B680
       test      r12d,r12d
       cmove     rdx,rdi
       lea       rdi,[rbp-1A0]
       mov       rsi,7F9A58A0B638
       call      qword ptr [7F9A5BDE7210]
       call      00007F9A5AE38AE0
       mov       rsi,rax
       mov       rdi,[rbp-50]
       call      qword ptr [7F9A5BE86CD0]
       mov       [rbp-1A8],rax
       lea       rdi,[rbp-1A8]
       call      qword ptr [7F9A5BDE7240]
       mov       rdi,7F9275800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-1A0]
       xor       edx,edx
       call      qword ptr [7F9A5BDE7258]
       jmp       near ptr M03_L32
M03_L101:
       lea       rdi,[rbp-238]
       mov       rsi,[rbp-2D8]
       call      qword ptr [7F9A5BDE71F8]
       mov       rdx,7F9A58A0B6A8
       mov       rdi,7F9A58A0B680
       test      r12d,r12d
       cmove     rdx,rdi
       lea       rdi,[rbp-238]
       mov       rsi,7F9A58A0B638
       call      qword ptr [7F9A5BDE7210]
       mov       rdi,7F9275800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-238]
       mov       esi,1
       xor       ecx,ecx
       call      qword ptr [7F9A5BDE7270]
       jmp       near ptr M03_L33
M03_L102:
       mov       rdi,rbx
       mov       esi,r15d
       call      qword ptr [7F9A5B8DE7F0]
       mov       [rbp-2B0],rax
       mov       [rbp-2A8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-2B0]
       vmovdqu   xmmword ptr [rbp-48],xmm0
       jmp       near ptr M03_L50
M03_L103:
       mov       [rbp-70],r12
       mov       r12d,[rbp-28C]
       mov       [rbp-68],r12w
       mov       r12d,[rbp-290]
       mov       [rbp-66],r12b
       mov       [rbp-60],rbx
       mov       [rbp-58],r15d
       lea       rdi,[rsp]
       lea       rsi,[rbp-70]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,r14
       mov       rsi,r13
       mov       rdx,[rbp-50]
       call      qword ptr [7F9A5BDE7708]
       mov       [rbp-2A0],rax
       mov       [rbp-298],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-2A0]
       vmovdqu   xmmword ptr [rbp-48],xmm0
       jmp       near ptr M03_L50
M03_L104:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
       sub       rsp,28
       vzeroupper
       mov       rsi,[rbp-350]
       mov       rax,[rbp-340]
       cmp       rsi,[rax+10]
       je        short M03_L105
       lea       rdi,[rax+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-340]
M03_L105:
       mov       r14,[rax+8]
       mov       rsi,[rbp-348]
       cmp       rsi,r14
       je        short M03_L108
       lea       rdi,[rax+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      r14,r14
       je        short M03_L106
       cmp       qword ptr [r14+10],0
       jne       short M03_L107
M03_L106:
       cmp       qword ptr [rbp-348],0
       je        short M03_L108
       mov       rsi,[rbp-348]
       cmp       qword ptr [rsi+10],0
       je        short M03_L108
M03_L107:
       mov       rdi,r14
       mov       rsi,[rbp-348]
       call      qword ptr [7F9A5BE86A60]
M03_L108:
       nop
       add       rsp,28
       ret
       sub       rsp,28
       vzeroupper
       cmp       dword ptr [rbp-23C],0
       je        short M03_L110
       cmp       qword ptr [rbp-358],0
       jne       short M03_L109
       xor       edi,edi
       call      qword ptr [7F9A5BE864C0]
       int       3
M03_L109:
       mov       rdi,[rbp-358]
       call      00007F9AD90E6790
       test      eax,eax
       je        short M03_L110
       mov       edi,eax
       mov       rsi,[rbp-358]
       call      qword ptr [7F9A5BE86508]
M03_L110:
       nop
       add       rsp,28
       ret
       sub       rsp,28
       vzeroupper
       mov       rdi,7F92758013C0
       mov       rdi,[rdi]
       mov       rsi,[rbp-2E0]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE72A0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Return(System.__Canon)
       nop
       add       rsp,28
       ret
; Total bytes of code 4536
```
```assembly
; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       push      r15
       push      r14
       push      rbx
       mov       rbx,rdi
       mov       r15,rsi
       mov       r14,rdx
       test      r15,r15
       je        short M04_L00
       mov       rdi,7F9A5BF0460C
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdi,[rbx+8]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       [rbx+18],r14
       pop       rbx
       pop       r14
       pop       r15
       ret
M04_L00:
       mov       rdi,7F9A5BF04608
       call      CORINFO_HELP_COUNTPROFILE32
       call      qword ptr [7F9A5BE8E040]
       int       3
; Total bytes of code 78
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       ret
; Total bytes of code 1
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       rax,rsi
       mov       rsi,rdx
       mov       rdi,offset PoolContextProbe+<>c.<NestedContext>b__6_0(Kevlar.KevlarContext)
       cmp       [rax+18],rdi
       jne       short M06_L00
       mov       rdi,[rax+8]
       jmp       qword ptr [7F9A5BDE7558]; PoolContextProbe+<>c.<NestedContext>b__6_0(Kevlar.KevlarContext)
M06_L00:
       mov       rdi,[rax+8]
       jmp       qword ptr [rax+18]
; Total bytes of code 40
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
M07_L00:
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,58
       lea       rbp,[rsp+80]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       mov       [rbp-30],rsi
       mov       rbx,rsi
       mov       r13,rdx
       mov       r15,rcx
       mov       r14,r8
       mov       r12,r9
       test      r15,r15
       je        near ptr M07_L06
       test      r14,r14
       je        near ptr M07_L07
       mov       rax,[rdi+38]
       test      rax,rax
       jne       near ptr M07_L08
       cmp       byte ptr [rdi+48],0
       jne       near ptr M07_L09
       mov       rax,[rdi+10]
       mov       [rbp-58],rax
       xor       ecx,ecx
       test      rcx,rcx
       cmove     rcx,rdi
       mov       rcx,[rcx+20]
       mov       rdx,7F9275800B00
       test      rcx,rcx
       cmove     rcx,[rdx]
       mov       [rbp-60],rcx
       mov       rdx,[rdi+38]
       test      rdx,rdx
       jne       near ptr M07_L10
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rdi+40]
M07_L01:
       mov       rdi,[rbx+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        short M07_L04
M07_L02:
       mov       rdx,[rdi+18]
       mov       rdx,[rdx+18]
       test      rdx,rdx
       je        near ptr M07_L05
       mov       rdi,rdx
       mov       [rbp-68],rsi
M07_L03:
       mov       [rsp],r14
       xor       edx,edx
       mov       [rsp+8],rdx
       mov       [rsp+10],r12
       mov       rsi,rax
       mov       rdx,rcx
       mov       rcx,[rbp-68]
       mov       r8,r13
       mov       r9,r15
       call      qword ptr [7F9A5B8DE598]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       mov       [rbp-50],rax
       mov       [rbp-48],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-50]
       vmovdqu   xmmword ptr [rbp-40],xmm0
       mov       rax,[rbp-40]
       mov       rdx,[rbp-38]
       add       rsp,58
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M07_L04:
       mov       [rbp-60],rcx
       mov       [rbp-68],rsi
       mov       rdi,rbx
       mov       rsi,7F9A5BCE2E88
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rbp-68]
       jmp       near ptr M07_L02
M07_L05:
       mov       [rbp-60],rcx
       mov       [rbp-68],rsi
       mov       rsi,7F9A5BCE3240
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       jmp       near ptr M07_L03
M07_L06:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,92C
       mov       rsi,7F9A5B90D998
       call      qword ptr [7F9A5AE4EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F9A5B52E2B0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M07_L07:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,902
       mov       rsi,7F9A5B90D998
       call      qword ptr [7F9A5AE4EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F9A5B52E2B0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M07_L08:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       rsi,rbx
       mov       rdx,r13
       mov       rcx,r15
       mov       r8,r14
       mov       r9,r12
       cmp       [rdi],edi
       add       rsp,58
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F9A5B8DE340]
M07_L09:
       call      qword ptr [7F9A5B8DE508]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M07_L10:
       mov       rdi,[rdx+8]
       call      qword ptr [rdx+18]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F9A5B8DE4F0]; Kevlar.Shield.get_Name()
       mov       [rbp-68],rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rbp-68]
       jmp       near ptr M07_L01
; Total bytes of code 583
```
```assembly
; Kevlar.Shield.get_Name()
       push      rbp
       mov       rbp,rsp
M08_L00:
       mov       rax,[rdi+38]
       test      rax,rax
       jne       short M08_L01
       mov       rax,[rdi+40]
       pop       rbp
       ret
M08_L01:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       jmp       short M08_L00
; Total bytes of code 31
```
```assembly
; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       push      rbp
       mov       rbp,rsp
       test      rsi,rsi
       je        short M09_L02
       mov       rax,[rsi]
       cmp       rax,rdi
       je        short M09_L02
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
M09_L00:
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       jne       short M09_L03
M09_L01:
       xor       esi,esi
M09_L02:
       mov       rax,rsi
       pop       rbp
       ret
M09_L03:
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       jmp       short M09_L00
; Total bytes of code 91
```
```assembly
; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,128
       lea       rbp,[rsp+150]
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFF10
M10_L00:
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       add       rax,30
       jne       short M10_L00
       mov       [rbp-30],rsi
       mov       [rbp-128],r8
       mov       rbx,rdi
       mov       r15,rsi
       mov       r13,rdx
       mov       r12,rcx
       mov       r14,r9
       mov       rdi,[r15+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M10_L19
M10_L01:
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rax+8]
       test      rax,rax
       je        near ptr M10_L24
M10_L02:
       mov       [rbp-50],r13
       mov       [rbp-48],rax
       mov       [rbp-40],r12
       mov       r13,[rbp-128]
       mov       [rbp-38],r13
       mov       rdi,[r15+18]
       mov       rdx,[rdi+28]
       test      rdx,rdx
       je        near ptr M10_L20
M10_L03:
       mov       rax,[rbp-48]
       test      rax,rax
       je        near ptr M10_L31
       cmp       qword ptr [rbp-50],0
       jne       near ptr M10_L36
       mov       rdi,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       cmp       [rax+18],rdi
       jne       near ptr M10_L35
       mov       rdi,[rax+8]
       mov       r15,[rbp-40]
       mov       r13,[rbp-38]
       mov       rdi,[rdi]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M10_L21
M10_L04:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0B0],xmm0
       vmovdqu   xmmword ptr [rbp-0A8],xmm0
       mov       [rbp-98],r15
       mov       [rbp-90],r13
       mov       [rbp-0C0],r14
       mov       dword ptr [rbp-0B8],0FFFFFFFF
       mov       rdi,[rsi+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M10_L22
M10_L05:
       mov       rsi,[rdi+18]
       mov       r14,[rsi+10]
       test      r14,r14
       je        near ptr M10_L23
M10_L06:
       mov       rdi,7F9AD94A0D68
       mov       rax,7F9AD9D06820
       call      rax
       cmp       dword ptr [rax],4
       jle       near ptr M10_L32
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        near ptr M10_L32
M10_L07:
       mov       r15,[rax+10]
       test      r15,r15
       jne       short M10_L08
       call      qword ptr [7F9A5B52C3F0]; System.Threading.Thread.InitializeCurrentThread()
       mov       r15,rax
M10_L08:
       mov       [rbp-138],r15
       mov       rsi,[r15+8]
       mov       [rbp-140],rsi
       mov       rsi,[r15+10]
       mov       [rbp-148],rsi
       mov       rdi,[r14+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M10_L10
M10_L09:
       lea       rdi,[rbp-0C0]
       call      rax
       jmp       short M10_L11
M10_L10:
       mov       rdi,r14
       mov       rsi,7F9A5BDD8060
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M10_L09
M10_L11:
       mov       rsi,[rbp-148]
       cmp       rsi,[r15+10]
       je        short M10_L12
       lea       rdi,[r15+10]
       call      CORINFO_HELP_ASSIGN_REF
M10_L12:
       mov       rdi,[r15+8]
       mov       r14,rdi
       mov       rsi,[rbp-140]
       cmp       rsi,r14
       je        short M10_L14
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      r14,r14
       je        short M10_L13
       cmp       qword ptr [r14+10],0
       jne       near ptr M10_L18
M10_L13:
       cmp       qword ptr [rbp-140],0
       jne       near ptr M10_L17
M10_L14:
       mov       rdi,[rbp-0B0]
       mov       rax,7F92758013E8
       cmp       rdi,[rax]
       jne       near ptr M10_L33
       vmovdqu   xmm0,xmmword ptr [rbp-0A8]
       vmovdqu   xmmword ptr [rbp-110],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-120]
       vmovdqu   ymmword ptr [rbp-0E0],ymm0
       xor       r15d,r15d
M10_L15:
       vmovdqu   ymm0,ymmword ptr [rbp-0E0]
       vmovdqu   ymmword ptr [rbp-78],ymm0
       xor       r14d,r14d
       mov       r13d,1
M10_L16:
       mov       [rbp-78],r15
       vmovdqu   ymm0,ymmword ptr [rbp-78]
       vmovdqu   ymmword ptr [rbx],ymm0
       mov       [rbx+8],r14w
       mov       [rbx+0A],r13b
       mov       rax,rbx
       vzeroupper
       add       rsp,128
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M10_L17:
       mov       rsi,[rbp-140]
       cmp       qword ptr [rsi+10],0
       je        near ptr M10_L14
M10_L18:
       mov       rdi,r14
       mov       rsi,[rbp-140]
       call      qword ptr [7F9A5BE86A60]
       jmp       near ptr M10_L14
M10_L19:
       mov       rdi,r15
       mov       rsi,7F9A5BDD6718
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M10_L01
M10_L20:
       mov       rdi,r15
       mov       rsi,7F9A5BDD6830
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdx,rax
       jmp       near ptr M10_L03
M10_L21:
       mov       rsi,7F9A5BDD7000
       call      qword ptr [7F9A5AE4F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M10_L04
M10_L22:
       mov       rdi,rsi
       mov       rsi,7F9A5BDD7C78
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M10_L05
M10_L23:
       mov       rsi,7F9A5BDD7ED8
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r14,rax
       jmp       near ptr M10_L06
M10_L24:
       mov       rdi,[r15+18]
       mov       rax,[rdi+18]
       test      rax,rax
       je        short M10_L25
       mov       [rbp-58],rax
       jmp       short M10_L26
M10_L25:
       mov       rdi,r15
       mov       rsi,7F9A5BDD6718
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-58],rax
M10_L26:
       mov       rdi,[r15+18]
       mov       rdi,[rdi+30]
       test      rdi,rdi
       je        short M10_L27
       jmp       short M10_L28
M10_L27:
       mov       rdi,r15
       mov       rsi,7F9A5BDD6A10
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M10_L28:
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-130],rax
       mov       rdi,[rbp-58]
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rax]
       mov       rdi,[rbp-130]
       mov       rdx,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       call      qword ptr [7F9A5AE46E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,[r15+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        short M10_L29
       jmp       short M10_L30
M10_L29:
       mov       rdi,r15
       mov       rsi,7F9A5BDD6718
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M10_L30:
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       lea       rdi,[rax+8]
       mov       rsi,[rbp-130]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-130]
       jmp       near ptr M10_L02
M10_L31:
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       mov       rsi,7F9A58A0B5D8
       call      qword ptr [7F9A5B525608]
       mov       rdi,r15
       call      qword ptr [7F9A5B8DE8E0]
       xor       r15d,r15d
       xor       r14d,r14d
       mov       r13d,1
       mov       [rbp-68],rax
       mov       [rbp-60],edx
       jmp       near ptr M10_L16
M10_L32:
       mov       edi,4
       call      qword ptr [7F9A5BE86490]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       near ptr M10_L07
M10_L33:
       mov       r15,[rbp-0B0]
       test      r15,r15
       jne       short M10_L34
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       call      qword ptr [7F9A5BE86A78]
       mov       [rbp-0B0],r15
M10_L34:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0F0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-100]
       vmovdqu   ymmword ptr [rbp-0E0],ymm0
       jmp       near ptr M10_L15
M10_L35:
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-38]
       lea       rsi,[rbp-78]
       mov       r8,r14
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       jmp       short M10_L37
M10_L36:
       lea       rdi,[rbp-50]
       lea       rsi,[rbp-78]
       mov       rcx,[rbp-50]
       mov       r8,r14
       call      qword ptr [7F9A5BDE6A30]
M10_L37:
       mov       r15,[rbp-78]
       movsx     r14,word ptr [rbp-70]
       movzx     r13d,byte ptr [rbp-6E]
       jmp       near ptr M10_L16
       push      rax
       mov       rsi,[rbp-148]
       mov       rax,[rbp-138]
       cmp       rsi,[rax+10]
       je        short M10_L38
       lea       rdi,[rax+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-138]
M10_L38:
       mov       rbx,[rax+8]
       mov       rsi,[rbp-140]
       cmp       rsi,rbx
       je        short M10_L41
       lea       rdi,[rax+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      rbx,rbx
       je        short M10_L39
       cmp       qword ptr [rbx+10],0
       jne       short M10_L40
M10_L39:
       cmp       qword ptr [rbp-140],0
       je        short M10_L41
       mov       rsi,[rbp-140]
       cmp       qword ptr [rsi+10],0
       je        short M10_L41
M10_L40:
       mov       rdi,rbx
       mov       rsi,[rbp-140]
       call      qword ptr [7F9A5BE86A60]
M10_L41:
       nop
       vzeroupper
       add       rsp,8
       ret
; Total bytes of code 1394
```
```assembly
; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       push      rbp
       mov       rbp,rsp
       mov       rax,rsi
       test      rax,rax
       je        short M11_L00
       mov       rsi,rdx
       mov       rdx,rcx
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       nop
M11_L00:
       pop       rbp
       ret
       push      rax
       lea       rax,[M11_L00]
       add       rsp,8
       ret
; Total bytes of code 41
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-48],rax
       mov       [rbp-30],rdi
       mov       [rbp-68],rdi
       mov       [rbp-70],rsi
       cmp       [rdi],dil
       xor       eax,eax
       mov       [rsi+68],rax
       mov       [rsi+60],eax
       mov       [rsi+30],rax
       mov       rax,0FFFFFFFF00000000
       mov       [rsi+58],rax
       xor       eax,eax
       mov       [rsi+40],rax
       mov       [rsi+48],rax
       mov       [rsi+50],rax
       mov       rax,[rsi+28]
       test      rax,rax
       jne       near ptr M12_L11
M12_L00:
       mov       rax,7F9275800B00
       mov       rsi,[rax]
       mov       rbx,[rbp-70]
       lea       rdi,[rbx+38]
       call      CORINFO_HELP_ASSIGN_REF
       mov       r15,[rbx+8]
       xor       edi,edi
       mov       [r15+20],rdi
       cmp       byte ptr [r15+34],0
       jne       near ptr M12_L12
M12_L01:
       mov       rdi,[r15+28]
       mov       rax,[r15+8]
       cmp       rdi,rax
       jne       short M12_L07
       cmp       dword ptr [rax+8],1
       jne       near ptr M12_L31
M12_L02:
       mov       rdi,[r15+8]
       xor       eax,eax
       mov       [rdi+0C],eax
       mov       [rdi+10],eax
       mov       rdi,[rbx+8]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7378]; Kevlar.KevlarProperties.Clear()
       cmp       qword ptr [rbx+10],0
       jne       near ptr M12_L57
M12_L03:
       mov       r15,[rbx+18]
       test      r15,r15
       je        short M12_L06
       cmp       byte ptr [r15+34],0
       jne       near ptr M12_L58
M12_L04:
       mov       rdi,[r15+28]
       mov       rax,[r15+8]
       cmp       rdi,rax
       jne       short M12_L09
       cmp       dword ptr [rax+8],1
       jne       near ptr M12_L74
M12_L05:
       mov       rdi,[r15+8]
       xor       eax,eax
       mov       [rdi+0C],eax
       mov       [rdi+10],eax
       mov       rdi,[rbx+18]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7378]; Kevlar.KevlarProperties.Clear()
M12_L06:
       mov       word ptr [rbx+64],0
       jmp       near ptr M12_L76
M12_L07:
       mov       r14,[r15+28]
       lea       rdi,[r14+8]
       mov       eax,0FFFFFFFF
       lock xadd [rdi],eax
       dec       eax
       je        short M12_L13
M12_L08:
       mov       rsi,[r15+8]
       lea       rdi,[r15+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M12_L02
M12_L09:
       mov       r14,[r15+28]
       lea       rdi,[r14+8]
       mov       eax,0FFFFFFFF
       lock xadd [rdi],eax
       dec       eax
       je        near ptr M12_L59
M12_L10:
       mov       rsi,[r15+8]
       lea       rdi,[r15+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M12_L05
M12_L11:
       mov       rdi,rax
       call      qword ptr [7F9A5BE1EA88]
       jmp       near ptr M12_L00
M12_L12:
       mov       rdi,[r15+28]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7390]
       mov       byte ptr [r15+34],0
       jmp       near ptr M12_L01
M12_L13:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F92758013D0
       mov       r13,[rdi]
       cmp       dword ptr [r13+1C],0
       je        short M12_L14
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r13+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F9A59E60568
       call      qword ptr [r11]
       jmp       near ptr M12_L08
M12_L14:
       mov       rdi,r13
       mov       rsi,r14
       call      qword ptr [7F9A5BE869A0]
       test      eax,eax
       jne       short M12_L15
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r13+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F9A59E60570
       call      qword ptr [r11]
       jmp       near ptr M12_L08
M12_L15:
       mov       r12,[r13+10]
       test      r12,r12
       je        near ptr M12_L25
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L17
M12_L16:
       mov       rax,7F9A59E5B1E8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-3C],eax
       test      eax,eax
       je        short M12_L16
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-3C]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L17:
       dec       eax
       cmp       dword ptr [r12+18],0
       jl        short M12_L18
       and       eax,[r12+18]
       jmp       short M12_L19
M12_L18:
       mov       rdi,[r12+8]
       mov       edi,[rdi+8]
       mov       eax,eax
       imul      rax,[r12+10]
       shr       rax,20
       inc       rax
       imul      rax,rdi
       shr       rax,20
M12_L19:
       xor       ecx,ecx
       jmp       short M12_L22
M12_L20:
       mov       rdi,[r12+8]
       cmp       eax,[rdi+8]
       jae       near ptr M12_L75
       mov       [rbp-34],eax
       mov       esi,eax
       mov       r8,[rdi+rsi*8+10]
       mov       [rbp-78],r8
       cmp       [r8],r8b
       lea       rdi,[r8+10]
       test      rdi,rdi
       je        near ptr M12_L69
       mov       rsi,r14
       xor       edx,edx
       call      00007F9AD9274060
       test      rax,rax
       je        short M12_L23
       mov       rdx,r14
       mov       rsi,[rbp-78]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F9A5B8DDF38]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M12_L23
       mov       eax,[rbp-34]
       inc       eax
       mov       edi,eax
       mov       rax,[r12+8]
       cmp       [rax+8],edi
       jne       short M12_L21
       xor       edi,edi
M12_L21:
       mov       ecx,[rbp-38]
       inc       ecx
       mov       eax,edi
M12_L22:
       mov       rdi,[r12+8]
       mov       [rbp-38],ecx
       cmp       [rdi+8],ecx
       jg        short M12_L20
       jmp       short M12_L24
M12_L23:
       cmp       dword ptr [r13+1C],0
       je        near ptr M12_L08
       jmp       near ptr M12_L30
M12_L24:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r13+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F9A59E60578
       call      qword ptr [r11]
       jmp       short M12_L23
M12_L25:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M12_L27
M12_L26:
       mov       rdi,7F9A59E5B1E0
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M12_L26
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M12_L27:
       dec       r12d
       imul      r12d,9E3779B9
       cmp       dword ptr [r13+18],0
       jge       short M12_L28
       mov       eax,[r13+20]
       imul      r12,rax
       shr       r12,20
       jmp       short M12_L29
M12_L28:
       and       r12d,[r13+18]
M12_L29:
       mov       rdi,[r13+8]
       lea       esi,[r12*8]
       cmp       esi,[rdi+8]
       jae       near ptr M12_L75
       lea       esi,[r12*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       je        near ptr M12_L69
       mov       rsi,r14
       call      00007F9AD9274040
       test      rax,rax
       je        near ptr M12_L23
       mov       rdi,r13
       mov       rsi,r14
       mov       rdx,rax
       mov       ecx,r12d
       call      qword ptr [7F9A5BE869B8]
       jmp       near ptr M12_L23
M12_L30:
       mov       rdi,r13
       call      qword ptr [7F9A5BE869D0]
       jmp       near ptr M12_L08
M12_L31:
       mov       rdi,[r15+8]
       call      qword ptr [7F9A5BDE73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F92758013D0
       mov       r14,[rdi]
       cmp       dword ptr [r14+1C],0
       je        short M12_L32
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F9A5BE869E8]
M12_L32:
       mov       r13,[r14+10]
       xor       r12d,r12d
       test      r13,r13
       jne       near ptr M12_L39
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M12_L34
M12_L33:
       mov       rdi,7F9A59E5B1E0
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M12_L33
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M12_L34:
       dec       r12d
       imul      edi,r12d,9E3779B9
       cmp       dword ptr [r14+18],0
       jge       short M12_L35
       mov       r12d,edi
       mov       edx,[r14+20]
       imul      r12,rdx
       shr       r12,20
       jmp       short M12_L36
M12_L35:
       and       edi,[r14+18]
       mov       r12d,edi
M12_L36:
       mov       rdi,[r14+8]
       lea       edx,[r12*8]
       cmp       edx,[rdi+8]
       jae       near ptr M12_L75
       lea       edx,[r12*8]
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       [rbp-80],rax
       test      rax,rax
       je        short M12_L37
       mov       rdx,rax
       xor       esi,esi
       call      00007F9AD9274060
       mov       rdi,[rbp-80]
       cmp       rax,rdi
       je        short M12_L38
M12_L37:
       xor       edi,edi
M12_L38:
       mov       [rbp-48],rdi
       jmp       near ptr M12_L50
M12_L39:
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L41
M12_L40:
       mov       rax,7F9A59E5B1E8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-54],eax
       test      eax,eax
       je        short M12_L40
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-54]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L41:
       dec       eax
       cmp       dword ptr [r13+18],0
       jl        short M12_L42
       and       eax,[r13+18]
       jmp       short M12_L43
M12_L42:
       mov       rdi,[r13+8]
       mov       edi,[rdi+8]
       mov       eax,eax
       imul      rax,[r13+10]
       shr       rax,20
       inc       rax
       imul      rax,rdi
       shr       rax,20
M12_L43:
       xor       ecx,ecx
       jmp       near ptr M12_L47
M12_L44:
       mov       rdi,[r13+8]
       cmp       eax,[rdi+8]
       jae       near ptr M12_L75
       mov       [rbp-4C],eax
       mov       edx,eax
       mov       r8,[rdi+rdx*8+10]
       mov       [rbp-88],r8
       mov       r9,[r8+10]
       mov       [rbp-90],r9
       test      r9,r9
       je        short M12_L45
       lea       rdi,[r8+10]
       test      rdi,rdi
       je        near ptr M12_L69
       mov       rdx,r9
       xor       esi,esi
       call      00007F9AD9274060
       mov       rcx,[rbp-90]
       cmp       rax,rcx
       mov       r8,[rbp-88]
       je        short M12_L48
M12_L45:
       lea       rdx,[rbp-48]
       mov       rsi,r8
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F9A5B8DDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M12_L50
       mov       eax,[rbp-4C]
       inc       eax
       mov       edi,eax
       mov       rsi,[r13+8]
       cmp       [rsi+8],edi
       jne       short M12_L46
       xor       edi,edi
M12_L46:
       mov       ecx,[rbp-50]
       inc       ecx
       mov       eax,edi
M12_L47:
       mov       rdi,[r13+8]
       mov       [rbp-50],ecx
       cmp       [rdi+8],ecx
       jg        near ptr M12_L44
       jmp       short M12_L49
M12_L48:
       mov       r9,rcx
       mov       [rbp-48],r9
       jmp       short M12_L50
M12_L49:
       xor       edi,edi
       mov       [rbp-48],rdi
M12_L50:
       mov       rax,[rbp-48]
       cmp       qword ptr [rbp-48],0
       jne       short M12_L51
       test      r13,r13
       je        short M12_L52
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       dword ptr [r12+8],1
       jmp       short M12_L54
M12_L51:
       mov       r13,rax
       jmp       short M12_L53
M12_L52:
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7F9A5BE86A00]
       mov       r13,rax
M12_L53:
       mov       r12,r13
M12_L54:
       xor       edi,edi
       mov       [rbp-48],rdi
       cmp       dword ptr [r14+1C],0
       jne       short M12_L55
       mov       rsi,r12
       jmp       short M12_L56
M12_L55:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F9A59E60580
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F9A5BE869E8]
       mov       rsi,rax
M12_L56:
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M12_L08
M12_L57:
       mov       rdi,[rbx+10]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7360]; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       mov       rdi,[rbx+10]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7378]; Kevlar.KevlarProperties.Clear()
       jmp       near ptr M12_L03
M12_L58:
       mov       rdi,[r15+28]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7390]
       mov       byte ptr [r15+34],0
       jmp       near ptr M12_L04
M12_L59:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F92758013D0
       mov       r13,[rdi]
       cmp       dword ptr [r13+1C],0
       je        short M12_L60
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r13+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F9A59E60588
       call      qword ptr [r11]
       jmp       near ptr M12_L10
M12_L60:
       mov       rdi,r13
       mov       rsi,r14
       call      qword ptr [7F9A5BE869A0]
       test      eax,eax
       jne       short M12_L61
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r13+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F9A59E60590
       call      qword ptr [r11]
       jmp       near ptr M12_L10
M12_L61:
       mov       r12,[r13+10]
       test      r12,r12
       je        near ptr M12_L72
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L63
M12_L62:
       mov       rax,7F9A59E5B1E8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-60],eax
       test      eax,eax
       je        short M12_L62
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-60]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L63:
       dec       eax
       cmp       dword ptr [r12+18],0
       jl        short M12_L64
       and       eax,[r12+18]
       jmp       short M12_L65
M12_L64:
       mov       rdi,[r12+8]
       mov       edi,[rdi+8]
       mov       eax,eax
       imul      rax,[r12+10]
       shr       rax,20
       inc       rax
       imul      rax,rdi
       shr       rax,20
M12_L65:
       xor       ecx,ecx
       jmp       short M12_L68
M12_L66:
       mov       rdi,[r12+8]
       cmp       eax,[rdi+8]
       jae       near ptr M12_L75
       mov       [rbp-58],eax
       mov       esi,eax
       mov       r8,[rdi+rsi*8+10]
       mov       [rbp-98],r8
       cmp       [r8],r8b
       lea       rdi,[r8+10]
       test      rdi,rdi
       je        short M12_L69
       mov       rsi,r14
       xor       edx,edx
       call      00007F9AD9274060
       test      rax,rax
       je        short M12_L70
       mov       rdx,r14
       mov       rsi,[rbp-98]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F9A5B8DDF38]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M12_L70
       mov       eax,[rbp-58]
       inc       eax
       mov       rcx,[r12+8]
       cmp       [rcx+8],eax
       jne       short M12_L67
       xor       eax,eax
M12_L67:
       mov       ecx,[rbp-5C]
       inc       ecx
M12_L68:
       mov       rdi,[r12+8]
       mov       [rbp-5C],ecx
       cmp       [rdi+8],ecx
       jg        short M12_L66
       jmp       short M12_L71
M12_L69:
       call      qword ptr [7F9A5BE86478]
       int       3
M12_L70:
       cmp       dword ptr [r13+1C],0
       je        near ptr M12_L10
       jmp       near ptr M12_L73
M12_L71:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r13+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F9A59E60598
       call      qword ptr [r11]
       jmp       short M12_L70
M12_L72:
       mov       rdi,r13
       call      qword ptr [7F9A5BE87018]
       mov       r12d,eax
       mov       rsi,[r13+8]
       lea       edx,[r12*8]
       cmp       edx,[rsi+8]
       jae       near ptr M12_L75
       lea       edx,[r12*8]
       lea       rsi,[rsi+rdx*8+10]
       mov       rdx,r14
       mov       rdi,7F9A5BEB34C0
       call      qword ptr [7F9A5B8DDEC0]
       test      rax,rax
       je        near ptr M12_L70
       mov       rdi,r13
       mov       rsi,r14
       mov       rdx,rax
       mov       ecx,r12d
       call      qword ptr [7F9A5BE869B8]
       jmp       near ptr M12_L70
M12_L73:
       mov       rdi,r13
       call      qword ptr [7F9A5BE869D0]
       jmp       near ptr M12_L10
M12_L74:
       mov       rdi,[r15+8]
       call      qword ptr [7F9A5BDE73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F92758013D0
       mov       rdi,[rdi]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE73D8]
       lea       rdi,[r15+8]
       mov       rsi,rax
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M12_L10
M12_L75:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M12_L76:
       mov       eax,1
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
       push      rax
       mov       rdi,[rbp-68]
       mov       rsi,[rdi]
       mov       rax,[rsi+30]
       mov       rax,[rax]
       mov       rbx,[rax+40]
       test      rbx,rbx
       je        short M12_L77
       jmp       short M12_L78
M12_L77:
       mov       rdi,rsi
       mov       rsi,7F9A5BE6F198
       call      qword ptr [7F9A5AE4F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rbx,rax
M12_L78:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-68]
       mov       r11b,[rdi+30]
       mov       [rax+8],r11b
       mov       rdi,rax
       mov       r11,rbx
       mov       rsi,[rbp-70]
       call      qword ptr [rbx]
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 2563
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F9A5A9EEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F9A5A9EEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       push      rbp
       push      r15
       push      r14
       push      rbx
       sub       rsp,128
       vzeroupper
       lea       rbp,[rsp+140]
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFEE0
M14_L00:
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       vmovdqa   xmmword ptr [rax+rbp],xmm8
       add       rax,30
       jne       short M14_L00
       mov       [rbp-20],rax
       mov       rbx,rdi
       mov       r15,rsi
       mov       r14d,edx
       xor       edi,edi
       mov       [rbp-0B0],rdi
       test      rbx,rbx
       jne       short M14_L03
M14_L01:
       mov       rdi,7F9275800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M14_L04
M14_L02:
       add       rsp,128
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M14_L03:
       mov       rdi,7F9275800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F9A5B8DE9B8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        short M14_L01
       lea       rdi,[rbp-0A8]
       mov       rsi,r15
       call      qword ptr [7F9A5BDE71F8]
       mov       rdx,7F9A58A0B6A8
       mov       rdi,7F9A58A0B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-0A8]
       mov       rsi,7F9A58A0B638
       call      qword ptr [7F9A5BDE7210]
       call      00007F9A5AE38AE0
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F9A5BE86CD0]
       mov       [rbp-0B0],rax
       lea       rdi,[rbp-0B0]
       call      qword ptr [7F9A5BDE7240]
       mov       rdi,7F9275800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-0A8]
       xor       edx,edx
       call      qword ptr [7F9A5BDE7258]
       jmp       near ptr M14_L01
M14_L04:
       lea       rdi,[rbp-140]
       mov       rsi,r15
       call      qword ptr [7F9A5BDE71F8]
       mov       rdx,7F9A58A0B6A8
       mov       rdi,7F9A58A0B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-140]
       mov       rsi,7F9A58A0B638
       call      qword ptr [7F9A5BDE7210]
       mov       rdi,7F9275800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-140]
       mov       esi,1
       xor       ecx,ecx
       call      qword ptr [7F9A5BDE7270]
       jmp       near ptr M14_L02
; Total bytes of code 394
```
```assembly
; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,48
       lea       rbp,[rsp+70]
       mov       r13,rdi
       mov       r14d,esi
       mov       rbx,rdx
       mov       r15,rcx
       mov       rdi,7F92758013C0
       mov       r12,[rdi]
       cmp       dword ptr [r12+1C],0
       jne       near ptr M15_L12
M15_L00:
       mov       rax,[r12+10]
       mov       [rbp-50],rax
       xor       ecx,ecx
       mov       [rbp-2C],ecx
       test      rax,rax
       je        near ptr M15_L13
       mov       rdi,7F9AD94A0D68
       mov       rdx,7F9AD9D06820
       call      rdx
       add       rax,48
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M15_L22
M15_L01:
       dec       eax
       mov       rcx,[rbp-50]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M15_L23
       and       r8d,eax
M15_L02:
       mov       eax,r8d
       xor       r8d,r8d
M15_L03:
       mov       rdi,[rcx+8]
       mov       [rbp-34],r8d
       cmp       [rdi+8],r8d
       jle       near ptr M15_L28
       cmp       eax,[rdi+8]
       jae       near ptr M15_L32
       mov       [rbp-30],eax
       mov       esi,eax
       mov       r9,[rdi+rsi*8+10]
       mov       [rbp-60],r9
       mov       r10,[r9+10]
       mov       [rbp-68],r10
       test      r10,r10
       jne       near ptr M15_L11
M15_L04:
       lea       r10,[r9+18]
       mov       rdx,[r9+8]
       mov       rdi,[r10]
       mov       esi,edi
       cmp       esi,0FFFFFFFF
       je        near ptr M15_L25
M15_L05:
       cmp       esi,[rdx+8]
       jae       near ptr M15_L32
       mov       r11d,esi
       shl       r11,4
       mov       r8d,[rdx+r11+18]
       mov       rax,rdi
       sar       rax,20
       inc       eax
       cdqe
       shl       rax,20
       or        r8,rax
       mov       rax,rdi
       lock cmpxchg [r10],r8
       cmp       rax,rdi
       jne       near ptr M15_L24
       mov       rax,[r9+8]
       mov       rdx,rax
       mov       edi,[rdx+8]
       cmp       esi,edi
       jae       near ptr M15_L32
       mov       rdx,[rdx+r11+10]
       lea       rdi,[rax+r11+10]
       xor       eax,eax
       mov       [rdi],rax
       add       r9,20
M15_L06:
       mov       rax,[r9]
       mov       [rbp-40],rax
       mov       [rdi+8],eax
       mov       r8,rax
       sar       r8,20
       inc       r8d
       movsxd    r8,r8d
       shl       r8,20
       mov       r10d,esi
       or        r8,r10
       lock cmpxchg [r9],r8
       cmp       rax,[rbp-40]
       jne       short M15_L06
       test      rdx,rdx
       je        near ptr M15_L25
       mov       eax,[rbp-2C]
M15_L07:
       test      rdx,rdx
       je        near ptr M15_L29
M15_L08:
       mov       rax,rdx
M15_L09:
       cmp       dword ptr [r12+1C],0
       jne       near ptr M15_L31
       mov       r12,rax
M15_L10:
       lea       rdi,[r12+68]
       mov       rsi,r13
       call      CORINFO_HELP_ASSIGN_REF
       mov       [r12+60],r14d
       lea       rdi,[r12+38]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r12+30]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,0FFFFFFFF00000000
       mov       [r12+58],rax
       xor       eax,eax
       mov       [r12+40],rax
       mov       rax,r12
       add       rsp,48
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M15_L11:
       lea       rdi,[r9+10]
       test      rdi,rdi
       je        near ptr M15_L27
       xor       esi,esi
       mov       rdx,r10
       call      00007F9AD9274060
       mov       r10,[rbp-68]
       cmp       rax,r10
       mov       r9,[rbp-60]
       jne       near ptr M15_L04
       mov       rdx,r10
       mov       eax,[rbp-2C]
       jmp       near ptr M15_L07
M15_L12:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F9A5BDE67C0]
       jmp       near ptr M15_L00
M15_L13:
       mov       rdi,7F9AD94A0D68
       mov       rcx,7F9AD9D06820
       call      rcx
       add       rax,3C
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M15_L15
M15_L14:
       mov       rdi,7F9A59E5B1F8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M15_L14
       mov       [rax+10],edi
M15_L15:
       dec       edi
       imul      edi,9E3779B9
       mov       edx,[r12+18]
       test      edx,edx
       jge       short M15_L16
       mov       ecx,edi
       mov       esi,[r12+20]
       imul      rcx,rsi
       shr       rcx,20
       jmp       short M15_L17
M15_L16:
       mov       ecx,edi
       and       ecx,edx
M15_L17:
       mov       eax,ecx
       mov       rdi,[r12+8]
       mov       [rbp-2C],eax
       lea       edx,[rax*8]
       cmp       edx,[rdi+8]
       jae       near ptr M15_L32
       lea       rdi,[rdi+rdx*8+10]
       mov       rcx,[rdi]
       mov       rdx,rcx
       mov       [rbp-58],rdx
       test      rdx,rdx
       je        short M15_L19
       xor       esi,esi
       call      00007F9AD9274060
       mov       rdi,[rbp-58]
       cmp       rax,rdi
       mov       eax,[rbp-2C]
       je        short M15_L20
M15_L18:
       xor       edx,edx
       jmp       short M15_L21
M15_L19:
       mov       eax,[rbp-2C]
       jmp       short M15_L18
M15_L20:
       mov       rdx,rdi
M15_L21:
       jmp       near ptr M15_L07
M15_L22:
       mov       rax,7F9A59E5B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-38],eax
       test      eax,eax
       je        short M15_L22
       mov       rdi,7F9AD94A0D68
       mov       rcx,7F9AD9D06820
       call      rcx
       add       rax,48
       mov       ecx,[rbp-38]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M15_L01
M15_L23:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M15_L02
M15_L24:
       mov       rdi,[r10]
       mov       esi,edi
       cmp       esi,0FFFFFFFF
       jne       near ptr M15_L05
M15_L25:
       mov       eax,[rbp-30]
       inc       eax
       mov       edx,eax
       mov       rcx,[rbp-50]
       mov       rax,[rcx+8]
       cmp       [rax+8],edx
       jne       short M15_L26
       xor       edx,edx
M15_L26:
       mov       r8d,[rbp-34]
       inc       r8d
       mov       eax,edx
       mov       rcx,[rbp-50]
       jmp       near ptr M15_L03
M15_L27:
       call      qword ptr [7F9A5BE86478]
       int       3
M15_L28:
       xor       edx,edx
       mov       eax,[rbp-2C]
       jmp       near ptr M15_L07
M15_L29:
       cmp       qword ptr [rbp-50],0
       je        short M15_L30
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-70],rax
       mov       rdi,rax
       call      qword ptr [7F9A5BDE6868]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-70]
       jmp       near ptr M15_L09
M15_L30:
       mov       rdi,r12
       mov       esi,eax
       call      qword ptr [7F9A5BDE6820]
       mov       rdx,rax
       jmp       near ptr M15_L08
M15_L31:
       mov       [rbp-48],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r12+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-48]
       mov       r11,7F9A59E605E0
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F9A5BDE67C0]
       mov       r12,rax
       jmp       near ptr M15_L10
M15_L32:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 1060
```
```assembly
; Kevlar.KevlarContext.get_PropertiesForCompletion()
       cmp       byte ptr [rdi+64],0
       jne       short M16_L00
       mov       rax,[rdi+8]
       ret
M16_L00:
       mov       rax,[rdi+10]
       ret
; Total bytes of code 16
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       push      rbp
       push      r15
       push      r14
       push      rbx
       sub       rsp,18
       lea       rbp,[rsp+30]
       mov       rbx,rsi
       lea       rdi,[rbx+20]
       mov       rsi,[rbx+8]
       mov       rax,[rdi]
       mov       r15d,eax
       cmp       r15d,0FFFFFFFF
       je        near ptr M17_L03
       mov       ecx,[rsi+8]
M17_L00:
       cmp       r15d,ecx
       jae       near ptr M17_L04
       mov       r14d,r15d
       shl       r14,4
       mov       r8d,[rsi+r14+18]
       mov       r9,rax
       sar       r9,20
       inc       r9d
       movsxd    r9,r9d
       shl       r9,20
       or        r8,r9
       mov       [rbp-20],rax
       lock cmpxchg [rdi],r8
       cmp       rax,[rbp-20]
       jne       short M17_L02
       mov       rdi,[rbx+8]
       cmp       r15d,[rdi+8]
       jae       short M17_L04
       lea       rdi,[rdi+r14+10]
       mov       rsi,rdx
       call      CORINFO_HELP_ASSIGN_REF
       lea       rcx,[rbx+18]
       mov       rdx,[rbx+8]
M17_L01:
       mov       rax,[rcx]
       mov       [rbp-28],rax
       cmp       r15d,[rdx+8]
       jae       short M17_L04
       mov       [rdx+r14+18],eax
       mov       rdi,rax
       sar       rdi,20
       inc       edi
       movsxd    rdi,edi
       shl       rdi,20
       mov       esi,r15d
       or        rdi,rsi
       lock cmpxchg [rcx],rdi
       cmp       rax,[rbp-28]
       jne       short M17_L01
       mov       eax,1
       add       rsp,18
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M17_L02:
       mov       rax,[rdi]
       mov       r15d,eax
       cmp       r15d,0FFFFFFFF
       jne       near ptr M17_L00
M17_L03:
       xor       eax,eax
       add       rsp,18
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M17_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 234
```
```assembly
; Kevlar.KevlarContext..ctor()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F9A5BDE6880]; Kevlar.KevlarProperties..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,offset MT_System.Object
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-18],rax
       mov       rdi,[rbp-18]
       call      qword ptr [7F9A5AE4C240]; System.Object..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+20]
       mov       rsi,[rbp-18]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-8]
       mov       dword ptr [rax+5C],0FFFFFFFF
       call      qword ptr [7F9A5B8DE538]; System.TimeProvider.get_System()
       mov       rcx,[rbp-8]
       lea       rdi,[rcx+38]
       mov       rsi,rax
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-8]
       call      qword ptr [7F9A5AE4C240]; System.Object..ctor()
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 166
```
```assembly
; System.Diagnostics.Metrics.Instrument.get_Enabled()
       mov       rax,[rdi+8]
       cmp       qword ptr [rax+8],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 16
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,130
       vzeroupper
       lea       rbp,[rsp+150]
       xor       eax,eax
       mov       [rbp-148],rax
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFEE0
M20_L00:
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       vmovdqa   xmmword ptr [rax+rbp],xmm8
       add       rax,30
       jne       short M20_L00
       mov       r15,rdi
       mov       rbx,rsi
       mov       r14d,edx
       mov       r13,[rbx+30]
       xor       edi,edi
       mov       [rbp-0B8],rdi
       test      r15,r15
       jne       short M20_L03
M20_L01:
       mov       rsi,[rbx+30]
       mov       rdi,7F9275800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M20_L04
M20_L02:
       add       rsp,130
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M20_L03:
       mov       rdi,7F9275800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F9A5B8DE9B8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        short M20_L01
       lea       rdi,[rbp-0B0]
       mov       rsi,r13
       call      qword ptr [7F9A5BDE71F8]
       mov       rdx,7F9A58A0B6A8
       mov       rdi,7F9A58A0B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-0B0]
       mov       rsi,7F9A58A0B638
       call      qword ptr [7F9A5BDE7210]
       call      00007F9A5AE38AE0
       mov       rsi,rax
       mov       rdi,r15
       call      qword ptr [7F9A5BE86CD0]
       mov       [rbp-0B8],rax
       lea       rdi,[rbp-0B8]
       call      qword ptr [7F9A5BDE7240]
       mov       rdi,7F9275800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-0B0]
       mov       rdx,rbx
       call      qword ptr [7F9A5BDE7258]
       jmp       near ptr M20_L01
M20_L04:
       lea       rdi,[rbp-148]
       call      qword ptr [7F9A5BDE71F8]
       mov       rdx,7F9A58A0B6A8
       mov       rdi,7F9A58A0B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-148]
       mov       rsi,7F9A58A0B638
       call      qword ptr [7F9A5BDE7210]
       mov       rdi,7F9275800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-148]
       mov       rcx,rbx
       mov       esi,1
       call      qword ptr [7F9A5BDE7270]
       jmp       near ptr M20_L02
; Total bytes of code 410
```
```assembly
; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+50]
       mov       rbx,rdi
       mov       rdi,7F92758013C0
       mov       r15,[rdi]
       test      rbx,rbx
       je        near ptr M21_L06
       cmp       dword ptr [r15+1C],0
       jne       near ptr M21_L07
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7F9A5BDE72B8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       je        near ptr M21_L08
       mov       r14,[r15+10]
       test      r14,r14
       je        near ptr M21_L15
       mov       rdi,7F9AD94A0D68
       mov       rax,7F9AD9D06820
       call      rax
       add       rax,48
       mov       r13d,[rax+10]
       test      r13d,r13d
       je        near ptr M21_L09
M21_L00:
       dec       r13d
       mov       r12d,[r14+18]
       test      r12d,r12d
       jl        near ptr M21_L10
       and       r12d,r13d
M21_L01:
       xor       r13d,r13d
       mov       rdi,[r14+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M21_L14
M21_L02:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M21_L23
       mov       esi,r12d
       mov       rax,[rdi+rsi*8+10]
       mov       [rbp-50],rax
       cmp       [rax],al
       lea       rdi,[rax+10]
       test      rdi,rdi
       je        near ptr M21_L20
       mov       rsi,rbx
       xor       edx,edx
       call      00007F9AD9274060
       test      rax,rax
       je        near ptr M21_L05
       mov       rcx,[rbp-50]
       lea       rdi,[rcx+20]
       mov       rsi,[rcx+8]
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       je        near ptr M21_L12
       mov       r8d,[rsi+8]
M21_L03:
       cmp       edx,r8d
       jae       near ptr M21_L23
       mov       r9d,edx
       shl       r9,4
       mov       [rbp-48],r9
       mov       r10d,[rsi+r9+18]
       mov       r11,rax
       sar       r11,20
       inc       r11d
       movsxd    r11,r11d
       shl       r11,20
       or        r10,r11
       mov       [rbp-38],rax
       lock cmpxchg [rdi],r10
       cmp       rax,[rbp-38]
       jne       near ptr M21_L11
       mov       rdi,[rcx+8]
       mov       [rbp-2C],edx
       cmp       edx,[rdi+8]
       jae       near ptr M21_L23
       lea       rdi,[rdi+r9+10]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       mov       rbx,[rbp-50]
       lea       rdi,[rbx+18]
       mov       rcx,[rbx+8]
       mov       ebx,[rbp-2C]
M21_L04:
       mov       rax,[rdi]
       mov       [rbp-40],rax
       cmp       ebx,[rcx+8]
       jae       near ptr M21_L23
       mov       r14,[rbp-48]
       mov       [rcx+r14+18],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       esi,ebx
       or        rdx,rsi
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-40]
       jne       short M21_L04
M21_L05:
       cmp       dword ptr [r15+1C],0
       jne       near ptr M21_L22
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M21_L06:
       mov       edi,29
       mov       rsi,7F9A5B2C54F0
       call      qword ptr [7F9A5AE4EF88]
       mov       rdi,rax
       call      qword ptr [7F9A5BE864C0]
       int       3
M21_L07:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F9A59E60550
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M21_L08:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F9A59E60558
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M21_L09:
       mov       rdi,7F9A59E5B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M21_L09
       mov       rdi,7F9AD94A0D68
       mov       rax,7F9AD9D06820
       call      rax
       add       rax,48
       mov       [rax+10],r13d
       jmp       near ptr M21_L00
M21_L10:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r13d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
       jmp       near ptr M21_L01
M21_L11:
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       jne       near ptr M21_L03
M21_L12:
       inc       r12d
       mov       rcx,[r14+8]
       cmp       [rcx+8],r12d
       jne       short M21_L13
       xor       r12d,r12d
M21_L13:
       inc       r13d
       cmp       [rcx+8],r13d
       jg        near ptr M21_L02
M21_L14:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F9A59E60560
       call      qword ptr [r11]
       jmp       near ptr M21_L05
M21_L15:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r14d,[rax+10]
       test      r14d,r14d
       jne       short M21_L17
M21_L16:
       mov       rdi,7F9A59E5B1F8
       mov       eax,1
       mov       r14d,eax
       lock xadd [rdi],r14d
       inc       r14d
       je        short M21_L16
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r14d
M21_L17:
       dec       r14d
       imul      r14d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M21_L18
       mov       r13d,r14d
       mov       r12d,[r15+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M21_L19
M21_L18:
       and       r14d,[r15+18]
       mov       r13d,r14d
M21_L19:
       mov       rdi,[r15+8]
       lea       esi,[r13*8]
       cmp       esi,[rdi+8]
       jae       short M21_L23
       lea       esi,[r13*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M21_L21
M21_L20:
       call      qword ptr [7F9A5BE86478]
       int       3
M21_L21:
       mov       rsi,rbx
       call      00007F9AD9274040
       test      rax,rax
       je        near ptr M21_L05
       mov       rdi,r15
       mov       rsi,rbx
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7F9A5BDE74F8]
       jmp       near ptr M21_L05
M21_L22:
       mov       rdi,r15
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F9A5BDE7528]
M21_L23:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 988
```
```assembly
; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,50
       lea       rbp,[rsp+60]
       xor       eax,eax
       mov       [rbp-58],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       rbx,rdi
       mov       r15,rsi
       mov       rdi,[rbx+28]
       cmp       dword ptr [rdi+0C],0
       jne       short M22_L02
M22_L00:
       cmp       qword ptr [rbx+10],0
       jne       short M22_L03
M22_L01:
       add       rsp,50
       pop       rbx
       pop       r15
       pop       rbp
       ret
M22_L02:
       mov       rdi,[r15+28]
       mov       esi,1
       cmp       [rdi],edi
       call      qword ptr [7F9A5BE86A18]
       jmp       short M22_L00
M22_L03:
       mov       rdi,[rbx+10]
       mov       rdx,[rbx+38]
       mov       rcx,[rbx+40]
       mov       rsi,r15
       mov       rax,[rdi]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
       cmp       qword ptr [rbx+18],0
       je        short M22_L01
       mov       rdi,[rbx+18]
       lea       rsi,[rbp-40]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE78A0]
       jmp       short M22_L05
M22_L04:
       mov       rdi,[rbp-28]
       vmovdqu   xmm0,xmmword ptr [rbp-28]
       vmovdqu   xmmword ptr [rbp-58],xmm0
       mov       rdx,[rbp-18]
       mov       [rbp-48],rdx
       mov       rdx,[rbp-50]
       mov       rcx,[rbp-48]
       mov       rsi,r15
       mov       rax,[rdi]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
M22_L05:
       lea       rdi,[rbp-40]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F9A5BDE7900]
       test      eax,eax
       jne       short M22_L04
       jmp       near ptr M22_L01
; Total bytes of code 207
```
```assembly
; Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,0D0
       lea       rbp,[rsp+0F0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       xor       eax,eax
       mov       [rbp-30],rax
       mov       [rbp-28],rdi
       mov       [rbp-0D8],rdi
       mov       rbx,rsi
       mov       r14,rdx
       mov       r13,rcx
       mov       r15,r8
       mov       rsi,[rdi]
       mov       rax,[rsi+30]
       mov       rax,[rax]
       mov       rax,[rax+18]
       test      rax,rax
       je        near ptr M23_L14
M23_L00:
       mov       [rbp-48],r14
       mov       [rbp-40],r13
       mov       [rbp-70],r15
       mov       dword ptr [rbp-68],0FFFFFFFF
       mov       rsi,[rax+18]
       mov       rcx,[rsi+18]
       test      rcx,rcx
       je        near ptr M23_L15
M23_L01:
       mov       rsi,[rcx+18]
       mov       r15,[rsi+10]
       test      r15,r15
       je        near ptr M23_L16
M23_L02:
       mov       rdi,7F9AD94A0D68
       mov       rax,7F9AD9D06820
       call      rax
       cmp       dword ptr [rax],4
       jle       near ptr M23_L17
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        near ptr M23_L17
M23_L03:
       mov       r14,[rax+10]
       test      r14,r14
       jne       short M23_L04
       call      qword ptr [7F9A5B52C3F0]; System.Threading.Thread.InitializeCurrentThread()
       mov       r14,rax
M23_L04:
       mov       [rbp-0E0],r14
       mov       rsi,[r14+8]
       mov       [rbp-0E8],rsi
       mov       rsi,[r14+10]
       mov       [rbp-0F0],rsi
       mov       rdi,[r15+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M23_L06
M23_L05:
       lea       rdi,[rbp-70]
       call      rax
       jmp       short M23_L07
M23_L06:
       mov       rdi,r15
       mov       rsi,7F9A5BDD8060
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M23_L05
M23_L07:
       mov       rsi,[rbp-0F0]
       cmp       rsi,[r14+10]
       je        short M23_L08
       lea       rdi,[r14+10]
       call      CORINFO_HELP_ASSIGN_REF
M23_L08:
       mov       rdi,[r14+8]
       mov       r15,rdi
       mov       rsi,[rbp-0E8]
       cmp       rsi,r15
       je        short M23_L10
       lea       rdi,[r14+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      r15,r15
       je        short M23_L09
       cmp       qword ptr [r15+10],0
       jne       near ptr M23_L13
M23_L09:
       cmp       qword ptr [rbp-0E8],0
       jne       short M23_L12
M23_L10:
       mov       rdi,[rbp-60]
       mov       rax,7F92758013E8
       cmp       rdi,[rax]
       jne       near ptr M23_L18
       vmovdqu   xmm0,xmmword ptr [rbp-58]
       vmovdqu   xmmword ptr [rbp-0C0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-0D0]
       vmovdqu   ymmword ptr [rbp-90],ymm0
       xor       r15d,r15d
M23_L11:
       mov       [rbp-90],r15
       vmovdqu   ymm0,ymmword ptr [rbp-90]
       vmovdqu   ymmword ptr [rbx],ymm0
       mov       word ptr [rbx+8],0
       mov       byte ptr [rbx+0A],1
       mov       rax,rbx
       vzeroupper
       add       rsp,0D0
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M23_L12:
       mov       rsi,[rbp-0E8]
       cmp       qword ptr [rsi+10],0
       je        short M23_L10
M23_L13:
       mov       rdi,r15
       mov       rsi,[rbp-0E8]
       call      qword ptr [7F9A5BE86A60]
       jmp       near ptr M23_L10
M23_L14:
       mov       rdi,rsi
       mov       rsi,7F9A5BDD7000
       call      qword ptr [7F9A5AE4F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       jmp       near ptr M23_L00
M23_L15:
       mov       rdi,rax
       mov       rsi,7F9A5BDD7C78
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rcx,rdi
       jmp       near ptr M23_L01
M23_L16:
       mov       rdi,rcx
       mov       rsi,7F9A5BDD7ED8
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r15,rax
       jmp       near ptr M23_L02
M23_L17:
       mov       edi,4
       call      qword ptr [7F9A5BE86490]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       near ptr M23_L03
M23_L18:
       mov       r15,[rbp-60]
       test      r15,r15
       jne       short M23_L19
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       call      qword ptr [7F9A5BE86A78]
       mov       [rbp-60],r15
M23_L19:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0A0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-0B0]
       vmovdqu   ymmword ptr [rbp-90],ymm0
       jmp       near ptr M23_L11
       push      rax
       mov       rsi,[rbp-0F0]
       mov       rax,[rbp-0E0]
       cmp       rsi,[rax+10]
       je        short M23_L20
       lea       rdi,[rax+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-0E0]
M23_L20:
       mov       rbx,[rax+8]
       mov       rsi,[rbp-0E8]
       cmp       rsi,rbx
       je        short M23_L23
       lea       rdi,[rax+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      rbx,rbx
       je        short M23_L21
       cmp       qword ptr [rbx+10],0
       jne       short M23_L22
M23_L21:
       cmp       qword ptr [rbp-0E8],0
       je        short M23_L23
       mov       rsi,[rbp-0E8]
       cmp       qword ptr [rsi+10],0
       je        short M23_L23
M23_L22:
       mov       rdi,rbx
       mov       rsi,[rbp-0E8]
       call      qword ptr [7F9A5BE86A60]
M23_L23:
       nop
       vzeroupper
       add       rsp,8
       ret
; Total bytes of code 814
```
```assembly
; System.Threading.Thread.InitializeCurrentThread()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,68
       lea       rbp,[rsp+90]
       xor       eax,eax
       mov       [rbp-30],rax
       lea       rdi,[rbp-30]
       mov       [rbp-90],rdi
       lea       rdi,[rbp-88]
       call      qword ptr [7F9A5A9EEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-90]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7F9A5A9EEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rbx,[rbp-30]
       call      qword ptr [7F9A5A9F0B98]
       lea       rdi,[rax+10]
       mov       rsi,[rbp-30]
       call      qword ptr [7F9A5A9EEEB8]; CORINFO_HELP_ASSIGN_REF
       mov       rax,rbx
       add       rsp,68
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 123
```
```assembly
; Kevlar.KevlarProperties.CopyChangedValuesTo(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-88],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       vmovdqa   xmmword ptr [rbp-40],xmm8
       mov       [rbp-30],rax
       mov       rbx,rdi
       mov       r15,rsi
       mov       r14,rdx
       mov       r13,[rbx+10]
       mov       r12,[rbx+38]
       mov       rax,[rbx+40]
       mov       [rbp-98],rax
       cmp       qword ptr [r15+10],0
       jne       short M25_L05
M25_L00:
       cmp       qword ptr [r15+18],0
       jne       short M25_L06
M25_L01:
       xor       ecx,ecx
M25_L02:
       xor       edi,edi
       mov       [rbp-78],rdi
       test      r13,r13
       mov       [rbp-90],rcx
       jne       near ptr M25_L07
M25_L03:
       cmp       qword ptr [rbx+18],0
       jne       near ptr M25_L08
M25_L04:
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M25_L05:
       vmovdqu   xmm0,xmmword ptr [r15+38]
       vmovdqu   xmmword ptr [rbp-88],xmm0
       mov       rsi,r12
       mov       rdx,rax
       lea       rdi,[rbp-88]
       call      qword ptr [7F9A5BE87138]
       test      eax,eax
       mov       rax,[rbp-98]
       je        short M25_L00
       mov       rcx,[r15+10]
       mov       [rbp-90],rcx
       mov       rcx,[rbp-90]
       jmp       short M25_L02
M25_L06:
       mov       rdi,[r15+18]
       mov       rsi,r12
       mov       rdx,rax
       lea       rcx,[rbp-78]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BE20BB0]
       test      eax,eax
       mov       rax,[rbp-98]
       je        near ptr M25_L01
       mov       rcx,[rbp-78]
       jmp       near ptr M25_L02
M25_L07:
       mov       rdi,r13
       mov       rdx,[r13]
       mov       rdx,[rdx+40]
       call      qword ptr [rdx+20]
       test      eax,eax
       je        near ptr M25_L03
       mov       rdi,r13
       mov       rsi,[rbp-90]
       call      qword ptr [7F9A5BDE7A50]
       test      eax,eax
       jne       near ptr M25_L03
       mov       rsi,r12
       mov       rdx,[rbp-98]
       mov       rdi,r14
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,[rbp-90]
       call      qword ptr [7F9A5BDE7A50]
       test      eax,eax
       je        near ptr M25_L03
       mov       rdx,r12
       mov       rcx,[rbp-98]
       mov       rdi,r13
       mov       rsi,r14
       mov       rax,[r13]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
       jmp       near ptr M25_L03
M25_L08:
       mov       rdi,[rbx+18]
       lea       rsi,[rbp-58]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE78A0]
       jmp       short M25_L10
M25_L09:
       mov       rdi,[rbp-40]
       vmovdqu   xmm0,xmmword ptr [rbp-40]
       vmovdqu   xmmword ptr [rbp-70],xmm0
       mov       rsi,[rbp-30]
       mov       [rbp-60],rsi
       mov       rsi,[rbp-68]
       mov       rdx,[rbp-60]
       mov       rcx,r15
       mov       r8,r14
       call      qword ptr [7F9A5BDE7A80]; Kevlar.KevlarProperties.CopyChangedValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
M25_L10:
       lea       rdi,[rbp-58]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F9A5BDE7900]
       test      eax,eax
       jne       short M25_L09
       jmp       near ptr M25_L04
; Total bytes of code 469
```
```assembly
; System.Threading.Monitor.Enter_Slowpath(System.Object)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,68
       lea       rbp,[rsp+90]
       mov       [rbp-30],rdi
       lea       rdi,[rbp-30]
       mov       [rbp-90],rdi
       lea       rdi,[rbp-88]
       call      qword ptr [7F9A5A9EEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-90]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7F9A5A9EEF08]; CORINFO_HELP_JIT_PINVOKE_END
       nop
       add       rsp,68
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; Kevlar.KevlarProperties.Find(PropertyIdentity)
       push      rbp
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+30]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-28],rsi
       mov       [rbp-30],rdx
       mov       rbx,rdi
       cmp       qword ptr [rbx+10],0
       jne       short M27_L02
M27_L00:
       cmp       qword ptr [rbx+18],0
       jne       short M27_L03
M27_L01:
       xor       eax,eax
       add       rsp,28
       pop       rbx
       pop       rbp
       ret
M27_L02:
       vmovdqu   xmm0,xmmword ptr [rbx+38]
       vmovdqu   xmmword ptr [rbp-20],xmm0
       mov       rsi,[rbp-28]
       mov       rdx,[rbp-30]
       lea       rdi,[rbp-20]
       call      qword ptr [7F9A5BE87138]
       test      eax,eax
       je        short M27_L00
       mov       rax,[rbx+10]
       add       rsp,28
       pop       rbx
       pop       rbp
       ret
M27_L03:
       mov       rdi,[rbx+18]
       mov       rsi,[rbp-28]
       mov       rdx,[rbp-30]
       lea       rcx,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BE20BB0]
       test      eax,eax
       je        short M27_L01
       mov       rax,[rbp-10]
       add       rsp,28
       pop       rbx
       pop       rbp
       ret
; Total bytes of code 143
```
```assembly
; Kevlar.KevlarProperties.RemoveMissingValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       push      r15
       push      r14
       push      rbx
       sub       rsp,18
       lea       rbp,[rsp+30]
       mov       [rbp-20],rsi
       mov       [rbp-28],rdx
       mov       rbx,rdi
       mov       r14,rcx
       mov       r15,r8
       test      rbx,rbx
       jne       short M28_L01
M28_L00:
       add       rsp,18
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M28_L01:
       mov       rdi,rbx
       mov       rax,[rbx]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       je        short M28_L00
       mov       rsi,[rbp-20]
       mov       rdx,[rbp-28]
       mov       rdi,r14
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       test      rax,rax
       je        short M28_L02
       mov       rdi,rax
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       jne       short M28_L00
M28_L02:
       mov       rsi,[rbp-20]
       mov       rdx,[rbp-28]
       mov       rdi,r15
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,rbx
       call      qword ptr [7F9A5BDE7A50]
       test      eax,eax
       je        short M28_L00
       mov       rsi,[rbp-20]
       mov       rdx,[rbp-28]
       mov       rdi,r15
       call      qword ptr [7F9A5BDE7A68]
       jmp       short M28_L00
; Total bytes of code 160
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Return(System.__Canon)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,38
       lea       rbp,[rsp+60]
       mov       [rbp-30],rdi
       mov       rbx,rdi
       mov       r15,rsi
       test      r15,r15
       je        near ptr M29_L04
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M29_L05
       mov       rdi,rbx
       mov       rsi,r15
       call      qword ptr [7F9A5BDE72B8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       je        near ptr M29_L08
       mov       r14,[rbx+10]
       test      r14,r14
       je        near ptr M29_L17
       mov       rdi,r14
       call      qword ptr [7F9A5B8DDCE0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       r13d,eax
       xor       r12d,r12d
       mov       rdi,[r14+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M29_L14
M29_L00:
       mov       rdi,[r14+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M29_L21
       mov       esi,r13d
       mov       rax,[rdi+rsi*8+10]
       mov       [rbp-58],rax
       cmp       [rax],al
       lea       rdi,[rax+10]
       test      rdi,rdi
       je        near ptr M29_L18
       mov       rsi,r15
       xor       edx,edx
       call      00007F9AD9274060
       test      rax,rax
       je        near ptr M29_L03
       mov       rcx,[rbp-58]
       lea       rdi,[rcx+20]
       mov       rsi,[rcx+8]
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       je        near ptr M29_L12
       mov       r8d,[rsi+8]
M29_L01:
       cmp       edx,r8d
       jae       near ptr M29_L21
       mov       r9d,edx
       shl       r9,4
       mov       [rbp-50],r9
       mov       r10d,[rsi+r9+18]
       mov       r11,rax
       sar       r11,20
       inc       r11d
       movsxd    r11,r11d
       shl       r11,20
       or        r10,r11
       mov       [rbp-40],rax
       lock cmpxchg [rdi],r10
       cmp       rax,[rbp-40]
       jne       near ptr M29_L11
       mov       rdi,[rcx+8]
       mov       [rbp-34],edx
       cmp       edx,[rdi+8]
       jae       near ptr M29_L21
       lea       rdi,[rdi+r9+10]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       r15,[rbp-58]
       lea       rdi,[r15+18]
       mov       rsi,[r15+8]
       mov       r15d,[rbp-34]
M29_L02:
       mov       rax,[rdi]
       mov       [rbp-48],rax
       cmp       r15d,[rsi+8]
       jae       near ptr M29_L21
       mov       r14,[rbp-50]
       mov       [rsi+r14+18],eax
       mov       rcx,rax
       sar       rcx,20
       inc       ecx
       movsxd    rcx,ecx
       shl       rcx,20
       mov       edx,r15d
       or        rcx,rdx
       lock cmpxchg [rdi],rcx
       cmp       rax,[rbp-48]
       jne       short M29_L02
M29_L03:
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M29_L20
       add       rsp,38
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M29_L04:
       mov       edi,29
       mov       rsi,7F9A5B2C54F0
       call      qword ptr [7F9A5AE4EF88]
       mov       rdi,rax
       call      qword ptr [7F9A5BE864C0]
       int       3
M29_L05:
       mov       rdi,[rbx]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       r14,[rsi+40]
       test      r14,r14
       je        short M29_L06
       jmp       short M29_L07
M29_L06:
       mov       rsi,7F9A5BE6F198
       call      qword ptr [7F9A5AE4F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       r14,rax
M29_L07:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       r11,r14
       mov       rsi,r15
       mov       rax,r14
       add       rsp,38
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [rax]
M29_L08:
       mov       rdi,[rbx]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       r14,[rsi+40]
       test      r14,r14
       je        short M29_L09
       jmp       short M29_L10
M29_L09:
       mov       rsi,7F9A5BE6F198
       call      qword ptr [7F9A5AE4F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       r14,rax
M29_L10:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       r11,r14
       mov       rsi,r15
       mov       rax,r14
       add       rsp,38
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [rax]
M29_L11:
       mov       rax,[rdi]
       mov       edx,eax
       cmp       edx,0FFFFFFFF
       jne       near ptr M29_L01
M29_L12:
       inc       r13d
       mov       rcx,[r14+8]
       cmp       [rcx+8],r13d
       jne       short M29_L13
       xor       r13d,r13d
M29_L13:
       inc       r12d
       cmp       [rcx+8],r12d
       jg        near ptr M29_L00
M29_L14:
       mov       rdi,[rbx]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       r14,[rsi+40]
       test      r14,r14
       je        short M29_L15
       jmp       short M29_L16
M29_L15:
       mov       rsi,7F9A5BE6F198
       call      qword ptr [7F9A5AE4F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       r14,rax
M29_L16:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       r11,r14
       mov       rsi,r15
       call      qword ptr [r14]
       jmp       near ptr M29_L03
M29_L17:
       mov       rdi,rbx
       call      qword ptr [7F9A5BDE67D8]
       mov       r14d,eax
       mov       rdi,[rbx+8]
       lea       esi,[r14*8]
       cmp       esi,[rdi+8]
       jae       short M29_L21
       lea       esi,[r14*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M29_L19
M29_L18:
       call      qword ptr [7F9A5BE86478]
       int       3
M29_L19:
       mov       rsi,r15
       call      00007F9AD9274040
       test      rax,rax
       je        near ptr M29_L03
       mov       rdi,rbx
       mov       rsi,r15
       mov       rdx,rax
       mov       ecx,r14d
       call      qword ptr [7F9A5BDE74F8]
       jmp       near ptr M29_L03
M29_L20:
       mov       rdi,rbx
       add       rsp,38
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F9A5BDE7528]
M29_L21:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 854
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F9A5A9EEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F9A5A9EEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; PoolContextProbe+<>c.<NestedContext>b__6_1(Kevlar.KevlarContext)
       xor       eax,eax
       mov       rdx,100000000002A
       ret
; Total bytes of code 13
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](Kevlar.KevlarContext, System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
M32_L00:
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,3D8
       vzeroupper
       lea       rbp,[rsp+400]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-3D0],xmm8
       mov       rax,0FFFFFFFFFFFFFC70
M32_L01:
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       add       rax,30
       jne       short M32_L01
       mov       [rbp-30],rax
       mov       rbx,rsi
       mov       r15,rdx
       test      r15,r15
       je        near ptr M32_L57
       test      rbx,rbx
       je        near ptr M32_L58
       mov       rax,[rdi+38]
       test      rax,rax
       jne       near ptr M32_L59
       cmp       byte ptr [rdi+48],0
       jne       near ptr M32_L60
       mov       r14,[rdi+10]
       mov       r13,[rdi+40]
       mov       rdi,7F9275801410
       mov       r12,[rdi]
       test      r12,r12
       je        near ptr M32_L61
M32_L02:
       mov       [rbp-350],r13
       mov       rcx,7F9275800BA0
       mov       rcx,[rcx]
       mov       rcx,[rcx+8]
       cmp       qword ptr [rcx+8],0
       jne       near ptr M32_L62
       xor       edi,edi
M32_L03:
       mov       [rbp-40],rdi
       mov       rdx,[rbx+68]
       mov       [rbp-3C8],rdx
       test      rdx,rdx
       jne       near ptr M32_L63
M32_L04:
       mov       r13,[rbx+68]
       mov       rdx,[rbx+38]
       mov       [rbp-368],rdx
       mov       rdi,7F92758013C0
       mov       rsi,[rdi]
       mov       [rbp-378],rsi
       cmp       dword ptr [rsi+1C],0
       jne       near ptr M32_L64
M32_L05:
       mov       rsi,[rbp-378]
       mov       r8,[rsi+10]
       mov       [rbp-388],r8
       xor       r9d,r9d
       mov       [rbp-64],r9d
       test      r8,r8
       je        near ptr M32_L65
       mov       rdi,7F9AD94A0D68
       mov       r10,7F9AD9D06820
       call      r10
       add       rax,48
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M32_L74
M32_L06:
       dec       eax
       mov       rcx,[rbp-388]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M32_L75
       and       r8d,eax
M32_L07:
       mov       eax,r8d
       xor       r8d,r8d
M32_L08:
       mov       rdi,[rcx+8]
       mov       [rbp-6C],r8d
       cmp       [rdi+8],r8d
       jle       near ptr M32_L80
       cmp       eax,[rdi+8]
       jae       near ptr M32_L102
       mov       [rbp-68],eax
       mov       esi,eax
       mov       r9,[rdi+rsi*8+10]
       mov       [rbp-398],r9
       mov       r10,[r9+10]
       mov       [rbp-3A0],r10
       test      r10,r10
       jne       near ptr M32_L53
M32_L09:
       lea       r10,[r9+18]
       mov       rdx,[r9+8]
       mov       rdi,[r10]
       mov       esi,edi
       cmp       esi,0FFFFFFFF
       je        near ptr M32_L77
M32_L10:
       cmp       esi,[rdx+8]
       jae       near ptr M32_L102
       mov       r11d,esi
       shl       r11,4
       mov       r8d,[rdx+r11+18]
       mov       rax,rdi
       sar       rax,20
       inc       eax
       cdqe
       shl       rax,20
       or        r8,rax
       mov       rax,rdi
       lock cmpxchg [r10],r8
       cmp       rax,rdi
       jne       near ptr M32_L76
       mov       rax,[r9+8]
       mov       rdx,rax
       cmp       esi,[rdx+8]
       jae       near ptr M32_L102
       mov       rdx,[rdx+r11+10]
       cmp       esi,[rax+8]
       jae       near ptr M32_L102
       lea       rdi,[rax+r11+10]
       xor       eax,eax
       mov       [rdi],rax
       add       r9,20
M32_L11:
       mov       rax,[r9]
       mov       [rbp-78],rax
       mov       [rdi+8],eax
       mov       r8,rax
       sar       r8,20
       inc       r8d
       movsxd    r8,r8d
       shl       r8,20
       mov       r10d,esi
       or        r8,r10
       lock cmpxchg [r9],r8
       cmp       rax,[rbp-78]
       jne       short M32_L11
       test      rdx,rdx
       je        near ptr M32_L77
       mov       rax,[rbp-378]
M32_L12:
       test      rdx,rdx
       je        near ptr M32_L81
M32_L13:
       mov       rcx,rdx
M32_L14:
       cmp       dword ptr [rax+1C],0
       jne       near ptr M32_L83
       mov       rdx,rcx
M32_L15:
       mov       [rbp-370],rdx
       lea       rdi,[rdx+68]
       mov       rsi,r13
       call      CORINFO_HELP_ASSIGN_REF
       xor       edi,edi
       mov       r13,[rbp-370]
       mov       [r13+60],edi
       lea       rdi,[r13+38]
       mov       rsi,[rbp-368]
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r13+30]
       mov       rsi,[rbp-350]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,0FFFFFFFF00000000
       mov       [r13+58],rdi
       xor       edi,edi
       mov       [r13+40],rdi
       cmp       qword ptr [r13+18],0
       je        near ptr M32_L84
M32_L16:
       mov       rdi,[rbx+8]
       mov       rsi,[r13+18]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE77F8]; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       mov       rdi,[r13+18]
       mov       rsi,[r13+8]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE77F8]; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       mov       rdi,[r13+8]
       mov       rsi,[rbx+8]
       cmp       [rdi],dil
       mov       rax,[rsi+28]
       add       rax,8
       lock inc  dword ptr [rax]
       mov       rsi,[rsi+28]
       lea       rdi,[rdi+28]
       call      CORINFO_HELP_ASSIGN_REF
       mov       byte ptr [r13+65],1
       mov       [rbp-358],r13
       mov       rdi,7F92758013E0
       mov       rax,[rdi]
       test      rax,rax
       je        near ptr M32_L85
M32_L17:
       mov       [rbp-98],r14
       mov       [rbp-90],rax
       mov       [rbp-88],r15
       mov       [rbp-80],r12
       cmp       qword ptr [rbp-90],0
       je        near ptr M32_L86
       cmp       qword ptr [rbp-98],0
       jne       near ptr M32_L91
       mov       r15,[rbp-90]
       mov       rdi,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       cmp       [r15+18],rdi
       jne       near ptr M32_L90
       mov       rdi,[r15+8]
       mov       r15,[rbp-88]
       mov       r14,[rbp-80]
       mov       rdi,[rdi]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M32_L54
M32_L18:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0F0],xmm0
       vmovdqu   xmmword ptr [rbp-0E8],xmm0
       mov       [rbp-0D8],r15
       mov       [rbp-0D0],r14
       mov       [rbp-100],r13
       mov       dword ptr [rbp-0F8],0FFFFFFFF
       mov       rdi,[rsi+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M32_L55
M32_L19:
       mov       rsi,[rdi+18]
       mov       rax,[rsi+10]
       test      rax,rax
       je        near ptr M32_L56
       mov       rdi,rax
M32_L20:
       lea       rsi,[rbp-100]
       call      qword ptr [7F9A5BDE6CB8]; System.Runtime.CompilerServices.AsyncMethodBuilderCore.Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       mov       rdi,[rbp-0F0]
       mov       rax,7F92758013E8
       cmp       rdi,[rax]
       jne       near ptr M32_L87
       mov       r15,[rbp-0E8]
       mov       r14d,[rbp-0E0]
       xor       r12d,r12d
M32_L21:
       xor       eax,eax
       mov       ecx,1
M32_L22:
       test      r12,r12
       jne       near ptr M32_L93
M32_L23:
       mov       [rbp-3D0],r15
       mov       [rbp-2F4],r14d
       test      r15,r15
       sete      r12b
       movzx     r12d,r12b
       mov       r15,[rbp-40]
       test      r15,r15
       jne       near ptr M32_L98
M32_L24:
       mov       rdi,7F9275800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M32_L99
M32_L25:
       mov       rdi,[r13+20]
       mov       [rbp-3B8],rdi
       xor       edi,edi
       mov       [rbp-22C],edi
       cmp       qword ptr [rbp-3B8],0
       je        near ptr M32_L35
       mov       rdi,[rbp-3B8]
       call      00007F9AD90E6020
       test      eax,eax
       je        near ptr M32_L36
M32_L26:
       mov       dword ptr [rbp-22C],1
       cmp       byte ptr [r13+64],0
       jne       near ptr M32_L37
       mov       r15,[r13+8]
M32_L27:
       mov       r13,[r13+18]
       mov       rbx,[rbx+8]
       mov       rdi,[r15+28]
       cmp       dword ptr [rdi+0C],0
       jne       near ptr M32_L38
M32_L28:
       mov       r14,[r13+10]
       mov       r12,[r13+38]
       mov       rax,[r13+40]
       mov       [rbp-3D8],rax
       test      r14,r14
       jne       near ptr M32_L39
M32_L29:
       cmp       qword ptr [r13+18],0
       jne       near ptr M32_L41
M32_L30:
       mov       r14,[r15+10]
       mov       r12,[r15+38]
       mov       rax,[r15+40]
       mov       [rbp-3E0],rax
       cmp       qword ptr [r13+10],0
       jne       near ptr M32_L44
M32_L31:
       cmp       qword ptr [r13+18],0
       jne       near ptr M32_L45
M32_L32:
       xor       ecx,ecx
M32_L33:
       xor       edi,edi
       mov       [rbp-2C8],rdi
       test      r14,r14
       mov       [rbp-3C0],rcx
       jne       near ptr M32_L46
M32_L34:
       cmp       qword ptr [r15+18],0
       je        near ptr M32_L50
       jmp       near ptr M32_L47
M32_L35:
       xor       edi,edi
       call      qword ptr [7F9A5BE864C0]
       int       3
M32_L36:
       mov       rdi,[rbp-3B8]
       call      qword ptr [7F9A5BE864F0]; System.Threading.Monitor.Enter_Slowpath(System.Object)
       jmp       near ptr M32_L26
M32_L37:
       mov       r15,[r13+10]
       jmp       near ptr M32_L27
M32_L38:
       mov       rdi,[r13+28]
       cmp       dword ptr [rdi+0C],0
       jne       near ptr M32_L28
       mov       rdi,[rbx+28]
       cmp       dword ptr [rdi+0C],0
       jne       near ptr M32_L28
       mov       rdi,[rbx+28]
       mov       esi,1
       cmp       [rdi],edi
       call      qword ptr [7F9A5BE86A18]
       jmp       near ptr M32_L28
M32_L39:
       mov       rdi,r14
       mov       rcx,[r14]
       mov       rcx,[rcx+40]
       call      qword ptr [rcx+20]
       test      eax,eax
       je        near ptr M32_L29
       mov       rsi,r12
       mov       rdx,[rbp-3D8]
       mov       rdi,r15
       call      qword ptr [7F9A5BDE7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       test      rax,rax
       je        short M32_L40
       mov       rdi,rax
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       jne       near ptr M32_L29
M32_L40:
       mov       rsi,r12
       mov       rdx,[rbp-3D8]
       mov       rdi,rbx
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,r14
       call      qword ptr [7F9A5BDE7A50]
       test      eax,eax
       je        near ptr M32_L29
       mov       rsi,r12
       mov       rdx,[rbp-3D8]
       mov       rdi,rbx
       call      qword ptr [7F9A5BDE7A68]
       jmp       near ptr M32_L29
M32_L41:
       mov       rdi,[r13+18]
       lea       rsi,[rbp-260]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE78A0]
       jmp       short M32_L43
M32_L42:
       mov       rdi,[rbp-248]
       vmovdqu   xmm0,xmmword ptr [rbp-248]
       vmovdqu   xmmword ptr [rbp-278],xmm0
       mov       rsi,[rbp-238]
       mov       [rbp-268],rsi
       mov       rsi,[rbp-270]
       mov       rdx,[rbp-268]
       mov       rcx,r15
       mov       r8,rbx
       call      qword ptr [7F9A5BDE7A08]; Kevlar.KevlarProperties.RemoveMissingValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
M32_L43:
       lea       rdi,[rbp-260]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F9A5BDE7900]
       test      eax,eax
       jne       short M32_L42
       jmp       near ptr M32_L30
M32_L44:
       vmovdqu   xmm0,xmmword ptr [r13+38]
       vmovdqu   xmmword ptr [rbp-2D8],xmm0
       mov       rsi,r12
       mov       rdx,rax
       lea       rdi,[rbp-2D8]
       call      qword ptr [7F9A5BE87138]
       test      eax,eax
       mov       rax,[rbp-3E0]
       je        near ptr M32_L31
       mov       rcx,[r13+10]
       mov       [rbp-3C0],rcx
       mov       rcx,[rbp-3C0]
       jmp       near ptr M32_L33
M32_L45:
       mov       rdi,[r13+18]
       mov       rsi,r12
       mov       rdx,rax
       lea       rcx,[rbp-2C8]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BE20BB0]
       test      eax,eax
       mov       rax,[rbp-3E0]
       je        near ptr M32_L32
       mov       rcx,[rbp-2C8]
       jmp       near ptr M32_L33
M32_L46:
       mov       rdi,r14
       mov       rdx,[r14]
       mov       rdx,[rdx+40]
       call      qword ptr [rdx+20]
       test      eax,eax
       je        near ptr M32_L34
       mov       rdi,r14
       mov       rsi,[rbp-3C0]
       call      qword ptr [7F9A5BDE7A50]
       test      eax,eax
       jne       near ptr M32_L34
       mov       rsi,r12
       mov       rdx,[rbp-3E0]
       mov       rdi,rbx
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,[rbp-3C0]
       call      qword ptr [7F9A5BDE7A50]
       test      eax,eax
       je        near ptr M32_L34
       mov       rdx,r12
       mov       rcx,[rbp-3E0]
       mov       rdi,r14
       mov       rsi,rbx
       mov       rax,[r14]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
       jmp       near ptr M32_L34
M32_L47:
       mov       rdi,[r15+18]
       lea       rsi,[rbp-2A8]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE78A0]
       jmp       short M32_L49
M32_L48:
       mov       rdi,[rbp-290]
       vmovdqu   xmm0,xmmword ptr [rbp-290]
       vmovdqu   xmmword ptr [rbp-2C0],xmm0
       mov       rsi,[rbp-280]
       mov       [rbp-2B0],rsi
       mov       rsi,[rbp-2B8]
       mov       rdx,[rbp-2B0]
       mov       rcx,r13
       mov       r8,rbx
       call      qword ptr [7F9A5BDE7A80]; Kevlar.KevlarProperties.CopyChangedValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
M32_L49:
       lea       rdi,[rbp-2A8]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F9A5BDE7900]
       test      eax,eax
       jne       short M32_L48
M32_L50:
       mov       rdi,[rbp-3B8]
       call      00007F9AD90E6790
       test      eax,eax
       je        short M32_L51
       mov       edi,eax
       mov       rsi,[rbp-3B8]
       call      qword ptr [7F9A5BE86508]
       nop
M32_L51:
       call      M32_L105
       nop
       cmp       qword ptr [rbp-3D0],0
       jne       near ptr M32_L100
       mov       esi,[rbp-2F4]
       mov       [rbp-30],esi
       mov       byte ptr [rbp-2A],1
M32_L52:
       mov       rax,[rbp-38]
       mov       rdx,[rbp-30]
       add       rsp,3D8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M32_L53:
       lea       rdi,[r9+10]
       test      rdi,rdi
       je        near ptr M32_L79
       xor       esi,esi
       mov       rdx,r10
       call      00007F9AD9274060
       mov       r10,[rbp-3A0]
       cmp       rax,r10
       mov       r9,[rbp-398]
       jne       near ptr M32_L09
       mov       rdx,r10
       mov       rax,[rbp-378]
       jmp       near ptr M32_L12
M32_L54:
       mov       rsi,7F9A5BDD7000
       call      qword ptr [7F9A5AE4F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M32_L18
M32_L55:
       mov       rdi,rsi
       mov       rsi,7F9A5BDD7C78
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M32_L19
M32_L56:
       mov       rsi,7F9A5BDD7ED8
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M32_L20
M32_L57:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,902
       mov       rsi,7F9A5B90D998
       call      qword ptr [7F9A5AE4EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F9A5B52E2B0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M32_L58:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,910
       mov       rsi,7F9A5B90D998
       call      qword ptr [7F9A5AE4EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F9A5B52E2B0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M32_L59:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       rsi,rbx
       mov       rdx,r15
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7570]
       mov       [rbp-340],rax
       mov       [rbp-338],rdx
       mov       rax,[rbp-340]
       mov       rdx,[rbp-338]
       add       rsp,3D8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M32_L60:
       call      qword ptr [7F9A5B8DE508]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M32_L61:
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       rsi,7F9275801408
       mov       rsi,[rsi]
       mov       rdi,r12
       mov       rdx,offset Kevlar.Shield+<>c__60`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__60_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F9A5AE46E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F9275801410
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M32_L02
M32_L62:
       call      00007F9A5AE38AE0
       mov       rdi,rax
       jmp       near ptr M32_L03
M32_L63:
       cmp       dword ptr [rdx+20],0
       je        near ptr M32_L04
       mov       rsi,r13
       xor       edx,edx
       call      qword ptr [7F9A5B8DE868]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rdi,rbx
       call      qword ptr [7F9A5BE87108]
       lea       rdi,[rbx+70]
       mov       rsi,[rbp-3C8]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,rbx
       call      qword ptr [7F9A5B8DE8E0]
       mov       rdi,rax
       mov       esi,edx
       call      qword ptr [7F9A5B8DE7F0]
       mov       [rbp-330],rax
       mov       [rbp-328],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-330]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       jmp       near ptr M32_L52
M32_L64:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F9A5BDE67C0]
       jmp       near ptr M32_L05
M32_L65:
       mov       rdi,7F9AD94A0D68
       mov       r9,7F9AD9D06820
       call      r9
       add       rax,3C
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M32_L67
M32_L66:
       mov       rdi,7F9A59E5B1F8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M32_L66
       mov       [rax+10],edi
M32_L67:
       dec       edi
       imul      edi,9E3779B9
       mov       rax,[rbp-378]
       mov       edx,[rax+18]
       test      edx,edx
       jge       short M32_L68
       mov       r9d,edi
       mov       esi,[rax+20]
       imul      r9,rsi
       shr       r9,20
       jmp       short M32_L69
M32_L68:
       mov       r9d,edi
       and       r9d,edx
M32_L69:
       mov       ecx,r9d
       mov       rdi,[rax+8]
       mov       [rbp-64],ecx
       lea       edx,[rcx*8]
       cmp       edx,[rdi+8]
       jae       near ptr M32_L102
       lea       rdi,[rdi+rdx*8+10]
       mov       r8,[rdi]
       mov       rdx,r8
       mov       [rbp-390],rdx
       test      rdx,rdx
       je        short M32_L71
       xor       esi,esi
       call      00007F9AD9274060
       mov       rdi,[rbp-390]
       cmp       rax,rdi
       mov       rax,[rbp-378]
       je        short M32_L72
M32_L70:
       xor       edx,edx
       jmp       short M32_L73
M32_L71:
       mov       rax,[rbp-378]
       jmp       short M32_L70
M32_L72:
       mov       rdx,rdi
M32_L73:
       jmp       near ptr M32_L12
M32_L74:
       mov       rax,7F9A59E5B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-70],eax
       test      eax,eax
       je        short M32_L74
       mov       rdi,7F9AD94A0D68
       mov       rcx,7F9AD9D06820
       call      rcx
       add       rax,48
       mov       ecx,[rbp-70]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M32_L06
M32_L75:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M32_L07
M32_L76:
       mov       rdi,[r10]
       mov       esi,edi
       cmp       esi,0FFFFFFFF
       jne       near ptr M32_L10
M32_L77:
       mov       eax,[rbp-68]
       inc       eax
       mov       edx,eax
       mov       rcx,[rbp-388]
       mov       rax,[rcx+8]
       cmp       [rax+8],edx
       jne       short M32_L78
       xor       edx,edx
M32_L78:
       mov       r8d,[rbp-6C]
       inc       r8d
       mov       eax,edx
       mov       rcx,[rbp-388]
       jmp       near ptr M32_L08
M32_L79:
       call      qword ptr [7F9A5BE86478]
       int       3
M32_L80:
       xor       edx,edx
       mov       rax,[rbp-378]
       jmp       near ptr M32_L12
M32_L81:
       cmp       qword ptr [rbp-388],0
       je        short M32_L82
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       rcx,rax
       mov       [rbp-3A8],rcx
       mov       rdi,rcx
       call      qword ptr [7F9A5BDE6868]; Kevlar.KevlarContext..ctor()
       mov       rcx,[rbp-3A8]
       mov       rax,rcx
       mov       rcx,rax
       mov       rax,[rbp-378]
       jmp       near ptr M32_L14
M32_L82:
       mov       rdi,rax
       mov       esi,[rbp-64]
       call      qword ptr [7F9A5BDE6820]
       mov       rdx,rax
       mov       rax,[rbp-378]
       jmp       near ptr M32_L13
M32_L83:
       mov       [rbp-380],rcx
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-378]
       mov       dil,[rdi+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-380]
       mov       r11,7F9A59E60600
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F9A5BDE67C0]
       mov       rdx,rax
       jmp       near ptr M32_L15
M32_L84:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-360],rax
       mov       rdi,rax
       call      qword ptr [7F9A5BDE6880]; Kevlar.KevlarProperties..ctor()
       lea       rdi,[r13+18]
       mov       rsi,[rbp-360]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M32_L16
M32_L85:
       mov       rdi,offset MT_System.Func<Kevlar.Internal.ShieldEngine+ContextAsyncCallback<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, System.Int32>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<Kevlar.Outcome<System.Int32>>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-3B0],rax
       mov       rsi,7F92758013D8
       mov       rsi,[rsi]
       mov       rdi,rax
       mov       rdx,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       call      qword ptr [7F9A5AE46E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F92758013E0
       mov       rsi,[rbp-3B0]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-3B0]
       jmp       near ptr M32_L17
M32_L86:
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       rdi,r12
       mov       rsi,7F9A58A0B5D8
       call      qword ptr [7F9A5B525608]
       mov       rdi,r12
       call      qword ptr [7F9A5B8DE8E0]
       mov       esi,edx
       xor       r12d,r12d
       xor       r15d,r15d
       mov       [rbp-2F8],r15d
       mov       dword ptr [rbp-2FC],1
       mov       r14d,esi
       mov       r15,rax
       mov       eax,[rbp-2F8]
       mov       ecx,[rbp-2FC]
       jmp       near ptr M32_L22
M32_L87:
       mov       r12,[rbp-0F0]
       test      r12,r12
       jne       short M32_L88
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       rdi,r12
       call      qword ptr [7F9A5BE86A78]
       mov       [rbp-0F0],r12
M32_L88:
       test      r12,r12
       jne       short M32_L89
       mov       edi,9
       call      qword ptr [7F9A5AE4FAE0]
       int       3
M32_L89:
       xor       r15d,r15d
       xor       r14d,r14d
       jmp       near ptr M32_L21
M32_L90:
       mov       rdx,[rbp-88]
       mov       rcx,[rbp-80]
       lea       rsi,[rbp-0B8]
       mov       r8,r13
       mov       rdi,[r15+8]
       call      qword ptr [r15+18]
       jmp       short M32_L92
M32_L91:
       lea       rdi,[rbp-98]
       lea       rsi,[rbp-0B8]
       mov       r8,r13
       mov       rcx,[rbp-98]
       mov       rdx,offset MT_Kevlar.Continuation<System.Int32, Kevlar.Internal.ShieldEngine+ContextAsyncCallback<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, System.Int32>>
       call      qword ptr [7F9A5BDE6A30]
M32_L92:
       mov       r12,[rbp-0B8]
       movsx     rax,word ptr [rbp-0B0]
       mov       r15d,eax
       movzx     ecx,byte ptr [rbp-0AE]
       mov       r14d,ecx
       mov       rdi,[rbp-0A8]
       mov       rax,rdi
       mov       edi,[rbp-0A0]
       mov       esi,edi
       mov       ecx,r14d
       mov       r14d,esi
       mov       rdx,rax
       mov       eax,r15d
       mov       r15,rdx
       jmp       near ptr M32_L22
M32_L93:
       mov       [rbp-2F8],eax
       mov       [rbp-2FC],ecx
       mov       rsi,r12
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F9A5AE46838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       test      rax,rax
       je        short M32_L94
       mov       rdi,rax
       call      qword ptr [7F9A5BDE7138]
       jmp       short M32_L95
M32_L94:
       mov       rdi,r12
       mov       esi,[rbp-2F8]
       mov       r11,7F9A59E60608
       call      qword ptr [r11]
       cmp       eax,1
       sete      al
       movzx     eax,al
M32_L95:
       test      eax,eax
       je        near ptr M32_L101
       mov       rsi,r12
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F9A5AE46838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r15,rax
       test      r15,r15
       je        short M32_L97
       mov       edi,[r15+34]
       and       edi,11000000
       cmp       edi,1000000
       je        short M32_L96
       mov       rdi,r15
       xor       esi,esi
       call      qword ptr [7F9A5BE86430]
M32_L96:
       mov       rdi,[r15+38]
       mov       r14d,[r15+40]
       mov       r15,rdi
       jmp       near ptr M32_L23
M32_L97:
       mov       rdi,r12
       mov       esi,[rbp-2F8]
       mov       r11,7F9A59E60610
       call      qword ptr [r11]
       mov       rdi,rax
       mov       r14d,edx
       mov       r15,rdi
       jmp       near ptr M32_L23
M32_L98:
       mov       rdi,7F9275800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F9A5B8DE9B8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M32_L24
       lea       rdi,[rbp-190]
       mov       rsi,[rbp-350]
       call      qword ptr [7F9A5BDE71F8]
       mov       rdx,7F9A58A0B6A8
       mov       rdi,7F9A58A0B680
       test      r12d,r12d
       cmove     rdx,rdi
       lea       rdi,[rbp-190]
       mov       rsi,7F9A58A0B638
       call      qword ptr [7F9A5BDE7210]
       call      00007F9A5AE38AE0
       mov       rsi,rax
       mov       rdi,r15
       call      qword ptr [7F9A5BE86CD0]
       mov       [rbp-198],rax
       lea       rdi,[rbp-198]
       call      qword ptr [7F9A5BDE7240]
       mov       rdi,7F9275800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-190]
       xor       edx,edx
       call      qword ptr [7F9A5BDE7258]
       jmp       near ptr M32_L24
M32_L99:
       lea       rdi,[rbp-228]
       mov       rsi,[rbp-350]
       call      qword ptr [7F9A5BDE71F8]
       mov       rdx,7F9A58A0B6A8
       mov       rdi,7F9A58A0B680
       test      r12d,r12d
       cmove     rdx,rdi
       lea       rdi,[rbp-228]
       mov       rsi,7F9A58A0B638
       call      qword ptr [7F9A5BDE7210]
       mov       rdi,7F9275800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-228]
       mov       esi,1
       xor       ecx,ecx
       call      qword ptr [7F9A5BDE7270]
       jmp       near ptr M32_L25
M32_L100:
       mov       rdi,[rbp-3D0]
       mov       esi,[rbp-2F4]
       call      qword ptr [7F9A5B8DE7F0]
       mov       [rbp-320],rax
       mov       [rbp-318],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-320]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       jmp       near ptr M32_L52
M32_L101:
       mov       [rbp-60],r12
       mov       r12d,[rbp-2F8]
       mov       [rbp-58],r12w
       mov       r12d,[rbp-2FC]
       mov       [rbp-56],r12b
       mov       [rbp-50],r15
       mov       [rbp-48],r14d
       lea       rdi,[rsp]
       lea       rsi,[rbp-60]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,r13
       mov       rsi,rbx
       mov       rdx,[rbp-40]
       call      qword ptr [7F9A5BDE7708]
       mov       [rbp-310],rax
       mov       [rbp-308],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-310]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       jmp       near ptr M32_L52
M32_L102:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
       sub       rsp,28
       vzeroupper
       cmp       dword ptr [rbp-22C],0
       je        short M32_L104
       cmp       qword ptr [rbp-3B8],0
       jne       short M32_L103
       xor       edi,edi
       call      qword ptr [7F9A5BE864C0]
       int       3
M32_L103:
       mov       rdi,[rbp-3B8]
       call      00007F9AD90E6790
       test      eax,eax
       je        short M32_L104
       mov       edi,eax
       mov       rsi,[rbp-3B8]
       call      qword ptr [7F9A5BE86508]
M32_L104:
       nop
       add       rsp,28
       ret
M32_L105:
       sub       rsp,28
       vzeroupper
       mov       rdi,7F92758013C0
       mov       rbx,[rdi]
       cmp       dword ptr [rbx+1C],0
       je        short M32_L106
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-358]
       mov       r11,7F9A59E60618
       call      qword ptr [r11]
       jmp       near ptr M32_L129
M32_L106:
       mov       rdi,rbx
       mov       rsi,[rbp-358]
       call      qword ptr [7F9A5BDE72B8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       jne       short M32_L107
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-358]
       mov       r11,7F9A59E60620
       call      qword ptr [r11]
       jmp       near ptr M32_L129
M32_L107:
       mov       r15,[rbx+10]
       test      r15,r15
       je        near ptr M32_L120
       mov       rdi,7F9AD94A0D68
       mov       rax,7F9AD9D06820
       call      rax
       add       rax,48
       mov       r14d,[rax+10]
       test      r14d,r14d
       jne       short M32_L109
M32_L108:
       mov       rdi,7F9A59E5B1A8
       mov       eax,1
       mov       r14d,eax
       lock xadd [rdi],r14d
       inc       r14d
       je        short M32_L108
       mov       rdi,7F9AD94A0D68
       mov       rax,7F9AD9D06820
       call      rax
       add       rax,48
       mov       [rax+10],r14d
M32_L109:
       dec       r14d
       mov       r13d,[r15+18]
       test      r13d,r13d
       jl        short M32_L110
       and       r13d,r14d
       jmp       short M32_L111
M32_L110:
       mov       rdi,[r15+8]
       mov       edi,[rdi+8]
       mov       r13d,r14d
       imul      r13,[r15+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
M32_L111:
       xor       r14d,r14d
       mov       rdi,[r15+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M32_L119
M32_L112:
       mov       rdi,[r15+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M32_L127
       mov       esi,r13d
       mov       r12,[rdi+rsi*8+10]
       cmp       [r12],r12b
       lea       rdi,[r12+10]
       test      rdi,rdi
       je        near ptr M32_L125
       mov       rsi,[rbp-358]
       xor       edx,edx
       call      00007F9AD9274060
       test      rax,rax
       je        near ptr M32_L118
       lea       rdi,[r12+20]
       mov       rsi,[r12+8]
       mov       rax,[rdi]
       mov       ecx,eax
       cmp       ecx,0FFFFFFFF
       je        short M32_L114
M32_L113:
       cmp       ecx,[rsi+8]
       jae       near ptr M32_L127
       mov       edx,ecx
       shl       rdx,4
       mov       [rbp-348],rdx
       mov       r8d,[rsi+rdx+18]
       mov       r9,rax
       sar       r9,20
       inc       r9d
       movsxd    r9,r9d
       shl       r9,20
       or        r8,r9
       mov       [rbp-2E8],rax
       lock cmpxchg [rdi],r8
       cmp       rax,[rbp-2E8]
       je        short M32_L116
       mov       rax,[rdi]
       mov       ecx,eax
       cmp       ecx,0FFFFFFFF
       jne       short M32_L113
M32_L114:
       inc       r13d
       mov       rcx,[r15+8]
       cmp       [rcx+8],r13d
       jne       short M32_L115
       xor       r13d,r13d
M32_L115:
       inc       r14d
       cmp       [rcx+8],r14d
       jg        near ptr M32_L112
       jmp       near ptr M32_L119
M32_L116:
       mov       rdi,[r12+8]
       mov       [rbp-2DC],ecx
       cmp       ecx,[rdi+8]
       jae       near ptr M32_L127
       lea       rdi,[rdi+rdx+10]
       mov       rsi,[rbp-358]
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r12+18]
       mov       rcx,[r12+8]
       mov       r15d,[rbp-2DC]
M32_L117:
       mov       rax,[rdi]
       mov       [rbp-2F0],rax
       cmp       r15d,[rcx+8]
       jae       near ptr M32_L127
       mov       r14,[rbp-348]
       mov       [rcx+r14+18],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       esi,r15d
       or        rdx,rsi
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-2F0]
       jne       short M32_L117
M32_L118:
       cmp       dword ptr [rbx+1C],0
       je        near ptr M32_L129
       jmp       near ptr M32_L128
M32_L119:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-358]
       mov       r11,7F9A59E60628
       call      qword ptr [r11]
       jmp       short M32_L118
M32_L120:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M32_L122
M32_L121:
       mov       rdi,7F9A59E5B1F8
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M32_L121
       mov       [rax+10],edi
M32_L122:
       dec       edi
       imul      r15d,edi,9E3779B9
       cmp       dword ptr [rbx+18],0
       jge       short M32_L123
       mov       r14d,r15d
       mov       r13d,[rbx+20]
       imul      r14,r13
       shr       r14,20
       jmp       short M32_L124
M32_L123:
       and       r15d,[rbx+18]
       mov       r14d,r15d
M32_L124:
       mov       rdi,[rbx+8]
       lea       esi,[r14*8]
       cmp       esi,[rdi+8]
       jae       short M32_L127
       lea       esi,[r14*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M32_L126
M32_L125:
       call      qword ptr [7F9A5BE86478]
       int       3
M32_L126:
       mov       rsi,[rbp-358]
       call      00007F9AD9274040
       test      rax,rax
       je        near ptr M32_L118
       mov       rdi,rbx
       mov       rsi,[rbp-358]
       mov       rdx,rax
       mov       ecx,r14d
       call      qword ptr [7F9A5BDE74F8]
       jmp       near ptr M32_L118
M32_L127:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M32_L128:
       mov       rdi,rbx
       call      qword ptr [7F9A5BDE7528]
M32_L129:
       nop
       add       rsp,28
       ret
; Total bytes of code 5379
```
```assembly
; Kevlar.Shield+<>c__60`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__60_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       rcx,rsi
       mov       rsi,rdx
       mov       rax,offset PoolContextProbe+<>c.<NestedContext>b__6_1(Kevlar.KevlarContext)
       cmp       [rcx+18],rax
       jne       short M33_L00
       xor       eax,eax
       mov       rdx,100000000002A
       ret
M33_L00:
       mov       rdi,[rcx+8]
       jmp       qword ptr [rcx+18]
; Total bytes of code 43
```
```assembly
; Kevlar.KevlarProperties..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F9A5BDE6898]; Kevlar.KevlarProperties+AdditionalAttemptState..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-8]
       call      qword ptr [7F9A5AE4C240]; System.Object..ctor()
       mov       rax,[rbp-8]
       mov       rsi,[rax+8]
       mov       rax,[rbp-8]
       lea       rdi,[rax+28]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 104
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       ebx,edi
       call      qword ptr [7F9A5AA06AF0]; Precode of System.Threading.Thread.GetThreadStaticsBase()
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M35_L01
       cmp       [rax],edi
       jle       short M35_L03
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M35_L03
M35_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M35_L01:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M35_L02
       movsxd    rcx,ecx
       add       rax,rcx
       jmp       short M35_L00
M35_L02:
       cmp       [rax+4],ecx
       jle       short M35_L03
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M35_L03
       mov       rax,[rdi]
       test      rax,rax
       je        short M35_L03
       jmp       short M35_L00
M35_L03:
       mov       edi,ebx
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
; Total bytes of code 133
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-18]
       mov       rcx,rax
       test      cl,1
       jne       short M36_L00
       ret
M36_L00:
       jmp       qword ptr [7F9A5AE45C20]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 23
```
```assembly
; Kevlar.KevlarProperties.Clear()
       push      rbp
       push      rbx
       sub       rsp,18
       lea       rbp,[rsp+20]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       rbx,rdi
       cmp       qword ptr [rbx+10],0
       jne       short M37_L01
M37_L00:
       add       rsp,18
       pop       rbx
       pop       rbp
       ret
M37_L01:
       xor       edi,edi
       mov       [rbx+30],edi
       mov       rdi,[rbx+18]
       test      rdi,rdi
       je        short M37_L02
       mov       eax,[rdi+38]
       sub       eax,[rdi+40]
       cmp       eax,20
       jl        short M37_L02
       xor       edi,edi
       mov       [rbx+38],rdi
       mov       [rbx+40],rdi
       mov       [rbx+10],rdi
       mov       [rbx+18],rdi
       jmp       short M37_L00
M37_L02:
       mov       rdi,[rbx+10]
       mov       rax,[rdi]
       mov       rax,[rax+40]
       call      qword ptr [rax+28]
       cmp       qword ptr [rbx+18],0
       je        short M37_L00
       mov       rdi,[rbx+18]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7480]
       mov       rdi,rax
       lea       rsi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7498]
       jmp       short M37_L04
M37_L03:
       mov       rdi,[rbp-18]
       mov       rax,[rbp-18]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+28]
M37_L04:
       lea       rdi,[rbp-20]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+ValueCollection+Enumerator
       call      qword ptr [7F9A5BDE74C8]
       test      eax,eax
       jne       short M37_L03
       jmp       near ptr M37_L00
; Total bytes of code 186
```
```assembly
; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       push      rax
       lea       rbp,[rsp+30]
       mov       rbx,rdi
       lea       rdi,[rbx+8]
       mov       eax,0FFFFFFFF
       lock xadd [rdi],eax
       dec       eax
       je        short M38_L01
M38_L00:
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M38_L01:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F92758013D0
       mov       r15,[rdi]
       cmp       dword ptr [r15+1C],0
       je        short M38_L02
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F9A59E60680
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M38_L02:
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7F9A5BE869A0]
       test      eax,eax
       jne       short M38_L03
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F9A59E60688
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M38_L03:
       mov       r14,[r15+10]
       test      r14,r14
       je        near ptr M38_L13
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M38_L05
M38_L04:
       mov       rdi,7F9A59E5B1E8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M38_L04
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M38_L05:
       dec       r13d
       cmp       dword ptr [r14+18],0
       jl        short M38_L06
       and       r13d,[r14+18]
       jmp       short M38_L07
M38_L06:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r14+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
M38_L07:
       xor       r12d,r12d
       jmp       short M38_L10
M38_L08:
       mov       rdi,[r14+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M38_L21
       mov       esi,r13d
       mov       rax,[rdi+rsi*8+10]
       mov       [rbp-30],rax
       cmp       [rax],al
       lea       rdi,[rax+10]
       test      rdi,rdi
       je        near ptr M38_L18
       mov       rsi,rbx
       xor       edx,edx
       call      00007F9AD9274060
       test      rax,rax
       je        short M38_L11
       mov       rdx,rbx
       mov       rsi,[rbp-30]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F9A5B8DDF38]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M38_L11
       inc       r13d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r13d
       jne       short M38_L09
       xor       r13d,r13d
M38_L09:
       inc       r12d
M38_L10:
       mov       rdi,[r14+8]
       cmp       [rdi+8],r12d
       jg        short M38_L08
       jmp       short M38_L12
M38_L11:
       cmp       dword ptr [r15+1C],0
       je        near ptr M38_L00
       jmp       near ptr M38_L20
M38_L12:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F9A59E60690
       call      qword ptr [r11]
       jmp       short M38_L11
M38_L13:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r14d,[rax+10]
       test      r14d,r14d
       jne       short M38_L15
M38_L14:
       mov       rdi,7F9A59E5B1E0
       mov       eax,1
       mov       r14d,eax
       lock xadd [rdi],r14d
       inc       r14d
       je        short M38_L14
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r14d
M38_L15:
       dec       r14d
       imul      r14d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M38_L16
       mov       r13d,r14d
       mov       r12d,[r15+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M38_L17
M38_L16:
       and       r14d,[r15+18]
       mov       r13d,r14d
M38_L17:
       mov       rdi,[r15+8]
       lea       esi,[r13*8]
       cmp       esi,[rdi+8]
       jae       short M38_L21
       lea       esi,[r13*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M38_L19
M38_L18:
       call      qword ptr [7F9A5BE86478]
       int       3
M38_L19:
       mov       rsi,rbx
       call      00007F9AD9274040
       test      rax,rax
       je        near ptr M38_L11
       mov       rdi,r15
       mov       rsi,rbx
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7F9A5BE869B8]
       jmp       near ptr M38_L11
M38_L20:
       mov       rdi,r15
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F9A5BE869D0]
M38_L21:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 726
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+30]
       mov       rbx,rsi
       mov       r15,rdx
       lea       rdi,[rbx+18]
       mov       rsi,[rbx+8]
       mov       rax,[rdi]
       mov       r14d,eax
       cmp       r14d,0FFFFFFFF
       je        near ptr M39_L03
       mov       ecx,[rsi+8]
M39_L00:
       cmp       r14d,ecx
       jae       near ptr M39_L04
       mov       r13d,r14d
       shl       r13,4
       mov       edx,[rsi+r13+18]
       mov       r8,rax
       sar       r8,20
       inc       r8d
       movsxd    r8,r8d
       shl       r8,20
       or        rdx,r8
       mov       [rbp-28],rax
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-28]
       jne       short M39_L02
       mov       rdi,[rbx+8]
       cmp       r14d,[rdi+8]
       jae       near ptr M39_L04
       mov       rsi,[rdi+r13+10]
       mov       rdi,r15
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbx+8]
       cmp       r14d,[rax+8]
       jae       short M39_L04
       lea       rcx,[rax+r13+10]
       xor       eax,eax
       mov       [rcx],rax
       add       rbx,20
M39_L01:
       mov       rax,[rbx]
       mov       [rbp-30],rax
       mov       [rcx+8],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       edi,r14d
       or        rdx,rdi
       lock cmpxchg [rbx],rdx
       cmp       rax,[rbp-30]
       jne       short M39_L01
       cmp       qword ptr [r15],0
       setne     al
       movzx     eax,al
       add       rsp,10
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M39_L02:
       mov       rax,[rdi]
       mov       r14d,eax
       cmp       r14d,0FFFFFFFF
       jne       near ptr M39_L00
M39_L03:
       xor       eax,eax
       mov       [r15],rax
       add       rsp,10
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M39_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 263
```
```assembly
; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,38
       lea       rbp,[rsp+60]
       xor       eax,eax
       mov       [rbp-38],rax
       mov       rbx,rdi
       cmp       byte ptr [rbx+34],0
       jne       short M40_L04
M40_L00:
       mov       rdi,[rbx+28]
       mov       rax,[rbx+8]
       cmp       rdi,rax
       jne       short M40_L02
       cmp       dword ptr [rax+8],1
       jne       near ptr M40_L23
M40_L01:
       mov       rax,[rbx+8]
       xor       ecx,ecx
       mov       [rax+0C],ecx
       mov       [rax+10],ecx
       add       rsp,38
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M40_L02:
       mov       r15,[rbx+28]
       lea       rdi,[r15+8]
       mov       eax,0FFFFFFFF
       lock xadd [rdi],eax
       dec       eax
       je        short M40_L05
M40_L03:
       mov       rsi,[rbx+8]
       lea       rdi,[rbx+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M40_L01
M40_L04:
       mov       rdi,[rbx+28]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7390]
       mov       byte ptr [rbx+34],0
       jmp       short M40_L00
M40_L05:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F92758013D0
       mov       r14,[rdi]
       cmp       dword ptr [r14+1C],0
       je        short M40_L06
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r15
       mov       r11,7F9A59E60500
       call      qword ptr [r11]
       jmp       short M40_L03
M40_L06:
       mov       rdi,r14
       mov       rsi,r15
       call      qword ptr [7F9A5BE869A0]
       test      eax,eax
       jne       short M40_L07
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r15
       mov       r11,7F9A59E60508
       call      qword ptr [r11]
       jmp       near ptr M40_L03
M40_L07:
       mov       r13,[r14+10]
       test      r13,r13
       je        near ptr M40_L17
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M40_L09
M40_L08:
       mov       rdi,7F9A59E5B1E8
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M40_L08
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M40_L09:
       dec       r12d
       cmp       dword ptr [r13+18],0
       jl        short M40_L10
       and       r12d,[r13+18]
       jmp       short M40_L11
M40_L10:
       mov       rdi,[r13+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r13+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
M40_L11:
       xor       eax,eax
       jmp       short M40_L14
M40_L12:
       mov       rdi,[r13+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M40_L49
       mov       esi,r12d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-48],rcx
       cmp       [rcx],cl
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        near ptr M40_L40
       mov       rsi,r15
       xor       edx,edx
       call      00007F9AD9274060
       test      rax,rax
       je        short M40_L15
       mov       rdx,r15
       mov       rsi,[rbp-48]
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F9A5B8DDF38]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M40_L15
       inc       r12d
       mov       rdi,[r13+8]
       cmp       [rdi+8],r12d
       jne       short M40_L13
       xor       r12d,r12d
M40_L13:
       mov       eax,[rbp-2C]
       inc       eax
M40_L14:
       mov       rdi,[r13+8]
       mov       [rbp-2C],eax
       cmp       [rdi+8],eax
       jg        short M40_L12
       jmp       short M40_L16
M40_L15:
       cmp       dword ptr [r14+1C],0
       je        near ptr M40_L03
       jmp       near ptr M40_L22
M40_L16:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r15
       mov       r11,7F9A59E60510
       call      qword ptr [r11]
       jmp       short M40_L15
M40_L17:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M40_L19
M40_L18:
       mov       rdi,7F9A59E5B1E0
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M40_L18
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M40_L19:
       dec       r13d
       imul      r13d,9E3779B9
       cmp       dword ptr [r14+18],0
       jge       short M40_L20
       mov       r12d,r13d
       mov       r13d,[r14+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M40_L21
M40_L20:
       and       r13d,[r14+18]
M40_L21:
       mov       rdi,[r14+8]
       lea       esi,[r13*8]
       cmp       esi,[rdi+8]
       jae       near ptr M40_L49
       lea       esi,[r13*8]
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       je        near ptr M40_L40
       mov       rsi,r15
       call      00007F9AD9274040
       test      rax,rax
       je        near ptr M40_L15
       mov       rdi,r14
       mov       rsi,r15
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7F9A5BE869B8]
       jmp       near ptr M40_L15
M40_L22:
       mov       rdi,r14
       call      qword ptr [7F9A5BE869D0]
       jmp       near ptr M40_L03
M40_L23:
       mov       rdi,[rbx+8]
       call      qword ptr [7F9A5BDE73A8]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F92758013D0
       mov       r15,[rdi]
       cmp       dword ptr [r15+1C],0
       je        short M40_L24
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F9A5BE869E8]
M40_L24:
       mov       r14,[r15+10]
       xor       r13d,r13d
       test      r14,r14
       jne       near ptr M40_L31
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M40_L26
M40_L25:
       mov       rdi,7F9A59E5B1E0
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M40_L25
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M40_L26:
       dec       r13d
       imul      edi,r13d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M40_L27
       mov       r13d,edi
       mov       edx,[r15+20]
       imul      r13,rdx
       shr       r13,20
       jmp       short M40_L28
M40_L27:
       and       edi,[r15+18]
       mov       r13d,edi
M40_L28:
       mov       rdi,[r15+8]
       lea       edx,[r13*8]
       cmp       edx,[rdi+8]
       jae       near ptr M40_L49
       lea       edx,[r13*8]
       lea       rdi,[rdi+rdx*8+10]
       mov       r12,[rdi]
       test      r12,r12
       je        short M40_L29
       mov       rdx,r12
       xor       esi,esi
       call      00007F9AD9274060
       cmp       rax,r12
       je        short M40_L30
M40_L29:
       xor       r12d,r12d
M40_L30:
       mov       [rbp-38],r12
       jmp       near ptr M40_L43
M40_L31:
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M40_L33
M40_L32:
       mov       rdi,7F9A59E5B1E8
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M40_L32
       mov       edi,44
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M40_L33:
       dec       r12d
       cmp       dword ptr [r14+18],0
       jl        short M40_L34
       and       r12d,[r14+18]
       jmp       short M40_L35
M40_L34:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
M40_L35:
       xor       eax,eax
       jmp       short M40_L39
M40_L36:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M40_L49
       mov       esi,r12d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-50],rcx
       mov       r8,[rcx+10]
       mov       [rbp-58],r8
       test      r8,r8
       je        short M40_L37
       lea       rdi,[rcx+10]
       test      rdi,rdi
       je        short M40_L40
       xor       esi,esi
       mov       rdx,r8
       call      00007F9AD9274060
       mov       rcx,[rbp-58]
       cmp       rax,rcx
       je        short M40_L41
       mov       rcx,[rbp-50]
M40_L37:
       lea       rdx,[rbp-38]
       mov       rsi,rcx
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F9A5B8DDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M40_L43
       inc       r12d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r12d
       jne       short M40_L38
       xor       r12d,r12d
M40_L38:
       mov       eax,[rbp-3C]
       inc       eax
M40_L39:
       mov       rdi,[r14+8]
       mov       [rbp-3C],eax
       cmp       [rdi+8],eax
       jg        near ptr M40_L36
       jmp       short M40_L42
M40_L40:
       call      qword ptr [7F9A5BE86478]
       int       3
M40_L41:
       mov       r8,rcx
       mov       [rbp-38],r8
       jmp       short M40_L43
M40_L42:
       xor       edi,edi
       mov       [rbp-38],rdi
M40_L43:
       mov       r12,[rbp-38]
       cmp       qword ptr [rbp-38],0
       jne       short M40_L45
       test      r14,r14
       je        short M40_L44
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       r14,rax
       mov       dword ptr [r14+8],1
       jmp       short M40_L46
M40_L44:
       mov       rdi,r15
       mov       esi,r13d
       call      qword ptr [7F9A5BE86A00]
       mov       r12,rax
M40_L45:
       mov       r14,r12
M40_L46:
       xor       edi,edi
       mov       [rbp-38],rdi
       cmp       dword ptr [r15+1C],0
       jne       short M40_L47
       mov       rsi,r14
       jmp       short M40_L48
M40_L47:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F9A59E60518
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F9A5BE869E8]
       mov       rsi,rax
M40_L48:
       lea       rdi,[rbx+8]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M40_L03
M40_L49:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 1457
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7F9A5A9F4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7F9A5A9EEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7F9A5A9FF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M41_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M41_L00
       mov       rsi,rax
       call      qword ptr [7F9A5A9EEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M41_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; System.Object..ctor()
       ret
; Total bytes of code 1
```
```assembly
; System.TimeProvider.get_System()
       mov       rax,7F9275800B00
       mov       rax,[rax]
       ret
; Total bytes of code 14
```
```assembly
; Kevlar.KevlarProperties.CopyChangedValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,30
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-38],xmm8
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       r15,rdi
       mov       rbx,rcx
       mov       r14,r8
       cmp       qword ptr [rbx+10],0
       jne       short M44_L04
M44_L00:
       cmp       qword ptr [rbx+18],0
       jne       short M44_L05
M44_L01:
       xor       r13d,r13d
M44_L02:
       xor       edi,edi
       mov       [rbp-28],rdi
       test      r15,r15
       jne       short M44_L06
M44_L03:
       add       rsp,30
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M44_L04:
       vmovdqu   xmm0,xmmword ptr [rbx+38]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-48]
       lea       rdi,[rbp-38]
       call      qword ptr [7F9A5BE87138]
       test      eax,eax
       je        short M44_L00
       mov       r13,[rbx+10]
       jmp       short M44_L02
M44_L05:
       mov       rdi,[rbx+18]
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-48]
       lea       rcx,[rbp-28]
       cmp       [rdi],edi
       call      qword ptr [7F9A5BE20BB0]
       test      eax,eax
       je        short M44_L01
       mov       r13,[rbp-28]
       jmp       short M44_L02
M44_L06:
       mov       rdi,r15
       mov       rax,[r15]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       je        short M44_L03
       mov       rdi,r15
       mov       rsi,r13
       call      qword ptr [7F9A5BDE7A50]
       test      eax,eax
       jne       short M44_L03
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-48]
       mov       rdi,r14
       cmp       [rdi],edi
       call      qword ptr [7F9A5BDE7A38]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,r13
       call      qword ptr [7F9A5BDE7A50]
       test      eax,eax
       je        near ptr M44_L03
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-48]
       mov       rdi,r15
       mov       rsi,r14
       mov       rax,[r15]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
       jmp       near ptr M44_L03
; Total bytes of code 264
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rdi
       mov       rdi,[rbx]
       call      qword ptr [7F9A5B8DDD10]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       r15d,[rax+10]
       test      r15d,r15d
       je        short M45_L02
M45_L00:
       dec       r15d
       mov       eax,[rbx+18]
       test      eax,eax
       jl        short M45_L03
       and       eax,r15d
M45_L01:
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
M45_L02:
       mov       rdi,[rbx]
       call      qword ptr [7F9A5AE45728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       edi,1
       mov       r15d,edi
       lock xadd [rax],r15d
       inc       r15d
       je        short M45_L02
       mov       rdi,[rbx]
       call      qword ptr [7F9A5B8DDD10]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       [rax+10],r15d
       jmp       short M45_L00
M45_L03:
       mov       rax,[rbx+8]
       mov       eax,[rax+8]
       mov       ecx,r15d
       imul      rcx,[rbx+10]
       shr       rcx,20
       inc       rcx
       imul      rax,rcx
       shr       rax,20
       jmp       short M45_L01
; Total bytes of code 134
```
```assembly
; System.Runtime.CompilerServices.AsyncMethodBuilderCore.Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       push      rbp
       push      r15
       push      r14
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+40]
       mov       [rbp-20],rdi
       mov       rbx,rdi
       mov       r15,rsi
       cmp       [r15],r15b
       mov       rdi,7F9AD94A0D68
       mov       rax,7F9AD9D06820
       call      rax
       cmp       dword ptr [rax],4
       jle       short M46_L07
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        short M46_L07
M46_L00:
       mov       r14,[rax+10]
       test      r14,r14
       jne       short M46_L01
       call      qword ptr [7F9A5B52C3F0]; System.Threading.Thread.InitializeCurrentThread()
       mov       r14,rax
M46_L01:
       mov       [rbp-28],r14
       mov       rsi,[r14+8]
       mov       [rbp-30],rsi
       mov       rsi,[r14+10]
       mov       [rbp-38],rsi
       mov       rdi,[rbx+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M46_L03
M46_L02:
       mov       rdi,r15
       call      rax
       jmp       short M46_L04
M46_L03:
       mov       rdi,rbx
       mov       rsi,7F9A5BDD8060
       call      qword ptr [7F9A5AE4F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M46_L02
M46_L04:
       mov       rsi,[rbp-38]
       cmp       rsi,[r14+10]
       jne       short M46_L08
M46_L05:
       mov       rdx,[r14+8]
       cmp       [rbp-30],rdx
       jne       short M46_L09
M46_L06:
       add       rsp,28
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M46_L07:
       mov       edi,4
       call      qword ptr [7F9A5BE86490]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       short M46_L00
M46_L08:
       lea       rdi,[r14+10]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M46_L05
M46_L09:
       mov       rdi,r14
       mov       rsi,[rbp-30]
       call      qword ptr [7F9A5BDE6D60]
       jmp       short M46_L06
       push      rax
       mov       rsi,[rbp-38]
       mov       rdi,[rbp-28]
       cmp       rsi,[rdi+10]
       je        short M46_L10
       lea       rdi,[rdi+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-28]
M46_L10:
       mov       rdx,[rdi+8]
       cmp       [rbp-30],rdx
       je        short M46_L11
       mov       rsi,[rbp-30]
       call      qword ptr [7F9A5BDE6D60]
M46_L11:
       nop
       add       rsp,8
       ret
; Total bytes of code 271
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       dword ptr [rax+8],1
       mov       rdi,[rbp-8]
       call      qword ptr [7F9A5AE4C240]; System.Object..ctor()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbx
       sub       rsp,10
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rbx,rdi
       mov       rdi,rbx
       call      qword ptr [7F9A5AA09718]; Precode of System.Runtime.CompilerServices.InitHelpers.InitClassSlow(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rbx+20]
       mov       rax,[rax-18]
       mov       [rsp+8],rax
       mov       rax,[rsp+8]
       and       rax,0FFFFFFFFFFFFFFFE
       xor       ecx,ecx
       mov       [rsp+8],rcx
       add       rsp,10
       pop       rbx
       ret
; Total bytes of code 59
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rax,[rdi+20]
       mov       ebx,[rax-28]
       cmp       ebx,0FFFFFFFF
       je        near ptr M49_L04
       mov       rdi,7F9AD94A0D68
       mov       rax,7F9AD9D06820
       call      rax
       add       rax,8
       add       rax,0FFFFFFFFFFFFFFF8
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M49_L01
       cmp       [rax],edi
       jle       short M49_L03
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M49_L03
M49_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M49_L01:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M49_L02
       movsxd    rdi,ecx
       add       rax,rdi
       jmp       short M49_L00
M49_L02:
       cmp       [rax+4],ecx
       jle       short M49_L03
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M49_L03
       mov       rax,[rdi]
       test      rax,rax
       je        short M49_L03
       jmp       short M49_L00
M49_L03:
       mov       edi,ebx
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7F9A5BE86340]
M49_L04:
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7F9A5B8DDD58]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 179
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      r15
       push      rbx
       push      rax
       mov       rbx,rdi
       mov       rdi,[rbx+20]
       mov       r15,[rdi-10]
       mov       rdi,r15
       test      dil,1
       jne       short M50_L00
       mov       rdi,7F9A5BED72DC
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,r15
       add       rsp,8
       pop       rbx
       pop       r15
       ret
M50_L00:
       mov       rdi,7F9A5BED72D8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,rbx
       add       rsp,8
       pop       rbx
       pop       r15
       jmp       qword ptr [7F9A5B23EA00]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 81
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       rsi,rdi
       lea       rdi,[rbp-30]
       mov       [rbp-94],rdi
       mov       [rbp-9C],rsi
       xor       edx,edx
       mov       [rbp-8C],edx
       lea       rdi,[rbp-88]
       call      qword ptr [7F9A5A9EEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       edx,[rbp-8C]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7F9A5A9EEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,[rbp-30]
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 131
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbx
       sub       rsp,10
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rbx,rdi
       mov       rdi,rbx
       call      qword ptr [7F9A5AA09718]; Precode of System.Runtime.CompilerServices.InitHelpers.InitClassSlow(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rbx+20]
       mov       rax,[rax-10]
       mov       [rsp+8],rax
       mov       rax,[rsp+8]
       and       rax,0FFFFFFFFFFFFFFFE
       xor       ecx,ecx
       mov       [rsp+8],rcx
       add       rsp,10
       pop       rbx
       ret
; Total bytes of code 59
```

