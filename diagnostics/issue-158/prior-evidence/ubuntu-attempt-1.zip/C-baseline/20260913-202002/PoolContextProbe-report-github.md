```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.45GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  C-baseline : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

Job=C-baseline  EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.4.0,DOTNET_TieredPGO=1  Arguments=/p:ReservoirVersion=1.4.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll  
IterationCount=10  LaunchCount=3  WarmupCount=5  

```
| Method           | Mean      | Error     | StdDev    | Median    | Code Size | Allocated |
|----------------- |----------:|----------:|----------:|----------:|----------:|----------:|
| SingleRentReturn |  15.82 ns |  0.065 ns |  0.094 ns |  15.77 ns |   5,433 B |         - |
| NestedRentReturn |  37.93 ns |  0.663 ns |  0.907 ns |  37.46 ns |   6,693 B |         - |
| SingleContext    | 102.18 ns |  1.582 ns |  2.166 ns | 102.59 ns |  16,161 B |         - |
| NestedContext    | 220.09 ns | 10.618 ns | 14.885 ns | 211.23 ns |  30,960 B |         - |
