## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: B-candidate(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.9.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.9.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=10, LaunchCount=3, WarmupCount=5))

```assembly
; PoolContextProbe.SingleRentReturn()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,48
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       [rbp-38],rax
       mov       rbx,rdi
       mov       r15,[rbx+8]
       cmp       byte ptr [r15+24],0
       jne       near ptr M00_L12
       cmp       dword ptr [r15+1C],0
       jne       near ptr M00_L39
M00_L00:
       mov       r14,[r15+10]
       xor       r13d,r13d
       test      r14,r14
       je        near ptr M00_L40
       mov       rdi,7FCA294A0D68
       mov       rax,7FCA29D08820
       call      rax
       add       rax,48
       mov       r12d,[rax+10]
       test      r12d,r12d
       je        near ptr M00_L48
M00_L01:
       dec       r12d
       mov       eax,[r14+18]
       test      eax,eax
       jl        near ptr M00_L49
       and       r12d,eax
M00_L02:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M00_L68
       mov       edx,r12d
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-58],rax
       mov       rcx,[rax+50]
       mov       [rbp-60],rcx
       test      rcx,rcx
       je        near ptr M00_L50
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M00_L65
       mov       rdx,rcx
       xor       esi,esi
       call      00007FCA29274060
       mov       rdx,[rbp-60]
       cmp       rax,rdx
       mov       rax,[rbp-58]
       jne       near ptr M00_L50
       mov       [rbp-38],rdx
M00_L03:
       mov       rsi,[rbp-38]
       cmp       qword ptr [rbp-38],0
       je        near ptr M00_L51
M00_L04:
       xor       edi,edi
       mov       [rbp-38],rdi
       cmp       dword ptr [r15+1C],0
       jne       near ptr M00_L53
M00_L05:
       mov       r15,rsi
       mov       r14d,[r15+8]
       mov       rbx,[rbx+8]
       cmp       byte ptr [rbx+24],0
       jne       near ptr M00_L54
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M00_L10
       mov       rdi,rbx
       mov       rsi,r15
       call      qword ptr [7FC9AB8BDF08]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItemGuarded(System.__Canon)
       test      eax,eax
       je        near ptr M00_L10
       mov       r13,[rbx+10]
       test      r13,r13
       je        near ptr M00_L60
       mov       rdi,7FCA294A0D68
       mov       rax,7FCA29D08820
       call      rax
       add       rax,48
       mov       r12d,[rax+10]
       test      r12d,r12d
       je        near ptr M00_L55
M00_L06:
       dec       r12d
       mov       eax,[r13+18]
       test      eax,eax
       jl        near ptr M00_L56
       and       r12d,eax
M00_L07:
       xor       eax,eax
       mov       [rbp-3C],eax
       mov       rdi,[r13+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M00_L59
M00_L08:
       mov       rdi,[r13+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M00_L68
       mov       esi,r12d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-68],rcx
       cmp       qword ptr [rcx+50],0
       jne       short M00_L11
       lea       rdi,[rcx+50]
       test      rdi,rdi
       je        near ptr M00_L65
       mov       rsi,r15
       xor       edx,edx
       call      00007FCA29274060
       test      rax,rax
       mov       rcx,[rbp-68]
       jne       short M00_L11
M00_L09:
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M00_L67
M00_L10:
       mov       eax,r14d
       add       rsp,48
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M00_L11:
       mov       rdx,r15
       mov       rsi,rcx
       mov       rdi,offset MT_Reservoir.StripedObjectStore<PoolContextProbe+Item>
       call      qword ptr [7FC9AB8BE040]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       je        near ptr M00_L57
       jmp       short M00_L09
M00_L12:
       cmp       dword ptr [r15+1C],0
       je        short M00_L13
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7FC9AB8BDBF0]
M00_L13:
       lea       rdi,[r15+28]
       mov       rsi,[rdi]
       test      rsi,rsi
       jne       short M00_L14
       mov       rsi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<PoolContextProbe+Item>
       call      qword ptr [7FC9ABE66A18]
       mov       rsi,rax
M00_L14:
       mov       rdi,rsi
       cmp       [rdi],edi
       call      qword ptr [7FC9ABE66A30]
       mov       r14,rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<PoolContextProbe+Item>
       call      qword ptr [7FC9AAE25728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       cmp       byte ptr [7FC9A9E3B1F0],0
       je        short M00_L17
       mov       edx,[r14+68]
       mov       rax,[r14+58]
       test      rax,rax
       je        short M00_L18
       xor       esi,esi
       mov       [r14+58],rsi
       cmp       [r14+68],edx
       jne       short M00_L15
       test      dl,1
       je        short M00_L16
M00_L15:
       mov       rdx,rax
       mov       rsi,r14
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<PoolContextProbe+Item>
       call      qword ptr [7FC9ABE66A48]
       test      rax,rax
       je        short M00_L18
M00_L16:
       jmp       near ptr M00_L36
M00_L17:
       cmp       qword ptr [r14+58],0
       je        short M00_L18
       lea       rdi,[r14+58]
       test      rdi,rdi
       je        near ptr M00_L65
       xor       esi,esi
       call      00007FCA29274040
       test      rax,rax
       jne       short M00_L16
M00_L18:
       cmp       byte ptr [r14+6C],0
       jne       short M00_L19
       mov       byte ptr [r14+6C],1
M00_L19:
       mov       r14,[r15+10]
       xor       r13d,r13d
       test      r14,r14
       jne       near ptr M00_L27
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M00_L21
M00_L20:
       mov       rdi,7FC9A9E3B1E8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M00_L20
       mov       [rax+10],edi
M00_L21:
       dec       edi
       imul      edi,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M00_L22
       mov       r13d,edi
       mov       edx,[r15+20]
       imul      r13,rdx
       shr       r13,20
       jmp       short M00_L23
M00_L22:
       and       edi,[r15+18]
       mov       r13d,edi
M00_L23:
       mov       rdi,[r15+8]
       lea       edx,[r13*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M00_L68
       lea       rdi,[rdi+rdx*8+10]
       mov       r12,[rdi]
       test      r12,r12
       je        short M00_L24
       mov       rdx,r12
       xor       esi,esi
       call      00007FCA29274060
       cmp       rax,r12
       je        short M00_L25
M00_L24:
       xor       edi,edi
       jmp       short M00_L26
M00_L25:
       mov       rdi,r12
M00_L26:
       mov       [rbp-30],rdi
       jmp       near ptr M00_L33
M00_L27:
       mov       edi,48
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M00_L29
M00_L28:
       mov       rdi,7FC9A9E3B178
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M00_L28
       mov       edi,48
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M00_L29:
       dec       r12d
       cmp       dword ptr [r14+18],0
       jl        short M00_L30
       and       r12d,[r14+18]
       jmp       short M00_L31
M00_L30:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
M00_L31:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M00_L68
       mov       edx,r12d
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-48],rax
       mov       rcx,[rax+50]
       mov       [rbp-50],rcx
       test      rcx,rcx
       je        short M00_L32
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M00_L65
       mov       rdx,rcx
       xor       esi,esi
       call      00007FCA29274060
       mov       rdx,[rbp-50]
       cmp       rax,rdx
       mov       rax,[rbp-48]
       jne       short M00_L32
       mov       [rbp-30],rdx
       jmp       short M00_L33
M00_L32:
       lea       rdx,[rbp-30]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<PoolContextProbe+Item>
       call      qword ptr [7FC9AB8BDDE8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M00_L33
       lea       rdx,[rbp-30]
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7FC9AB8BDD10]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M00_L33:
       mov       rax,[rbp-30]
       cmp       qword ptr [rbp-30],0
       jne       short M00_L35
       test      r14,r14
       je        short M00_L34
       mov       rdi,offset MT_PoolContextProbe+Item
       call      CORINFO_HELP_NEWSFAST
       mov       dword ptr [rax+8],2A
       jmp       short M00_L35
M00_L34:
       mov       rdi,r15
       mov       esi,r13d
       call      qword ptr [7FC9AB8BDCC8]
M00_L35:
       xor       edi,edi
       mov       [rbp-30],rdi
M00_L36:
       cmp       dword ptr [r15+1C],0
       jne       short M00_L37
       mov       rsi,rax
       jmp       short M00_L38
M00_L37:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7FC9AB8BDBF0]
       mov       rsi,rax
M00_L38:
       jmp       near ptr M00_L05
M00_L39:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7FC9AB8BDBF0]
       jmp       near ptr M00_L00
M00_L40:
       mov       rdi,7FCA294A0D68
       mov       rax,7FCA29D08820
       call      rax
       add       rax,3C
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M00_L42
M00_L41:
       mov       rdi,7FC9A9E3B1E8
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M00_L41
       mov       [rax+10],edi
M00_L42:
       dec       edi
       imul      edi,9E3779B9
       mov       edx,[r15+18]
       test      edx,edx
       jge       short M00_L43
       mov       r13d,edi
       mov       esi,[r15+20]
       imul      r13,rsi
       shr       r13,20
       jmp       short M00_L44
M00_L43:
       mov       r13d,edi
       and       r13d,edx
M00_L44:
       mov       rdi,[r15+8]
       lea       edx,[r13*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M00_L68
       lea       rdi,[rdi+rdx*8+10]
       mov       r12,[rdi]
       test      r12,r12
       je        short M00_L45
       mov       rdx,r12
       xor       esi,esi
       call      00007FCA29274060
       cmp       rax,r12
       je        short M00_L46
M00_L45:
       xor       edi,edi
       jmp       short M00_L47
M00_L46:
       mov       rdi,r12
M00_L47:
       mov       [rbp-38],rdi
       jmp       near ptr M00_L03
M00_L48:
       mov       rdi,7FC9A9E3B178
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M00_L48
       mov       rdi,7FCA294A0D68
       mov       rax,7FCA29D08820
       call      rax
       add       rax,48
       mov       [rax+10],r12d
       jmp       near ptr M00_L01
M00_L49:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
       jmp       near ptr M00_L02
M00_L50:
       lea       rdx,[rbp-38]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<PoolContextProbe+Item>
       call      qword ptr [7FC9AB8BDDE8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       near ptr M00_L03
       lea       rdx,[rbp-38]
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7FC9AB8BDD10]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       jmp       near ptr M00_L03
M00_L51:
       test      r14,r14
       je        short M00_L52
       mov       rdi,offset MT_PoolContextProbe+Item
       call      CORINFO_HELP_NEWSFAST
       mov       rsi,rax
       mov       dword ptr [rsi+8],2A
       jmp       near ptr M00_L04
M00_L52:
       mov       rdi,r15
       mov       esi,r13d
       call      qword ptr [7FC9AB8BDCC8]
       mov       rsi,rax
       jmp       near ptr M00_L04
M00_L53:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7FC9AB8BDBF0]
       mov       rsi,rax
       jmp       near ptr M00_L05
M00_L54:
       mov       rdi,rbx
       call      qword ptr [7FC9AB8BDEA8]
       jmp       near ptr M00_L10
M00_L55:
       mov       rdi,7FC9A9E3B178
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M00_L55
       mov       rdi,7FCA294A0D68
       mov       rax,7FCA29D08820
       call      rax
       add       rax,48
       mov       [rax+10],r12d
       jmp       near ptr M00_L06
M00_L56:
       mov       rdi,[r13+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r13+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
       jmp       near ptr M00_L07
M00_L57:
       inc       r12d
       mov       rdi,[r13+8]
       cmp       [rdi+8],r12d
       jne       short M00_L58
       xor       r12d,r12d
M00_L58:
       mov       eax,[rbp-3C]
       inc       eax
       mov       rdi,[r13+8]
       cmp       [rdi+8],eax
       mov       [rbp-3C],eax
       jg        near ptr M00_L08
M00_L59:
       cmp       [rbx],bl
       jmp       near ptr M00_L09
M00_L60:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M00_L62
M00_L61:
       mov       rdi,7FC9A9E3B1E8
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M00_L61
       mov       [rax+10],edi
M00_L62:
       dec       edi
       imul      r13d,edi,9E3779B9
       cmp       dword ptr [rbx+18],0
       jge       short M00_L63
       mov       r12d,r13d
       mov       r13d,[rbx+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M00_L64
M00_L63:
       and       r13d,[rbx+18]
M00_L64:
       mov       rdi,[rbx+8]
       lea       esi,[r13*8+8]
       cmp       esi,[rdi+8]
       jae       short M00_L68
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M00_L66
M00_L65:
       call      qword ptr [7FC9ABE66268]
       int       3
M00_L66:
       mov       rsi,r15
       call      00007FCA29274040
       test      rax,rax
       je        near ptr M00_L09
       mov       rdi,rbx
       mov       rsi,r15
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7FC9AB8BE028]
       jmp       near ptr M00_L09
M00_L67:
       mov       rdi,rbx
       call      qword ptr [7FC9AB8BE070]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       jmp       near ptr M00_L10
M00_L68:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 1953
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItemGuarded(System.__Canon)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       cmp       [rdi],dil
       mov       eax,1
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
       push      rax
       mov       rbx,rdi
       mov       rdi,offset MT_System.Exception[]
       mov       esi,2
       call      CORINFO_HELP_NEWARR_1_PTR
       mov       r15,rax
       lea       rdi,[r15+10]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r15+18]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,offset MT_System.AggregateException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,0C1
       mov       rsi,7FC9AB2A54D8
       call      qword ptr [7FC9AAE2EF88]
       mov       rsi,rax
       mov       rdi,rbx
       mov       rdx,r15
       call      qword ptr [7FC9AB8BDFB0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
       push      rax
       mov       rsi,rdi
       mov       [rbp-20],rsi
       mov       rdi,[rbp-18]
       cmp       [rdi],dil
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 170
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+48]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+60]
       mov       rdi,[rbp-10]
       call      qword ptr [7FC9AB8BDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M02_L00
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M02_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+48]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M02_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rbp-20]
       mov       rdi,rax
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+58]
       mov       rax,[rbp-18]
       mov       rdx,[rax+48]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7FC9AB8BDE18]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       eax,1
       add       rsp,30
       pop       rbp
       ret
M02_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 171
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-10]
       mov       rcx,rax
       test      cl,1
       jne       short M03_L00
       ret
M03_L00:
       jmp       qword ptr [7FC9AB21EA48]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 23
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+48]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+58]
       mov       rdi,[rbp-10]
       call      qword ptr [7FC9AB8BDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M04_L00
       mov       rax,[rbp-20]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M04_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+48]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M04_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rax]
       mov       rdi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       mov       rax,[rax+48]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M04_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       xor       ecx,ecx
       mov       [rax],rcx
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+60]
       mov       rax,[rbp-18]
       mov       rdx,[rax+48]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7FC9AB8BDE18]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       rax,[rbp-20]
       cmp       qword ptr [rax],0
       setne     al
       movzx     eax,al
       add       rsp,30
       pop       rbp
       ret
M04_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 221
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       push      rbp
       sub       rsp,60
       lea       rbp,[rsp+60]
       xor       eax,eax
       mov       [rbp-54],rax
       mov       [rbp-4C],eax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-3C],esi
       mov       [rbp-48],rdx
       mov       dword ptr [rbp-60],3E8
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FC9AB8BDD28]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       eax,[rax+14]
       dec       eax
       mov       [rbp-4C],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-4C]
       jbe       short M05_L02
       mov       eax,[rbp-4C]
       cmp       eax,[rbp-3C]
       je        short M05_L01
       mov       rdi,[rbp-38]
       mov       esi,[rbp-4C]
       mov       rdx,[rbp-48]
       call      qword ptr [7FC9AB8BDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       je        short M05_L00
       mov       rdi,7FC9ABCB72E0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,60
       pop       rbp
       ret
M05_L00:
       mov       rdi,7FC9ABCB72E4
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       short M05_L02
M05_L01:
       mov       rdi,7FC9ABCB72E8
       call      CORINFO_HELP_COUNTPROFILE32
M05_L02:
       mov       eax,[rbp-3C]
       mov       [rbp-50],eax
       mov       dword ptr [rbp-54],1
       jmp       near ptr M05_L06
M05_L03:
       mov       eax,[rbp-50]
       inc       eax
       mov       [rbp-58],eax
       mov       eax,[rbp-50]
       inc       eax
       mov       [rbp-50],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-58]
       jne       short M05_L04
       mov       rdi,7FC9ABCB72EC
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-50],eax
M05_L04:
       mov       rdi,[rbp-38]
       mov       esi,[rbp-50]
       mov       rdx,[rbp-48]
       call      qword ptr [7FC9AB8BDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       je        short M05_L05
       mov       rdi,7FC9ABCB72F0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FC9AB8BDD28]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       ecx,[rbp-50]
       inc       ecx
       mov       [rax+14],ecx
       mov       eax,1
       add       rsp,60
       pop       rbp
       ret
M05_L05:
       mov       rdi,7FC9ABCB72F4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-54]
       inc       eax
       mov       [rbp-54],eax
M05_L06:
       mov       eax,[rbp-60]
       dec       eax
       mov       [rbp-60],eax
       cmp       dword ptr [rbp-60],0
       jg        short M05_L07
       lea       rdi,[rbp-60]
       mov       esi,52
       call      CORINFO_HELP_PATCHPOINT
M05_L07:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-54]
       jg        near ptr M05_L03
       mov       rdi,7FC9ABCB72F8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-48]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,60
       pop       rbp
       ret
; Total bytes of code 406
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       push      rbp
       sub       rsp,0B0
       lea       rbp,[rsp+0B0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       dword ptr [rbp-88],3E8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-98],rax
       mov       rax,[rbp-98]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+50]
       mov       [rbp-0A0],rax
       cmp       qword ptr [rbp-0A0],0
       je        short M06_L00
       mov       rax,[rbp-0A0]
       mov       [rbp-70],rax
       jmp       short M06_L01
M06_L00:
       mov       rdi,[rbp-98]
       mov       rsi,7FC9ABF3B2F8
       call      qword ptr [7FC9AAE2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-70],rax
M06_L01:
       mov       rax,[rbp-38]
       cmp       [rax],al
       mov       rax,[rbp-38]
       lea       rdi,[rax+28]
       mov       rsi,[rbp-70]
       mov       rdx,[rbp-38]
       call      qword ptr [7FC9ABE666D0]; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       nop
M06_L02:
       mov       rax,[rbp-38]
       mov       rax,[rax+10]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-48],0
       je        near ptr M06_L07
M06_L03:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M06_L04
       lea       rdi,[rbp-88]
       mov       esi,1D
       call      CORINFO_HELP_PATCHPOINT
M06_L04:
       lea       rsi,[rbp-50]
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7FC9AB8BDC98]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       test      eax,eax
       je        short M06_L05
       mov       rdi,7FC9ABF67FA4
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-50]
       call      qword ptr [7FC9ABF2C558]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       jmp       short M06_L03
M06_L05:
       cmp       qword ptr [rbp-40],0
       je        short M06_L06
       mov       rdi,7FC9ABF67FA8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7FC9ABF2C570]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FC9ABF2C588]
M06_L06:
       mov       rdi,7FC9ABF67FAC
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M06_L07:
       xor       eax,eax
       mov       [rbp-54],eax
       jmp       near ptr M06_L12
M06_L08:
       mov       rdi,[rbp-38]
       mov       esi,[rbp-54]
       call      qword ptr [7FC9AB8BDC80]
       mov       [rbp-60],rax
       mov       rax,[rbp-60]
       cmp       qword ptr [rax],0
       je        near ptr M06_L11
       mov       rdi,7FC9ABF67FB0
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-68],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-0A8],rax
       mov       rax,[rbp-0A8]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+40]
       mov       [rbp-0B0],rax
       cmp       qword ptr [rbp-0B0],0
       je        short M06_L09
       mov       rax,[rbp-0B0]
       mov       [rbp-78],rax
       jmp       short M06_L10
M06_L09:
       mov       rdi,[rbp-0A8]
       mov       rsi,7FC9ABCC09D0
       call      qword ptr [7FC9AAE2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-78],rax
M06_L10:
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-60]
       mov       rdx,[rbp-68]
       call      qword ptr [7FC9AB8BDFC8]
       mov       [rbp-90],rax
       mov       rsi,[rbp-90]
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       call      qword ptr [7FC9ABF2C558]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
M06_L11:
       mov       rdi,7FC9ABF67FB4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-54]
       inc       eax
       mov       [rbp-54],eax
M06_L12:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M06_L13
       lea       rdi,[rbp-88]
       mov       esi,79
       call      CORINFO_HELP_PATCHPOINT
M06_L13:
       mov       rdi,[rbp-38]
       call      qword ptr [7FC9ABF2C5A0]
       cmp       eax,[rbp-54]
       jg        near ptr M06_L08
       cmp       qword ptr [rbp-40],0
       je        short M06_L14
       mov       rdi,7FC9ABF67FB8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7FC9ABF2C570]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FC9ABF2C588]
M06_L14:
       mov       rdi,7FC9ABF67FBC
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
       push      rax
       mov       [rbp-80],rdi
       mov       rdi,7FC9ABF67FA0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-80]
       mov       [rbp-40],rax
       lea       rax,[M06_L02]
       add       rsp,8
       ret
; Total bytes of code 760
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-50],rcx
       mov       dword ptr [rbp-70],3E8
M07_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M07_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M07_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7FC9AB8BDE30]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-50]
       mov       [rcx],eax
       mov       rax,[rbp-50]
       cmp       dword ptr [rax],0FFFFFFFF
       jne       short M07_L02
       mov       rdi,7FC9ABCB7270
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,70
       pop       rbp
       ret
M07_L02:
       mov       rax,[rbp-50]
       mov       eax,[rax]
       mov       rcx,[rbp-48]
       cmp       eax,[rcx+8]
       jae       short M07_L04
       mov       edx,eax
       imul      rdx,10
       lea       rcx,[rcx+rdx+10]
       mov       eax,[rcx+8]
       mov       [rbp-5C],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-5C]
       call      qword ptr [7FC9AB8BDE48]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-68],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-68]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M07_L03
       mov       rdi,7FC9ABCB7274
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,70
       pop       rbp
       ret
M07_L03:
       mov       rdi,7FC9ABCB7278
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M07_L00
M07_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 269
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-4C],ecx
       mov       dword ptr [rbp-70],3E8
M08_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M08_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M08_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rax,[rbp-48]
       mov       ecx,[rbp-4C]
       cmp       ecx,[rax+8]
       jae       near ptr M08_L03
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       add       rax,8
       mov       [rbp-68],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7FC9AB8BDE30]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-68]
       mov       [rcx],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-4C]
       call      qword ptr [7FC9AB8BDE48]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-60],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-60]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M08_L02
       mov       rdi,7FC9ABCB84F0
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,70
       pop       rbp
       ret
M08_L02:
       mov       rdi,7FC9ABCB84F4
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M08_L00
M08_L03:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 235
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbx
       sub       rsp,10
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rbx,rdi
       mov       rdi,rbx
       call      qword ptr [7FC9AA9E9718]; Precode of System.Runtime.CompilerServices.InitHelpers.InitClassSlow(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rbx+20]
       mov       rax,[rax-10]
       mov       [rsp+8],rax
       mov       rax,[rsp+8]
       and       rax,0FFFFFFFFFFFFFFFE
       xor       ecx,ecx
       mov       [rsp+8],rcx
       add       rsp,10
       pop       rbx
       ret
; Total bytes of code 59
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rax,[rdi+20]
       mov       ebx,[rax-28]
       cmp       ebx,0FFFFFFFF
       je        near ptr M10_L04
       mov       rdi,7FCA294A0D68
       mov       rax,7FCA29D08820
       call      rax
       add       rax,8
       add       rax,0FFFFFFFFFFFFFFF8
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M10_L01
       cmp       [rax],edi
       jle       short M10_L03
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M10_L03
M10_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M10_L01:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M10_L02
       movsxd    rdi,ecx
       add       rax,rdi
       jmp       short M10_L00
M10_L02:
       cmp       [rax+4],ecx
       jle       short M10_L03
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M10_L03
       mov       rax,[rdi]
       test      rax,rax
       je        short M10_L03
       jmp       short M10_L00
M10_L03:
       mov       edi,ebx
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7FC9ABE663A0]
M10_L04:
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7FC9AB8BDD70]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 179
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+30]
       mov       [rbp-28],rdi
       mov       rbx,rdi
       mov       r15,rdx
       mov       rdi,[rbx+8]
       cmp       esi,[rdi+8]
       jae       short M11_L02
       mov       edx,esi
       mov       r14,[rdi+rdx*8+10]
       mov       r13,[r14+50]
       test      r13,r13
       je        short M11_L01
       lea       rdi,[r14+50]
       test      rdi,rdi
       je        short M11_L00
       mov       rdx,r13
       xor       esi,esi
       call      00007FCA29274060
       cmp       rax,r13
       jne       short M11_L01
       mov       rdi,r15
       mov       rsi,r13
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       eax,1
       add       rsp,10
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M11_L00:
       call      qword ptr [7FC9ABE66268]
       int       3
M11_L01:
       mov       rdi,[rbx]
       mov       rsi,r14
       mov       rdx,r15
       add       rsp,10
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7FC9AB8BDDE8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
M11_L02:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 145
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7FC9AA9CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7FC9AA9CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       push      rbp
       sub       rsp,310
       lea       rbp,[rsp+310]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-270],xmm8
       mov       rax,0FFFFFFFFFFFFFDF0
M13_L00:
       vmovdqa   xmmword ptr [rbp+rax-50],xmm8
       vmovdqa   xmmword ptr [rbp+rax-40],xmm8
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       add       rax,30
       jne       short M13_L00
       mov       [rbp-50],rax
       mov       [rbp-30],rsi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       dword ptr [rbp-228],3E8
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       jne       short M13_L01
       mov       rdi,7FC9ABF694A8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,310
       pop       rbp
       ret
M13_L01:
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+10]
       mov       [rbp-278],rax
       cmp       qword ptr [rbp-278],0
       je        short M13_L02
       mov       rax,[rbp-278]
       mov       [rbp-148],rax
       jmp       short M13_L03
M13_L02:
       mov       rdi,[rbp-40]
       mov       rsi,7FC9ABF3B598
       call      qword ptr [7FC9AAE2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-148],rax
M13_L03:
       mov       rdi,[rbp-148]
       call      qword ptr [7FC9AAE25728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       movzx     eax,byte ptr [rax]
       test      eax,eax
       je        near ptr M13_L37
       vxorps    ymm0,ymm0,ymm0
       vmovdqu   ymmword ptr [rbp-98],ymm0
       vmovdqu   ymmword ptr [rbp-78],ymm0
       mov       rax,[rbp-50]
       mov       [rbp-0B8],rax
       xor       eax,eax
       mov       [rbp-0C0],eax
       lea       rsi,[rbp-0C0]
       mov       rdi,[rbp-0B8]
       call      qword ptr [7FC9AAE25980]; System.Threading.Monitor.Enter(System.Object, Boolean ByRef)
       mov       rdi,[rbp-50]
       cmp       [rdi],edi
       call      qword ptr [7FC9ABF2C660]
       mov       [rbp-0C8],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-280],rax
       mov       rax,[rbp-280]
       cmp       qword ptr [rax+8],30
       jle       short M13_L04
       mov       rax,[rbp-280]
       mov       rax,[rax+30]
       mov       [rbp-288],rax
       cmp       qword ptr [rbp-288],0
       je        short M13_L04
       mov       rax,[rbp-288]
       mov       [rbp-178],rax
       jmp       short M13_L05
M13_L04:
       mov       rdi,[rbp-40]
       mov       rsi,7FC9ABF3B720
       call      qword ptr [7FC9AAE2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-178],rax
M13_L05:
       mov       rax,[rbp-0C8]
       mov       [rbp-1F0],rax
       mov       rdi,[rbp-1F0]
       mov       rsi,7FC9ABF694B0
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-1F0]
       mov       [rbp-230],rax
       mov       rdi,[rbp-230]
       mov       r11,[rbp-178]
       mov       rax,[rbp-178]
       call      qword ptr [rax]
       mov       [rbp-0AC],eax
       cmp       dword ptr [rbp-0AC],8
       jg        near ptr M13_L08
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-290],rax
       mov       rax,[rbp-290]
       cmp       qword ptr [rax+8],58
       jle       short M13_L06
       mov       rax,[rbp-290]
       mov       rax,[rax+58]
       mov       [rbp-298],rax
       cmp       qword ptr [rbp-298],0
       je        short M13_L06
       mov       rax,[rbp-298]
       mov       [rbp-1D8],rax
       jmp       short M13_L07
M13_L06:
       mov       rdi,[rbp-40]
       mov       rsi,7FC9ABF3BB50
       call      qword ptr [7FC9AAE2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1D8],rax
M13_L07:
       lea       rsi,[rbp-98]
       mov       rdi,[rbp-1D8]
       mov       edx,8
       call      qword ptr [7FC9ABF2C618]
       mov       [rbp-1E8],rax
       mov       [rbp-1E0],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-1E8]
       vmovdqu   xmmword ptr [rbp-0A8],xmm0
       jmp       near ptr M13_L13
M13_L08:
       mov       rdi,7FC9ABF695B8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2A0],rax
       mov       rax,[rbp-2A0]
       cmp       qword ptr [rax+8],38
       jle       short M13_L09
       mov       rax,[rbp-2A0]
       mov       rax,[rax+38]
       mov       [rbp-2A8],rax
       cmp       qword ptr [rbp-2A8],0
       je        short M13_L09
       mov       rax,[rbp-2A8]
       mov       [rbp-180],rax
       jmp       short M13_L10
M13_L09:
       mov       rdi,[rbp-40]
       mov       rsi,7FC9ABF3B758
       call      qword ptr [7FC9AAE2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-180],rax
M13_L10:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2B0],rax
       mov       rax,[rbp-2B0]
       cmp       qword ptr [rax+8],40
       jle       short M13_L11
       mov       rax,[rbp-2B0]
       mov       rax,[rax+40]
       mov       [rbp-2B8],rax
       cmp       qword ptr [rbp-2B8],0
       je        short M13_L11
       mov       rax,[rbp-2B8]
       mov       [rbp-188],rax
       jmp       short M13_L12
M13_L11:
       mov       rdi,[rbp-40]
       mov       rsi,7FC9ABF3B7E8
       call      qword ptr [7FC9AAE2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-188],rax
M13_L12:
       movsxd    rsi,dword ptr [rbp-0AC]
       mov       rdi,[rbp-180]
       call      CORINFO_HELP_NEWARR_1_PTR
       mov       [rbp-238],rax
       mov       rsi,[rbp-238]
       mov       rdi,[rbp-188]
       call      qword ptr [7FC9AB8B5458]; System.Span`1[[System.__Canon, System.Private.CoreLib]].op_Implicit(System.__Canon[])
       mov       [rbp-198],rax
       mov       [rbp-190],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-198]
       vmovdqu   xmmword ptr [rbp-0A8],xmm0
M13_L13:
       xor       eax,eax
       mov       [rbp-0CC],eax
       jmp       near ptr M13_L17
M13_L14:
       mov       rdi,7FC9ABF695BC
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2C0],rax
       mov       rax,[rbp-2C0]
       cmp       qword ptr [rax+8],48
       jle       short M13_L15
       mov       rax,[rbp-2C0]
       mov       rax,[rax+48]
       mov       [rbp-2C8],rax
       cmp       qword ptr [rbp-2C8],0
       je        short M13_L15
       mov       rax,[rbp-2C8]
       mov       [rbp-1A0],rax
       jmp       short M13_L16
M13_L15:
       mov       rdi,[rbp-40]
       mov       rsi,7FC9ABF3B7F8
       call      qword ptr [7FC9AAE2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1A0],rax
M13_L16:
       mov       rax,[rbp-0C8]
       mov       [rbp-1F8],rax
       mov       rdi,[rbp-1F8]
       mov       rsi,7FC9ABF695C0
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-1F8]
       mov       [rbp-240],rax
       mov       rdi,[rbp-240]
       mov       r11,[rbp-1A0]
       mov       esi,[rbp-0CC]
       mov       rax,[rbp-1A0]
       call      qword ptr [rax]
       mov       [rbp-0D8],rax
       mov       rax,[rbp-0D8]
       inc       dword ptr [rax+68]
       mov       eax,[rbp-0CC]
       inc       eax
       mov       [rbp-0CC],eax
M13_L17:
       mov       eax,[rbp-228]
       dec       eax
       mov       [rbp-228],eax
       cmp       dword ptr [rbp-228],0
       jg        short M13_L18
       lea       rdi,[rbp-228]
       mov       esi,8C
       call      CORINFO_HELP_PATCHPOINT
M13_L18:
       mov       eax,[rbp-0CC]
       cmp       eax,[rbp-0AC]
       jl        near ptr M13_L14
       call      qword ptr [7FC9ABF2C678]
       xor       eax,eax
       mov       [rbp-0DC],eax
       jmp       near ptr M13_L30
M13_L19:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2D0],rax
       mov       rax,[rbp-2D0]
       cmp       qword ptr [rax+8],48
       jle       short M13_L20
       mov       rax,[rbp-2D0]
       mov       rax,[rax+48]
       mov       [rbp-2D8],rax
       cmp       qword ptr [rbp-2D8],0
       je        short M13_L20
       mov       rax,[rbp-2D8]
       mov       [rbp-1A8],rax
       jmp       short M13_L21
M13_L20:
       mov       rdi,[rbp-40]
       mov       rsi,7FC9ABF3B7F8
       call      qword ptr [7FC9AAE2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1A8],rax
M13_L21:
       mov       rax,[rbp-0C8]
       mov       [rbp-200],rax
       mov       rdi,[rbp-200]
       mov       rsi,7FC9ABF696C8
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-200]
       mov       [rbp-248],rax
       mov       rdi,[rbp-248]
       mov       r11,[rbp-1A8]
       mov       esi,[rbp-0DC]
       mov       rax,[rbp-1A8]
       call      qword ptr [rax]
       mov       [rbp-0E8],rax
       mov       rax,[rbp-0E8]
       mov       [rbp-0F8],rax
       xor       eax,eax
       mov       [rbp-100],eax
       lea       rsi,[rbp-100]
       mov       rdi,[rbp-0F8]
       call      qword ptr [7FC9AAE25980]; System.Threading.Monitor.Enter(System.Object, Boolean ByRef)
       mov       rax,[rbp-0E8]
       cmp       [rax],al
       mov       rax,[rbp-0E8]
       add       rax,58
       mov       [rbp-1B0],rax
       xor       eax,eax
       mov       [rbp-108],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-2E0],rax
       cmp       qword ptr [rbp-2E0],0
       je        short M13_L22
       mov       rax,[rbp-2E0]
       mov       [rbp-1B8],rax
       jmp       short M13_L23
M13_L22:
       mov       rdi,[rbp-40]
       mov       rsi,7FC9ABF3B618
       call      qword ptr [7FC9AAE2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1B8],rax
M13_L23:
       mov       rdi,[rbp-1B8]
       mov       rsi,[rbp-1B0]
       mov       rdx,[rbp-108]
       call      qword ptr [7FC9AB8BDFC8]
       mov       [rbp-0F0],rax
       cmp       qword ptr [rbp-0F0],0
       je        near ptr M13_L27
       mov       rax,[rbp-0E8]
       mov       rax,[rax+60]
       mov       [rbp-110],rax
       cmp       qword ptr [rbp-110],0
       je        short M13_L24
       mov       rdi,7FC9ABF697D0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-110]
       mov       rsi,[rbp-0F0]
       cmp       [rdi],edi
       call      qword ptr [7FC9ABF2C690]
       jmp       near ptr M13_L27
M13_L24:
       mov       rdi,7FC9ABF697D4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2E8],rax
       mov       rax,[rbp-2E8]
       cmp       qword ptr [rax+8],50
       jle       short M13_L25
       mov       rax,[rbp-2E8]
       mov       rax,[rax+50]
       mov       [rbp-2F0],rax
       cmp       qword ptr [rbp-2F0],0
       je        short M13_L25
       mov       rax,[rbp-2F0]
       mov       [rbp-1C8],rax
       jmp       short M13_L26
M13_L25:
       mov       rdi,[rbp-40]
       mov       rsi,7FC9ABF3B998
       call      qword ptr [7FC9AAE2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1C8],rax
M13_L26:
       mov       rdi,[rbp-1C8]
       call      CORINFO_HELP_NEWFAST
       mov       [rbp-1C0],rax
       mov       rdi,[rbp-1C0]
       mov       rsi,[rbp-0F0]
       call      qword ptr [7FC9AB8BE3A0]; System.WeakReference`1[[System.__Canon, System.Private.CoreLib]]..ctor(System.__Canon)
       mov       rax,[rbp-0E8]
       lea       rdi,[rax+60]
       mov       rsi,[rbp-1C0]
       call      CORINFO_HELP_ASSIGN_REF
M13_L27:
       mov       rax,[rbp-0E8]
       inc       dword ptr [rax+68]
       call      M13_L50
       jmp       short M13_L29
M13_L28:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M13_L29:
       mov       rdi,7FC9ABF697E0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-0A0]
       cmp       [rbp-0DC],eax
       jae       short M13_L28
       mov       eax,[rbp-0DC]
       mov       rcx,[rbp-0A8]
       lea       rdi,[rcx+rax*8]
       mov       rsi,[rbp-0F0]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       eax,[rbp-0DC]
       inc       eax
       mov       [rbp-0DC],eax
M13_L30:
       mov       eax,[rbp-228]
       dec       eax
       mov       [rbp-228],eax
       cmp       dword ptr [rbp-228],0
       jg        short M13_L31
       lea       rdi,[rbp-228]
       mov       esi,13A
       call      CORINFO_HELP_PATCHPOINT
M13_L31:
       mov       eax,[rbp-0DC]
       cmp       eax,[rbp-0AC]
       jl        near ptr M13_L19
       call      M13_L52
       nop
       xor       eax,eax
       mov       [rbp-114],eax
       jmp       short M13_L34
M13_L32:
       mov       eax,[rbp-0A0]
       cmp       [rbp-114],eax
       jae       near ptr M13_L49
       mov       eax,[rbp-114]
       mov       rcx,[rbp-0A8]
       mov       rax,[rcx+rax*8]
       mov       [rbp-120],rax
       cmp       qword ptr [rbp-120],0
       je        short M13_L33
       mov       rdi,7FC9ABF697EC
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-48]
       mov       rsi,[rbp-120]
       cmp       [rdi],edi
       call      qword ptr [7FC9ABF2C6A8]
       nop
M13_L33:
       mov       rdi,7FC9ABF697F8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-114]
       inc       eax
       mov       [rbp-114],eax
M13_L34:
       mov       eax,[rbp-228]
       dec       eax
       mov       [rbp-228],eax
       cmp       dword ptr [rbp-228],0
       jg        short M13_L35
       lea       rdi,[rbp-228]
       mov       esi,18A
       call      CORINFO_HELP_PATCHPOINT
M13_L35:
       mov       eax,[rbp-114]
       cmp       eax,[rbp-0AC]
       jl        near ptr M13_L32
       cmp       qword ptr [rbp-58],0
       je        short M13_L36
       mov       rdi,7FC9ABF697FC
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-58]
       call      qword ptr [7FC9ABF2C570]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FC9ABF2C588]
M13_L36:
       mov       rdi,7FC9ABF69800
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,310
       pop       rbp
       ret
M13_L37:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-2F8],rax
       cmp       qword ptr [rbp-2F8],0
       je        short M13_L38
       mov       rax,[rbp-2F8]
       mov       [rbp-150],rax
       jmp       short M13_L39
M13_L38:
       mov       rdi,[rbp-40]
       mov       rsi,7FC9ABF3B5A8
       call      qword ptr [7FC9AAE2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-150],rax
M13_L39:
       mov       rdi,[rbp-50]
       cmp       [rdi],edi
       call      qword ptr [7FC9ABF2C660]
       mov       [rbp-208],rax
       mov       rdi,[rbp-208]
       mov       rsi,7FC9ABF69808
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-208]
       mov       [rbp-250],rax
       mov       rdi,[rbp-250]
       mov       r11,[rbp-150]
       mov       rax,[rbp-150]
       call      qword ptr [rax]
       mov       [rbp-130],rax
       jmp       near ptr M13_L46
M13_L40:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-300],rax
       cmp       qword ptr [rbp-300],0
       je        short M13_L41
       mov       rax,[rbp-300]
       mov       [rbp-158],rax
       jmp       short M13_L42
M13_L41:
       mov       rdi,[rbp-40]
       mov       rsi,7FC9ABF3B5E0
       call      qword ptr [7FC9AAE2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-158],rax
M13_L42:
       mov       rax,[rbp-130]
       mov       [rbp-210],rax
       mov       rdi,[rbp-210]
       mov       rsi,7FC9ABF69910
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-210]
       mov       [rbp-260],rax
       mov       rdi,[rbp-260]
       mov       r11,[rbp-158]
       mov       rax,[rbp-158]
       call      qword ptr [rax]
       mov       [rbp-258],rax
       mov       rax,[rbp-258]
       cmp       [rax],al
       mov       rax,[rbp-258]
       add       rax,58
       mov       [rbp-160],rax
       xor       eax,eax
       mov       [rbp-108],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-308],rax
       cmp       qword ptr [rbp-308],0
       je        short M13_L43
       mov       rax,[rbp-308]
       mov       [rbp-168],rax
       jmp       short M13_L44
M13_L43:
       mov       rdi,[rbp-40]
       mov       rsi,7FC9ABF3B618
       call      qword ptr [7FC9AAE2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-168],rax
M13_L44:
       mov       rdi,[rbp-168]
       mov       rsi,[rbp-160]
       mov       rdx,[rbp-108]
       call      qword ptr [7FC9AB8BDFC8]
       mov       [rbp-138],rax
       cmp       qword ptr [rbp-138],0
       je        short M13_L45
       mov       rdi,7FC9ABF69A18
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-48]
       mov       rsi,[rbp-138]
       cmp       [rdi],edi
       call      qword ptr [7FC9ABF2C6A8]
       jmp       short M13_L46
M13_L45:
       mov       rdi,7FC9ABF69A1C
       call      CORINFO_HELP_COUNTPROFILE32
M13_L46:
       mov       eax,[rbp-228]
       dec       eax
       mov       [rbp-228],eax
       cmp       dword ptr [rbp-228],0
       jg        short M13_L47
       lea       rdi,[rbp-228]
       mov       esi,1E9
       call      CORINFO_HELP_PATCHPOINT
M13_L47:
       mov       rax,[rbp-130]
       mov       [rbp-218],rax
       mov       rdi,[rbp-218]
       mov       rsi,7FC9ABF69A28
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-218]
       mov       [rbp-268],rax
       mov       rdi,[rbp-268]
       mov       r11,7FC9A9E40880
       call      qword ptr [r11]
       test      eax,eax
       jne       near ptr M13_L40
       call      M13_L56
       nop
       cmp       qword ptr [rbp-58],0
       je        short M13_L48
       mov       rdi,7FC9ABF69C44
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-58]
       call      qword ptr [7FC9ABF2C570]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FC9ABF2C588]
M13_L48:
       mov       rdi,7FC9ABF69C48
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,310
       pop       rbp
       ret
M13_L49:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M13_L50:
       push      rax
       movzx     eax,byte ptr [rbp-100]
       test      eax,eax
       je        short M13_L51
       mov       rdi,7FC9ABF697D8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-0F8]
       call      qword ptr [7FC9AAE26808]; System.Threading.Monitor.Exit(System.Object)
M13_L51:
       mov       rdi,7FC9ABF697DC
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
M13_L52:
       push      rax
       movzx     eax,byte ptr [rbp-0C0]
       test      eax,eax
       je        short M13_L53
       mov       rdi,7FC9ABF697E4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-0B8]
       call      qword ptr [7FC9AAE26808]; System.Threading.Monitor.Exit(System.Object)
M13_L53:
       mov       rdi,7FC9ABF697E8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
       push      rax
       mov       [rbp-1D0],rdi
       mov       rax,[rbp-1D0]
       mov       [rbp-128],rax
       cmp       qword ptr [rbp-58],0
       jne       short M13_L54
       mov       rdi,7FC9ABF697F0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-128]
       mov       [rbp-58],rax
M13_L54:
       mov       rdi,7FC9ABF697F4
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rax,[M13_L33]
       add       rsp,8
       ret
       push      rax
       mov       [rbp-170],rdi
       mov       rax,[rbp-170]
       mov       [rbp-140],rax
       cmp       qword ptr [rbp-58],0
       jne       short M13_L55
       mov       rdi,7FC9ABF69A20
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-140]
       mov       [rbp-58],rax
M13_L55:
       mov       rdi,7FC9ABF69A24
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rax,[M13_L46]
       add       rsp,8
       ret
M13_L56:
       push      rax
       cmp       qword ptr [rbp-130],0
       je        short M13_L57
       mov       rdi,7FC9ABF69B30
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-130]
       mov       [rbp-220],rax
       mov       rdi,[rbp-220]
       mov       rsi,7FC9ABF69B38
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-220]
       mov       [rbp-270],rax
       mov       rdi,[rbp-270]
       mov       r11,7FC9A9E40888
       call      qword ptr [r11]
M13_L57:
       mov       rdi,7FC9ABF69C40
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
; Total bytes of code 3431
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       push      rax
       lea       rbp,[rsp+30]
       mov       [rbp-30],rdi
       mov       rbx,rdi
       mov       r15,rsi
       mov       rdi,rbx
       call      qword ptr [7FC9AB8BDCE0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       r14d,eax
       mov       rdi,[rbx+8]
       cmp       r14d,[rdi+8]
       jae       near ptr M14_L03
       mov       edx,r14d
       mov       r13,[rdi+rdx*8+10]
       mov       r12,[r13+50]
       test      r12,r12
       je        short M14_L02
       lea       rdi,[r13+50]
       test      rdi,rdi
       je        short M14_L01
       mov       rdx,r12
       xor       esi,esi
       call      00007FCA29274060
       cmp       rax,r12
       jne       short M14_L02
       mov       rdi,r15
       mov       rsi,r12
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
M14_L00:
       mov       eax,1
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M14_L01:
       call      qword ptr [7FC9ABE66268]
       int       3
M14_L02:
       mov       rdi,[rbx]
       mov       rsi,r13
       mov       rdx,r15
       call      qword ptr [7FC9AB8BDDE8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M14_L00
       mov       rdi,rbx
       mov       esi,r14d
       mov       rdx,r15
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7FC9AB8BDD10]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M14_L03:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 185
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       cmp       qword ptr [rbp-10],0
       jne       short M15_L00
       add       rsp,30
       pop       rbp
       ret
M15_L00:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FC9AB8BDBD8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
M15_L01:
       add       rsp,30
       pop       rbp
       ret
       push      rax
       mov       [rbp-28],rdi
       mov       rax,[rbp-28]
       mov       [rbp-20],rax
       mov       rax,[rbp-18]
       cmp       qword ptr [rax],0
       jne       short M15_L02
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
M15_L02:
       lea       rax,[M15_L01]
       add       rsp,8
       ret
; Total bytes of code 114
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       eax,[rbp-10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 27
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-1C],edx
       mov       rax,[rbp-18]
       sar       rax,20
       lea       esi,[rax+1]
       mov       rdi,[rbp-10]
       mov       edx,[rbp-1C]
       call      qword ptr [7FC9AB21E100]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 56
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       rsi,rdi
       lea       rdi,[rbp-30]
       mov       [rbp-94],rdi
       mov       [rbp-9C],rsi
       xor       edx,edx
       mov       [rbp-8C],edx
       lea       rdi,[rbp-88]
       call      qword ptr [7FC9AA9CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       edx,[rbp-8C]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7FC9AA9CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,[rbp-30]
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 131
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7FC9AA9D4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7FC9AA9CEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7FC9AA9DF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M19_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M19_L00
       mov       rsi,rax
       call      qword ptr [7FC9AA9CEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M19_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7FC9AA9CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7FC9AA9CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; System.Threading.Monitor.Enter(System.Object, Boolean ByRef)
       push      rbp
       push      r15
       push      rbx
       lea       rbp,[rsp+10]
       mov       r15,rdi
       mov       rbx,rsi
       cmp       byte ptr [rbx],0
       je        short M21_L00
       call      qword ptr [7FC9AA9E69F0]
       int       3
M21_L00:
       test      r15,r15
       je        short M21_L02
       mov       rdi,r15
       call      qword ptr [7FC9AA9E69B0]
       test      eax,eax
       jne       short M21_L01
       mov       rdi,r15
       call      qword ptr [7FC9AA9E69C0]
M21_L01:
       mov       byte ptr [rbx],1
       pop       rbx
       pop       r15
       pop       rbp
       ret
M21_L02:
       xor       edi,edi
       call      qword ptr [7FC9AA9E1208]
       int       3
; Total bytes of code 71
```
```assembly
; System.Span`1[[System.__Canon, System.Private.CoreLib]].op_Implicit(System.__Canon[])
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7FC9AA9D69B0]
       mov       rdi,rax
       test      rbx,rbx
       je        short M22_L01
       mov       r15,[rbx]
       call      qword ptr [7FC9AA9D8528]
       cmp       r15,rax
       jne       short M22_L02
       lea       rax,[rbx+10]
       mov       edx,[rbx+8]
M22_L00:
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
M22_L01:
       xor       eax,eax
       xor       edx,edx
       jmp       short M22_L00
M22_L02:
       call      qword ptr [7FC9AA9E4118]
       int       3
; Total bytes of code 77
```
```assembly
; System.WeakReference`1[[System.__Canon, System.Private.CoreLib]]..ctor(System.__Canon)
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       xor       edx,edx
       jmp       qword ptr [rax]
; Total bytes of code 12
```
```assembly
; System.Threading.Monitor.Exit(System.Object)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rbx,rdi
       test      rbx,rbx
       je        short M24_L00
       mov       rdi,rbx
       call      00007FCA290E6790
       test      eax,eax
       jne       short M24_L01
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M24_L00:
       xor       edi,edi
       call      qword ptr [7FC9ABE663B8]
       int       3
M24_L01:
       mov       edi,eax
       mov       rsi,rbx
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7FC9ABE66C58]
; Total bytes of code 61
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rdi
       mov       rdi,[rbx]
       call      qword ptr [7FC9AB8BDD28]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       r15d,[rax+10]
       test      r15d,r15d
       je        short M25_L02
M25_L00:
       dec       r15d
       mov       eax,[rbx+18]
       test      eax,eax
       jl        short M25_L03
       and       eax,r15d
M25_L01:
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
M25_L02:
       mov       rdi,[rbx]
       call      qword ptr [7FC9AAE25728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       edi,1
       mov       r15d,edi
       lock xadd [rax],r15d
       inc       r15d
       je        short M25_L02
       mov       rdi,[rbx]
       call      qword ptr [7FC9AB8BDD28]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       [rax+10],r15d
       jmp       short M25_L00
M25_L03:
       mov       rax,[rbx+8]
       mov       eax,[rax+8]
       mov       ecx,r15d
       imul      rcx,[rbx+10]
       shr       rcx,20
       inc       rcx
       imul      rax,rcx
       shr       rax,20
       jmp       short M25_L01
; Total bytes of code 134
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7FC9ABF2C6C0]; PoolContextProbe+Policy.Destroy(Item)
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 49
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-10],edx
       movsxd    rax,dword ptr [rbp-0C]
       shl       rax,20
       mov       ecx,[rbp-10]
       or        rax,rcx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 40
```
```assembly
; PoolContextProbe+Policy.Destroy(Item)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 24
```

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: B-candidate(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.9.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.9.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=10, LaunchCount=3, WarmupCount=5))

```assembly
; PoolContextProbe.NestedRentReturn()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,0F8
       lea       rbp,[rsp+120]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       vmovdqa   xmmword ptr [rbp-40],xmm8
       xor       eax,eax
       mov       [rbp-30],rax
       mov       rbx,rdi
       mov       r15,[rbx+8]
       cmp       byte ptr [r15+24],0
       jne       near ptr M00_L38
       cmp       dword ptr [r15+1C],0
       jne       near ptr M00_L64
M00_L00:
       mov       r14,[r15+10]
       xor       r13d,r13d
       test      r14,r14
       je        near ptr M00_L65
       mov       rdi,7FB92AEA0D68
       mov       rax,7FB92B82C820
       call      rax
       add       rax,48
       mov       r12d,[rax+10]
       test      r12d,r12d
       je        near ptr M00_L72
M00_L01:
       dec       r12d
       mov       eax,[r14+18]
       test      eax,eax
       jl        near ptr M00_L73
       and       r12d,eax
M00_L02:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M00_L151
       mov       edx,r12d
       mov       rax,[rdi+rdx*8+10]
       mov       rcx,rax
       mov       [rbp-0D0],rcx
       mov       rax,[rcx+50]
       mov       [rbp-0D8],rax
       test      rax,rax
       jne       near ptr M00_L30
M00_L03:
       lea       rdx,[rcx+58]
       mov       rdi,[rcx+48]
       mov       rax,[rdx]
       mov       esi,eax
       cmp       esi,0FFFFFFFF
       je        near ptr M00_L75
       mov       r8d,[rdi+8]
M00_L04:
       cmp       esi,[rdi+8]
       jae       near ptr M00_L151
       mov       r8d,esi
       shl       r8,4
       mov       r9d,[rdi+r8+18]
       mov       r10,rax
       sar       r10,20
       inc       r10d
       movsxd    r10,r10d
       shl       r10,20
       or        r9,r10
       mov       [rbp-40],rax
       lock cmpxchg [rdx],r9
       cmp       rax,[rbp-40]
       jne       near ptr M00_L74
       mov       rax,[rcx+48]
       mov       rdx,rax
       cmp       esi,[rdx+8]
       jae       near ptr M00_L151
       mov       rdx,[rdx+r8+10]
       mov       [rbp-38],rdx
       cmp       esi,[rax+8]
       jae       near ptr M00_L151
       lea       rdx,[rax+r8+10]
       xor       eax,eax
       mov       [rdx],rax
       add       rcx,60
M00_L05:
       mov       rax,[rcx]
       mov       [rbp-48],rax
       mov       [rdx+8],eax
       mov       rdi,rax
       sar       rdi,20
       inc       edi
       movsxd    rdi,edi
       shl       rdi,20
       mov       r8d,esi
       or        rdi,r8
       lock cmpxchg [rcx],rdi
       cmp       rax,[rbp-48]
       jne       short M00_L05
       cmp       qword ptr [rbp-38],0
       setne     dl
       movzx     edx,dl
M00_L06:
       test      edx,edx
       je        near ptr M00_L76
M00_L07:
       mov       r12,[rbp-38]
       cmp       qword ptr [rbp-38],0
       je        near ptr M00_L77
M00_L08:
       xor       edi,edi
       mov       [rbp-38],rdi
       cmp       dword ptr [r15+1C],0
       jne       near ptr M00_L79
M00_L09:
       mov       r15,[rbx+8]
       cmp       byte ptr [r15+24],0
       jne       near ptr M00_L80
       cmp       dword ptr [r15+1C],0
       jne       near ptr M00_L106
M00_L10:
       mov       r14,[r15+10]
       xor       r13d,r13d
       test      r14,r14
       je        near ptr M00_L107
       mov       rdi,7FB92AEA0D68
       mov       rax,7FB92B82C820
       call      rax
       add       rax,48
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M00_L114
M00_L11:
       dec       eax
       mov       ecx,[r14+18]
       test      ecx,ecx
       jl        near ptr M00_L115
       and       ecx,eax
M00_L12:
       mov       eax,ecx
       mov       [rbp-64],eax
       mov       rdi,[r14+8]
       cmp       eax,[rdi+8]
       jae       near ptr M00_L151
       mov       edx,eax
       mov       rcx,[rdi+rdx*8+10]
       mov       [rbp-100],rcx
       mov       r8,[rcx+50]
       mov       [rbp-108],r8
       test      r8,r8
       mov       eax,[rbp-64]
       jne       near ptr M00_L31
M00_L13:
       lea       rdx,[rcx+58]
       mov       rdi,[rcx+48]
       mov       rsi,[rdx]
       mov       r8d,esi
       cmp       r8d,0FFFFFFFF
       je        near ptr M00_L117
       mov       r9d,[rdi+8]
M00_L14:
       cmp       r8d,[rdi+8]
       jae       near ptr M00_L151
       mov       r9d,r8d
       shl       r9,4
       mov       r10d,[rdi+r9+18]
       mov       r11,rsi
       sar       r11,20
       inc       r11d
       movsxd    r11,r11d
       shl       r11,20
       or        r10,r11
       mov       rax,rsi
       lock cmpxchg [rdx],r10
       cmp       rax,rsi
       jne       near ptr M00_L116
       mov       rax,[rcx+48]
       mov       rdx,rax
       cmp       r8d,[rdx+8]
       jae       near ptr M00_L151
       mov       rdx,[rdx+r9+10]
       mov       [rbp-60],rdx
       cmp       r8d,[rax+8]
       jae       near ptr M00_L151
       lea       rdx,[rax+r9+10]
       xor       eax,eax
       mov       [rdx],rax
       add       rcx,60
M00_L15:
       mov       rax,[rcx]
       mov       [rbp-70],rax
       mov       [rdx+8],eax
       mov       rdi,rax
       sar       rdi,20
       inc       edi
       movsxd    rdi,edi
       shl       rdi,20
       mov       esi,r8d
       or        rdi,rsi
       lock cmpxchg [rcx],rdi
       cmp       rax,[rbp-70]
       jne       short M00_L15
       cmp       qword ptr [rbp-60],0
       setne     dl
       movzx     edx,dl
       mov       eax,[rbp-64]
M00_L16:
       test      edx,edx
       je        near ptr M00_L118
M00_L17:
       mov       rsi,[rbp-60]
       cmp       qword ptr [rbp-60],0
       je        near ptr M00_L119
M00_L18:
       xor       edi,edi
       mov       [rbp-60],rdi
       cmp       dword ptr [r15+1C],0
       jne       near ptr M00_L121
M00_L19:
       mov       r15,rsi
       mov       r14d,[r12+8]
       add       r14d,[r15+8]
       mov       r13,[rbx+8]
       cmp       byte ptr [r13+24],0
       jne       near ptr M00_L122
       cmp       dword ptr [r13+1C],0
       jne       near ptr M00_L24
       mov       rdi,r13
       mov       rsi,r15
       call      qword ptr [7FB8AD2EDF08]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItemGuarded(System.__Canon)
       test      eax,eax
       je        near ptr M00_L24
       mov       rax,[r13+10]
       mov       [rbp-110],rax
       test      rax,rax
       je        near ptr M00_L129
       mov       rdi,7FB92AEA0D68
       mov       rcx,7FB92B82C820
       call      rcx
       add       rax,48
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M00_L123
M00_L20:
       dec       eax
       mov       rcx,[rbp-110]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M00_L124
       and       r8d,eax
M00_L21:
       mov       eax,r8d
       xor       r8d,r8d
       mov       [rbp-78],r8d
       mov       rdi,[rcx+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M00_L128
M00_L22:
       mov       rdi,[rcx+8]
       cmp       eax,[rdi+8]
       jae       near ptr M00_L151
       mov       [rbp-74],eax
       mov       esi,eax
       mov       r9,[rdi+rsi*8+10]
       mov       [rbp-118],r9
       cmp       qword ptr [r9+50],0
       jne       near ptr M00_L32
       lea       rdi,[r9+50]
       test      rdi,rdi
       je        near ptr M00_L148
       mov       rsi,r15
       xor       edx,edx
       call      00007FB92AC74060
       test      rax,rax
       mov       r9,[rbp-118]
       jne       near ptr M00_L32
M00_L23:
       cmp       dword ptr [r13+1C],0
       jne       near ptr M00_L134
M00_L24:
       mov       rbx,[rbx+8]
       cmp       [rbx],bl
       test      r12,r12
       je        near ptr M00_L135
       cmp       byte ptr [rbx+24],0
       jne       near ptr M00_L136
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M00_L29
       mov       rdi,rbx
       mov       rsi,r12
       call      qword ptr [7FB8AD2EDF08]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItemGuarded(System.__Canon)
       test      eax,eax
       je        near ptr M00_L29
       mov       r15,[rbx+10]
       test      r15,r15
       je        near ptr M00_L143
       mov       rdi,7FB92AEA0D68
       mov       rax,7FB92B82C820
       call      rax
       add       rax,48
       mov       r13d,[rax+10]
       test      r13d,r13d
       je        near ptr M00_L137
M00_L25:
       dec       r13d
       mov       eax,[r15+18]
       test      eax,eax
       jl        near ptr M00_L138
       and       r13d,eax
M00_L26:
       xor       eax,eax
       mov       [rbp-94],eax
       mov       rdi,[r15+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M00_L142
M00_L27:
       mov       rdi,[r15+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M00_L151
       mov       esi,r13d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-120],rcx
       cmp       qword ptr [rcx+50],0
       jne       near ptr M00_L35
       lea       rdi,[rcx+50]
       test      rdi,rdi
       je        near ptr M00_L148
       mov       rsi,r12
       xor       edx,edx
       call      00007FB92AC74060
       test      rax,rax
       mov       rcx,[rbp-120]
       jne       near ptr M00_L35
M00_L28:
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M00_L150
M00_L29:
       mov       eax,r14d
       add       rsp,0F8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M00_L30:
       lea       rdi,[rcx+50]
       test      rdi,rdi
       je        near ptr M00_L148
       mov       rdx,rax
       xor       esi,esi
       call      00007FB92AC74060
       mov       rdx,[rbp-0D8]
       cmp       rax,rdx
       mov       rcx,[rbp-0D0]
       jne       near ptr M00_L03
       mov       [rbp-38],rdx
       jmp       near ptr M00_L07
M00_L31:
       lea       rdi,[rcx+50]
       test      rdi,rdi
       je        near ptr M00_L148
       mov       rdx,r8
       xor       esi,esi
       call      00007FB92AC74060
       mov       rdx,[rbp-108]
       cmp       rax,rdx
       mov       eax,[rbp-64]
       mov       rcx,[rbp-100]
       jne       near ptr M00_L13
       mov       [rbp-60],rdx
       jmp       near ptr M00_L17
M00_L32:
       lea       rdi,[r9+60]
       mov       rsi,[r9+48]
       mov       rdx,[rdi]
       mov       r10d,edx
       cmp       r10d,0FFFFFFFF
       je        near ptr M00_L126
       mov       r11d,[rsi+8]
       mov       [rbp-0A4],r11d
M00_L33:
       cmp       r10d,r11d
       jae       near ptr M00_L151
       mov       r8d,r10d
       shl       r8,4
       mov       [rbp-0B0],r8
       mov       r11d,[rsi+r8+18]
       mov       r8,rdx
       sar       r8,20
       inc       r8d
       movsxd    r8,r8d
       shl       r8,20
       or        r8,r11
       mov       rax,rdx
       lock cmpxchg [rdi],r8
       cmp       rax,rdx
       jne       near ptr M00_L125
       mov       rdi,[r9+48]
       mov       [rbp-80],r10d
       cmp       r10d,[rdi+8]
       jae       near ptr M00_L151
       mov       rax,[rbp-0B0]
       lea       rdi,[rdi+rax+10]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       r15,[rbp-118]
       lea       rdi,[r15+58]
       mov       rcx,[r15+48]
       mov       r15d,[rbp-80]
M00_L34:
       mov       rax,[rdi]
       mov       [rbp-88],rax
       cmp       r15d,[rcx+8]
       jae       near ptr M00_L151
       mov       rdx,[rbp-0B0]
       mov       [rcx+rdx+18],eax
       mov       rsi,rax
       sar       rsi,20
       inc       esi
       movsxd    rsi,esi
       shl       rsi,20
       mov       r8d,r15d
       or        rsi,r8
       lock cmpxchg [rdi],rsi
       cmp       rax,[rbp-88]
       jne       short M00_L34
       jmp       near ptr M00_L23
M00_L35:
       lea       rdi,[rcx+60]
       mov       rsi,[rcx+48]
       mov       rdx,[rdi]
       mov       r8d,edx
       cmp       r8d,0FFFFFFFF
       je        near ptr M00_L140
       mov       r9d,[rsi+8]
M00_L36:
       cmp       r8d,r9d
       jae       near ptr M00_L151
       mov       r10d,r8d
       shl       r10,4
       mov       [rbp-0B8],r10
       mov       r11d,[rsi+r10+18]
       mov       rax,rdx
       sar       rax,20
       inc       eax
       cdqe
       shl       rax,20
       or        r11,rax
       mov       rax,rdx
       lock cmpxchg [rdi],r11
       cmp       rax,rdx
       jne       near ptr M00_L139
       mov       rdi,[rcx+48]
       mov       [rbp-98],r8d
       cmp       r8d,[rdi+8]
       jae       near ptr M00_L151
       lea       rdi,[rdi+r10+10]
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       mov       r12,[rbp-120]
       lea       rdi,[r12+58]
       mov       rcx,[r12+48]
       mov       r15d,[rbp-98]
M00_L37:
       mov       rax,[rdi]
       mov       [rbp-0A0],rax
       cmp       r15d,[rcx+8]
       jae       near ptr M00_L151
       mov       r13,[rbp-0B8]
       mov       [rcx+r13+18],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       esi,r15d
       or        rdx,rsi
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-0A0]
       jne       short M00_L37
       jmp       near ptr M00_L28
M00_L38:
       cmp       dword ptr [r15+1C],0
       je        short M00_L39
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7FB8AD2EDBF0]
M00_L39:
       lea       rdi,[r15+28]
       mov       rsi,[rdi]
       test      rsi,rsi
       jne       short M00_L40
       mov       rsi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<PoolContextProbe+Item>
       call      qword ptr [7FB8AD896850]
       mov       rsi,rax
M00_L40:
       mov       rdi,rsi
       cmp       [rdi],edi
       call      qword ptr [7FB8AD896868]
       mov       r12,rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<PoolContextProbe+Item>
       call      qword ptr [7FB8AC855728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       cmp       byte ptr [7FB8AB86B1F0],0
       je        short M00_L43
       mov       edx,[r12+68]
       mov       rax,[r12+58]
       test      rax,rax
       je        short M00_L44
       xor       esi,esi
       mov       [r12+58],rsi
       cmp       [r12+68],edx
       jne       short M00_L41
       test      dl,1
       je        short M00_L42
M00_L41:
       mov       rdx,rax
       mov       rsi,r12
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<PoolContextProbe+Item>
       call      qword ptr [7FB8AD896880]
       test      rax,rax
       je        short M00_L44
M00_L42:
       jmp       near ptr M00_L61
M00_L43:
       cmp       qword ptr [r12+58],0
       je        short M00_L44
       lea       rdi,[r12+58]
       test      rdi,rdi
       je        near ptr M00_L148
       xor       esi,esi
       call      00007FB92AC74040
       test      rax,rax
       jne       short M00_L42
M00_L44:
       cmp       byte ptr [r12+6C],0
       jne       short M00_L45
       mov       byte ptr [r12+6C],1
M00_L45:
       mov       r14,[r15+10]
       xor       r13d,r13d
       test      r14,r14
       jne       near ptr M00_L52
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M00_L47
M00_L46:
       mov       rdi,7FB8AB86B1E8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M00_L46
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M00_L47:
       dec       r13d
       imul      edi,r13d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M00_L48
       mov       r13d,edi
       mov       edx,[r15+20]
       imul      r13,rdx
       shr       r13,20
       jmp       short M00_L49
M00_L48:
       and       edi,[r15+18]
       mov       r13d,edi
M00_L49:
       mov       rdi,[r15+8]
       lea       edx,[r13*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M00_L151
       lea       rdi,[rdi+rdx*8+10]
       mov       r12,[rdi]
       test      r12,r12
       je        short M00_L50
       mov       rdx,r12
       xor       esi,esi
       call      00007FB92AC74060
       cmp       rax,r12
       je        short M00_L51
M00_L50:
       xor       r12d,r12d
M00_L51:
       mov       [rbp-30],r12
       jmp       near ptr M00_L58
M00_L52:
       mov       edi,48
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M00_L54
M00_L53:
       mov       rdi,7FB8AB86B178
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M00_L53
       mov       edi,48
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M00_L54:
       dec       r12d
       cmp       dword ptr [r14+18],0
       jl        short M00_L55
       and       r12d,[r14+18]
       jmp       short M00_L56
M00_L55:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
M00_L56:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M00_L151
       mov       edx,r12d
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-0C0],rax
       mov       rcx,[rax+50]
       mov       [rbp-0C8],rcx
       test      rcx,rcx
       je        short M00_L57
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M00_L148
       mov       rdx,rcx
       xor       esi,esi
       call      00007FB92AC74060
       mov       rdx,[rbp-0C8]
       cmp       rax,rdx
       mov       rax,[rbp-0C0]
       jne       short M00_L57
       mov       [rbp-30],rdx
       jmp       short M00_L58
M00_L57:
       lea       rdx,[rbp-30]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<PoolContextProbe+Item>
       call      qword ptr [7FB8AD2EDDE8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M00_L58
       lea       rdx,[rbp-30]
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7FB8AD2EDD10]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M00_L58:
       mov       rax,[rbp-30]
       cmp       qword ptr [rbp-30],0
       jne       short M00_L60
       test      r14,r14
       je        short M00_L59
       mov       rdi,offset MT_PoolContextProbe+Item
       call      CORINFO_HELP_NEWSFAST
       mov       dword ptr [rax+8],2A
       jmp       short M00_L60
M00_L59:
       mov       rdi,r15
       mov       esi,r13d
       call      qword ptr [7FB8AD2EDCC8]
M00_L60:
       xor       edi,edi
       mov       [rbp-30],rdi
M00_L61:
       cmp       dword ptr [r15+1C],0
       jne       short M00_L62
       mov       r12,rax
       jmp       short M00_L63
M00_L62:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7FB8AD2EDBF0]
       mov       r12,rax
M00_L63:
       jmp       near ptr M00_L09
M00_L64:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7FB8AD2EDBF0]
       jmp       near ptr M00_L00
M00_L65:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M00_L67
M00_L66:
       mov       rdi,7FB8AB86B1E8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M00_L66
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M00_L67:
       dec       r13d
       imul      edi,r13d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M00_L68
       mov       r13d,edi
       mov       edx,[r15+20]
       imul      r13,rdx
       shr       r13,20
       jmp       short M00_L69
M00_L68:
       and       edi,[r15+18]
       mov       r13d,edi
M00_L69:
       mov       rdi,[r15+8]
       lea       edx,[r13*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M00_L151
       lea       rdi,[rdi+rdx*8+10]
       mov       r12,[rdi]
       test      r12,r12
       je        short M00_L70
       mov       rdx,r12
       xor       esi,esi
       call      00007FB92AC74060
       cmp       rax,r12
       je        short M00_L71
M00_L70:
       xor       r12d,r12d
M00_L71:
       mov       [rbp-38],r12
       jmp       near ptr M00_L07
M00_L72:
       mov       rdi,7FB8AB86B178
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M00_L72
       mov       rdi,7FB92AEA0D68
       mov       rax,7FB92B82C820
       call      rax
       add       rax,48
       mov       [rax+10],r12d
       jmp       near ptr M00_L01
M00_L73:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
       jmp       near ptr M00_L02
M00_L74:
       mov       rax,[rdx]
       mov       esi,eax
       cmp       esi,0FFFFFFFF
       jne       near ptr M00_L04
M00_L75:
       xor       edx,edx
       mov       [rbp-38],rdx
       jmp       near ptr M00_L06
M00_L76:
       lea       rdx,[rbp-38]
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7FB8AD2EDD10]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       jmp       near ptr M00_L07
M00_L77:
       test      r14,r14
       je        short M00_L78
       mov       rdi,offset MT_PoolContextProbe+Item
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       dword ptr [r12+8],2A
       jmp       near ptr M00_L08
M00_L78:
       mov       rdi,r15
       mov       esi,r13d
       call      qword ptr [7FB8AD2EDCC8]
       mov       r12,rax
       jmp       near ptr M00_L08
M00_L79:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7FB8AD2EDBF0]
       mov       r12,rax
       jmp       near ptr M00_L09
M00_L80:
       cmp       dword ptr [r15+1C],0
       je        short M00_L81
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7FB8AD2EDBF0]
M00_L81:
       lea       rdi,[r15+28]
       mov       rsi,[rdi]
       test      rsi,rsi
       jne       short M00_L82
       mov       rsi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<PoolContextProbe+Item>
       call      qword ptr [7FB8AD896850]
       mov       rsi,rax
M00_L82:
       mov       rdi,rsi
       cmp       [rdi],edi
       call      qword ptr [7FB8AD896868]
       mov       r14,rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<PoolContextProbe+Item>
       call      qword ptr [7FB8AC855728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       cmp       byte ptr [7FB8AB86B1F0],0
       je        short M00_L85
       mov       edx,[r14+68]
       mov       rax,[r14+58]
       test      rax,rax
       je        short M00_L86
       xor       esi,esi
       mov       [r14+58],rsi
       cmp       [r14+68],edx
       jne       short M00_L83
       test      dl,1
       je        short M00_L84
M00_L83:
       mov       rdx,rax
       mov       rsi,r14
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<PoolContextProbe+Item>
       call      qword ptr [7FB8AD896880]
       test      rax,rax
       je        short M00_L86
M00_L84:
       jmp       near ptr M00_L103
M00_L85:
       cmp       qword ptr [r14+58],0
       je        short M00_L86
       lea       rdi,[r14+58]
       test      rdi,rdi
       je        near ptr M00_L148
       xor       esi,esi
       call      00007FB92AC74040
       test      rax,rax
       jne       short M00_L84
M00_L86:
       cmp       byte ptr [r14+6C],0
       jne       short M00_L87
       mov       byte ptr [r14+6C],1
M00_L87:
       mov       r14,[r15+10]
       xor       r13d,r13d
       test      r14,r14
       jne       near ptr M00_L94
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M00_L89
M00_L88:
       mov       rdi,7FB8AB86B1E8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M00_L88
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M00_L89:
       dec       r13d
       imul      edi,r13d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M00_L90
       mov       r13d,edi
       mov       edx,[r15+20]
       imul      r13,rdx
       shr       r13,20
       jmp       short M00_L91
M00_L90:
       and       edi,[r15+18]
       mov       r13d,edi
M00_L91:
       mov       rdi,[r15+8]
       lea       edx,[r13*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M00_L151
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       [rbp-0E0],rax
       test      rax,rax
       je        short M00_L92
       mov       rdx,rax
       xor       esi,esi
       call      00007FB92AC74060
       mov       rdi,[rbp-0E0]
       cmp       rax,rdi
       je        short M00_L93
M00_L92:
       xor       edi,edi
M00_L93:
       mov       [rbp-50],rdi
       jmp       near ptr M00_L100
M00_L94:
       mov       edi,48
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M00_L96
M00_L95:
       mov       rax,7FB8AB86B178
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-54],eax
       test      eax,eax
       je        short M00_L95
       mov       edi,48
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-54]
       mov       [rax+10],ecx
       mov       eax,ecx
M00_L96:
       dec       eax
       cmp       dword ptr [r14+18],0
       jl        short M00_L97
       mov       ecx,eax
       and       ecx,[r14+18]
       jmp       short M00_L98
M00_L97:
       mov       rcx,[r14+8]
       mov       edi,[rcx+8]
       mov       ecx,eax
       imul      rcx,[r14+10]
       shr       rcx,20
       inc       rcx
       imul      rcx,rdi
       shr       rcx,20
       mov       eax,ecx
       mov       ecx,eax
M00_L98:
       mov       rdi,[r14+8]
       cmp       ecx,[rdi+8]
       jae       near ptr M00_L151
       mov       [rbp-58],ecx
       mov       edx,ecx
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-0E8],rax
       mov       r8,[rax+50]
       mov       [rbp-0F0],r8
       test      r8,r8
       je        short M00_L99
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M00_L148
       mov       rdx,r8
       xor       esi,esi
       call      00007FB92AC74060
       mov       rdx,[rbp-0F0]
       cmp       rax,rdx
       mov       rax,[rbp-0E8]
       jne       short M00_L99
       mov       [rbp-50],rdx
       jmp       short M00_L100
M00_L99:
       lea       rdx,[rbp-50]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<PoolContextProbe+Item>
       call      qword ptr [7FB8AD2EDDE8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M00_L100
       lea       rdx,[rbp-50]
       mov       rdi,r14
       mov       esi,[rbp-58]
       call      qword ptr [7FB8AD2EDD10]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M00_L100:
       mov       rax,[rbp-50]
       cmp       qword ptr [rbp-50],0
       jne       short M00_L102
       test      r14,r14
       je        short M00_L101
       cmp       [r15],r15b
       mov       rdi,offset MT_PoolContextProbe+Item
       call      CORINFO_HELP_NEWSFAST
       mov       dword ptr [rax+8],2A
       jmp       short M00_L102
M00_L101:
       mov       rdi,r15
       mov       esi,r13d
       call      qword ptr [7FB8AD2EDCC8]
M00_L102:
       xor       edi,edi
       mov       [rbp-50],rdi
M00_L103:
       cmp       dword ptr [r15+1C],0
       jne       short M00_L104
       mov       rsi,rax
       jmp       short M00_L105
M00_L104:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7FB8AD2EDBF0]
       mov       rsi,rax
M00_L105:
       jmp       near ptr M00_L19
M00_L106:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7FB8AD2EDBF0]
       jmp       near ptr M00_L10
M00_L107:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M00_L109
M00_L108:
       mov       rdi,7FB8AB86B1E8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M00_L108
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M00_L109:
       dec       r13d
       imul      edi,r13d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M00_L110
       mov       r13d,edi
       mov       edx,[r15+20]
       imul      r13,rdx
       shr       r13,20
       jmp       short M00_L111
M00_L110:
       and       edi,[r15+18]
       mov       r13d,edi
M00_L111:
       mov       rdi,[r15+8]
       lea       edx,[r13*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M00_L151
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       [rbp-0F8],rax
       test      rax,rax
       je        short M00_L112
       mov       rdx,rax
       xor       esi,esi
       call      00007FB92AC74060
       mov       rdi,[rbp-0F8]
       cmp       rax,rdi
       je        short M00_L113
M00_L112:
       xor       edi,edi
M00_L113:
       mov       [rbp-60],rdi
       jmp       near ptr M00_L17
M00_L114:
       mov       rax,7FB8AB86B178
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-68],eax
       test      eax,eax
       je        short M00_L114
       mov       rdi,7FB92AEA0D68
       mov       rcx,7FB92B82C820
       call      rcx
       add       rax,48
       mov       ecx,[rbp-68]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M00_L11
M00_L115:
       mov       rcx,[r14+8]
       mov       edi,[rcx+8]
       mov       ecx,eax
       imul      rcx,[r14+10]
       shr       rcx,20
       inc       rcx
       imul      rcx,rdi
       shr       rcx,20
       mov       eax,ecx
       mov       ecx,eax
       jmp       near ptr M00_L12
M00_L116:
       mov       rsi,[rdx]
       mov       r8d,esi
       cmp       r8d,0FFFFFFFF
       jne       near ptr M00_L14
       mov       eax,[rbp-64]
M00_L117:
       xor       edx,edx
       mov       [rbp-60],rdx
       jmp       near ptr M00_L16
M00_L118:
       lea       rdx,[rbp-60]
       mov       rdi,r14
       mov       esi,eax
       call      qword ptr [7FB8AD2EDD10]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       jmp       near ptr M00_L17
M00_L119:
       test      r14,r14
       je        short M00_L120
       cmp       [r15],r15b
       mov       rdi,offset MT_PoolContextProbe+Item
       call      CORINFO_HELP_NEWSFAST
       mov       rsi,rax
       mov       dword ptr [rsi+8],2A
       jmp       near ptr M00_L18
M00_L120:
       mov       rdi,r15
       mov       esi,r13d
       call      qword ptr [7FB8AD2EDCC8]
       mov       rsi,rax
       jmp       near ptr M00_L18
M00_L121:
       mov       rdi,offset MT_Reservoir.ObjectPool<PoolContextProbe+Item, PoolContextProbe+Policy>
       call      qword ptr [7FB8AD2EDBF0]
       mov       rsi,rax
       jmp       near ptr M00_L19
M00_L122:
       mov       rdi,r13
       call      qword ptr [7FB8AD2EDEA8]
       jmp       near ptr M00_L24
M00_L123:
       mov       rax,7FB8AB86B178
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-7C],eax
       test      eax,eax
       je        short M00_L123
       mov       rdi,7FB92AEA0D68
       mov       rcx,7FB92B82C820
       call      rcx
       add       rax,48
       mov       ecx,[rbp-7C]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M00_L20
M00_L124:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M00_L21
M00_L125:
       mov       rdx,[rdi]
       mov       r10d,edx
       cmp       r10d,0FFFFFFFF
       mov       r11d,[rbp-0A4]
       jne       near ptr M00_L33
M00_L126:
       mov       eax,[rbp-74]
       inc       eax
       mov       r9d,eax
       mov       rcx,[rbp-110]
       mov       r10,[rcx+8]
       cmp       [r10+8],r9d
       jne       short M00_L127
       xor       r9d,r9d
       xor       edi,edi
       mov       r9d,edi
M00_L127:
       mov       r8d,[rbp-78]
       inc       r8d
       cmp       [r10+8],r8d
       mov       [rbp-78],r8d
       mov       eax,r9d
       jg        near ptr M00_L22
M00_L128:
       cmp       [r13],r13b
       jmp       near ptr M00_L23
M00_L129:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M00_L131
M00_L130:
       mov       rax,7FB8AB86B1E8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-8C],eax
       test      eax,eax
       je        short M00_L130
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rbp-8C]
       mov       [rax+10],edi
       mov       eax,edi
M00_L131:
       dec       eax
       imul      edi,eax,9E3779B9
       cmp       dword ptr [r13+18],0
       jge       short M00_L132
       mov       eax,edi
       mov       ecx,[r13+20]
       imul      rax,rcx
       shr       rax,20
       jmp       short M00_L133
M00_L132:
       mov       eax,edi
       and       eax,[r13+18]
M00_L133:
       mov       rdi,[r13+8]
       mov       [rbp-90],eax
       lea       esi,[rax*8+8]
       cmp       esi,[rdi+8]
       jae       near ptr M00_L151
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       je        near ptr M00_L148
       mov       rsi,r15
       call      00007FB92AC74040
       test      rax,rax
       je        near ptr M00_L23
       mov       rdi,r13
       mov       rsi,r15
       mov       rdx,rax
       mov       ecx,[rbp-90]
       call      qword ptr [7FB8AD2EE028]
       jmp       near ptr M00_L23
M00_L134:
       mov       rdi,r13
       call      qword ptr [7FB8AD2EE070]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       jmp       near ptr M00_L24
M00_L135:
       mov       edi,29
       mov       rsi,7FB8ACCD54D8
       call      qword ptr [7FB8AC85EF88]
       mov       rdi,rax
       call      qword ptr [7FB8AD8963D0]
       int       3
M00_L136:
       mov       rdi,rbx
       mov       rsi,r12
       call      qword ptr [7FB8AD2EDEA8]
       jmp       near ptr M00_L29
M00_L137:
       mov       rdi,7FB8AB86B178
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M00_L137
       mov       rdi,7FB92AEA0D68
       mov       rax,7FB92B82C820
       call      rax
       add       rax,48
       mov       [rax+10],r13d
       jmp       near ptr M00_L25
M00_L138:
       mov       rdi,[r15+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r15+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
       jmp       near ptr M00_L26
M00_L139:
       mov       rdx,[rdi]
       mov       r8d,edx
       cmp       r8d,0FFFFFFFF
       jne       near ptr M00_L36
M00_L140:
       inc       r13d
       mov       rcx,[r15+8]
       cmp       [rcx+8],r13d
       jne       short M00_L141
       xor       r13d,r13d
M00_L141:
       mov       eax,[rbp-94]
       inc       eax
       cmp       [rcx+8],eax
       mov       [rbp-94],eax
       jg        near ptr M00_L27
M00_L142:
       cmp       [rbx],bl
       jmp       near ptr M00_L28
M00_L143:
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r15d,[rax+10]
       test      r15d,r15d
       jne       short M00_L145
M00_L144:
       mov       rdi,7FB8AB86B1E8
       mov       eax,1
       mov       r15d,eax
       lock xadd [rdi],r15d
       inc       r15d
       je        short M00_L144
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r15d
M00_L145:
       dec       r15d
       imul      r15d,9E3779B9
       cmp       dword ptr [rbx+18],0
       jge       short M00_L146
       mov       r13d,r15d
       mov       r15d,[rbx+20]
       imul      r15,r13
       shr       r15,20
       jmp       short M00_L147
M00_L146:
       and       r15d,[rbx+18]
M00_L147:
       mov       rdi,[rbx+8]
       lea       esi,[r15*8+8]
       cmp       esi,[rdi+8]
       jae       short M00_L151
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M00_L149
M00_L148:
       call      qword ptr [7FB8AD8963B8]
       int       3
M00_L149:
       mov       rsi,r12
       call      00007FB92AC74040
       test      rax,rax
       je        near ptr M00_L28
       mov       rdi,rbx
       mov       rsi,r12
       mov       rdx,rax
       mov       ecx,r15d
       call      qword ptr [7FB8AD2EE028]
       jmp       near ptr M00_L28
M00_L150:
       mov       rdi,rbx
       call      qword ptr [7FB8AD2EE070]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       jmp       near ptr M00_L29
M00_L151:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 5011
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItemGuarded(System.__Canon)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       cmp       [rdi],dil
       mov       eax,1
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
       push      rax
       mov       rbx,rdi
       mov       rdi,offset MT_System.Exception[]
       mov       esi,2
       call      CORINFO_HELP_NEWARR_1_PTR
       mov       r15,rax
       lea       rdi,[r15+10]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r15+18]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,offset MT_System.AggregateException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,0C1
       mov       rsi,7FB8ACCD54D8
       call      qword ptr [7FB8AC85EF88]
       mov       rsi,rax
       mov       rdi,rbx
       mov       rdx,r15
       call      qword ptr [7FB8AD2EDFB0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
       push      rax
       mov       rsi,rdi
       mov       [rbp-20],rsi
       mov       rdi,[rbp-18]
       cmp       [rdi],dil
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 170
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-10]
       mov       rcx,rax
       test      cl,1
       jne       short M02_L00
       ret
M02_L00:
       jmp       qword ptr [7FB8ACC4EA48]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 23
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+30]
       mov       rbx,rsi
       mov       r15,rdx
       lea       rdi,[rbx+58]
       mov       rsi,[rbx+48]
       mov       rax,[rdi]
       mov       r14d,eax
       cmp       r14d,0FFFFFFFF
       je        near ptr M03_L03
       mov       ecx,[rsi+8]
M03_L00:
       cmp       r14d,ecx
       jae       near ptr M03_L04
       mov       r13d,r14d
       shl       r13,4
       mov       edx,[rsi+r13+18]
       mov       r8,rax
       sar       r8,20
       inc       r8d
       movsxd    r8,r8d
       shl       r8,20
       or        rdx,r8
       mov       [rbp-28],rax
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-28]
       jne       short M03_L02
       mov       rdi,[rbx+48]
       cmp       r14d,[rdi+8]
       jae       near ptr M03_L04
       mov       rsi,[rdi+r13+10]
       mov       rdi,r15
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbx+48]
       cmp       r14d,[rax+8]
       jae       short M03_L04
       lea       rcx,[rax+r13+10]
       xor       eax,eax
       mov       [rcx],rax
       add       rbx,60
M03_L01:
       mov       rax,[rbx]
       mov       [rbp-30],rax
       mov       [rcx+8],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       edi,r14d
       or        rdx,rdi
       lock cmpxchg [rbx],rdx
       cmp       rax,[rbp-30]
       jne       short M03_L01
       cmp       qword ptr [r15],0
       setne     al
       movzx     eax,al
       add       rsp,10
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M03_L02:
       mov       rax,[rdi]
       mov       r14d,eax
       cmp       r14d,0FFFFFFFF
       jne       near ptr M03_L00
M03_L03:
       xor       eax,eax
       mov       [r15],rax
       add       rsp,10
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M03_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 263
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       push      rbp
       sub       rsp,60
       lea       rbp,[rsp+60]
       xor       eax,eax
       mov       [rbp-54],rax
       mov       [rbp-4C],eax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-3C],esi
       mov       [rbp-48],rdx
       mov       dword ptr [rbp-60],3E8
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FB8AD2EDD28]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       eax,[rax+14]
       dec       eax
       mov       [rbp-4C],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-4C]
       jbe       short M04_L02
       mov       eax,[rbp-4C]
       cmp       eax,[rbp-3C]
       je        short M04_L01
       mov       rdi,[rbp-38]
       mov       esi,[rbp-4C]
       mov       rdx,[rbp-48]
       call      qword ptr [7FB8AD2EDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       je        short M04_L00
       mov       rdi,7FB8AD6E72E0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,60
       pop       rbp
       ret
M04_L00:
       mov       rdi,7FB8AD6E72E4
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       short M04_L02
M04_L01:
       mov       rdi,7FB8AD6E72E8
       call      CORINFO_HELP_COUNTPROFILE32
M04_L02:
       mov       eax,[rbp-3C]
       mov       [rbp-50],eax
       mov       dword ptr [rbp-54],1
       jmp       near ptr M04_L06
M04_L03:
       mov       eax,[rbp-50]
       inc       eax
       mov       [rbp-58],eax
       mov       eax,[rbp-50]
       inc       eax
       mov       [rbp-50],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-58]
       jne       short M04_L04
       mov       rdi,7FB8AD6E72EC
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-50],eax
M04_L04:
       mov       rdi,[rbp-38]
       mov       esi,[rbp-50]
       mov       rdx,[rbp-48]
       call      qword ptr [7FB8AD2EDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       je        short M04_L05
       mov       rdi,7FB8AD6E72F0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FB8AD2EDD28]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       ecx,[rbp-50]
       inc       ecx
       mov       [rax+14],ecx
       mov       eax,1
       add       rsp,60
       pop       rbp
       ret
M04_L05:
       mov       rdi,7FB8AD6E72F4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-54]
       inc       eax
       mov       [rbp-54],eax
M04_L06:
       mov       eax,[rbp-60]
       dec       eax
       mov       [rbp-60],eax
       cmp       dword ptr [rbp-60],0
       jg        short M04_L07
       lea       rdi,[rbp-60]
       mov       esi,52
       call      CORINFO_HELP_PATCHPOINT
M04_L07:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-54]
       jg        near ptr M04_L03
       mov       rdi,7FB8AD6E72F8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-48]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,60
       pop       rbp
       ret
; Total bytes of code 406
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       push      rbp
       sub       rsp,0B0
       lea       rbp,[rsp+0B0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       dword ptr [rbp-88],3E8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-98],rax
       mov       rax,[rbp-98]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+50]
       mov       [rbp-0A0],rax
       cmp       qword ptr [rbp-0A0],0
       je        short M05_L00
       mov       rax,[rbp-0A0]
       mov       [rbp-70],rax
       jmp       short M05_L01
M05_L00:
       mov       rdi,[rbp-98]
       mov       rsi,7FB8AD96C890
       call      qword ptr [7FB8AC85F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-70],rax
M05_L01:
       mov       rax,[rbp-38]
       cmp       [rax],al
       mov       rax,[rbp-38]
       lea       rdi,[rax+28]
       mov       rsi,[rbp-70]
       mov       rdx,[rbp-38]
       call      qword ptr [7FB8AD896898]; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       nop
M05_L02:
       mov       rax,[rbp-38]
       mov       rax,[rax+10]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-48],0
       je        near ptr M05_L07
M05_L03:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M05_L04
       lea       rdi,[rbp-88]
       mov       esi,1D
       call      CORINFO_HELP_PATCHPOINT
M05_L04:
       lea       rsi,[rbp-50]
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7FB8AD2EDC98]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       test      eax,eax
       je        short M05_L05
       mov       rdi,7FB8AD999F94
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-50]
       call      qword ptr [7FB8AD95C6F0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       jmp       short M05_L03
M05_L05:
       cmp       qword ptr [rbp-40],0
       je        short M05_L06
       mov       rdi,7FB8AD999F98
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7FB8AD95C708]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FB8AD95C720]
M05_L06:
       mov       rdi,7FB8AD999F9C
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M05_L07:
       xor       eax,eax
       mov       [rbp-54],eax
       jmp       near ptr M05_L12
M05_L08:
       mov       rdi,[rbp-38]
       mov       esi,[rbp-54]
       call      qword ptr [7FB8AD2EDC80]
       mov       [rbp-60],rax
       mov       rax,[rbp-60]
       cmp       qword ptr [rax],0
       je        near ptr M05_L11
       mov       rdi,7FB8AD999FA0
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-68],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-0A8],rax
       mov       rax,[rbp-0A8]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+40]
       mov       [rbp-0B0],rax
       cmp       qword ptr [rbp-0B0],0
       je        short M05_L09
       mov       rax,[rbp-0B0]
       mov       [rbp-78],rax
       jmp       short M05_L10
M05_L09:
       mov       rdi,[rbp-0A8]
       mov       rsi,7FB8AD6F09D0
       call      qword ptr [7FB8AC85F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-78],rax
M05_L10:
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-60]
       mov       rdx,[rbp-68]
       call      qword ptr [7FB8AD2EDFC8]
       mov       [rbp-90],rax
       mov       rsi,[rbp-90]
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       call      qword ptr [7FB8AD95C6F0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
M05_L11:
       mov       rdi,7FB8AD999FA4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-54]
       inc       eax
       mov       [rbp-54],eax
M05_L12:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M05_L13
       lea       rdi,[rbp-88]
       mov       esi,79
       call      CORINFO_HELP_PATCHPOINT
M05_L13:
       mov       rdi,[rbp-38]
       call      qword ptr [7FB8AD95C738]
       cmp       eax,[rbp-54]
       jg        near ptr M05_L08
       cmp       qword ptr [rbp-40],0
       je        short M05_L14
       mov       rdi,7FB8AD999FA8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7FB8AD95C708]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FB8AD95C720]
M05_L14:
       mov       rdi,7FB8AD999FAC
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
       push      rax
       mov       [rbp-80],rdi
       mov       rdi,7FB8AD999F90
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-80]
       mov       [rbp-40],rax
       lea       rax,[M05_L02]
       add       rsp,8
       ret
; Total bytes of code 760
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbx
       sub       rsp,10
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rbx,rdi
       mov       rdi,rbx
       call      qword ptr [7FB8AC419718]; Precode of System.Runtime.CompilerServices.InitHelpers.InitClassSlow(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rbx+20]
       mov       rax,[rax-10]
       mov       [rsp+8],rax
       mov       rax,[rsp+8]
       and       rax,0FFFFFFFFFFFFFFFE
       xor       ecx,ecx
       mov       [rsp+8],rcx
       add       rsp,10
       pop       rbx
       ret
; Total bytes of code 59
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rax,[rdi+20]
       mov       ebx,[rax-28]
       cmp       ebx,0FFFFFFFF
       je        near ptr M07_L04
       mov       rdi,7FB92AEA0D68
       mov       rax,7FB92B82C820
       call      rax
       add       rax,8
       add       rax,0FFFFFFFFFFFFFFF8
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M07_L01
       cmp       [rax],edi
       jle       short M07_L03
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M07_L03
M07_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M07_L01:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M07_L02
       movsxd    rdi,ecx
       add       rax,rdi
       jmp       short M07_L00
M07_L02:
       cmp       [rax+4],ecx
       jle       short M07_L03
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M07_L03
       mov       rax,[rdi]
       test      rax,rax
       je        short M07_L03
       jmp       short M07_L00
M07_L03:
       mov       edi,ebx
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7FB8AD896388]
M07_L04:
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7FB8AD2EDD70]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 179
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+30]
       mov       [rbp-28],rdi
       mov       rbx,rdi
       mov       r15,rdx
       mov       rdi,[rbx+8]
       cmp       esi,[rdi+8]
       jae       short M08_L03
       mov       edx,esi
       mov       r14,[rdi+rdx*8+10]
       mov       r13,[r14+50]
       test      r13,r13
       jne       short M08_L01
M08_L00:
       mov       rdi,[rbx]
       mov       rsi,r14
       mov       rdx,r15
       add       rsp,10
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7FB8AD2EDDE8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
M08_L01:
       lea       rdi,[r14+50]
       test      rdi,rdi
       je        short M08_L02
       mov       rdx,r13
       xor       esi,esi
       call      00007FB92AC74060
       cmp       rax,r13
       jne       short M08_L00
       mov       rdi,r15
       mov       rsi,r13
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       eax,1
       add       rsp,10
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M08_L02:
       call      qword ptr [7FB8AD8963B8]
       int       3
M08_L03:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 145
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7FB8AC3FEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7FB8AC3FEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       push      rbp
       sub       rsp,310
       lea       rbp,[rsp+310]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-270],xmm8
       mov       rax,0FFFFFFFFFFFFFDF0
M10_L00:
       vmovdqa   xmmword ptr [rbp+rax-50],xmm8
       vmovdqa   xmmword ptr [rbp+rax-40],xmm8
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       add       rax,30
       jne       short M10_L00
       mov       [rbp-50],rax
       mov       [rbp-30],rsi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       dword ptr [rbp-228],3E8
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       jne       short M10_L01
       mov       rdi,7FB8AD99B498
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,310
       pop       rbp
       ret
M10_L01:
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+10]
       mov       [rbp-278],rax
       cmp       qword ptr [rbp-278],0
       je        short M10_L02
       mov       rax,[rbp-278]
       mov       [rbp-148],rax
       jmp       short M10_L03
M10_L02:
       mov       rdi,[rbp-40]
       mov       rsi,7FB8AD96CB30
       call      qword ptr [7FB8AC85F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-148],rax
M10_L03:
       mov       rdi,[rbp-148]
       call      qword ptr [7FB8AC855728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       movzx     eax,byte ptr [rax]
       test      eax,eax
       je        near ptr M10_L37
       vxorps    ymm0,ymm0,ymm0
       vmovdqu   ymmword ptr [rbp-98],ymm0
       vmovdqu   ymmword ptr [rbp-78],ymm0
       mov       rax,[rbp-50]
       mov       [rbp-0B8],rax
       xor       eax,eax
       mov       [rbp-0C0],eax
       lea       rsi,[rbp-0C0]
       mov       rdi,[rbp-0B8]
       call      qword ptr [7FB8AC855980]; System.Threading.Monitor.Enter(System.Object, Boolean ByRef)
       mov       rdi,[rbp-50]
       cmp       [rdi],edi
       call      qword ptr [7FB8AD95C7F8]
       mov       [rbp-0C8],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-280],rax
       mov       rax,[rbp-280]
       cmp       qword ptr [rax+8],30
       jle       short M10_L04
       mov       rax,[rbp-280]
       mov       rax,[rax+30]
       mov       [rbp-288],rax
       cmp       qword ptr [rbp-288],0
       je        short M10_L04
       mov       rax,[rbp-288]
       mov       [rbp-178],rax
       jmp       short M10_L05
M10_L04:
       mov       rdi,[rbp-40]
       mov       rsi,7FB8AD96CCB8
       call      qword ptr [7FB8AC85F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-178],rax
M10_L05:
       mov       rax,[rbp-0C8]
       mov       [rbp-1F0],rax
       mov       rdi,[rbp-1F0]
       mov       rsi,7FB8AD99B4A0
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-1F0]
       mov       [rbp-230],rax
       mov       rdi,[rbp-230]
       mov       r11,[rbp-178]
       mov       rax,[rbp-178]
       call      qword ptr [rax]
       mov       [rbp-0AC],eax
       cmp       dword ptr [rbp-0AC],8
       jg        near ptr M10_L08
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-290],rax
       mov       rax,[rbp-290]
       cmp       qword ptr [rax+8],58
       jle       short M10_L06
       mov       rax,[rbp-290]
       mov       rax,[rax+58]
       mov       [rbp-298],rax
       cmp       qword ptr [rbp-298],0
       je        short M10_L06
       mov       rax,[rbp-298]
       mov       [rbp-1D8],rax
       jmp       short M10_L07
M10_L06:
       mov       rdi,[rbp-40]
       mov       rsi,7FB8AD96D0E8
       call      qword ptr [7FB8AC85F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1D8],rax
M10_L07:
       lea       rsi,[rbp-98]
       mov       rdi,[rbp-1D8]
       mov       edx,8
       call      qword ptr [7FB8AD95C7B0]
       mov       [rbp-1E8],rax
       mov       [rbp-1E0],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-1E8]
       vmovdqu   xmmword ptr [rbp-0A8],xmm0
       jmp       near ptr M10_L13
M10_L08:
       mov       rdi,7FB8AD99B5A8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2A0],rax
       mov       rax,[rbp-2A0]
       cmp       qword ptr [rax+8],38
       jle       short M10_L09
       mov       rax,[rbp-2A0]
       mov       rax,[rax+38]
       mov       [rbp-2A8],rax
       cmp       qword ptr [rbp-2A8],0
       je        short M10_L09
       mov       rax,[rbp-2A8]
       mov       [rbp-180],rax
       jmp       short M10_L10
M10_L09:
       mov       rdi,[rbp-40]
       mov       rsi,7FB8AD96CCF0
       call      qword ptr [7FB8AC85F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-180],rax
M10_L10:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2B0],rax
       mov       rax,[rbp-2B0]
       cmp       qword ptr [rax+8],40
       jle       short M10_L11
       mov       rax,[rbp-2B0]
       mov       rax,[rax+40]
       mov       [rbp-2B8],rax
       cmp       qword ptr [rbp-2B8],0
       je        short M10_L11
       mov       rax,[rbp-2B8]
       mov       [rbp-188],rax
       jmp       short M10_L12
M10_L11:
       mov       rdi,[rbp-40]
       mov       rsi,7FB8AD96CD80
       call      qword ptr [7FB8AC85F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-188],rax
M10_L12:
       movsxd    rsi,dword ptr [rbp-0AC]
       mov       rdi,[rbp-180]
       call      CORINFO_HELP_NEWARR_1_PTR
       mov       [rbp-238],rax
       mov       rsi,[rbp-238]
       mov       rdi,[rbp-188]
       call      qword ptr [7FB8AD2E5458]; System.Span`1[[System.__Canon, System.Private.CoreLib]].op_Implicit(System.__Canon[])
       mov       [rbp-198],rax
       mov       [rbp-190],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-198]
       vmovdqu   xmmword ptr [rbp-0A8],xmm0
M10_L13:
       xor       eax,eax
       mov       [rbp-0CC],eax
       jmp       near ptr M10_L17
M10_L14:
       mov       rdi,7FB8AD99B5AC
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2C0],rax
       mov       rax,[rbp-2C0]
       cmp       qword ptr [rax+8],48
       jle       short M10_L15
       mov       rax,[rbp-2C0]
       mov       rax,[rax+48]
       mov       [rbp-2C8],rax
       cmp       qword ptr [rbp-2C8],0
       je        short M10_L15
       mov       rax,[rbp-2C8]
       mov       [rbp-1A0],rax
       jmp       short M10_L16
M10_L15:
       mov       rdi,[rbp-40]
       mov       rsi,7FB8AD96CD90
       call      qword ptr [7FB8AC85F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1A0],rax
M10_L16:
       mov       rax,[rbp-0C8]
       mov       [rbp-1F8],rax
       mov       rdi,[rbp-1F8]
       mov       rsi,7FB8AD99B5B0
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-1F8]
       mov       [rbp-240],rax
       mov       rdi,[rbp-240]
       mov       r11,[rbp-1A0]
       mov       esi,[rbp-0CC]
       mov       rax,[rbp-1A0]
       call      qword ptr [rax]
       mov       [rbp-0D8],rax
       mov       rax,[rbp-0D8]
       inc       dword ptr [rax+68]
       mov       eax,[rbp-0CC]
       inc       eax
       mov       [rbp-0CC],eax
M10_L17:
       mov       eax,[rbp-228]
       dec       eax
       mov       [rbp-228],eax
       cmp       dword ptr [rbp-228],0
       jg        short M10_L18
       lea       rdi,[rbp-228]
       mov       esi,8C
       call      CORINFO_HELP_PATCHPOINT
M10_L18:
       mov       eax,[rbp-0CC]
       cmp       eax,[rbp-0AC]
       jl        near ptr M10_L14
       call      qword ptr [7FB8AD95C810]
       xor       eax,eax
       mov       [rbp-0DC],eax
       jmp       near ptr M10_L30
M10_L19:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2D0],rax
       mov       rax,[rbp-2D0]
       cmp       qword ptr [rax+8],48
       jle       short M10_L20
       mov       rax,[rbp-2D0]
       mov       rax,[rax+48]
       mov       [rbp-2D8],rax
       cmp       qword ptr [rbp-2D8],0
       je        short M10_L20
       mov       rax,[rbp-2D8]
       mov       [rbp-1A8],rax
       jmp       short M10_L21
M10_L20:
       mov       rdi,[rbp-40]
       mov       rsi,7FB8AD96CD90
       call      qword ptr [7FB8AC85F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1A8],rax
M10_L21:
       mov       rax,[rbp-0C8]
       mov       [rbp-200],rax
       mov       rdi,[rbp-200]
       mov       rsi,7FB8AD99B6B8
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-200]
       mov       [rbp-248],rax
       mov       rdi,[rbp-248]
       mov       r11,[rbp-1A8]
       mov       esi,[rbp-0DC]
       mov       rax,[rbp-1A8]
       call      qword ptr [rax]
       mov       [rbp-0E8],rax
       mov       rax,[rbp-0E8]
       mov       [rbp-0F8],rax
       xor       eax,eax
       mov       [rbp-100],eax
       lea       rsi,[rbp-100]
       mov       rdi,[rbp-0F8]
       call      qword ptr [7FB8AC855980]; System.Threading.Monitor.Enter(System.Object, Boolean ByRef)
       mov       rax,[rbp-0E8]
       cmp       [rax],al
       mov       rax,[rbp-0E8]
       add       rax,58
       mov       [rbp-1B0],rax
       xor       eax,eax
       mov       [rbp-108],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-2E0],rax
       cmp       qword ptr [rbp-2E0],0
       je        short M10_L22
       mov       rax,[rbp-2E0]
       mov       [rbp-1B8],rax
       jmp       short M10_L23
M10_L22:
       mov       rdi,[rbp-40]
       mov       rsi,7FB8AD96CBB0
       call      qword ptr [7FB8AC85F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1B8],rax
M10_L23:
       mov       rdi,[rbp-1B8]
       mov       rsi,[rbp-1B0]
       mov       rdx,[rbp-108]
       call      qword ptr [7FB8AD2EDFC8]
       mov       [rbp-0F0],rax
       cmp       qword ptr [rbp-0F0],0
       je        near ptr M10_L27
       mov       rax,[rbp-0E8]
       mov       rax,[rax+60]
       mov       [rbp-110],rax
       cmp       qword ptr [rbp-110],0
       je        short M10_L24
       mov       rdi,7FB8AD99B7C0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-110]
       mov       rsi,[rbp-0F0]
       cmp       [rdi],edi
       call      qword ptr [7FB8AD95C828]
       jmp       near ptr M10_L27
M10_L24:
       mov       rdi,7FB8AD99B7C4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       [rbp-2E8],rax
       mov       rax,[rbp-2E8]
       cmp       qword ptr [rax+8],50
       jle       short M10_L25
       mov       rax,[rbp-2E8]
       mov       rax,[rax+50]
       mov       [rbp-2F0],rax
       cmp       qword ptr [rbp-2F0],0
       je        short M10_L25
       mov       rax,[rbp-2F0]
       mov       [rbp-1C8],rax
       jmp       short M10_L26
M10_L25:
       mov       rdi,[rbp-40]
       mov       rsi,7FB8AD96CF30
       call      qword ptr [7FB8AC85F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-1C8],rax
M10_L26:
       mov       rdi,[rbp-1C8]
       call      CORINFO_HELP_NEWFAST
       mov       [rbp-1C0],rax
       mov       rdi,[rbp-1C0]
       mov       rsi,[rbp-0F0]
       call      qword ptr [7FB8AD2EE3A0]; System.WeakReference`1[[System.__Canon, System.Private.CoreLib]]..ctor(System.__Canon)
       mov       rax,[rbp-0E8]
       lea       rdi,[rax+60]
       mov       rsi,[rbp-1C0]
       call      CORINFO_HELP_ASSIGN_REF
M10_L27:
       mov       rax,[rbp-0E8]
       inc       dword ptr [rax+68]
       call      M10_L50
       jmp       short M10_L29
M10_L28:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M10_L29:
       mov       rdi,7FB8AD99B7D0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-0A0]
       cmp       [rbp-0DC],eax
       jae       short M10_L28
       mov       eax,[rbp-0DC]
       mov       rcx,[rbp-0A8]
       lea       rdi,[rcx+rax*8]
       mov       rsi,[rbp-0F0]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       eax,[rbp-0DC]
       inc       eax
       mov       [rbp-0DC],eax
M10_L30:
       mov       eax,[rbp-228]
       dec       eax
       mov       [rbp-228],eax
       cmp       dword ptr [rbp-228],0
       jg        short M10_L31
       lea       rdi,[rbp-228]
       mov       esi,13A
       call      CORINFO_HELP_PATCHPOINT
M10_L31:
       mov       eax,[rbp-0DC]
       cmp       eax,[rbp-0AC]
       jl        near ptr M10_L19
       call      M10_L52
       nop
       xor       eax,eax
       mov       [rbp-114],eax
       jmp       short M10_L34
M10_L32:
       mov       eax,[rbp-0A0]
       cmp       [rbp-114],eax
       jae       near ptr M10_L49
       mov       eax,[rbp-114]
       mov       rcx,[rbp-0A8]
       mov       rax,[rcx+rax*8]
       mov       [rbp-120],rax
       cmp       qword ptr [rbp-120],0
       je        short M10_L33
       mov       rdi,7FB8AD99B7DC
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-48]
       mov       rsi,[rbp-120]
       cmp       [rdi],edi
       call      qword ptr [7FB8AD95C840]
       nop
M10_L33:
       mov       rdi,7FB8AD99B7E8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-114]
       inc       eax
       mov       [rbp-114],eax
M10_L34:
       mov       eax,[rbp-228]
       dec       eax
       mov       [rbp-228],eax
       cmp       dword ptr [rbp-228],0
       jg        short M10_L35
       lea       rdi,[rbp-228]
       mov       esi,18A
       call      CORINFO_HELP_PATCHPOINT
M10_L35:
       mov       eax,[rbp-114]
       cmp       eax,[rbp-0AC]
       jl        near ptr M10_L32
       cmp       qword ptr [rbp-58],0
       je        short M10_L36
       mov       rdi,7FB8AD99B7EC
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-58]
       call      qword ptr [7FB8AD95C708]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FB8AD95C720]
M10_L36:
       mov       rdi,7FB8AD99B7F0
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,310
       pop       rbp
       ret
M10_L37:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-2F8],rax
       cmp       qword ptr [rbp-2F8],0
       je        short M10_L38
       mov       rax,[rbp-2F8]
       mov       [rbp-150],rax
       jmp       short M10_L39
M10_L38:
       mov       rdi,[rbp-40]
       mov       rsi,7FB8AD96CB40
       call      qword ptr [7FB8AC85F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-150],rax
M10_L39:
       mov       rdi,[rbp-50]
       cmp       [rdi],edi
       call      qword ptr [7FB8AD95C7F8]
       mov       [rbp-208],rax
       mov       rdi,[rbp-208]
       mov       rsi,7FB8AD99B7F8
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-208]
       mov       [rbp-250],rax
       mov       rdi,[rbp-250]
       mov       r11,[rbp-150]
       mov       rax,[rbp-150]
       call      qword ptr [rax]
       mov       [rbp-130],rax
       jmp       near ptr M10_L46
M10_L40:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-300],rax
       cmp       qword ptr [rbp-300],0
       je        short M10_L41
       mov       rax,[rbp-300]
       mov       [rbp-158],rax
       jmp       short M10_L42
M10_L41:
       mov       rdi,[rbp-40]
       mov       rsi,7FB8AD96CB78
       call      qword ptr [7FB8AC85F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-158],rax
M10_L42:
       mov       rax,[rbp-130]
       mov       [rbp-210],rax
       mov       rdi,[rbp-210]
       mov       rsi,7FB8AD99B900
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-210]
       mov       [rbp-260],rax
       mov       rdi,[rbp-260]
       mov       r11,[rbp-158]
       mov       rax,[rbp-158]
       call      qword ptr [rax]
       mov       [rbp-258],rax
       mov       rax,[rbp-258]
       cmp       [rax],al
       mov       rax,[rbp-258]
       add       rax,58
       mov       [rbp-160],rax
       xor       eax,eax
       mov       [rbp-108],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-308],rax
       cmp       qword ptr [rbp-308],0
       je        short M10_L43
       mov       rax,[rbp-308]
       mov       [rbp-168],rax
       jmp       short M10_L44
M10_L43:
       mov       rdi,[rbp-40]
       mov       rsi,7FB8AD96CBB0
       call      qword ptr [7FB8AC85F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-168],rax
M10_L44:
       mov       rdi,[rbp-168]
       mov       rsi,[rbp-160]
       mov       rdx,[rbp-108]
       call      qword ptr [7FB8AD2EDFC8]
       mov       [rbp-138],rax
       cmp       qword ptr [rbp-138],0
       je        short M10_L45
       mov       rdi,7FB8AD99BA08
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-48]
       mov       rsi,[rbp-138]
       cmp       [rdi],edi
       call      qword ptr [7FB8AD95C840]
       jmp       short M10_L46
M10_L45:
       mov       rdi,7FB8AD99BA0C
       call      CORINFO_HELP_COUNTPROFILE32
M10_L46:
       mov       eax,[rbp-228]
       dec       eax
       mov       [rbp-228],eax
       cmp       dword ptr [rbp-228],0
       jg        short M10_L47
       lea       rdi,[rbp-228]
       mov       esi,1E9
       call      CORINFO_HELP_PATCHPOINT
M10_L47:
       mov       rax,[rbp-130]
       mov       [rbp-218],rax
       mov       rdi,[rbp-218]
       mov       rsi,7FB8AD99BA18
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-218]
       mov       [rbp-268],rax
       mov       rdi,[rbp-268]
       mov       r11,7FB8AB870880
       call      qword ptr [r11]
       test      eax,eax
       jne       near ptr M10_L40
       call      M10_L56
       nop
       cmp       qword ptr [rbp-58],0
       je        short M10_L48
       mov       rdi,7FB8AD99BC34
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-58]
       call      qword ptr [7FB8AD95C708]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FB8AD95C720]
M10_L48:
       mov       rdi,7FB8AD99BC38
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,310
       pop       rbp
       ret
M10_L49:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M10_L50:
       push      rax
       movzx     eax,byte ptr [rbp-100]
       test      eax,eax
       je        short M10_L51
       mov       rdi,7FB8AD99B7C8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-0F8]
       call      qword ptr [7FB8AC856808]; System.Threading.Monitor.Exit(System.Object)
M10_L51:
       mov       rdi,7FB8AD99B7CC
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
M10_L52:
       push      rax
       movzx     eax,byte ptr [rbp-0C0]
       test      eax,eax
       je        short M10_L53
       mov       rdi,7FB8AD99B7D4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-0B8]
       call      qword ptr [7FB8AC856808]; System.Threading.Monitor.Exit(System.Object)
M10_L53:
       mov       rdi,7FB8AD99B7D8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
       push      rax
       mov       [rbp-1D0],rdi
       mov       rax,[rbp-1D0]
       mov       [rbp-128],rax
       cmp       qword ptr [rbp-58],0
       jne       short M10_L54
       mov       rdi,7FB8AD99B7E0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-128]
       mov       [rbp-58],rax
M10_L54:
       mov       rdi,7FB8AD99B7E4
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rax,[M10_L33]
       add       rsp,8
       ret
       push      rax
       mov       [rbp-170],rdi
       mov       rax,[rbp-170]
       mov       [rbp-140],rax
       cmp       qword ptr [rbp-58],0
       jne       short M10_L55
       mov       rdi,7FB8AD99BA10
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-140]
       mov       [rbp-58],rax
M10_L55:
       mov       rdi,7FB8AD99BA14
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rax,[M10_L46]
       add       rsp,8
       ret
M10_L56:
       push      rax
       cmp       qword ptr [rbp-130],0
       je        short M10_L57
       mov       rdi,7FB8AD99BB20
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-130]
       mov       [rbp-220],rax
       mov       rdi,[rbp-220]
       mov       rsi,7FB8AD99BB28
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-220]
       mov       [rbp-270],rax
       mov       rdi,[rbp-270]
       mov       r11,7FB8AB870888
       call      qword ptr [r11]
M10_L57:
       mov       rdi,7FB8AD99BC30
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
; Total bytes of code 3431
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       push      rax
       lea       rbp,[rsp+30]
       mov       [rbp-30],rdi
       mov       rbx,rdi
       mov       r15,rsi
       mov       rdi,rbx
       call      qword ptr [7FB8AD2EDCE0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       r14d,eax
       mov       rdi,[rbx+8]
       cmp       r14d,[rdi+8]
       jae       near ptr M11_L05
       mov       edx,r14d
       mov       r13,[rdi+rdx*8+10]
       mov       r12,[r13+50]
       test      r12,r12
       jne       short M11_L02
M11_L00:
       mov       rdi,[rbx]
       mov       rsi,r13
       mov       rdx,r15
       call      qword ptr [7FB8AD2EDDE8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       je        short M11_L04
M11_L01:
       mov       eax,1
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M11_L02:
       lea       rdi,[r13+50]
       test      rdi,rdi
       je        short M11_L03
       mov       rdx,r12
       xor       esi,esi
       call      00007FB92AC74060
       cmp       rax,r12
       jne       short M11_L00
       mov       rdi,r15
       mov       rsi,r12
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp       short M11_L01
M11_L03:
       call      qword ptr [7FB8AD8963B8]
       int       3
M11_L04:
       mov       rdi,rbx
       mov       esi,r14d
       mov       rdx,r15
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7FB8AD2EDD10]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M11_L05:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 187
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       cmp       qword ptr [rbp-10],0
       jne       short M12_L00
       add       rsp,30
       pop       rbp
       ret
M12_L00:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FB8AD2EDBD8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
M12_L01:
       add       rsp,30
       pop       rbp
       ret
       push      rax
       mov       [rbp-28],rdi
       mov       rax,[rbp-28]
       mov       [rbp-20],rax
       mov       rax,[rbp-18]
       cmp       qword ptr [rax],0
       jne       short M12_L02
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
M12_L02:
       lea       rax,[M12_L01]
       add       rsp,8
       ret
; Total bytes of code 114
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       rsi,rdi
       lea       rdi,[rbp-30]
       mov       [rbp-94],rdi
       mov       [rbp-9C],rsi
       xor       edx,edx
       mov       [rbp-8C],edx
       lea       rdi,[rbp-88]
       call      qword ptr [7FB8AC3FEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       edx,[rbp-8C]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7FB8AC3FEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,[rbp-30]
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 131
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7FB8AC404740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7FB8AC3FEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7FB8AC40F690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M14_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M14_L00
       mov       rsi,rax
       call      qword ptr [7FB8AC3FEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M14_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7FB8AC3FEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7FB8AC3FEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; System.Threading.Monitor.Enter(System.Object, Boolean ByRef)
       push      rbp
       push      r15
       push      rbx
       lea       rbp,[rsp+10]
       mov       r15,rdi
       mov       rbx,rsi
       cmp       byte ptr [rbx],0
       je        short M16_L00
       call      qword ptr [7FB8AC4169F0]
       int       3
M16_L00:
       test      r15,r15
       je        short M16_L02
       mov       rdi,r15
       call      qword ptr [7FB8AC4169B0]
       test      eax,eax
       jne       short M16_L01
       mov       rdi,r15
       call      qword ptr [7FB8AC4169C0]
M16_L01:
       mov       byte ptr [rbx],1
       pop       rbx
       pop       r15
       pop       rbp
       ret
M16_L02:
       xor       edi,edi
       call      qword ptr [7FB8AC411208]
       int       3
; Total bytes of code 71
```
```assembly
; System.Span`1[[System.__Canon, System.Private.CoreLib]].op_Implicit(System.__Canon[])
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7FB8AC4069B0]
       mov       rdi,rax
       test      rbx,rbx
       je        short M17_L01
       mov       r15,[rbx]
       call      qword ptr [7FB8AC408528]
       cmp       r15,rax
       jne       short M17_L02
       lea       rax,[rbx+10]
       mov       edx,[rbx+8]
M17_L00:
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
M17_L01:
       xor       eax,eax
       xor       edx,edx
       jmp       short M17_L00
M17_L02:
       call      qword ptr [7FB8AC414118]
       int       3
; Total bytes of code 77
```
```assembly
; System.WeakReference`1[[System.__Canon, System.Private.CoreLib]]..ctor(System.__Canon)
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       xor       edx,edx
       jmp       qword ptr [rax]
; Total bytes of code 12
```
```assembly
; System.Threading.Monitor.Exit(System.Object)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rbx,rdi
       test      rbx,rbx
       je        short M19_L00
       mov       rdi,rbx
       call      00007FB92AAE6790
       test      eax,eax
       jne       short M19_L01
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M19_L00:
       xor       edi,edi
       call      qword ptr [7FB8AD8963D0]
       int       3
M19_L01:
       mov       edi,eax
       mov       rsi,rbx
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7FB8AD896C70]
; Total bytes of code 61
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rdi
       mov       rdi,[rbx]
       call      qword ptr [7FB8AD2EDD28]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       r15d,[rax+10]
       test      r15d,r15d
       je        short M20_L02
M20_L00:
       dec       r15d
       mov       eax,[rbx+18]
       test      eax,eax
       jl        short M20_L03
       and       eax,r15d
M20_L01:
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
M20_L02:
       mov       rdi,[rbx]
       call      qword ptr [7FB8AC855728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       edi,1
       mov       r15d,edi
       lock xadd [rax],r15d
       inc       r15d
       je        short M20_L02
       mov       rdi,[rbx]
       call      qword ptr [7FB8AD2EDD28]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       [rax+10],r15d
       jmp       short M20_L00
M20_L03:
       mov       rax,[rbx+8]
       mov       eax,[rax+8]
       mov       ecx,r15d
       imul      rcx,[rbx+10]
       shr       rcx,20
       inc       rcx
       imul      rax,rcx
       shr       rax,20
       jmp       short M20_L01
; Total bytes of code 134
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7FB8AD95C858]; PoolContextProbe+Policy.Destroy(Item)
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 49
```
```assembly
; PoolContextProbe+Policy.Destroy(Item)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 24
```

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: B-candidate(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.9.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.9.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=10, LaunchCount=3, WarmupCount=5))

```assembly
; PoolContextProbe.SingleContext()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,48
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-48],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-40],xmm8
       mov       [rbp-30],rax
       mov       rdi,7FB18D800AB0
       mov       rbx,[rdi]
       mov       rdi,7FB18D800400
       mov       r15,[rdi]
       test      rbx,rbx
       je        near ptr M00_L04
M00_L00:
       mov       rdi,7FB18D800AF0
       mov       r14,[rdi]
       test      r14,r14
       je        near ptr M00_L05
M00_L01:
       mov       rdi,7FB18D800AF8
       mov       r13,[rdi]
       test      r13,r13
       je        near ptr M00_L06
M00_L02:
       mov       rax,[r15+38]
       test      rax,rax
       jne       near ptr M00_L07
       cmp       byte ptr [r15+48],0
       jne       near ptr M00_L08
       mov       r12,[r15+10]
       xor       edi,edi
       test      rdi,rdi
       cmove     rdi,r15
       mov       rdi,[rdi+20]
       mov       rax,7FB18D800B00
       test      rdi,rdi
       cmove     rdi,[rax]
       mov       [rbp-50],rdi
       mov       rax,[r15+38]
       test      rax,rax
       jne       near ptr M00_L09
       mov       rdi,[rbp-50]
       mov       rcx,[r15+40]
M00_L03:
       mov       [rsp],r13
       xor       esi,esi
       mov       [rsp+8],rsi
       mov       [rsp+10],rsi
       mov       rsi,r12
       mov       rdx,rdi
       mov       r8,rbx
       mov       r9,r14
       mov       rdi,7FB977EBE488
       call      qword ptr [7FB977ABE6B8]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       mov       [rbp-48],rax
       mov       [rbp-40],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-48]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       mov       rax,[rbp-38]
       mov       rdx,[rbp-30]
       add       rsp,48
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M00_L04:
       mov       rdi,offset MT_System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rsi,7FB18D800AA8
       mov       rsi,[rsi]
       mov       rdi,rbx
       mov       rdx,offset PoolContextProbe+<>c.<SingleContext>b__5_0(Kevlar.KevlarContext)
       call      qword ptr [7FB977026E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7FB18D800AB0
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L00
M00_L05:
       mov       rdi,offset MT_System.Action<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarProperties>
       call      CORINFO_HELP_NEWSFAST
       mov       r14,rax
       mov       rsi,7FB18D800AE8
       mov       rsi,[rsi]
       mov       rdi,r14
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       call      qword ptr [7FB977026E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7FB18D800AF0
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L01
M00_L06:
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r13,rax
       mov       rsi,7FB18D800AE8
       mov       rsi,[rsi]
       mov       rdi,r13
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7FB977026E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7FB18D800AF8
       mov       rsi,r13
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L02
M00_L07:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       r8,r13
       mov       rdx,rbx
       mov       rcx,r14
       mov       rsi,7FB977EBCB18
       xor       r9d,r9d
       cmp       [rdi],edi
       add       rsp,48
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7FB977ABE460]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
M00_L08:
       call      qword ptr [7FB977ABE628]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M00_L09:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FB977ABE610]; Kevlar.Shield.get_Name()
       mov       rcx,rax
       mov       rdi,[rbp-50]
       jmp       near ptr M00_L03
; Total bytes of code 604
```
```assembly
; BenchmarkDotNet.Helpers.AwaitHelper.GetResult[[System.Int32, System.Private.CoreLib]](System.Threading.Tasks.ValueTask`1<Int32>)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp-48],rax
       mov       [rbp-40],rax
       mov       [rbp-38],rdi
       mov       [rbp-30],rsi
       mov       rbx,rdi
       mov       r15d,esi
       movsx     r14,word ptr [rbp-2C]
       test      rbx,rbx
       je        near ptr M01_L11
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<System.Int32>
       call      qword ptr [7FB977026838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r13,rax
       mov       rax,r13
       test      rax,rax
       jne       near ptr M01_L05
       mov       rdi,offset MT_Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource
       cmp       [rbx],rdi
       je        short M01_L02
       mov       rdi,rbx
       mov       esi,r14d
       mov       r11,7FB9760405F8
       call      qword ptr [r11]
M01_L00:
       test      eax,eax
       je        near ptr M01_L15
M01_L01:
       test      r13,r13
       jne       near ptr M01_L09
       mov       rdi,offset MT_Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource
       cmp       [rbx],rdi
       je        short M01_L06
       mov       rdi,rbx
       mov       esi,r14d
       mov       r11,7FB976040600
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M01_L02:
       lea       rsi,[rbx+40]
       movsx     rdi,word ptr [rsi+28]
       cmp       r14d,edi
       jne       near ptr M01_L12
       cmp       qword ptr [rsi],0
       jne       near ptr M01_L13
M01_L03:
       xor       r12d,r12d
M01_L04:
       mov       eax,r12d
       jmp       short M01_L00
M01_L05:
       test      dword ptr [rax+34],1600000
       jne       short M01_L01
       jmp       near ptr M01_L15
M01_L06:
       mov       [rbp-50],rbx
       lea       rdi,[rbx+40]
       movsx     rsi,word ptr [rdi+28]
       cmp       r14d,esi
       jne       short M01_L07
       cmp       byte ptr [rdi+2A],0
       je        short M01_L07
       cmp       qword ptr [rdi+18],0
       jne       short M01_L07
       mov       r15,[rdi+20]
       jmp       short M01_L08
M01_L07:
       call      qword ptr [7FB9780665C8]
       int       3
M01_L08:
       lea       r13,[rbx+40]
       inc       esi
       mov       [r13+28],si
       xor       edi,edi
       mov       [r13],rdi
       mov       [r13+8],rdi
       mov       [r13+10],rdi
       mov       [r13+18],rdi
       mov       [r13+20],rdi
       mov       byte ptr [r13+2A],0
       mov       rdi,[rbx+8]
       lea       rdi,[rdi+20]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M01_L11
M01_L09:
       mov       edi,[r13+34]
       and       edi,11000000
       cmp       edi,1000000
       jne       near ptr M01_L16
M01_L10:
       mov       r15d,[r13+38]
M01_L11:
       mov       eax,r15d
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M01_L12:
       call      qword ptr [7FB978066550]
       int       3
M01_L13:
       cmp       byte ptr [rsi+2A],0
       je        near ptr M01_L03
       cmp       qword ptr [rsi+18],0
       je        short M01_L14
       mov       rsi,[rsi+18]
       mov       rsi,[rsi+8]
       mov       rdi,offset MT_System.OperationCanceledException
       call      qword ptr [7FB977026838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r12d,3
       mov       ecx,2
       test      rax,rax
       cmove     r12d,ecx
       jmp       near ptr M01_L04
M01_L14:
       mov       r12d,1
       jmp       near ptr M01_L04
M01_L15:
       mov       [rbp-48],rbx
       mov       [rbp-40],r15d
       mov       [rbp-3C],r14w
       call      qword ptr [7FB977FDFBB8]
       mov       rdi,rax
       mov       rsi,[rbp-48]
       mov       rdx,[rbp-40]
       cmp       [rdi],edi
       call      qword ptr [7FB977FDFB88]
       jmp       near ptr M01_L01
M01_L16:
       mov       rdi,r13
       xor       esi,esi
       call      qword ptr [7FB9780665B0]
       jmp       near ptr M01_L10
       push      rax
       mov       rsi,[rbp-50]
       lea       r13,[rsi+40]
       inc       word ptr [r13+28]
       xor       edi,edi
       mov       [r13],rdi
       mov       [r13+8],rdi
       mov       [r13+10],rdi
       mov       [r13+18],rdi
       mov       [r13+20],rdi
       mov       byte ptr [r13+2A],0
       mov       rdi,[rsi+8]
       lea       rdi,[rdi+20]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,8
       ret
; Total bytes of code 585
```
```assembly
; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,2B8
       vzeroupper
       lea       rbp,[rsp+2E0]
       xor       eax,eax
       mov       [rbp-228],rax
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFE20
M02_L00:
       vmovdqa   xmmword ptr [rbp+rax-40],xmm8
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       add       rax,30
       jne       short M02_L00
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-230],r8
       mov       r13,rsi
       mov       r14,rdx
       mov       rbx,rcx
       mov       r15,r9
       mov       r12,[rbp+20]
       mov       rax,7FB18D800BA0
       mov       rax,[rax]
       mov       rax,[rax+8]
       cmp       qword ptr [rax+8],0
       jne       near ptr M02_L26
       xor       edi,edi
M02_L01:
       mov       [rbp-40],rdi
       test      r12,r12
       jne       near ptr M02_L27
M02_L02:
       mov       rdi,7FB18D8013C0
       mov       rax,[rdi]
       mov       [rbp-250],rax
       cmp       byte ptr [rax+24],0
       jne       near ptr M02_L50
       cmp       dword ptr [rax+1C],0
       jne       near ptr M02_L80
M02_L03:
       mov       rax,[rbp-250]
       mov       rcx,[rax+10]
       mov       [rbp-298],rcx
       xor       edx,edx
       mov       [rbp-0AC],edx
       test      rcx,rcx
       je        near ptr M02_L81
       mov       rdi,7FB9F56A0D68
       mov       rsi,7FB9F5F04820
       call      rsi
       add       rax,40
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M02_L90
M02_L04:
       dec       eax
       mov       rcx,[rbp-298]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M02_L91
       and       r8d,eax
M02_L05:
       mov       rdi,[rcx+8]
       cmp       r8d,[rdi+8]
       jae       near ptr M02_L125
       mov       [rbp-0C0],r8d
       mov       edx,r8d
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-2A8],rax
       mov       r9,[rax+50]
       mov       [rbp-2B0],r9
       test      r9,r9
       je        near ptr M02_L92
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M02_L118
       mov       rdx,r9
       xor       esi,esi
       call      00007FB9F5474060
       mov       rdx,[rbp-2B0]
       cmp       rax,rdx
       mov       rax,[rbp-2A8]
       jne       near ptr M02_L92
       mov       [rbp-0B8],rdx
       mov       eax,[rbp-0AC]
       mov       rcx,[rbp-250]
M02_L06:
       mov       rdx,[rbp-0B8]
       cmp       qword ptr [rbp-0B8],0
       je        near ptr M02_L93
M02_L07:
       mov       rax,rdx
M02_L08:
       xor       edi,edi
       mov       [rbp-0B8],rdi
       cmp       dword ptr [rcx+1C],0
       jne       near ptr M02_L96
       mov       rdx,rax
M02_L09:
       mov       [rbp-248],rdx
       lea       rdi,[rdx+68]
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       xor       edi,edi
       mov       r12,[rbp-248]
       mov       [r12+60],edi
       lea       rdi,[r12+38]
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r12+30]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       mov       rsi,0FFFFFFFF00000000
       mov       [r12+58],rsi
       xor       esi,esi
       mov       [r12+40],rsi
       mov       [rbp-238],r12
       jmp       short M02_L11
M02_L10:
       mov       rdi,7FB97603B200
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M02_L10
       jmp       near ptr M02_L82
M02_L11:
       mov       rdx,[r12+8]
       mov       rsi,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       cmp       [r15+18],rsi
       je        short M02_L12
       mov       rsi,[rbp-230]
       mov       rdi,[r15+8]
       call      qword ptr [r15+18]
       nop
M02_L12:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M02_L24
M02_L13:
       lea       rdi,[rbp-60]
       mov       rdx,r13
       mov       rcx,[rbp-230]
       mov       r8,[rbp+10]
       mov       r9,r12
       call      qword ptr [7FB977ABE790]; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       rbx,[rbp-60]
       test      rbx,rbx
       jne       near ptr M02_L97
       mov       r14,[rbp-50]
       mov       r15d,[rbp-48]
M02_L14:
       test      r14,r14
       sete      bl
       movzx     ebx,bl
       mov       r13,[r12+30]
       cmp       qword ptr [rbp-40],0
       jne       near ptr M02_L102
M02_L15:
       mov       rsi,[r12+30]
       mov       rdi,7FB18D800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M02_L103
M02_L16:
       cmp       byte ptr [r12+64],0
       jne       near ptr M02_L104
       mov       rbx,[r12+8]
M02_L17:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rax,[rsi+28]
       test      rax,rax
       je        near ptr M02_L25
       mov       rdi,rax
M02_L18:
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-230]
       mov       rcx,rbx
       call      qword ptr [7FB977ABE880]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,7FB18D8013C0
       mov       rbx,[rdi]
       cmp       byte ptr [rbx+24],0
       jne       near ptr M02_L105
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M02_L106
       mov       rdi,rbx
       mov       rsi,r12
       call      qword ptr [7FB977FD7450]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItemGuarded(System.__Canon)
       test      eax,eax
       je        near ptr M02_L107
       mov       r12,[rbx+10]
       test      r12,r12
       je        near ptr M02_L113
       mov       rdi,7FB9F56A0D68
       mov       rax,7FB9F5F04820
       call      rax
       add       rax,40
       mov       r13d,[rax+10]
       test      r13d,r13d
       je        near ptr M02_L108
M02_L19:
       dec       r13d
       mov       eax,[r12+18]
       test      eax,eax
       jl        near ptr M02_L109
       and       r13d,eax
M02_L20:
       xor       eax,eax
       mov       [rbp-1EC],eax
       mov       rdi,[r12+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M02_L112
M02_L21:
       mov       rdi,[r12+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M02_L125
       mov       esi,r13d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-2C0],rcx
       cmp       qword ptr [rcx+50],0
       jne       near ptr M02_L110
       lea       rdi,[rcx+50]
       test      rdi,rdi
       je        near ptr M02_L118
       mov       rsi,[rbp-238]
       xor       edx,edx
       call      00007FB9F5474060
       test      rax,rax
       mov       rcx,[rbp-2C0]
       jne       near ptr M02_L110
M02_L22:
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M02_L120
M02_L23:
       test      r14,r14
       jne       near ptr M02_L121
       xor       eax,eax
       mov       edx,r15d
       mov       rdi,1000000000000
       or        rdx,rdi
       add       rsp,2B8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L24:
       mov       rsi,7FB977EC3E30
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M02_L13
M02_L25:
       mov       rsi,7FB977EC4208
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M02_L18
M02_L26:
       call      00007FB977018AE0
       mov       rdi,rax
       jmp       near ptr M02_L01
M02_L27:
       cmp       dword ptr [r12+20],0
       je        near ptr M02_L02
       mov       rsi,rbx
       xor       edx,edx
       call      qword ptr [7FB977ABE988]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       cmp       qword ptr [rbp+18],0
       je        near ptr M02_L49
       mov       rdi,r12
       mov       rcx,rbx
       mov       rdx,r14
       xor       esi,esi
       call      qword ptr [7FB977ABE9A0]; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       mov       rbx,rax
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       r15,[rsi+28]
       test      r15,r15
       je        short M02_L28
       jmp       short M02_L29
M02_L28:
       mov       rsi,7FB977EC4208
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r15,rax
M02_L29:
       mov       rdi,rbx
       cmp       [rdi],edi
       call      qword ptr [7FB977ABE9B8]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       rcx,rax
       mov       rdi,r15
       mov       rdx,[rbp-230]
       mov       rsi,[rbp+18]
       call      qword ptr [7FB977ABE880]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,7FB18D8013C0
       mov       r15,[rdi]
       cmp       byte ptr [r15+24],0
       je        short M02_L30
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7FB977FD73F0]
       jmp       near ptr M02_L49
M02_L30:
       cmp       dword ptr [r15+1C],0
       je        short M02_L31
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7FB976040520
       call      qword ptr [r11]
       jmp       near ptr M02_L49
M02_L31:
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7FB977FD7450]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItemGuarded(System.__Canon)
       test      eax,eax
       jne       short M02_L32
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7FB976040528
       call      qword ptr [r11]
       jmp       near ptr M02_L49
M02_L32:
       mov       r14,[r15+10]
       test      r14,r14
       je        near ptr M02_L43
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M02_L34
M02_L33:
       mov       rdi,7FB97603B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M02_L33
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M02_L34:
       dec       r13d
       cmp       dword ptr [r14+18],0
       jl        short M02_L35
       and       r13d,[r14+18]
       jmp       short M02_L36
M02_L35:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r14+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
M02_L36:
       xor       eax,eax
       jmp       short M02_L40
M02_L37:
       mov       rdi,[r14+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M02_L125
       mov       esi,r13d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-240],rcx
       cmp       qword ptr [rcx+50],0
       jne       short M02_L38
       lea       rdi,[rcx+50]
       test      rdi,rdi
       je        near ptr M02_L118
       mov       rsi,rbx
       xor       edx,edx
       call      00007FB9F5474060
       test      rax,rax
       mov       rcx,[rbp-240]
       je        short M02_L41
M02_L38:
       mov       rdx,rbx
       mov       rsi,rcx
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7FB977ABE058]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M02_L41
       inc       r13d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r13d
       jne       short M02_L39
       xor       r13d,r13d
M02_L39:
       mov       eax,[rbp-94]
       inc       eax
M02_L40:
       mov       rdi,[r14+8]
       mov       [rbp-94],eax
       cmp       [rdi+8],eax
       jg        near ptr M02_L37
       jmp       short M02_L42
M02_L41:
       cmp       dword ptr [r15+1C],0
       je        near ptr M02_L49
       jmp       near ptr M02_L48
M02_L42:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7FB976040530
       call      qword ptr [r11]
       jmp       short M02_L41
M02_L43:
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L45
M02_L44:
       mov       rdi,7FB97603B200
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M02_L44
       mov       [rax+10],edi
M02_L45:
       dec       edi
       imul      r14d,edi,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M02_L46
       mov       r13d,r14d
       mov       r14d,[r15+20]
       imul      r14,r13
       shr       r14,20
       jmp       short M02_L47
M02_L46:
       and       r14d,[r15+18]
M02_L47:
       mov       rdi,[r15+8]
       lea       esi,[r14*8+8]
       cmp       esi,[rdi+8]
       jae       near ptr M02_L125
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       je        near ptr M02_L118
       mov       rsi,rbx
       call      00007FB9F5474040
       test      rax,rax
       je        near ptr M02_L41
       mov       rdi,r15
       mov       rsi,rbx
       mov       rdx,rax
       mov       ecx,r14d
       call      qword ptr [7FB977FD7660]
       jmp       near ptr M02_L41
M02_L48:
       mov       rdi,r15
       call      qword ptr [7FB977FD7690]
M02_L49:
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rdi,rbx
       call      qword ptr [7FB978067030]
       lea       rdi,[rbx+70]
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,rbx
       call      qword ptr [7FB977ABEA00]
       mov       rdi,rax
       mov       esi,edx
       call      qword ptr [7FB977ABE910]
       mov       [rbp-218],rax
       mov       [rbp-210],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-218]
       vmovdqu   xmmword ptr [rbp-90],xmm0
       mov       rax,[rbp-90]
       mov       rdx,[rbp-88]
       add       rsp,2B8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L50:
       cmp       dword ptr [rax+1C],0
       je        short M02_L51
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7FB977FD68F8]
M02_L51:
       mov       rax,[rbp-250]
       lea       rdi,[rax+28]
       mov       rsi,[rdi]
       test      rsi,rsi
       jne       short M02_L52
       mov       rsi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7FB978066BF8]
       mov       rsi,rax
M02_L52:
       mov       rdi,rsi
       cmp       [rdi],edi
       call      qword ptr [7FB978066C10]
       mov       [rbp-258],rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7FB977025728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       cmp       byte ptr [7FB97603B208],0
       je        short M02_L56
       mov       rax,[rbp-258]
       mov       edx,[rax+68]
       mov       rcx,[rax+58]
       test      rcx,rcx
       je        near ptr M02_L59
       xor       esi,esi
       mov       [rax+58],rsi
       cmp       [rax+68],edx
       jne       short M02_L53
       test      dl,1
       je        short M02_L54
M02_L53:
       mov       rdx,rcx
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7FB978066C28]
       mov       rcx,rax
       mov       rax,rcx
       test      rax,rax
       mov       rcx,rax
       je        short M02_L55
M02_L54:
       mov       rax,rcx
       jmp       near ptr M02_L77
M02_L55:
       mov       rax,[rbp-258]
       jmp       short M02_L59
M02_L56:
       mov       rcx,[rbp-258]
       cmp       qword ptr [rcx+58],0
       je        short M02_L57
       lea       rdi,[rcx+58]
       test      rdi,rdi
       jne       short M02_L58
       jmp       near ptr M02_L118
M02_L57:
       mov       rax,rcx
       jmp       short M02_L59
M02_L58:
       xor       esi,esi
       call      00007FB9F5474040
       test      rax,rax
       mov       rcx,rax
       jne       short M02_L54
       mov       rax,[rbp-258]
M02_L59:
       cmp       byte ptr [rax+6C],0
       jne       short M02_L60
       mov       byte ptr [rax+6C],1
M02_L60:
       mov       rax,[rbp-250]
       mov       rcx,[rax+10]
       mov       [rbp-268],rcx
       xor       edx,edx
       mov       [rbp-98],edx
       test      rcx,rcx
       jne       near ptr M02_L68
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L62
M02_L61:
       mov       rdi,7FB97603B200
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M02_L61
       mov       [rax+10],edi
M02_L62:
       dec       edi
       imul      edi,9E3779B9
       mov       rax,[rbp-250]
       cmp       dword ptr [rax+18],0
       jge       short M02_L63
       mov       edx,edi
       mov       esi,[rax+20]
       imul      rdx,rsi
       shr       rdx,20
       jmp       short M02_L64
M02_L63:
       and       edi,[rax+18]
       mov       edx,edi
M02_L64:
       mov       ecx,edx
       mov       rdi,[rax+8]
       mov       [rbp-98],ecx
       lea       edx,[rcx*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M02_L125
       lea       rdi,[rdi+rdx*8+10]
       mov       r8,[rdi]
       mov       [rbp-270],r8
       test      r8,r8
       je        short M02_L65
       mov       rdx,r8
       xor       esi,esi
       call      00007FB9F5474060
       mov       rdi,[rbp-270]
       cmp       rax,rdi
       je        short M02_L66
M02_L65:
       xor       esi,esi
       jmp       short M02_L67
M02_L66:
       mov       rsi,rdi
M02_L67:
       mov       [rbp-0A0],rsi
       jmp       near ptr M02_L74
M02_L68:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M02_L70
M02_L69:
       mov       rax,7FB97603B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-0A4],eax
       test      eax,eax
       je        short M02_L69
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-0A4]
       mov       [rax+10],ecx
       mov       eax,ecx
M02_L70:
       dec       eax
       mov       rcx,[rbp-268]
       cmp       dword ptr [rcx+18],0
       jl        short M02_L71
       mov       r8d,eax
       and       r8d,[rcx+18]
       jmp       short M02_L72
M02_L71:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
M02_L72:
       mov       rdi,[rcx+8]
       cmp       r8d,[rdi+8]
       jae       near ptr M02_L125
       mov       [rbp-0A8],r8d
       mov       edx,r8d
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-278],rax
       mov       r9,[rax+50]
       mov       [rbp-280],r9
       test      r9,r9
       je        short M02_L73
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M02_L118
       mov       rdx,r9
       xor       esi,esi
       call      00007FB9F5474060
       mov       rdx,[rbp-280]
       cmp       rax,rdx
       mov       rax,[rbp-278]
       jne       short M02_L73
       mov       [rbp-0A0],rdx
       jmp       short M02_L74
M02_L73:
       lea       rdx,[rbp-0A0]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7FB977ABDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M02_L74
       lea       rdx,[rbp-0A0]
       mov       rdi,[rbp-268]
       mov       esi,[rbp-0A8]
       call      qword ptr [7FB977ABDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M02_L74:
       mov       rax,[rbp-0A0]
       cmp       qword ptr [rbp-0A0],0
       jne       short M02_L76
       cmp       qword ptr [rbp-268],0
       je        short M02_L75
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-288],rax
       mov       rdi,rax
       call      qword ptr [7FB977FD69A0]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-288]
       jmp       short M02_L76
M02_L75:
       mov       rdi,[rbp-250]
       mov       esi,[rbp-98]
       call      qword ptr [7FB977FD6958]
M02_L76:
       xor       edi,edi
       mov       [rbp-0A0],rdi
M02_L77:
       mov       rcx,[rbp-250]
       cmp       dword ptr [rcx+1C],0
       jne       short M02_L78
       jmp       short M02_L79
M02_L78:
       mov       [rbp-260],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-250]
       mov       dil,[rdi+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-260]
       mov       r11,7FB976040538
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7FB977FD68F8]
M02_L79:
       mov       rdx,rax
       jmp       near ptr M02_L09
M02_L80:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7FB977FD68F8]
       jmp       near ptr M02_L03
M02_L81:
       mov       rdi,7FB9F56A0D68
       mov       rdx,7FB9F5F04820
       call      rdx
       add       rax,30
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L83
       jmp       near ptr M02_L10
M02_L82:
       mov       [rax+10],edi
M02_L83:
       dec       edi
       imul      edi,9E3779B9
       mov       rcx,[rbp-250]
       mov       edx,[rcx+18]
       test      edx,edx
       jge       short M02_L84
       mov       edx,edi
       mov       esi,[rcx+20]
       imul      rdx,rsi
       shr       rdx,20
       jmp       short M02_L85
M02_L84:
       and       edx,edi
M02_L85:
       mov       eax,edx
       mov       rdi,[rcx+8]
       mov       [rbp-0AC],eax
       lea       edx,[rax*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M02_L125
       lea       rdi,[rdi+rdx*8+10]
       mov       r8,[rdi]
       mov       [rbp-2A0],r8
       test      r8,r8
       je        short M02_L87
       mov       rdx,r8
       xor       esi,esi
       call      00007FB9F5474060
       mov       rdi,[rbp-2A0]
       cmp       rax,rdi
       mov       eax,[rbp-0AC]
       mov       rcx,[rbp-250]
       je        short M02_L88
M02_L86:
       xor       esi,esi
       jmp       short M02_L89
M02_L87:
       mov       eax,[rbp-0AC]
       mov       rcx,[rbp-250]
       jmp       short M02_L86
M02_L88:
       mov       r8,rdi
       mov       rsi,r8
M02_L89:
       mov       [rbp-0B8],rsi
       jmp       near ptr M02_L06
M02_L90:
       mov       rax,7FB97603B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-0BC],eax
       test      eax,eax
       je        short M02_L90
       mov       rdi,7FB9F56A0D68
       mov       rcx,7FB9F5F04820
       call      rcx
       add       rax,40
       mov       ecx,[rbp-0BC]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M02_L04
M02_L91:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M02_L05
M02_L92:
       lea       rdx,[rbp-0B8]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7FB977ABDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M02_L94
       lea       rdx,[rbp-0B8]
       mov       rdi,[rbp-298]
       mov       esi,[rbp-0C0]
       call      qword ptr [7FB977ABDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       mov       eax,[rbp-0AC]
       mov       rcx,[rbp-250]
       jmp       near ptr M02_L06
M02_L93:
       cmp       qword ptr [rbp-298],0
       je        short M02_L95
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-2B8],rax
       mov       rdi,rax
       call      qword ptr [7FB977FD69A0]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-2B8]
       mov       rcx,[rbp-250]
       jmp       near ptr M02_L08
M02_L94:
       mov       eax,[rbp-0AC]
       mov       rcx,[rbp-250]
       jmp       near ptr M02_L06
M02_L95:
       mov       rdi,rcx
       mov       esi,eax
       call      qword ptr [7FB977FD6958]
       mov       rdx,rax
       mov       rcx,[rbp-250]
       jmp       near ptr M02_L07
M02_L96:
       mov       [rbp-290],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rcx,[rbp-250]
       mov       dil,[rcx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-290]
       mov       r11,7FB976040540
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7FB977FD68F8]
       mov       rdx,rax
       jmp       near ptr M02_L09
M02_L97:
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7FB977026838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       test      rax,rax
       je        short M02_L98
       mov       rdi,rax
       call      qword ptr [7FB977FD7270]
       jmp       short M02_L99
M02_L98:
       mov       rdi,rbx
       movsx     rsi,word ptr [rbp-58]
       mov       r11,7FB976040548
       call      qword ptr [r11]
       cmp       eax,1
       sete      al
       movzx     eax,al
M02_L99:
       test      eax,eax
       je        near ptr M02_L122
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7FB977026838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r15,rax
       test      r15,r15
       je        short M02_L101
       mov       edi,[r15+34]
       and       edi,11000000
       cmp       edi,1000000
       je        short M02_L100
       mov       rdi,r15
       xor       esi,esi
       call      qword ptr [7FB9780665B0]
M02_L100:
       mov       r14,[r15+38]
       mov       r15d,[r15+40]
       jmp       near ptr M02_L14
M02_L101:
       mov       rdi,rbx
       movsx     rsi,word ptr [rbp-58]
       mov       r11,7FB976040550
       call      qword ptr [r11]
       mov       r14,rax
       mov       r15d,edx
       jmp       near ptr M02_L14
M02_L102:
       mov       rdi,7FB18D800BA0
       mov       rdi,[rdi]
       call      qword ptr [7FB977ABEAD8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M02_L15
       lea       rdi,[rbp-150]
       mov       rsi,r13
       call      qword ptr [7FB977FD7330]
       mov       rdx,7FB96CA0B6A8
       mov       rdi,7FB96CA0B680
       test      ebx,ebx
       cmove     rdx,rdi
       lea       rdi,[rbp-150]
       mov       rsi,7FB96CA0B638
       call      qword ptr [7FB977FD7348]
       call      00007FB977018AE0
       mov       rsi,rax
       mov       rdi,[rbp-40]
       call      qword ptr [7FB978067048]
       mov       [rbp-158],rax
       lea       rdi,[rbp-158]
       call      qword ptr [7FB977FD7378]
       mov       rdi,7FB18D800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-150]
       mov       rdx,r12
       call      qword ptr [7FB977FD7390]
       jmp       near ptr M02_L15
M02_L103:
       lea       rdi,[rbp-1E8]
       call      qword ptr [7FB977FD7330]
       mov       rdx,7FB96CA0B6A8
       mov       rdi,7FB96CA0B680
       test      ebx,ebx
       cmove     rdx,rdi
       lea       rdi,[rbp-1E8]
       mov       rsi,7FB96CA0B638
       call      qword ptr [7FB977FD7348]
       mov       rdi,7FB18D800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-1E8]
       mov       rcx,r12
       mov       esi,1
       call      qword ptr [7FB977FD73A8]
       jmp       near ptr M02_L16
M02_L104:
       mov       rbx,[r12+10]
       jmp       near ptr M02_L17
M02_L105:
       mov       rdi,rbx
       mov       rsi,r12
       call      qword ptr [7FB977FD73F0]
       jmp       near ptr M02_L23
M02_L106:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7FB976040558
       call      qword ptr [r11]
       jmp       near ptr M02_L23
M02_L107:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7FB976040560
       call      qword ptr [r11]
       jmp       near ptr M02_L23
M02_L108:
       mov       rdi,7FB97603B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M02_L108
       mov       rdi,7FB9F56A0D68
       mov       rax,7FB9F5F04820
       call      rax
       add       rax,40
       mov       [rax+10],r13d
       jmp       near ptr M02_L19
M02_L109:
       mov       rdi,[r12+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r12+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
       jmp       near ptr M02_L20
M02_L110:
       mov       rdx,[rbp-238]
       mov       rsi,rcx
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7FB977ABE058]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       near ptr M02_L22
       inc       r13d
       mov       rdi,[r12+8]
       cmp       [rdi+8],r13d
       jne       short M02_L111
       xor       r13d,r13d
M02_L111:
       mov       eax,[rbp-1EC]
       inc       eax
       mov       rdi,[r12+8]
       cmp       [rdi+8],eax
       mov       [rbp-1EC],eax
       jg        near ptr M02_L21
M02_L112:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-238]
       mov       r11,7FB976040568
       call      qword ptr [r11]
       jmp       near ptr M02_L22
M02_L113:
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L115
M02_L114:
       mov       rdi,7FB97603B200
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M02_L114
       mov       [rax+10],edi
M02_L115:
       dec       edi
       imul      r13d,edi,9E3779B9
       cmp       dword ptr [rbx+18],0
       jge       short M02_L116
       mov       r12d,r13d
       mov       r13d,[rbx+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M02_L117
M02_L116:
       and       r13d,[rbx+18]
M02_L117:
       mov       rdi,[rbx+8]
       lea       esi,[r13*8+8]
       cmp       esi,[rdi+8]
       jae       near ptr M02_L125
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M02_L119
M02_L118:
       call      qword ptr [7FB9780664C0]
       int       3
M02_L119:
       mov       rsi,[rbp-238]
       call      00007FB9F5474040
       test      rax,rax
       je        near ptr M02_L22
       mov       rdi,rbx
       mov       rsi,[rbp-238]
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7FB977FD7660]
       jmp       near ptr M02_L22
M02_L120:
       mov       rdi,rbx
       call      qword ptr [7FB977FD7690]
       jmp       near ptr M02_L23
M02_L121:
       mov       rdi,r14
       mov       esi,r15d
       call      qword ptr [7FB977ABE910]
       mov       [rbp-228],rax
       mov       [rbp-220],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-228]
       vmovdqu   xmmword ptr [rbp-80],xmm0
       mov       rax,[rbp-80]
       mov       rdx,[rbp-78]
       add       rsp,2B8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L122:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rax,[rsi+20]
       test      rax,rax
       je        short M02_L123
       mov       rdi,rax
       jmp       short M02_L124
M02_L123:
       mov       rsi,7FB977EC3FC8
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M02_L124:
       mov       [rbp-208],rdi
       lea       rdi,[rsp]
       lea       rsi,[rbp-60]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,[rbp-208]
       mov       rsi,r12
       mov       rdx,[rbp-230]
       mov       rcx,[rbp+18]
       mov       r8,[rbp-40]
       call      qword ptr [7FB977ABE838]
       mov       [rbp-200],rax
       mov       [rbp-1F8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-200]
       vmovdqu   xmmword ptr [rbp-70],xmm0
       mov       rax,[rbp-70]
       mov       rdx,[rbp-68]
       add       rsp,2B8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L125:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
       sub       rsp,28
       vzeroupper
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-238]
       xor       edx,edx
       call      qword ptr [7FB977ABEA78]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       r13,[rsi+28]
       test      r13,r13
       je        short M02_L126
       jmp       short M02_L127
M02_L126:
       mov       rsi,7FB977EC4208
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r13,rax
M02_L127:
       mov       rdi,[rbp-238]
       cmp       [rdi],edi
       call      qword ptr [7FB977ABE9B8]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       rcx,rax
       mov       rdi,r13
       mov       rdx,[rbp-230]
       mov       rsi,[rbp+18]
       call      qword ptr [7FB977ABE880]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-238]
       call      qword ptr [7FB977ABE9D0]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 4935
```
```assembly
; PoolContextProbe+<>c.<SingleContext>b__5_0(Kevlar.KevlarContext)
       xor       eax,eax
       mov       rdx,100000000002A
       ret
; Total bytes of code 13
```
```assembly
; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       push      r15
       push      r14
       push      rbx
       mov       rbx,rdi
       mov       r15,rsi
       mov       r14,rdx
       test      r15,r15
       je        short M04_L00
       mov       rdi,7FB9780D73F4
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdi,[rbx+8]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       [rbx+18],r14
       pop       rbx
       pop       r14
       pop       r15
       ret
M04_L00:
       mov       rdi,7FB9780D73F0
       call      CORINFO_HELP_COUNTPROFILE32
       call      qword ptr [7FB97806E418]
       int       3
; Total bytes of code 78
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       ret
; Total bytes of code 1
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       rcx,rsi
       mov       rsi,rdx
       mov       rax,offset PoolContextProbe+<>c.<SingleContext>b__5_0(Kevlar.KevlarContext)
       cmp       [rcx+18],rax
       jne       short M06_L00
       xor       eax,eax
       mov       rdx,100000000002A
       ret
M06_L00:
       mov       rdi,[rcx+8]
       jmp       qword ptr [rcx+18]
; Total bytes of code 43
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
M07_L00:
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,58
       lea       rbp,[rsp+80]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       mov       [rbp-30],rsi
       mov       rbx,rsi
       mov       r13,rdx
       mov       r15,rcx
       mov       r14,r8
       mov       r12,r9
       test      r15,r15
       je        near ptr M07_L06
       test      r14,r14
       je        near ptr M07_L07
       mov       rax,[rdi+38]
       test      rax,rax
       jne       near ptr M07_L08
       cmp       byte ptr [rdi+48],0
       jne       near ptr M07_L09
       mov       rax,[rdi+10]
       mov       [rbp-58],rax
       xor       ecx,ecx
       test      rcx,rcx
       cmove     rcx,rdi
       mov       rcx,[rcx+20]
       mov       rdx,7FB18D800B00
       test      rcx,rcx
       cmove     rcx,[rdx]
       mov       [rbp-60],rcx
       mov       rdx,[rdi+38]
       test      rdx,rdx
       jne       near ptr M07_L10
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rdi+40]
M07_L01:
       mov       rdi,[rbx+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        short M07_L04
M07_L02:
       mov       rdx,[rdi+18]
       mov       rdx,[rdx+18]
       test      rdx,rdx
       je        near ptr M07_L05
       mov       rdi,rdx
       mov       [rbp-68],rsi
M07_L03:
       mov       [rsp],r14
       xor       edx,edx
       mov       [rsp+8],rdx
       mov       [rsp+10],r12
       mov       rsi,rax
       mov       rdx,rcx
       mov       rcx,[rbp-68]
       mov       r8,r13
       mov       r9,r15
       call      qword ptr [7FB977ABE6B8]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       mov       [rbp-50],rax
       mov       [rbp-48],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-50]
       vmovdqu   xmmword ptr [rbp-40],xmm0
       mov       rax,[rbp-40]
       mov       rdx,[rbp-38]
       add       rsp,58
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M07_L04:
       mov       [rbp-60],rcx
       mov       [rbp-68],rsi
       mov       rdi,rbx
       mov       rsi,7FB977EC35E0
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rbp-68]
       jmp       near ptr M07_L02
M07_L05:
       mov       [rbp-60],rcx
       mov       [rbp-68],rsi
       mov       rsi,7FB977EC3998
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       jmp       near ptr M07_L03
M07_L06:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,92C
       mov       rsi,7FB977AEE0F0
       call      qword ptr [7FB97702EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7FB97770E2E0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M07_L07:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,902
       mov       rsi,7FB977AEE0F0
       call      qword ptr [7FB97702EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7FB97770E2E0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M07_L08:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       rsi,rbx
       mov       rdx,r13
       mov       rcx,r15
       mov       r8,r14
       mov       r9,r12
       cmp       [rdi],edi
       add       rsp,58
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7FB977ABE460]
M07_L09:
       call      qword ptr [7FB977ABE628]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M07_L10:
       mov       rdi,[rdx+8]
       call      qword ptr [rdx+18]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FB977ABE610]; Kevlar.Shield.get_Name()
       mov       [rbp-68],rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rbp-68]
       jmp       near ptr M07_L01
; Total bytes of code 583
```
```assembly
; Kevlar.Shield.get_Name()
       push      rbp
       mov       rbp,rsp
M08_L00:
       mov       rax,[rdi+38]
       test      rax,rax
       jne       short M08_L01
       mov       rax,[rdi+40]
       pop       rbp
       ret
M08_L01:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       jmp       short M08_L00
; Total bytes of code 31
```
```assembly
; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       push      rbp
       mov       rbp,rsp
       test      rsi,rsi
       je        short M09_L02
       mov       rax,[rsi]
       cmp       rax,rdi
       je        short M09_L02
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
M09_L00:
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       jne       short M09_L03
M09_L01:
       xor       esi,esi
M09_L02:
       mov       rax,rsi
       pop       rbp
       ret
M09_L03:
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       jmp       short M09_L00
; Total bytes of code 91
```
```assembly
; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,128
       lea       rbp,[rsp+150]
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFF10
M10_L00:
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       add       rax,30
       jne       short M10_L00
       mov       [rbp-30],rsi
       mov       [rbp-128],r8
       mov       rbx,rdi
       mov       r15,rsi
       mov       r13,rdx
       mov       r12,rcx
       mov       r14,r9
       mov       rdi,[r15+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M10_L19
M10_L01:
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rax+8]
       test      rax,rax
       je        near ptr M10_L24
M10_L02:
       mov       [rbp-50],r13
       mov       [rbp-48],rax
       mov       [rbp-40],r12
       mov       r13,[rbp-128]
       mov       [rbp-38],r13
       mov       rdi,[r15+18]
       mov       rdx,[rdi+28]
       test      rdx,rdx
       je        near ptr M10_L20
M10_L03:
       mov       rax,[rbp-48]
       test      rax,rax
       je        near ptr M10_L31
       cmp       qword ptr [rbp-50],0
       jne       near ptr M10_L36
       mov       rdi,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       cmp       [rax+18],rdi
       jne       near ptr M10_L35
       mov       rdi,[rax+8]
       mov       r15,[rbp-40]
       mov       r13,[rbp-38]
       mov       rdi,[rdi]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M10_L21
M10_L04:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0B0],xmm0
       vmovdqu   xmmword ptr [rbp-0A8],xmm0
       mov       [rbp-98],r15
       mov       [rbp-90],r13
       mov       [rbp-0C0],r14
       mov       dword ptr [rbp-0B8],0FFFFFFFF
       mov       rdi,[rsi+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M10_L22
M10_L05:
       mov       rsi,[rdi+18]
       mov       r14,[rsi+10]
       test      r14,r14
       je        near ptr M10_L23
M10_L06:
       mov       rdi,7FB9F56A0D68
       mov       rax,7FB9F5F04820
       call      rax
       cmp       dword ptr [rax],4
       jle       near ptr M10_L32
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        near ptr M10_L32
M10_L07:
       mov       r15,[rax+10]
       test      r15,r15
       jne       short M10_L08
       call      qword ptr [7FB97770C420]; System.Threading.Thread.InitializeCurrentThread()
       mov       r15,rax
M10_L08:
       mov       [rbp-138],r15
       mov       rsi,[r15+8]
       mov       [rbp-140],rsi
       mov       rsi,[r15+10]
       mov       [rbp-148],rsi
       mov       rdi,[r14+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M10_L10
M10_L09:
       lea       rdi,[rbp-0C0]
       call      rax
       jmp       short M10_L11
M10_L10:
       mov       rdi,r14
       mov       rsi,7FB977FB82A0
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M10_L09
M10_L11:
       mov       rsi,[rbp-148]
       cmp       rsi,[r15+10]
       je        short M10_L12
       lea       rdi,[r15+10]
       call      CORINFO_HELP_ASSIGN_REF
M10_L12:
       mov       rdi,[r15+8]
       mov       r14,rdi
       mov       rsi,[rbp-140]
       cmp       rsi,r14
       je        short M10_L14
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      r14,r14
       je        short M10_L13
       cmp       qword ptr [r14+10],0
       jne       near ptr M10_L18
M10_L13:
       cmp       qword ptr [rbp-140],0
       jne       near ptr M10_L17
M10_L14:
       mov       rdi,[rbp-0B0]
       mov       rax,7FB18D8013E8
       cmp       rdi,[rax]
       jne       near ptr M10_L33
       vmovdqu   xmm0,xmmword ptr [rbp-0A8]
       vmovdqu   xmmword ptr [rbp-110],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-120]
       vmovdqu   ymmword ptr [rbp-0E0],ymm0
       xor       r15d,r15d
M10_L15:
       vmovdqu   ymm0,ymmword ptr [rbp-0E0]
       vmovdqu   ymmword ptr [rbp-78],ymm0
       xor       r14d,r14d
       mov       r13d,1
M10_L16:
       mov       [rbp-78],r15
       vmovdqu   ymm0,ymmword ptr [rbp-78]
       vmovdqu   ymmword ptr [rbx],ymm0
       mov       [rbx+8],r14w
       mov       [rbx+0A],r13b
       mov       rax,rbx
       vzeroupper
       add       rsp,128
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M10_L17:
       mov       rsi,[rbp-140]
       cmp       qword ptr [rsi+10],0
       je        near ptr M10_L14
M10_L18:
       mov       rdi,r14
       mov       rsi,[rbp-140]
       call      qword ptr [7FB978067270]
       jmp       near ptr M10_L14
M10_L19:
       mov       rdi,r15
       mov       rsi,7FB977FB6958
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M10_L01
M10_L20:
       mov       rdi,r15
       mov       rsi,7FB977FB6A70
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdx,rax
       jmp       near ptr M10_L03
M10_L21:
       mov       rsi,7FB977FB7240
       call      qword ptr [7FB97702F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M10_L04
M10_L22:
       mov       rdi,rsi
       mov       rsi,7FB977FB7EB8
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M10_L05
M10_L23:
       mov       rsi,7FB977FB8118
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r14,rax
       jmp       near ptr M10_L06
M10_L24:
       mov       rdi,[r15+18]
       mov       rax,[rdi+18]
       test      rax,rax
       je        short M10_L25
       mov       [rbp-58],rax
       jmp       short M10_L26
M10_L25:
       mov       rdi,r15
       mov       rsi,7FB977FB6958
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-58],rax
M10_L26:
       mov       rdi,[r15+18]
       mov       rdi,[rdi+30]
       test      rdi,rdi
       je        short M10_L27
       jmp       short M10_L28
M10_L27:
       mov       rdi,r15
       mov       rsi,7FB977FB6C50
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M10_L28:
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-130],rax
       mov       rdi,[rbp-58]
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rax]
       mov       rdi,[rbp-130]
       mov       rdx,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       call      qword ptr [7FB977026E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,[r15+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        short M10_L29
       jmp       short M10_L30
M10_L29:
       mov       rdi,r15
       mov       rsi,7FB977FB6958
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M10_L30:
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       lea       rdi,[rax+8]
       mov       rsi,[rbp-130]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-130]
       jmp       near ptr M10_L02
M10_L31:
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       mov       rsi,7FB96CA0B5D8
       call      qword ptr [7FB977705650]
       mov       rdi,r15
       call      qword ptr [7FB977ABEA00]
       xor       r15d,r15d
       xor       r14d,r14d
       mov       r13d,1
       mov       [rbp-68],rax
       mov       [rbp-60],edx
       jmp       near ptr M10_L16
M10_L32:
       mov       edi,4
       call      qword ptr [7FB9780665E0]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       near ptr M10_L07
M10_L33:
       mov       r15,[rbp-0B0]
       test      r15,r15
       jne       short M10_L34
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       call      qword ptr [7FB978067288]
       mov       [rbp-0B0],r15
M10_L34:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0F0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-100]
       vmovdqu   ymmword ptr [rbp-0E0],ymm0
       jmp       near ptr M10_L15
M10_L35:
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-38]
       lea       rsi,[rbp-78]
       mov       r8,r14
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       jmp       short M10_L37
M10_L36:
       lea       rdi,[rbp-50]
       lea       rsi,[rbp-78]
       mov       rcx,[rbp-50]
       mov       r8,r14
       call      qword ptr [7FB977FD6B68]
M10_L37:
       mov       r15,[rbp-78]
       movsx     r14,word ptr [rbp-70]
       movzx     r13d,byte ptr [rbp-6E]
       jmp       near ptr M10_L16
       push      rax
       mov       rsi,[rbp-148]
       mov       rax,[rbp-138]
       cmp       rsi,[rax+10]
       je        short M10_L38
       lea       rdi,[rax+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-138]
M10_L38:
       mov       rbx,[rax+8]
       mov       rsi,[rbp-140]
       cmp       rsi,rbx
       je        short M10_L41
       lea       rdi,[rax+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      rbx,rbx
       je        short M10_L39
       cmp       qword ptr [rbx+10],0
       jne       short M10_L40
M10_L39:
       cmp       qword ptr [rbp-140],0
       je        short M10_L41
       mov       rsi,[rbp-140]
       cmp       qword ptr [rsi+10],0
       je        short M10_L41
M10_L40:
       mov       rdi,rbx
       mov       rsi,[rbp-140]
       call      qword ptr [7FB978067270]
M10_L41:
       nop
       vzeroupper
       add       rsp,8
       ret
; Total bytes of code 1394
```
```assembly
; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       push      rbp
       mov       rbp,rsp
       mov       rax,rsi
       test      rax,rax
       je        short M11_L00
       mov       rsi,rdx
       mov       rdx,rcx
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       nop
M11_L00:
       pop       rbp
       ret
       push      rax
       lea       rax,[M11_L00]
       add       rsp,8
       ret
; Total bytes of code 41
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItemGuarded(System.__Canon)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,0B8
       lea       rbp,[rsp+0E0]
       xor       eax,eax
       mov       [rbp-68],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       vmovdqa   xmmword ptr [rbp-40],xmm8
       mov       [rbp-30],rdi
       mov       [rbp-78],rdi
       mov       [rbp-80],rsi
       cmp       [rdi],dil
       xor       eax,eax
       mov       [rsi+68],rax
       mov       [rsi+60],eax
       mov       [rsi+30],rax
       mov       rax,0FFFFFFFF00000000
       mov       [rsi+58],rax
       xor       eax,eax
       mov       [rsi+40],rax
       mov       [rsi+48],rax
       mov       [rsi+50],rax
       mov       rax,[rsi+28]
       test      rax,rax
       jne       near ptr M12_L07
M12_L00:
       mov       rax,7FB18D800B00
       mov       rsi,[rax]
       mov       rbx,[rbp-80]
       lea       rdi,[rbx+38]
       call      CORINFO_HELP_ASSIGN_REF
       mov       r15,[rbx+8]
       xor       edi,edi
       mov       [r15+20],rdi
       cmp       byte ptr [r15+34],0
       jne       near ptr M12_L08
M12_L01:
       mov       rdi,[r15+28]
       mov       rax,[r15+8]
       cmp       rdi,rax
       jne       near ptr M12_L09
       cmp       dword ptr [rax+8],1
       jne       near ptr M12_L10
M12_L02:
       mov       rdi,[r15+8]
       xor       eax,eax
       mov       [rdi+0C],eax
       mov       [rdi+10],eax
       mov       rdi,[rbx+8]
       cmp       [rdi],edi
       call      qword ptr [7FB977FD74E0]; Kevlar.KevlarProperties.Clear()
       cmp       qword ptr [rbx+10],0
       jne       near ptr M12_L59
M12_L03:
       mov       r15,[rbx+18]
       test      r15,r15
       je        short M12_L06
       cmp       byte ptr [r15+34],0
       jne       near ptr M12_L60
M12_L04:
       mov       rdi,[r15+28]
       mov       rax,[r15+8]
       cmp       rdi,rax
       jne       near ptr M12_L61
       cmp       dword ptr [rax+8],1
       jne       near ptr M12_L62
M12_L05:
       mov       rdi,[r15+8]
       cmp       [rdi],edi
       call      qword ptr [7FB977FD7558]; Kevlar.KevlarProperties+AdditionalAttemptState.Reset()
       mov       rdi,[rbx+18]
       cmp       [rdi],edi
       call      qword ptr [7FB977FD74E0]; Kevlar.KevlarProperties.Clear()
M12_L06:
       mov       word ptr [rbx+64],0
       jmp       near ptr M12_L112
M12_L07:
       mov       rdi,rax
       call      qword ptr [7FB9780006F8]
       jmp       near ptr M12_L00
M12_L08:
       mov       rdi,[r15+28]
       cmp       [rdi],edi
       call      qword ptr [7FB977FD74F8]
       mov       byte ptr [r15+34],0
       jmp       near ptr M12_L01
M12_L09:
       mov       rdi,[r15+28]
       call      qword ptr [7FB977FD7510]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       jmp       near ptr M12_L58
M12_L10:
       mov       rdi,[r15+8]
       call      qword ptr [7FB977FD7510]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7FB18D8013D0
       mov       r14,[rdi]
       cmp       byte ptr [r14+24],0
       je        near ptr M12_L37
       cmp       dword ptr [r14+1C],0
       je        short M12_L11
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7FB978066BE0]
M12_L11:
       lea       rdi,[r14+28]
       mov       rsi,[rdi]
       test      rsi,rsi
       jne       short M12_L12
       mov       rsi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7FB978066BF8]
       mov       rsi,rax
M12_L12:
       mov       rdi,rsi
       cmp       [rdi],edi
       call      qword ptr [7FB978066C10]
       mov       r13,rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7FB977025728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       cmp       byte ptr [7FB97603B1E8],0
       je        short M12_L15
       mov       edx,[r13+68]
       mov       rax,[r13+58]
       mov       r12,rax
       test      r12,r12
       je        short M12_L16
       xor       esi,esi
       mov       [r13+58],rsi
       cmp       [r13+68],edx
       jne       short M12_L13
       test      dl,1
       je        short M12_L14
M12_L13:
       mov       rdx,r12
       mov       rsi,r13
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7FB978066C28]
       mov       r12,rax
       test      r12,r12
       je        short M12_L16
M12_L14:
       jmp       near ptr M12_L34
M12_L15:
       cmp       qword ptr [r13+58],0
       je        short M12_L16
       lea       rdi,[r13+58]
       test      rdi,rdi
       je        near ptr M12_L95
       xor       esi,esi
       call      00007FB9F5474040
       mov       r12,rax
       test      r12,r12
       jne       short M12_L14
M12_L16:
       cmp       byte ptr [r13+6C],0
       jne       short M12_L17
       mov       byte ptr [r13+6C],1
M12_L17:
       mov       r12,[r14+10]
       xor       r13d,r13d
       test      r12,r12
       jne       near ptr M12_L24
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M12_L19
M12_L18:
       mov       rdi,7FB97603B1E0
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M12_L18
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M12_L19:
       dec       r13d
       imul      edi,r13d,9E3779B9
       cmp       dword ptr [r14+18],0
       jge       short M12_L20
       mov       r13d,edi
       mov       edx,[r14+20]
       imul      r13,rdx
       shr       r13,20
       jmp       short M12_L21
M12_L20:
       and       edi,[r14+18]
       mov       r13d,edi
M12_L21:
       mov       rdi,[r14+8]
       lea       edx,[r13*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M12_L108
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       [rbp-90],rax
       test      rax,rax
       je        short M12_L22
       mov       rdx,rax
       xor       esi,esi
       call      00007FB9F5474060
       mov       rdi,[rbp-90]
       cmp       rax,rdi
       je        short M12_L23
M12_L22:
       xor       edi,edi
M12_L23:
       mov       [rbp-38],rdi
       jmp       near ptr M12_L30
M12_L24:
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L26
M12_L25:
       mov       rax,7FB97603B1F0
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-3C],eax
       test      eax,eax
       je        short M12_L25
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-3C]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L26:
       dec       eax
       cmp       dword ptr [r12+18],0
       jl        short M12_L27
       mov       ecx,eax
       and       ecx,[r12+18]
       jmp       short M12_L28
M12_L27:
       mov       rcx,[r12+8]
       mov       edi,[rcx+8]
       mov       ecx,eax
       imul      rcx,[r12+10]
       shr       rcx,20
       inc       rcx
       imul      rcx,rdi
       shr       rcx,20
       mov       eax,ecx
       mov       ecx,eax
M12_L28:
       mov       rdi,[r12+8]
       cmp       ecx,[rdi+8]
       jae       near ptr M12_L108
       mov       [rbp-40],ecx
       mov       edx,ecx
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-98],rax
       mov       r8,[rax+50]
       mov       [rbp-0A0],r8
       test      r8,r8
       je        short M12_L29
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M12_L95
       mov       rdx,r8
       xor       esi,esi
       call      00007FB9F5474060
       mov       rdx,[rbp-0A0]
       cmp       rax,rdx
       mov       rax,[rbp-98]
       jne       short M12_L29
       mov       [rbp-38],rdx
       jmp       short M12_L30
M12_L29:
       lea       rdx,[rbp-38]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7FB977ABDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M12_L30
       lea       rdx,[rbp-38]
       mov       rdi,r12
       mov       esi,[rbp-40]
       call      qword ptr [7FB977ABDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M12_L30:
       mov       rax,[rbp-38]
       cmp       qword ptr [rbp-38],0
       jne       short M12_L32
       test      r12,r12
       je        short M12_L31
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       dword ptr [rax+8],1
       mov       r12,rax
       jmp       short M12_L33
M12_L31:
       mov       rdi,r14
       mov       esi,r13d
       call      qword ptr [7FB978066C40]
M12_L32:
       mov       r12,rax
M12_L33:
       xor       edi,edi
       mov       [rbp-38],rdi
M12_L34:
       cmp       dword ptr [r14+1C],0
       jne       short M12_L35
       mov       rsi,r12
       jmp       short M12_L36
M12_L35:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7FB9760405B8
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7FB978066BE0]
       mov       rsi,rax
M12_L36:
       jmp       near ptr M12_L57
M12_L37:
       cmp       dword ptr [r14+1C],0
       je        short M12_L38
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7FB978066BE0]
M12_L38:
       mov       r13,[r14+10]
       xor       r12d,r12d
       test      r13,r13
       jne       near ptr M12_L45
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M12_L40
M12_L39:
       mov       rdi,7FB97603B1E0
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M12_L39
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M12_L40:
       dec       r12d
       imul      edi,r12d,9E3779B9
       cmp       dword ptr [r14+18],0
       jge       short M12_L41
       mov       r12d,edi
       mov       edx,[r14+20]
       imul      r12,rdx
       shr       r12,20
       jmp       short M12_L42
M12_L41:
       and       edi,[r14+18]
       mov       r12d,edi
M12_L42:
       mov       rdi,[r14+8]
       lea       edx,[r12*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M12_L108
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       [rbp-0A8],rax
       test      rax,rax
       je        short M12_L43
       mov       rdx,rax
       xor       esi,esi
       call      00007FB9F5474060
       mov       rdi,[rbp-0A8]
       cmp       rax,rdi
       je        short M12_L44
M12_L43:
       xor       edi,edi
M12_L44:
       mov       [rbp-48],rdi
       jmp       near ptr M12_L51
M12_L45:
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L47
M12_L46:
       mov       rax,7FB97603B1F0
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-4C],eax
       test      eax,eax
       je        short M12_L46
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-4C]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L47:
       dec       eax
       cmp       dword ptr [r13+18],0
       jl        short M12_L48
       mov       ecx,eax
       and       ecx,[r13+18]
       jmp       short M12_L49
M12_L48:
       mov       rcx,[r13+8]
       mov       edi,[rcx+8]
       mov       ecx,eax
       imul      rcx,[r13+10]
       shr       rcx,20
       inc       rcx
       imul      rcx,rdi
       shr       rcx,20
       mov       eax,ecx
       mov       ecx,eax
M12_L49:
       mov       rdi,[r13+8]
       cmp       ecx,[rdi+8]
       jae       near ptr M12_L108
       mov       [rbp-50],ecx
       mov       edx,ecx
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-0B0],rax
       mov       r8,[rax+50]
       mov       [rbp-0B8],r8
       test      r8,r8
       je        short M12_L50
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M12_L95
       mov       rdx,r8
       xor       esi,esi
       call      00007FB9F5474060
       mov       rdx,[rbp-0B8]
       cmp       rax,rdx
       mov       rax,[rbp-0B0]
       jne       short M12_L50
       mov       [rbp-48],rdx
       jmp       short M12_L51
M12_L50:
       lea       rdx,[rbp-48]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7FB977ABDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M12_L51
       lea       rdx,[rbp-48]
       mov       rdi,r13
       mov       esi,[rbp-50]
       call      qword ptr [7FB977ABDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M12_L51:
       mov       rax,[rbp-48]
       cmp       qword ptr [rbp-48],0
       jne       short M12_L52
       test      r13,r13
       je        short M12_L53
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       dword ptr [r12+8],1
       jmp       short M12_L55
M12_L52:
       mov       r13,rax
       jmp       short M12_L54
M12_L53:
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7FB978066C40]
       mov       r13,rax
M12_L54:
       mov       r12,r13
M12_L55:
       xor       edi,edi
       mov       [rbp-48],rdi
       cmp       dword ptr [r14+1C],0
       jne       short M12_L56
       mov       rsi,r12
       jmp       short M12_L57
M12_L56:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7FB9760405C0
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7FB978066BE0]
       mov       rsi,rax
M12_L57:
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
M12_L58:
       mov       rsi,[r15+8]
       lea       rdi,[r15+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M12_L02
M12_L59:
       mov       rdi,[rbx+10]
       cmp       [rdi],edi
       call      qword ptr [7FB977FD74C8]; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       mov       rdi,[rbx+10]
       cmp       [rdi],edi
       call      qword ptr [7FB977FD74E0]; Kevlar.KevlarProperties.Clear()
       jmp       near ptr M12_L03
M12_L60:
       mov       rdi,[r15+28]
       cmp       [rdi],edi
       call      qword ptr [7FB977FD74F8]
       mov       byte ptr [r15+34],0
       jmp       near ptr M12_L04
M12_L61:
       mov       rdi,[r15+28]
       call      qword ptr [7FB977FD7510]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       jmp       near ptr M12_L111
M12_L62:
       mov       rdi,[r15+8]
       call      qword ptr [7FB977FD7510]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7FB18D8013D0
       mov       r14,[rdi]
       cmp       byte ptr [r14+24],0
       je        near ptr M12_L89
       cmp       dword ptr [r14+1C],0
       je        short M12_L63
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7FB978066BE0]
M12_L63:
       lea       rdi,[r14+28]
       mov       rsi,[rdi]
       test      rsi,rsi
       jne       short M12_L64
       mov       rsi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7FB978066BF8]
       mov       rsi,rax
M12_L64:
       mov       rdi,rsi
       cmp       [rdi],edi
       call      qword ptr [7FB978066C10]
       mov       r13,rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7FB977025728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       cmp       byte ptr [7FB97603B1E8],0
       je        short M12_L67
       mov       edx,[r13+68]
       mov       rax,[r13+58]
       mov       r12,rax
       test      r12,r12
       je        short M12_L68
       xor       esi,esi
       mov       [r13+58],rsi
       cmp       [r13+68],edx
       jne       short M12_L65
       test      dl,1
       je        short M12_L66
M12_L65:
       mov       rdx,r12
       mov       rsi,r13
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7FB978066C28]
       mov       r12,rax
       test      r12,r12
       je        short M12_L68
M12_L66:
       jmp       near ptr M12_L86
M12_L67:
       cmp       qword ptr [r13+58],0
       je        short M12_L68
       lea       rdi,[r13+58]
       test      rdi,rdi
       je        near ptr M12_L95
       xor       esi,esi
       call      00007FB9F5474040
       mov       r12,rax
       test      r12,r12
       jne       short M12_L66
M12_L68:
       cmp       byte ptr [r13+6C],0
       jne       short M12_L69
       mov       byte ptr [r13+6C],1
M12_L69:
       mov       r12,[r14+10]
       xor       r13d,r13d
       test      r12,r12
       jne       near ptr M12_L76
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M12_L71
M12_L70:
       mov       rdi,7FB97603B1E0
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M12_L70
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M12_L71:
       dec       r13d
       imul      edi,r13d,9E3779B9
       cmp       dword ptr [r14+18],0
       jge       short M12_L72
       mov       r13d,edi
       mov       edx,[r14+20]
       imul      r13,rdx
       shr       r13,20
       jmp       short M12_L73
M12_L72:
       and       edi,[r14+18]
       mov       r13d,edi
M12_L73:
       mov       rdi,[r14+8]
       lea       edx,[r13*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M12_L108
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       [rbp-0C0],rax
       test      rax,rax
       je        short M12_L74
       mov       rdx,rax
       xor       esi,esi
       call      00007FB9F5474060
       mov       rdi,[rbp-0C0]
       cmp       rax,rdi
       je        short M12_L75
M12_L74:
       xor       edi,edi
M12_L75:
       mov       [rbp-58],rdi
       jmp       near ptr M12_L82
M12_L76:
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L78
M12_L77:
       mov       rax,7FB97603B1F0
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-5C],eax
       test      eax,eax
       je        short M12_L77
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-5C]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L78:
       dec       eax
       cmp       dword ptr [r12+18],0
       jl        short M12_L79
       mov       ecx,eax
       and       ecx,[r12+18]
       jmp       short M12_L80
M12_L79:
       mov       rcx,[r12+8]
       mov       edi,[rcx+8]
       mov       ecx,eax
       imul      rcx,[r12+10]
       shr       rcx,20
       inc       rcx
       imul      rcx,rdi
       shr       rcx,20
       mov       eax,ecx
       mov       ecx,eax
M12_L80:
       mov       rdi,[r12+8]
       cmp       ecx,[rdi+8]
       jae       near ptr M12_L108
       mov       [rbp-60],ecx
       mov       edx,ecx
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-0C8],rax
       mov       r8,[rax+50]
       mov       [rbp-0D0],r8
       test      r8,r8
       je        short M12_L81
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M12_L95
       mov       rdx,r8
       xor       esi,esi
       call      00007FB9F5474060
       mov       r8,[rbp-0D0]
       cmp       rax,r8
       mov       rax,[rbp-0C8]
       jne       short M12_L81
       mov       [rbp-58],r8
       jmp       short M12_L82
M12_L81:
       lea       rdx,[rbp-58]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7FB977ABDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M12_L82
       lea       rdx,[rbp-58]
       mov       rdi,r12
       mov       esi,[rbp-60]
       call      qword ptr [7FB977ABDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M12_L82:
       mov       rax,[rbp-58]
       cmp       qword ptr [rbp-58],0
       jne       short M12_L84
       test      r12,r12
       je        short M12_L83
       cmp       [r14],r14b
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       dword ptr [rax+8],1
       mov       r12,rax
       jmp       short M12_L85
M12_L83:
       mov       rdi,r14
       mov       esi,r13d
       call      qword ptr [7FB978066C40]
M12_L84:
       mov       r12,rax
M12_L85:
       xor       edi,edi
       mov       [rbp-58],rdi
M12_L86:
       cmp       dword ptr [r14+1C],0
       jne       short M12_L87
       mov       rsi,r12
       jmp       short M12_L88
M12_L87:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7FB9760405C8
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7FB978066BE0]
       mov       rsi,rax
M12_L88:
       jmp       near ptr M12_L110
M12_L89:
       cmp       dword ptr [r14+1C],0
       je        short M12_L90
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7FB978066BE0]
M12_L90:
       mov       r13,[r14+10]
       xor       r12d,r12d
       test      r13,r13
       jne       near ptr M12_L98
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M12_L92
M12_L91:
       mov       rdi,7FB97603B1E0
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M12_L91
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M12_L92:
       dec       r12d
       imul      edi,r12d,9E3779B9
       cmp       dword ptr [r14+18],0
       jge       short M12_L93
       mov       r12d,edi
       mov       edx,[r14+20]
       imul      r12,rdx
       shr       r12,20
       jmp       short M12_L94
M12_L93:
       and       edi,[r14+18]
       mov       r12d,edi
M12_L94:
       mov       rdi,[r14+8]
       lea       edx,[r12*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M12_L108
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       [rbp-0D8],rax
       test      rax,rax
       je        short M12_L96
       mov       rdx,rax
       xor       esi,esi
       call      00007FB9F5474060
       mov       rdi,[rbp-0D8]
       cmp       rax,rdi
       je        short M12_L97
       jmp       short M12_L96
M12_L95:
       call      qword ptr [7FB9780664C0]
       int       3
M12_L96:
       xor       edi,edi
M12_L97:
       mov       [rbp-68],rdi
       jmp       near ptr M12_L103
M12_L98:
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L100
M12_L99:
       mov       rax,7FB97603B1F0
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-6C],eax
       test      eax,eax
       je        short M12_L99
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-6C]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L100:
       dec       eax
       cmp       dword ptr [r13+18],0
       jl        short M12_L101
       mov       ecx,eax
       and       ecx,[r13+18]
       jmp       short M12_L102
M12_L101:
       mov       rcx,[r13+8]
       mov       edx,[rcx+8]
       mov       ecx,eax
       imul      rcx,[r13+10]
       shr       rcx,20
       inc       rcx
       imul      rcx,rdx
       shr       rcx,20
       mov       eax,ecx
       mov       ecx,eax
M12_L102:
       lea       rdx,[rbp-68]
       mov       rdi,r13
       mov       [rbp-70],ecx
       mov       esi,ecx
       call      qword ptr [7FB977ABDD10]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       jne       short M12_L103
       lea       rdx,[rbp-68]
       mov       rdi,r13
       mov       esi,[rbp-70]
       call      qword ptr [7FB977ABDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M12_L103:
       mov       rax,[rbp-68]
       cmp       qword ptr [rbp-68],0
       jne       short M12_L104
       test      r13,r13
       je        short M12_L105
       cmp       [r14],r14b
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       dword ptr [r12+8],1
       jmp       short M12_L107
M12_L104:
       mov       r13,rax
       jmp       short M12_L106
M12_L105:
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7FB978066C40]
       mov       r13,rax
M12_L106:
       mov       r12,r13
M12_L107:
       xor       edi,edi
       mov       [rbp-68],rdi
       cmp       dword ptr [r14+1C],0
       jne       short M12_L109
       mov       rsi,r12
       jmp       short M12_L110
M12_L108:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M12_L109:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7FB9760405D0
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7FB978066BE0]
       mov       rsi,rax
M12_L110:
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
M12_L111:
       mov       rsi,[r15+8]
       lea       rdi,[r15+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M12_L05
M12_L112:
       mov       eax,1
       add       rsp,0B8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
       push      rax
       mov       rbx,rdi
       mov       rdi,offset MT_System.Exception[]
       mov       esi,2
       call      CORINFO_HELP_NEWARR_1_PTR
       mov       r15,rax
       lea       rdi,[r15+10]
       mov       rsi,[rbp-88]
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r15+18]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,offset MT_System.AggregateException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,0C1
       mov       rsi,7FB9774A54F0
       call      qword ptr [7FB97702EF88]
       mov       rsi,rax
       mov       rdi,rbx
       mov       rdx,r15
       call      qword ptr [7FB977ABDFC8]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
       push      rax
       mov       rsi,rdi
       mov       [rbp-88],rsi
       mov       rdi,[rbp-78]
       mov       rsi,[rdi]
       mov       rax,[rsi+30]
       mov       rax,[rax]
       mov       rbx,[rax+50]
       test      rbx,rbx
       je        short M12_L113
       jmp       short M12_L114
M12_L113:
       mov       rdi,rsi
       mov       rsi,7FB97804E2B0
       call      qword ptr [7FB97702F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rbx,rax
M12_L114:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-78]
       mov       r11b,[rdi+30]
       mov       [rax+8],r11b
       mov       rdi,rax
       mov       r11,rbx
       mov       rsi,[rbp-80]
       call      qword ptr [rbx]
       nop
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 3564
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7FB976BCEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7FB976BCEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       movzx     edx,byte ptr [rbp-14]
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       xor       ecx,ecx
       call      qword ptr [7FB977FD72E8]; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       movzx     esi,byte ptr [rbp-14]
       mov       rdi,[rbp-10]
       xor       edx,edx
       call      qword ptr [7FB977FD7300]; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 65
```
```assembly
; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,98
       lea       rbp,[rsp+0C0]
       xor       eax,eax
       mov       [rbp-38],rax
       mov       [rbp-50],rax
       mov       r13,rdi
       mov       r14d,esi
       mov       rbx,rdx
       mov       r15,rcx
       mov       rdi,7FB18D8013C0
       mov       r12,[rdi]
       cmp       byte ptr [r12+24],0
       jne       near ptr M15_L08
       cmp       dword ptr [r12+1C],0
       jne       near ptr M15_L38
M15_L00:
       mov       rax,[r12+10]
       mov       [rbp-0A0],rax
       xor       ecx,ecx
       mov       [rbp-44],ecx
       test      rax,rax
       je        near ptr M15_L39
       mov       rdi,7FB9F56A0D68
       mov       rdx,7FB9F5F04820
       call      rdx
       add       rax,40
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M15_L48
M15_L01:
       dec       eax
       mov       rcx,[rbp-0A0]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M15_L49
       and       r8d,eax
M15_L02:
       mov       rdi,[rcx+8]
       cmp       r8d,[rdi+8]
       jae       near ptr M15_L56
       mov       [rbp-58],r8d
       mov       edx,r8d
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-0B0],rax
       mov       r9,[rax+50]
       mov       [rbp-0B8],r9
       test      r9,r9
       je        near ptr M15_L51
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M15_L50
       mov       rdx,r9
       xor       esi,esi
       call      00007FB9F5474060
       mov       rdx,[rbp-0B8]
       cmp       rax,rdx
       mov       rax,[rbp-0B0]
       jne       near ptr M15_L51
       mov       [rbp-50],rdx
       mov       eax,[rbp-44]
M15_L03:
       mov       rcx,[rbp-50]
       cmp       qword ptr [rbp-50],0
       je        near ptr M15_L52
M15_L04:
       mov       rax,rcx
M15_L05:
       xor       edi,edi
       mov       [rbp-50],rdi
       cmp       dword ptr [r12+1C],0
       jne       near ptr M15_L55
       mov       r12,rax
M15_L06:
       lea       rdi,[r12+68]
       mov       rsi,r13
       call      CORINFO_HELP_ASSIGN_REF
       mov       [r12+60],r14d
       lea       rdi,[r12+38]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r12+30]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,0FFFFFFFF00000000
       mov       [r12+58],rax
       xor       eax,eax
       mov       [r12+40],rax
       mov       rax,r12
       add       rsp,98
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M15_L07:
       mov       rdi,7FB97603B200
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M15_L07
       jmp       near ptr M15_L40
M15_L08:
       cmp       dword ptr [r12+1C],0
       je        short M15_L09
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7FB977FD68F8]
M15_L09:
       lea       rdi,[r12+28]
       mov       rsi,[rdi]
       test      rsi,rsi
       jne       short M15_L10
       mov       rsi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7FB978066BF8]
       mov       rsi,rax
M15_L10:
       mov       rdi,rsi
       cmp       [rdi],edi
       call      qword ptr [7FB978066C10]
       mov       [rbp-60],rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7FB977025728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       cmp       byte ptr [7FB97603B208],0
       je        short M15_L14
       mov       rax,[rbp-60]
       mov       edx,[rax+68]
       mov       rcx,[rax+58]
       test      rcx,rcx
       je        short M15_L17
       xor       esi,esi
       mov       [rax+58],rsi
       cmp       [rax+68],edx
       jne       short M15_L11
       test      dl,1
       je        short M15_L12
M15_L11:
       mov       rdx,rcx
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7FB978066C28]
       mov       rcx,rax
       mov       rax,rcx
       test      rax,rax
       mov       rcx,rax
       je        short M15_L13
M15_L12:
       mov       rax,rcx
       jmp       near ptr M15_L35
M15_L13:
       mov       rax,[rbp-60]
       jmp       short M15_L17
M15_L14:
       mov       rcx,[rbp-60]
       cmp       qword ptr [rcx+58],0
       je        short M15_L15
       lea       rdi,[rcx+58]
       test      rdi,rdi
       jne       short M15_L16
       jmp       near ptr M15_L50
M15_L15:
       mov       rax,rcx
       jmp       short M15_L17
M15_L16:
       xor       esi,esi
       call      00007FB9F5474040
       test      rax,rax
       mov       rcx,rax
       jne       short M15_L12
       mov       rax,[rbp-60]
M15_L17:
       cmp       byte ptr [rax+6C],0
       jne       short M15_L18
       mov       byte ptr [rax+6C],1
M15_L18:
       mov       rax,[r12+10]
       mov       [rbp-70],rax
       xor       ecx,ecx
       mov       [rbp-2C],ecx
       test      rax,rax
       jne       near ptr M15_L26
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M15_L20
M15_L19:
       mov       rdi,7FB97603B200
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M15_L19
       mov       [rax+10],edi
M15_L20:
       dec       edi
       imul      edi,9E3779B9
       cmp       dword ptr [r12+18],0
       jge       short M15_L21
       mov       ecx,edi
       mov       edx,[r12+20]
       imul      rcx,rdx
       shr       rcx,20
       jmp       short M15_L22
M15_L21:
       and       edi,[r12+18]
       mov       ecx,edi
M15_L22:
       mov       eax,ecx
       mov       rdi,[r12+8]
       mov       [rbp-2C],eax
       lea       edx,[rax*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M15_L56
       lea       rdi,[rdi+rdx*8+10]
       mov       rcx,[rdi]
       mov       [rbp-78],rcx
       test      rcx,rcx
       je        short M15_L23
       mov       rdx,rcx
       xor       esi,esi
       call      00007FB9F5474060
       mov       rdi,[rbp-78]
       cmp       rax,rdi
       je        short M15_L24
M15_L23:
       xor       esi,esi
       jmp       short M15_L25
M15_L24:
       mov       rsi,rdi
M15_L25:
       mov       [rbp-38],rsi
       jmp       near ptr M15_L32
M15_L26:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M15_L28
M15_L27:
       mov       rax,7FB97603B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-3C],eax
       test      eax,eax
       je        short M15_L27
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-3C]
       mov       [rax+10],ecx
       mov       eax,ecx
M15_L28:
       dec       eax
       mov       rcx,[rbp-70]
       cmp       dword ptr [rcx+18],0
       jl        short M15_L29
       mov       r8d,eax
       and       r8d,[rcx+18]
       jmp       short M15_L30
M15_L29:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
M15_L30:
       mov       rdi,[rcx+8]
       cmp       r8d,[rdi+8]
       jae       near ptr M15_L56
       mov       [rbp-40],r8d
       mov       edx,r8d
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-80],rax
       mov       r9,[rax+50]
       mov       [rbp-88],r9
       test      r9,r9
       je        short M15_L31
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M15_L50
       mov       rdx,r9
       xor       esi,esi
       call      00007FB9F5474060
       mov       r9,[rbp-88]
       cmp       rax,r9
       mov       rax,[rbp-80]
       jne       short M15_L31
       mov       [rbp-38],r9
       jmp       short M15_L32
M15_L31:
       lea       rdx,[rbp-38]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7FB977ABDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M15_L32
       lea       rdx,[rbp-38]
       mov       rdi,[rbp-70]
       mov       esi,[rbp-40]
       call      qword ptr [7FB977ABDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M15_L32:
       mov       rax,[rbp-38]
       cmp       qword ptr [rbp-38],0
       jne       short M15_L34
       cmp       qword ptr [rbp-70],0
       je        short M15_L33
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-90],rax
       mov       rdi,rax
       call      qword ptr [7FB977FD69A0]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-90]
       jmp       short M15_L34
M15_L33:
       mov       rdi,r12
       mov       esi,[rbp-2C]
       call      qword ptr [7FB977FD6958]
M15_L34:
       xor       edi,edi
       mov       [rbp-38],rdi
M15_L35:
       cmp       dword ptr [r12+1C],0
       jne       short M15_L36
       mov       r12,rax
       jmp       short M15_L37
M15_L36:
       mov       [rbp-68],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r12+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-68]
       mov       r11,7FB976040570
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7FB977FD68F8]
       mov       r12,rax
M15_L37:
       jmp       near ptr M15_L06
M15_L38:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7FB977FD68F8]
       jmp       near ptr M15_L00
M15_L39:
       mov       rdi,7FB9F56A0D68
       mov       rcx,7FB9F5F04820
       call      rcx
       add       rax,30
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M15_L41
       jmp       near ptr M15_L07
M15_L40:
       mov       [rax+10],edi
M15_L41:
       dec       edi
       imul      edi,9E3779B9
       mov       edx,[r12+18]
       test      edx,edx
       jge       short M15_L42
       mov       ecx,edi
       mov       esi,[r12+20]
       imul      rcx,rsi
       shr       rcx,20
       jmp       short M15_L43
M15_L42:
       mov       ecx,edi
       and       ecx,edx
M15_L43:
       mov       eax,ecx
       mov       rdi,[r12+8]
       mov       [rbp-44],eax
       lea       edx,[rax*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M15_L56
       lea       rdi,[rdi+rdx*8+10]
       mov       rcx,[rdi]
       mov       [rbp-0A8],rcx
       test      rcx,rcx
       je        short M15_L45
       mov       rdx,rcx
       xor       esi,esi
       call      00007FB9F5474060
       mov       rdi,[rbp-0A8]
       cmp       rax,rdi
       mov       eax,[rbp-44]
       je        short M15_L46
M15_L44:
       xor       esi,esi
       jmp       short M15_L47
M15_L45:
       mov       eax,[rbp-44]
       jmp       short M15_L44
M15_L46:
       mov       rcx,rdi
       mov       rsi,rcx
M15_L47:
       mov       [rbp-50],rsi
       jmp       near ptr M15_L03
M15_L48:
       mov       rax,7FB97603B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-54],eax
       test      eax,eax
       je        short M15_L48
       mov       rdi,7FB9F56A0D68
       mov       rcx,7FB9F5F04820
       call      rcx
       add       rax,40
       mov       ecx,[rbp-54]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M15_L01
M15_L49:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M15_L02
M15_L50:
       call      qword ptr [7FB9780664C0]
       int       3
M15_L51:
       lea       rdx,[rbp-50]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7FB977ABDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M15_L53
       lea       rdx,[rbp-50]
       mov       rdi,[rbp-0A0]
       mov       esi,[rbp-58]
       call      qword ptr [7FB977ABDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       mov       eax,[rbp-44]
       jmp       near ptr M15_L03
M15_L52:
       cmp       qword ptr [rbp-0A0],0
       je        short M15_L54
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-0C0],rax
       mov       rdi,rax
       call      qword ptr [7FB977FD69A0]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-0C0]
       jmp       near ptr M15_L05
M15_L53:
       mov       eax,[rbp-44]
       jmp       near ptr M15_L03
M15_L54:
       mov       rdi,r12
       mov       esi,eax
       call      qword ptr [7FB977FD6958]
       mov       rcx,rax
       jmp       near ptr M15_L04
M15_L55:
       mov       [rbp-98],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r12+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-98]
       mov       r11,7FB976040578
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7FB977FD68F8]
       mov       r12,rax
       jmp       near ptr M15_L06
M15_L56:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 1808
```
```assembly
; Kevlar.KevlarContext.get_PropertiesForCompletion()
       cmp       byte ptr [rdi+64],0
       jne       short M16_L00
       mov       rax,[rdi+8]
       ret
M16_L00:
       mov       rax,[rdi+10]
       ret
; Total bytes of code 16
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+48]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+60]
       mov       rdi,[rbp-10]
       call      qword ptr [7FB977ABDE18]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M17_L00
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M17_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+48]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M17_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rbp-20]
       mov       rdi,rax
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+58]
       mov       rax,[rbp-18]
       mov       rdx,[rax+48]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7FB977ABDE30]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       eax,1
       add       rsp,30
       pop       rbp
       ret
M17_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 171
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-10]
       mov       rcx,rax
       test      cl,1
       jne       short M18_L00
       ret
M18_L00:
       jmp       qword ptr [7FB97741EA48]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 23
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+48]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+58]
       mov       rdi,[rbp-10]
       call      qword ptr [7FB977ABDE18]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M19_L00
       mov       rax,[rbp-20]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M19_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+48]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M19_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rax]
       mov       rdi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       mov       rax,[rax+48]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M19_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       xor       ecx,ecx
       mov       [rax],rcx
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+60]
       mov       rax,[rbp-18]
       mov       rdx,[rax+48]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7FB977ABDE30]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       rax,[rbp-20]
       cmp       qword ptr [rax],0
       setne     al
       movzx     eax,al
       add       rsp,30
       pop       rbp
       ret
M19_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 221
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       push      rbp
       sub       rsp,60
       lea       rbp,[rsp+60]
       xor       eax,eax
       mov       [rbp-54],rax
       mov       [rbp-4C],eax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-3C],esi
       mov       [rbp-48],rdx
       mov       dword ptr [rbp-60],3E8
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FB977ABDD40]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       eax,[rax+14]
       dec       eax
       mov       [rbp-4C],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-4C]
       jbe       short M20_L02
       mov       eax,[rbp-4C]
       cmp       eax,[rbp-3C]
       je        short M20_L01
       mov       rdi,[rbp-38]
       mov       esi,[rbp-4C]
       mov       rdx,[rbp-48]
       call      qword ptr [7FB977ABDD10]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       je        short M20_L00
       mov       rdi,7FB977EB72E0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,60
       pop       rbp
       ret
M20_L00:
       mov       rdi,7FB977EB72E4
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       short M20_L02
M20_L01:
       mov       rdi,7FB977EB72E8
       call      CORINFO_HELP_COUNTPROFILE32
M20_L02:
       mov       eax,[rbp-3C]
       mov       [rbp-50],eax
       mov       dword ptr [rbp-54],1
       jmp       near ptr M20_L06
M20_L03:
       mov       eax,[rbp-50]
       inc       eax
       mov       [rbp-58],eax
       mov       eax,[rbp-50]
       inc       eax
       mov       [rbp-50],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-58]
       jne       short M20_L04
       mov       rdi,7FB977EB72EC
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-50],eax
M20_L04:
       mov       rdi,[rbp-38]
       mov       esi,[rbp-50]
       mov       rdx,[rbp-48]
       call      qword ptr [7FB977ABDD10]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       je        short M20_L05
       mov       rdi,7FB977EB72F0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FB977ABDD40]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       ecx,[rbp-50]
       inc       ecx
       mov       [rax+14],ecx
       mov       eax,1
       add       rsp,60
       pop       rbp
       ret
M20_L05:
       mov       rdi,7FB977EB72F4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-54]
       inc       eax
       mov       [rbp-54],eax
M20_L06:
       mov       eax,[rbp-60]
       dec       eax
       mov       [rbp-60],eax
       cmp       dword ptr [rbp-60],0
       jg        short M20_L07
       lea       rdi,[rbp-60]
       mov       esi,52
       call      CORINFO_HELP_PATCHPOINT
M20_L07:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-54]
       jg        near ptr M20_L03
       mov       rdi,7FB977EB72F8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-48]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,60
       pop       rbp
       ret
; Total bytes of code 406
```
```assembly
; Kevlar.KevlarContext..ctor()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7FB977FD69B8]; Kevlar.KevlarProperties..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,offset MT_System.Object
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-18],rax
       mov       rdi,[rbp-18]
       call      qword ptr [7FB97702C240]; System.Object..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+20]
       mov       rsi,[rbp-18]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-8]
       mov       dword ptr [rax+5C],0FFFFFFFF
       call      qword ptr [7FB977ABE658]; System.TimeProvider.get_System()
       mov       rcx,[rbp-8]
       lea       rdi,[rcx+38]
       mov       rsi,rax
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-8]
       call      qword ptr [7FB97702C240]; System.Object..ctor()
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 166
```
```assembly
; System.Diagnostics.Metrics.Instrument.get_Enabled()
       mov       rax,[rdi+8]
       cmp       qword ptr [rax+8],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 16
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,130
       vzeroupper
       lea       rbp,[rsp+150]
       xor       eax,eax
       mov       [rbp-148],rax
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFEE0
M23_L00:
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       vmovdqa   xmmword ptr [rax+rbp],xmm8
       add       rax,30
       jne       short M23_L00
       mov       r15,rdi
       mov       rbx,rsi
       mov       r14d,edx
       mov       r13,[rbx+30]
       xor       edi,edi
       mov       [rbp-0B8],rdi
       test      r15,r15
       jne       short M23_L03
M23_L01:
       mov       rsi,[rbx+30]
       mov       rdi,7FB18D800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M23_L04
M23_L02:
       add       rsp,130
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M23_L03:
       mov       rdi,7FB18D800BA0
       mov       rdi,[rdi]
       call      qword ptr [7FB977ABEAD8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        short M23_L01
       lea       rdi,[rbp-0B0]
       mov       rsi,r13
       call      qword ptr [7FB977FD7330]
       mov       rdx,7FB96CA0B6A8
       mov       rdi,7FB96CA0B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-0B0]
       mov       rsi,7FB96CA0B638
       call      qword ptr [7FB977FD7348]
       call      00007FB977018AE0
       mov       rsi,rax
       mov       rdi,r15
       call      qword ptr [7FB978067048]
       mov       [rbp-0B8],rax
       lea       rdi,[rbp-0B8]
       call      qword ptr [7FB977FD7378]
       mov       rdi,7FB18D800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-0B0]
       mov       rdx,rbx
       call      qword ptr [7FB977FD7390]
       jmp       near ptr M23_L01
M23_L04:
       lea       rdi,[rbp-148]
       call      qword ptr [7FB977FD7330]
       mov       rdx,7FB96CA0B6A8
       mov       rdi,7FB96CA0B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-148]
       mov       rsi,7FB96CA0B638
       call      qword ptr [7FB977FD7348]
       mov       rdi,7FB18D800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-148]
       mov       rcx,rbx
       mov       esi,1
       call      qword ptr [7FB977FD73A8]
       jmp       near ptr M23_L02
; Total bytes of code 410
```
```assembly
; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       push      rax
       lea       rbp,[rsp+30]
       mov       rbx,rdi
       mov       rdi,7FB18D8013C0
       mov       r15,[rdi]
       test      rbx,rbx
       je        near ptr M24_L04
       cmp       byte ptr [r15+24],0
       jne       near ptr M24_L05
       cmp       dword ptr [r15+1C],0
       jne       near ptr M24_L06
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7FB977FD7450]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItemGuarded(System.__Canon)
       test      eax,eax
       je        near ptr M24_L07
       mov       r14,[r15+10]
       test      r14,r14
       je        near ptr M24_L13
       mov       rdi,7FB9F56A0D68
       mov       rax,7FB9F5F04820
       call      rax
       add       rax,40
       mov       r13d,[rax+10]
       test      r13d,r13d
       je        near ptr M24_L08
M24_L00:
       dec       r13d
       mov       r12d,[r14+18]
       test      r12d,r12d
       jl        near ptr M24_L09
       and       r12d,r13d
M24_L01:
       xor       r13d,r13d
       mov       rdi,[r14+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M24_L12
M24_L02:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M24_L21
       mov       esi,r12d
       mov       rax,[rdi+rsi*8+10]
       mov       [rbp-30],rax
       cmp       qword ptr [rax+50],0
       jne       near ptr M24_L10
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M24_L18
       mov       rsi,rbx
       xor       edx,edx
       call      00007FB9F5474060
       test      rax,rax
       mov       rax,[rbp-30]
       jne       near ptr M24_L10
M24_L03:
       cmp       dword ptr [r15+1C],0
       jne       near ptr M24_L20
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M24_L04:
       mov       edi,29
       mov       rsi,7FB9774A54F0
       call      qword ptr [7FB97702EF88]
       mov       rdi,rax
       call      qword ptr [7FB978066610]
       int       3
M24_L05:
       mov       rdi,r15
       mov       rsi,rbx
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7FB977FD73F0]
M24_L06:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7FB9760405A0
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M24_L07:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7FB9760405A8
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M24_L08:
       mov       rdi,7FB97603B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M24_L08
       mov       rdi,7FB9F56A0D68
       mov       rax,7FB9F5F04820
       call      rax
       add       rax,40
       mov       [rax+10],r13d
       jmp       near ptr M24_L00
M24_L09:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r13d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
       jmp       near ptr M24_L01
M24_L10:
       mov       rdx,rbx
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7FB977ABE058]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       near ptr M24_L03
       inc       r12d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r12d
       jne       short M24_L11
       xor       r12d,r12d
M24_L11:
       inc       r13d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r13d
       jg        near ptr M24_L02
M24_L12:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7FB9760405B0
       call      qword ptr [r11]
       jmp       near ptr M24_L03
M24_L13:
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r14d,[rax+10]
       test      r14d,r14d
       jne       short M24_L15
M24_L14:
       mov       rdi,7FB97603B200
       mov       eax,1
       mov       r14d,eax
       lock xadd [rdi],r14d
       inc       r14d
       je        short M24_L14
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r14d
M24_L15:
       dec       r14d
       imul      r14d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M24_L16
       mov       r13d,r14d
       mov       r12d,[r15+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M24_L17
M24_L16:
       and       r14d,[r15+18]
       mov       r13d,r14d
M24_L17:
       mov       rdi,[r15+8]
       lea       esi,[r13*8+8]
       cmp       esi,[rdi+8]
       jae       short M24_L21
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M24_L19
M24_L18:
       call      qword ptr [7FB9780664C0]
       int       3
M24_L19:
       mov       rsi,rbx
       call      00007FB9F5474040
       test      rax,rax
       je        near ptr M24_L03
       mov       rdi,r15
       mov       rsi,rbx
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7FB977FD7660]
       jmp       near ptr M24_L03
M24_L20:
       mov       rdi,r15
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7FB977FD7690]
M24_L21:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 852
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-18]
       mov       rcx,rax
       test      cl,1
       jne       short M25_L00
       ret
M25_L00:
       jmp       qword ptr [7FB977025C20]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 23
```
```assembly
; Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,0D0
       lea       rbp,[rsp+0F0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       xor       eax,eax
       mov       [rbp-30],rax
       mov       [rbp-28],rdi
       mov       [rbp-0D8],rdi
       mov       rbx,rsi
       mov       r14,rdx
       mov       r13,rcx
       mov       r15,r8
       mov       rsi,[rdi]
       mov       rax,[rsi+30]
       mov       rax,[rax]
       mov       rax,[rax+18]
       test      rax,rax
       je        near ptr M26_L14
M26_L00:
       mov       [rbp-48],r14
       mov       [rbp-40],r13
       mov       [rbp-70],r15
       mov       dword ptr [rbp-68],0FFFFFFFF
       mov       rsi,[rax+18]
       mov       rcx,[rsi+18]
       test      rcx,rcx
       je        near ptr M26_L15
M26_L01:
       mov       rsi,[rcx+18]
       mov       r15,[rsi+10]
       test      r15,r15
       je        near ptr M26_L16
M26_L02:
       mov       rdi,7FB9F56A0D68
       mov       rax,7FB9F5F04820
       call      rax
       cmp       dword ptr [rax],4
       jle       near ptr M26_L17
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        near ptr M26_L17
M26_L03:
       mov       r14,[rax+10]
       test      r14,r14
       jne       short M26_L04
       call      qword ptr [7FB97770C420]; System.Threading.Thread.InitializeCurrentThread()
       mov       r14,rax
M26_L04:
       mov       [rbp-0E0],r14
       mov       rsi,[r14+8]
       mov       [rbp-0E8],rsi
       mov       rsi,[r14+10]
       mov       [rbp-0F0],rsi
       mov       rdi,[r15+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M26_L06
M26_L05:
       lea       rdi,[rbp-70]
       call      rax
       jmp       short M26_L07
M26_L06:
       mov       rdi,r15
       mov       rsi,7FB977FB82A0
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M26_L05
M26_L07:
       mov       rsi,[rbp-0F0]
       cmp       rsi,[r14+10]
       je        short M26_L08
       lea       rdi,[r14+10]
       call      CORINFO_HELP_ASSIGN_REF
M26_L08:
       mov       rdi,[r14+8]
       mov       r15,rdi
       mov       rsi,[rbp-0E8]
       cmp       rsi,r15
       je        short M26_L10
       lea       rdi,[r14+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      r15,r15
       je        short M26_L09
       cmp       qword ptr [r15+10],0
       jne       near ptr M26_L13
M26_L09:
       cmp       qword ptr [rbp-0E8],0
       jne       short M26_L12
M26_L10:
       mov       rdi,[rbp-60]
       mov       rax,7FB18D8013E8
       cmp       rdi,[rax]
       jne       near ptr M26_L18
       vmovdqu   xmm0,xmmword ptr [rbp-58]
       vmovdqu   xmmword ptr [rbp-0C0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-0D0]
       vmovdqu   ymmword ptr [rbp-90],ymm0
       xor       r15d,r15d
M26_L11:
       mov       [rbp-90],r15
       vmovdqu   ymm0,ymmword ptr [rbp-90]
       vmovdqu   ymmword ptr [rbx],ymm0
       mov       word ptr [rbx+8],0
       mov       byte ptr [rbx+0A],1
       mov       rax,rbx
       vzeroupper
       add       rsp,0D0
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M26_L12:
       mov       rsi,[rbp-0E8]
       cmp       qword ptr [rsi+10],0
       je        short M26_L10
M26_L13:
       mov       rdi,r15
       mov       rsi,[rbp-0E8]
       call      qword ptr [7FB978067270]
       jmp       near ptr M26_L10
M26_L14:
       mov       rdi,rsi
       mov       rsi,7FB977FB7240
       call      qword ptr [7FB97702F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       jmp       near ptr M26_L00
M26_L15:
       mov       rdi,rax
       mov       rsi,7FB977FB7EB8
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rcx,rdi
       jmp       near ptr M26_L01
M26_L16:
       mov       rdi,rcx
       mov       rsi,7FB977FB8118
       call      qword ptr [7FB97702F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r15,rax
       jmp       near ptr M26_L02
M26_L17:
       mov       edi,4
       call      qword ptr [7FB9780665E0]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       near ptr M26_L03
M26_L18:
       mov       r15,[rbp-60]
       test      r15,r15
       jne       short M26_L19
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       call      qword ptr [7FB978067288]
       mov       [rbp-60],r15
M26_L19:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0A0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-0B0]
       vmovdqu   ymmword ptr [rbp-90],ymm0
       jmp       near ptr M26_L11
       push      rax
       mov       rsi,[rbp-0F0]
       mov       rax,[rbp-0E0]
       cmp       rsi,[rax+10]
       je        short M26_L20
       lea       rdi,[rax+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-0E0]
M26_L20:
       mov       rbx,[rax+8]
       mov       rsi,[rbp-0E8]
       cmp       rsi,rbx
       je        short M26_L23
       lea       rdi,[rax+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      rbx,rbx
       je        short M26_L21
       cmp       qword ptr [rbx+10],0
       jne       short M26_L22
M26_L21:
       cmp       qword ptr [rbp-0E8],0
       je        short M26_L23
       mov       rsi,[rbp-0E8]
       cmp       qword ptr [rsi+10],0
       je        short M26_L23
M26_L22:
       mov       rdi,rbx
       mov       rsi,[rbp-0E8]
       call      qword ptr [7FB978067270]
M26_L23:
       nop
       vzeroupper
       add       rsp,8
       ret
; Total bytes of code 814
```
```assembly
; System.Threading.Thread.InitializeCurrentThread()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,68
       lea       rbp,[rsp+90]
       xor       eax,eax
       mov       [rbp-30],rax
       lea       rdi,[rbp-30]
       mov       [rbp-90],rdi
       lea       rdi,[rbp-88]
       call      qword ptr [7FB976BCEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-90]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7FB976BCEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rbx,[rbp-30]
       call      qword ptr [7FB976BD0B98]
       lea       rdi,[rax+10]
       mov       rsi,[rbp-30]
       call      qword ptr [7FB976BCEEB8]; CORINFO_HELP_ASSIGN_REF
       mov       rax,rbx
       add       rsp,68
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 123
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7FB976BCEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7FB976BCEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       ebx,edi
       call      qword ptr [7FB976BE6AF0]; Precode of System.Threading.Thread.GetThreadStaticsBase()
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M29_L01
       cmp       [rax],edi
       jle       short M29_L03
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M29_L03
M29_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M29_L01:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M29_L02
       movsxd    rcx,ecx
       add       rax,rcx
       jmp       short M29_L00
M29_L02:
       cmp       [rax+4],ecx
       jle       short M29_L03
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M29_L03
       mov       rax,[rdi]
       test      rax,rax
       je        short M29_L03
       jmp       short M29_L00
M29_L03:
       mov       edi,ebx
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
; Total bytes of code 133
```
```assembly
; Kevlar.KevlarProperties.Clear()
       push      rbp
       push      rbx
       sub       rsp,18
       lea       rbp,[rsp+20]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       rbx,rdi
       cmp       qword ptr [rbx+10],0
       jne       short M30_L01
M30_L00:
       add       rsp,18
       pop       rbx
       pop       rbp
       ret
M30_L01:
       xor       edi,edi
       mov       [rbx+30],edi
       mov       rdi,[rbx+18]
       test      rdi,rdi
       je        short M30_L02
       mov       eax,[rdi+38]
       sub       eax,[rdi+40]
       cmp       eax,20
       jl        short M30_L02
       xor       edi,edi
       mov       [rbx+38],rdi
       mov       [rbx+40],rdi
       mov       [rbx+10],rdi
       mov       [rbx+18],rdi
       jmp       short M30_L00
M30_L02:
       mov       rdi,[rbx+10]
       mov       rax,[rdi]
       mov       rax,[rax+40]
       call      qword ptr [rax+28]
       cmp       qword ptr [rbx+18],0
       je        short M30_L00
       mov       rdi,[rbx+18]
       cmp       [rdi],edi
       call      qword ptr [7FB977FD75E8]
       mov       rdi,rax
       lea       rsi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7FB977FD7600]
       jmp       short M30_L04
M30_L03:
       mov       rdi,[rbp-18]
       mov       rax,[rbp-18]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+28]
M30_L04:
       lea       rdi,[rbp-20]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+ValueCollection+Enumerator
       call      qword ptr [7FB977FD7630]
       test      eax,eax
       jne       short M30_L03
       jmp       near ptr M30_L00
; Total bytes of code 186
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState.Reset()
       xor       eax,eax
       mov       [rdi+0C],eax
       mov       [rdi+10],eax
       ret
; Total bytes of code 9
```
```assembly
; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7FB977FD7C30]; Kevlar.KevlarProperties+AdditionalAttemptState.ReleaseReference()
       test      eax,eax
       je        short M32_L00
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      qword ptr [7FB977025710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7FB18D8013D0
       mov       rax,[rax]
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7FB977FD7C48]
M32_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 92
```
```assembly
; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,38
       lea       rbp,[rsp+60]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       [rbp-38],rax
       mov       rbx,rdi
       cmp       byte ptr [rbx+34],0
       jne       short M33_L02
M33_L00:
       mov       rdi,[rbx+28]
       mov       rax,[rbx+8]
       cmp       rdi,rax
       jne       short M33_L03
       cmp       dword ptr [rax+8],1
       jne       short M33_L04
M33_L01:
       mov       rax,[rbx+8]
       xor       ecx,ecx
       mov       [rax+0C],ecx
       mov       [rax+10],ecx
       add       rsp,38
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M33_L02:
       mov       rdi,[rbx+28]
       cmp       [rdi],edi
       call      qword ptr [7FB977FD74F8]
       mov       byte ptr [rbx+34],0
       jmp       short M33_L00
M33_L03:
       mov       rdi,[rbx+28]
       call      qword ptr [7FB977FD7510]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       jmp       near ptr M33_L53
M33_L04:
       mov       rdi,[rbx+8]
       call      qword ptr [7FB977FD7510]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7FB18D8013D0
       mov       r15,[rdi]
       cmp       byte ptr [r15+24],0
       je        near ptr M33_L31
       cmp       dword ptr [r15+1C],0
       je        short M33_L05
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7FB978066BE0]
M33_L05:
       lea       rdi,[r15+28]
       mov       rsi,[rdi]
       test      rsi,rsi
       jne       short M33_L06
       mov       rsi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7FB978066BF8]
       mov       rsi,rax
M33_L06:
       mov       rdi,rsi
       cmp       [rdi],edi
       call      qword ptr [7FB978066C10]
       mov       r14,rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7FB977025728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       cmp       byte ptr [7FB97603B1E8],0
       je        short M33_L09
       mov       edx,[r14+68]
       mov       rax,[r14+58]
       mov       r13,rax
       test      r13,r13
       je        short M33_L10
       xor       esi,esi
       mov       [r14+58],rsi
       cmp       [r14+68],edx
       jne       short M33_L07
       test      dl,1
       je        short M33_L08
M33_L07:
       mov       rdx,r13
       mov       rsi,r14
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7FB978066C28]
       mov       r13,rax
       test      r13,r13
       je        short M33_L10
M33_L08:
       jmp       near ptr M33_L28
M33_L09:
       cmp       qword ptr [r14+58],0
       je        short M33_L10
       lea       rdi,[r14+58]
       test      rdi,rdi
       je        near ptr M33_L44
       xor       esi,esi
       call      00007FB9F5474040
       mov       r13,rax
       test      r13,r13
       jne       short M33_L08
M33_L10:
       cmp       byte ptr [r14+6C],0
       jne       short M33_L11
       mov       byte ptr [r14+6C],1
M33_L11:
       mov       r13,[r15+10]
       xor       r14d,r14d
       test      r13,r13
       jne       near ptr M33_L18
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r14d,[rax+10]
       test      r14d,r14d
       jne       short M33_L13
M33_L12:
       mov       rdi,7FB97603B1E0
       mov       eax,1
       mov       r14d,eax
       lock xadd [rdi],r14d
       inc       r14d
       je        short M33_L12
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r14d
M33_L13:
       dec       r14d
       imul      edi,r14d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M33_L14
       mov       r14d,edi
       mov       edx,[r15+20]
       imul      r14,rdx
       shr       r14,20
       jmp       short M33_L15
M33_L14:
       and       edi,[r15+18]
       mov       r14d,edi
M33_L15:
       mov       rdi,[r15+8]
       lea       edx,[r14*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M33_L54
       lea       rdi,[rdi+rdx*8+10]
       mov       r12,[rdi]
       test      r12,r12
       je        short M33_L16
       mov       rdx,r12
       xor       esi,esi
       call      00007FB9F5474060
       cmp       rax,r12
       je        short M33_L17
M33_L16:
       xor       r12d,r12d
M33_L17:
       mov       [rbp-30],r12
       jmp       near ptr M33_L24
M33_L18:
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M33_L20
M33_L19:
       mov       rdi,7FB97603B1F0
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M33_L19
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M33_L20:
       dec       r12d
       cmp       dword ptr [r13+18],0
       jl        short M33_L21
       and       r12d,[r13+18]
       jmp       short M33_L22
M33_L21:
       mov       rdi,[r13+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r13+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
M33_L22:
       mov       rdi,[r13+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M33_L54
       mov       edx,r12d
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-40],rax
       mov       rcx,[rax+50]
       mov       [rbp-48],rcx
       test      rcx,rcx
       je        short M33_L23
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M33_L44
       mov       rdx,rcx
       xor       esi,esi
       call      00007FB9F5474060
       mov       rcx,[rbp-48]
       cmp       rax,rcx
       mov       rax,[rbp-40]
       jne       short M33_L23
       mov       [rbp-30],rcx
       jmp       short M33_L24
M33_L23:
       lea       rdx,[rbp-30]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7FB977ABDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M33_L24
       lea       rdx,[rbp-30]
       mov       rdi,r13
       mov       esi,r12d
       call      qword ptr [7FB977ABDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M33_L24:
       mov       r12,[rbp-30]
       cmp       qword ptr [rbp-30],0
       jne       short M33_L26
       test      r13,r13
       je        short M33_L25
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       dword ptr [rax+8],1
       mov       r13,rax
       jmp       short M33_L27
M33_L25:
       mov       rdi,r15
       mov       esi,r14d
       call      qword ptr [7FB978066C40]
       mov       r12,rax
M33_L26:
       mov       r13,r12
M33_L27:
       xor       edi,edi
       mov       [rbp-30],rdi
M33_L28:
       cmp       dword ptr [r15+1C],0
       jne       short M33_L29
       mov       rsi,r13
       jmp       short M33_L30
M33_L29:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r13
       mov       r11,7FB976040500
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7FB978066BE0]
       mov       rsi,rax
M33_L30:
       jmp       near ptr M33_L52
M33_L31:
       cmp       dword ptr [r15+1C],0
       je        short M33_L32
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7FB978066BE0]
M33_L32:
       mov       r14,[r15+10]
       xor       r13d,r13d
       test      r14,r14
       jne       near ptr M33_L39
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M33_L34
M33_L33:
       mov       rdi,7FB97603B1E0
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M33_L33
       mov       edi,3C
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M33_L34:
       dec       r13d
       imul      edi,r13d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M33_L35
       mov       r13d,edi
       mov       edx,[r15+20]
       imul      r13,rdx
       shr       r13,20
       jmp       short M33_L36
M33_L35:
       and       edi,[r15+18]
       mov       r13d,edi
M33_L36:
       mov       rdi,[r15+8]
       lea       edx,[r13*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M33_L54
       lea       rdi,[rdi+rdx*8+10]
       mov       r12,[rdi]
       test      r12,r12
       je        short M33_L37
       mov       rdx,r12
       xor       esi,esi
       call      00007FB9F5474060
       cmp       rax,r12
       je        short M33_L38
M33_L37:
       xor       r12d,r12d
M33_L38:
       mov       [rbp-38],r12
       jmp       near ptr M33_L47
M33_L39:
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M33_L41
M33_L40:
       mov       rdi,7FB97603B1F0
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M33_L40
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M33_L41:
       dec       r12d
       cmp       dword ptr [r14+18],0
       jl        short M33_L42
       and       r12d,[r14+18]
       jmp       short M33_L43
M33_L42:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
M33_L43:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M33_L54
       mov       edx,r12d
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-50],rax
       mov       rcx,[rax+50]
       mov       [rbp-58],rcx
       test      rcx,rcx
       je        short M33_L46
       lea       rdi,[rax+50]
       test      rdi,rdi
       jne       short M33_L45
M33_L44:
       call      qword ptr [7FB9780664C0]
       int       3
M33_L45:
       mov       rdx,rcx
       xor       esi,esi
       call      00007FB9F5474060
       mov       rdx,[rbp-58]
       cmp       rax,rdx
       mov       rax,[rbp-50]
       jne       short M33_L46
       mov       [rbp-38],rdx
       jmp       short M33_L47
M33_L46:
       lea       rdx,[rbp-38]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7FB977ABDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M33_L47
       lea       rdx,[rbp-38]
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7FB977ABDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M33_L47:
       mov       r12,[rbp-38]
       cmp       qword ptr [rbp-38],0
       jne       short M33_L49
       test      r14,r14
       je        short M33_L48
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       r14,rax
       mov       dword ptr [r14+8],1
       jmp       short M33_L50
M33_L48:
       mov       rdi,r15
       mov       esi,r13d
       call      qword ptr [7FB978066C40]
       mov       r12,rax
M33_L49:
       mov       r14,r12
M33_L50:
       xor       edi,edi
       mov       [rbp-38],rdi
       cmp       dword ptr [r15+1C],0
       jne       short M33_L51
       mov       rsi,r14
       jmp       short M33_L52
M33_L51:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7FB976040508
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7FB978066BE0]
       mov       rsi,rax
M33_L52:
       lea       rdi,[rbx+8]
       call      CORINFO_HELP_ASSIGN_REF
M33_L53:
       mov       rsi,[rbx+8]
       lea       rdi,[rbx+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M33_L01
M33_L54:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 1539
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+30]
       mov       [rbp-28],rdi
       mov       rbx,rdi
       mov       r15,rdx
       mov       rdi,[rbx+8]
       cmp       esi,[rdi+8]
       jae       short M34_L02
       mov       edx,esi
       mov       r14,[rdi+rdx*8+10]
       mov       r13,[r14+50]
       test      r13,r13
       je        short M34_L01
       lea       rdi,[r14+50]
       test      rdi,rdi
       je        short M34_L00
       mov       rdx,r13
       xor       esi,esi
       call      00007FB9F5474060
       cmp       rax,r13
       jne       short M34_L01
       mov       rdi,r15
       mov       rsi,r13
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       eax,1
       add       rsp,10
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M34_L00:
       call      qword ptr [7FB9780664C0]
       int       3
M34_L01:
       mov       rdi,[rbx]
       mov       rsi,r14
       mov       rdx,r15
       add       rsp,10
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7FB977ABDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
M34_L02:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 145
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7FB976BD4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7FB976BCEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7FB976BDF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M35_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M35_L00
       mov       rsi,rax
       call      qword ptr [7FB976BCEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M35_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,0A0
       vzeroupper
       lea       rbp,[rsp+0C0]
       xor       eax,eax
       mov       [rbp-0B8],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqa   xmmword ptr [rbp-30],xmm8
       mov       rbx,rdi
       mov       r15,rsi
       mov       r13d,edx
       mov       r14,rcx
       test      rbx,rbx
       jne       short M36_L01
M36_L00:
       add       rsp,0A0
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M36_L01:
       mov       rdi,7FB18D800BA0
       mov       rdi,[rdi]
       call      qword ptr [7FB977ABEAD8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        short M36_L00
       lea       rdi,[rbp-0B0]
       mov       rsi,r15
       call      qword ptr [7FB977FD7330]
       mov       rdx,7FB96CA0B6A8
       mov       rdi,7FB96CA0B680
       test      r13b,r13b
       cmove     rdx,rdi
       lea       rdi,[rbp-0B0]
       mov       rsi,7FB96CA0B638
       call      qword ptr [7FB977FD7348]
       call      00007FB977018AE0
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7FB978067048]
       mov       [rbp-0B8],rax
       lea       rdi,[rbp-0B8]
       call      qword ptr [7FB977FD7378]
       mov       rdi,7FB18D800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-0B0]
       mov       rdx,r14
       call      qword ptr [7FB977FD7390]
       jmp       near ptr M36_L00
; Total bytes of code 264
```
```assembly
; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,90
       lea       rbp,[rsp+0A0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0A0],ymm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       mov       rax,rdi
       mov       r15d,esi
       mov       rbx,rdx
       mov       rdi,7FB18D800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       short M37_L01
M37_L00:
       add       rsp,90
       pop       rbx
       pop       r15
       pop       rbp
       ret
M37_L01:
       lea       rdi,[rbp-0A0]
       mov       rsi,rax
       call      qword ptr [7FB977FD7330]
       mov       rdx,7FB96CA0B6A8
       mov       rdi,7FB96CA0B680
       test      r15b,r15b
       cmove     rdx,rdi
       lea       rdi,[rbp-0A0]
       mov       rsi,7FB96CA0B638
       call      qword ptr [7FB977FD7348]
       mov       rdi,7FB18D800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-0A0]
       mov       rcx,rbx
       mov       esi,1
       call      qword ptr [7FB977FD73A8]
       jmp       short M37_L00
; Total bytes of code 199
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-50],rcx
       mov       dword ptr [rbp-70],3E8
M38_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M38_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M38_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7FB977ABDE48]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-50]
       mov       [rcx],eax
       mov       rax,[rbp-50]
       cmp       dword ptr [rax],0FFFFFFFF
       jne       short M38_L02
       mov       rdi,7FB977EB7270
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,70
       pop       rbp
       ret
M38_L02:
       mov       rax,[rbp-50]
       mov       eax,[rax]
       mov       rcx,[rbp-48]
       cmp       eax,[rcx+8]
       jae       short M38_L04
       mov       edx,eax
       imul      rdx,10
       lea       rcx,[rcx+rdx+10]
       mov       eax,[rcx+8]
       mov       [rbp-5C],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-5C]
       call      qword ptr [7FB977ABDE60]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-68],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-68]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M38_L03
       mov       rdi,7FB977EB7274
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,70
       pop       rbp
       ret
M38_L03:
       mov       rdi,7FB977EB7278
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M38_L00
M38_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 269
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-4C],ecx
       mov       dword ptr [rbp-70],3E8
M39_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M39_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M39_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rax,[rbp-48]
       mov       ecx,[rbp-4C]
       cmp       ecx,[rax+8]
       jae       near ptr M39_L03
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       add       rax,8
       mov       [rbp-68],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7FB977ABDE48]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-68]
       mov       [rcx],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-4C]
       call      qword ptr [7FB977ABDE60]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-60],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-60]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M39_L02
       mov       rdi,7FB977EB84F0
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,70
       pop       rbp
       ret
M39_L02:
       mov       rdi,7FB977EB84F4
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M39_L00
M39_L03:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 235
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbx
       sub       rsp,10
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rbx,rdi
       mov       rdi,rbx
       call      qword ptr [7FB976BE9718]; Precode of System.Runtime.CompilerServices.InitHelpers.InitClassSlow(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rbx+20]
       mov       rax,[rax-10]
       mov       [rsp+8],rax
       mov       rax,[rsp+8]
       and       rax,0FFFFFFFFFFFFFFFE
       xor       ecx,ecx
       mov       [rsp+8],rcx
       add       rsp,10
       pop       rbx
       ret
; Total bytes of code 59
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rax,[rdi+20]
       mov       ebx,[rax-28]
       cmp       ebx,0FFFFFFFF
       je        near ptr M41_L04
       mov       rdi,7FB9F56A0D68
       mov       rax,7FB9F5F04820
       call      rax
       add       rax,8
       add       rax,0FFFFFFFFFFFFFFF8
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M41_L01
       cmp       [rax],edi
       jle       short M41_L03
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M41_L03
M41_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M41_L01:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M41_L02
       movsxd    rdi,ecx
       add       rax,rdi
       jmp       short M41_L00
M41_L02:
       cmp       [rax+4],ecx
       jle       short M41_L03
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M41_L03
       mov       rax,[rdi]
       test      rax,rax
       je        short M41_L03
       jmp       short M41_L00
M41_L03:
       mov       edi,ebx
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7FB978066490]
M41_L04:
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7FB977ABDD88]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 179
```
```assembly
; Kevlar.KevlarProperties..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7FB977FD69D0]; Kevlar.KevlarProperties+AdditionalAttemptState..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-8]
       call      qword ptr [7FB97702C240]; System.Object..ctor()
       mov       rax,[rbp-8]
       mov       rsi,[rax+8]
       mov       rax,[rbp-8]
       lea       rdi,[rax+28]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 104
```
```assembly
; System.Object..ctor()
       ret
; Total bytes of code 1
```
```assembly
; System.TimeProvider.get_System()
       mov       rax,7FB18D800B00
       mov       rax,[rax]
       ret
; Total bytes of code 14
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbx
       sub       rsp,10
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rbx,rdi
       mov       rdi,rbx
       call      qword ptr [7FB976BE9718]; Precode of System.Runtime.CompilerServices.InitHelpers.InitClassSlow(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rbx+20]
       mov       rax,[rax-18]
       mov       [rsp+8],rax
       mov       rax,[rsp+8]
       and       rax,0FFFFFFFFFFFFFFFE
       xor       ecx,ecx
       mov       [rsp+8],rcx
       add       rsp,10
       pop       rbx
       ret
; Total bytes of code 59
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState.ReleaseReference()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       call      qword ptr [7FB977FD7C60]; System.Threading.Interlocked.Decrement(Int32 ByRef)
       test      eax,eax
       sete      al
       movzx     eax,al
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 48
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       eax,[rbp-10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 27
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-1C],edx
       mov       rax,[rbp-18]
       sar       rax,20
       lea       esi,[rax+1]
       mov       rdi,[rbp-10]
       mov       edx,[rbp-1C]
       call      qword ptr [7FB97741E100]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 56
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       rsi,rdi
       lea       rdi,[rbp-30]
       mov       [rbp-94],rdi
       mov       [rbp-9C],rsi
       xor       edx,edx
       mov       [rbp-8C],edx
       lea       rdi,[rbp-88]
       call      qword ptr [7FB976BCEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       edx,[rbp-8C]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7FB976BCEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,[rbp-30]
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 131
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       dword ptr [rax+8],1
       mov       rdi,[rbp-8]
       call      qword ptr [7FB97702C240]; System.Object..ctor()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; System.Threading.Interlocked.Decrement(Int32 ByRef)
       mov       eax,0FFFFFFFF
       lock xadd [rdi],eax
       dec       eax
       ret
; Total bytes of code 12
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-10],edx
       movsxd    rax,dword ptr [rbp-0C]
       shl       rax,20
       mov       ecx,[rbp-10]
       or        rax,rcx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 40
```

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: B-candidate(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.9.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.9.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=10, LaunchCount=3, WarmupCount=5))

```assembly
; PoolContextProbe.NestedContext()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,48
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-48],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-40],xmm8
       mov       [rbp-30],rax
       mov       rdi,7F2979800AC0
       mov       rbx,[rdi]
       mov       rdi,7F2979800400
       mov       r15,[rdi]
       test      rbx,rbx
       je        near ptr M00_L04
M00_L00:
       mov       rdi,7F2979800AF0
       mov       r14,[rdi]
       test      r14,r14
       je        near ptr M00_L05
M00_L01:
       mov       rdi,7F2979800AF8
       mov       r13,[rdi]
       test      r13,r13
       je        near ptr M00_L06
M00_L02:
       mov       rax,[r15+38]
       test      rax,rax
       jne       near ptr M00_L07
       cmp       byte ptr [r15+48],0
       jne       near ptr M00_L08
       mov       r12,[r15+10]
       xor       edi,edi
       test      rdi,rdi
       cmove     rdi,r15
       mov       rdi,[rdi+20]
       mov       rax,7F2979800B00
       test      rdi,rdi
       cmove     rdi,[rax]
       mov       [rbp-50],rdi
       mov       rax,[r15+38]
       test      rax,rax
       jne       near ptr M00_L09
       mov       rdi,[rbp-50]
       mov       rcx,[r15+40]
M00_L03:
       mov       [rsp],r13
       xor       esi,esi
       mov       [rsp+8],rsi
       mov       [rsp+10],rsi
       mov       rsi,r12
       mov       rdx,rdi
       mov       r8,rbx
       mov       r9,r14
       mov       rdi,7F31640DE488
       call      qword ptr [7F3163CDE6B8]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       mov       [rbp-48],rax
       mov       [rbp-40],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-48]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       mov       rax,[rbp-38]
       mov       rdx,[rbp-30]
       add       rsp,48
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M00_L04:
       mov       rdi,offset MT_System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rsi,7F2979800AA8
       mov       rsi,[rsi]
       mov       rdi,rbx
       mov       rdx,offset PoolContextProbe+<>c.<NestedContext>b__6_0(Kevlar.KevlarContext)
       call      qword ptr [7F3163246E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F2979800AC0
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L00
M00_L05:
       mov       rdi,offset MT_System.Action<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarProperties>
       call      CORINFO_HELP_NEWSFAST
       mov       r14,rax
       mov       rsi,7F2979800AE8
       mov       rsi,[rsi]
       mov       rdi,r14
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       call      qword ptr [7F3163246E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F2979800AF0
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L01
M00_L06:
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r13,rax
       mov       rsi,7F2979800AE8
       mov       rsi,[rsi]
       mov       rdi,r13
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F3163246E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F2979800AF8
       mov       rsi,r13
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M00_L02
M00_L07:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       r8,r13
       mov       rdx,rbx
       mov       rcx,r14
       mov       rsi,7F31640DCB18
       xor       r9d,r9d
       cmp       [rdi],edi
       add       rsp,48
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F3163CDE460]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
M00_L08:
       call      qword ptr [7F3163CDE628]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M00_L09:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F3163CDE610]; Kevlar.Shield.get_Name()
       mov       rcx,rax
       mov       rdi,[rbp-50]
       jmp       near ptr M00_L03
; Total bytes of code 604
```
```assembly
; BenchmarkDotNet.Helpers.AwaitHelper.GetResult[[System.Int32, System.Private.CoreLib]](System.Threading.Tasks.ValueTask`1<Int32>)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp-48],rax
       mov       [rbp-40],rax
       mov       [rbp-38],rdi
       mov       [rbp-30],rsi
       mov       rbx,rdi
       mov       r15d,esi
       movsx     r14,word ptr [rbp-2C]
       test      rbx,rbx
       je        near ptr M01_L11
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<System.Int32>
       call      qword ptr [7F3163246838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r13,rax
       mov       rax,r13
       test      rax,rax
       jne       near ptr M01_L05
       mov       rdi,offset MT_Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource
       cmp       [rbx],rdi
       je        short M01_L02
       mov       rdi,rbx
       mov       esi,r14d
       mov       r11,7F3162260698
       call      qword ptr [r11]
M01_L00:
       test      eax,eax
       je        near ptr M01_L15
M01_L01:
       test      r13,r13
       jne       near ptr M01_L09
       mov       rdi,offset MT_Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource
       cmp       [rbx],rdi
       je        short M01_L06
       mov       rdi,rbx
       mov       esi,r14d
       mov       r11,7F31622606A0
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M01_L02:
       lea       rsi,[rbx+40]
       movsx     rdi,word ptr [rsi+28]
       cmp       r14d,edi
       jne       near ptr M01_L12
       cmp       qword ptr [rsi],0
       jne       near ptr M01_L13
M01_L03:
       xor       r12d,r12d
M01_L04:
       mov       eax,r12d
       jmp       short M01_L00
M01_L05:
       test      dword ptr [rax+34],1600000
       jne       short M01_L01
       jmp       near ptr M01_L15
M01_L06:
       mov       [rbp-50],rbx
       lea       rdi,[rbx+40]
       movsx     rsi,word ptr [rdi+28]
       cmp       r14d,esi
       jne       short M01_L07
       cmp       byte ptr [rdi+2A],0
       je        short M01_L07
       cmp       qword ptr [rdi+18],0
       jne       short M01_L07
       mov       r15,[rdi+20]
       jmp       short M01_L08
M01_L07:
       call      qword ptr [7F31642865B0]
       int       3
M01_L08:
       lea       r13,[rbx+40]
       inc       esi
       mov       [r13+28],si
       xor       edi,edi
       mov       [r13],rdi
       mov       [r13+8],rdi
       mov       [r13+10],rdi
       mov       [r13+18],rdi
       mov       [r13+20],rdi
       mov       byte ptr [r13+2A],0
       mov       rdi,[rbx+8]
       lea       rdi,[rdi+20]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M01_L11
M01_L09:
       mov       edi,[r13+34]
       and       edi,11000000
       cmp       edi,1000000
       jne       near ptr M01_L16
M01_L10:
       mov       r15d,[r13+38]
M01_L11:
       mov       eax,r15d
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M01_L12:
       call      qword ptr [7F3164286538]
       int       3
M01_L13:
       cmp       byte ptr [rsi+2A],0
       je        near ptr M01_L03
       cmp       qword ptr [rsi+18],0
       je        short M01_L14
       mov       rsi,[rsi+18]
       mov       rsi,[rsi+8]
       mov       rdi,offset MT_System.OperationCanceledException
       call      qword ptr [7F3163246838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r12d,3
       mov       ecx,2
       test      rax,rax
       cmove     r12d,ecx
       jmp       near ptr M01_L04
M01_L14:
       mov       r12d,1
       jmp       near ptr M01_L04
M01_L15:
       mov       [rbp-48],rbx
       mov       [rbp-40],r15d
       mov       [rbp-3C],r14w
       call      qword ptr [7F31641FFBB8]
       mov       rdi,rax
       mov       rsi,[rbp-48]
       mov       rdx,[rbp-40]
       cmp       [rdi],edi
       call      qword ptr [7F31641FFB88]
       jmp       near ptr M01_L01
M01_L16:
       mov       rdi,r13
       xor       esi,esi
       call      qword ptr [7F3164286598]
       jmp       near ptr M01_L10
       push      rax
       mov       rsi,[rbp-50]
       lea       r13,[rsi+40]
       inc       word ptr [r13+28]
       xor       edi,edi
       mov       [r13],rdi
       mov       [r13+8],rdi
       mov       [r13+10],rdi
       mov       [r13+18],rdi
       mov       [r13+20],rdi
       mov       byte ptr [r13+2A],0
       mov       rdi,[rsi+8]
       lea       rdi,[rdi+20]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,8
       ret
; Total bytes of code 585
```
```assembly
; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,2D8
       vzeroupper
       lea       rbp,[rsp+300]
       xor       eax,eax
       mov       [rbp-238],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-230],xmm8
       mov       rax,0FFFFFFFFFFFFFE20
M02_L00:
       vmovdqa   xmmword ptr [rbp+rax-40],xmm8
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       add       rax,30
       jne       short M02_L00
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-248],r8
       mov       r13,rsi
       mov       r14,rdx
       mov       rbx,rcx
       mov       r15,r9
       mov       r12,[rbp+20]
       mov       rax,7F2979800BA0
       mov       rax,[rax]
       mov       rax,[rax+8]
       cmp       qword ptr [rax+8],0
       jne       near ptr M02_L34
       xor       edi,edi
M02_L01:
       mov       [rbp-40],rdi
       test      r12,r12
       jne       near ptr M02_L35
M02_L02:
       mov       rdi,7F29798013C0
       mov       rax,[rdi]
       mov       [rbp-268],rax
       cmp       byte ptr [rax+24],0
       jne       near ptr M02_L58
       cmp       dword ptr [rax+1C],0
       jne       near ptr M02_L88
M02_L03:
       mov       rax,[rbp-268]
       mov       rcx,[rax+10]
       mov       [rbp-2B0],rcx
       xor       edx,edx
       mov       [rbp-0AC],edx
       test      rcx,rcx
       je        near ptr M02_L89
       mov       rdi,7F31E18A0D68
       mov       rsi,7F31E21B6820
       call      rsi
       add       rax,40
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M02_L98
M02_L04:
       dec       eax
       mov       rcx,[rbp-2B0]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M02_L99
       and       r8d,eax
M02_L05:
       mov       eax,r8d
       mov       [rbp-0BC],eax
       mov       rdi,[rcx+8]
       cmp       eax,[rdi+8]
       jae       near ptr M02_L136
       mov       edx,eax
       mov       r8,[rdi+rdx*8+10]
       mov       [rbp-2C0],r8
       mov       r9,[r8+50]
       mov       [rbp-2C8],r9
       test      r9,r9
       mov       eax,[rbp-0BC]
       mov       rcx,[rbp-2B0]
       jne       near ptr M02_L14
M02_L06:
       lea       rdx,[r8+58]
       mov       rdi,[r8+48]
       mov       rsi,[rdx]
       mov       r9d,esi
       cmp       r9d,0FFFFFFFF
       je        near ptr M02_L102
M02_L07:
       cmp       r9d,[rdi+8]
       jae       near ptr M02_L136
       mov       r10d,r9d
       shl       r10,4
       mov       r11d,[rdi+r10+18]
       mov       rax,rsi
       sar       rax,20
       inc       eax
       cdqe
       shl       rax,20
       or        r11,rax
       mov       rax,rsi
       lock cmpxchg [rdx],r11
       cmp       rax,rsi
       jne       near ptr M02_L101
       mov       rax,[r8+48]
       mov       rdx,rax
       cmp       r9d,[rdx+8]
       jae       near ptr M02_L136
       mov       rdx,[rdx+r10+10]
       mov       [rbp-0B8],rdx
       cmp       r9d,[rax+8]
       jae       near ptr M02_L136
       lea       rdx,[rax+r10+10]
       xor       eax,eax
       mov       [rdx],rax
       add       r8,60
M02_L08:
       mov       rax,[r8]
       mov       [rbp-0C8],rax
       mov       [rdx+8],eax
       mov       rdi,rax
       sar       rdi,20
       inc       edi
       movsxd    rdi,edi
       shl       rdi,20
       mov       esi,r9d
       or        rdi,rsi
       lock cmpxchg [r8],rdi
       cmp       rax,[rbp-0C8]
       jne       short M02_L08
       cmp       qword ptr [rbp-0B8],0
       setne     dl
       movzx     edx,dl
       mov       eax,[rbp-0BC]
M02_L09:
       test      edx,edx
       je        near ptr M02_L103
       mov       eax,[rbp-0AC]
M02_L10:
       mov       rdx,[rbp-0B8]
       cmp       qword ptr [rbp-0B8],0
       je        near ptr M02_L104
M02_L11:
       mov       rax,rdx
M02_L12:
       xor       edi,edi
       mov       [rbp-0B8],rdi
       mov       rcx,[rbp-268]
       cmp       dword ptr [rcx+1C],0
       jne       near ptr M02_L106
       mov       rdx,rax
M02_L13:
       mov       [rbp-260],rdx
       lea       rdi,[rdx+68]
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       xor       edi,edi
       mov       r12,[rbp-260]
       mov       [r12+60],edi
       lea       rdi,[r12+38]
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r12+30]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       mov       rsi,0FFFFFFFF00000000
       mov       [r12+58],rsi
       xor       esi,esi
       mov       [r12+40],rsi
       mov       [rbp-250],r12
       jmp       short M02_L16
M02_L14:
       lea       rdi,[r8+50]
       test      rdi,rdi
       je        near ptr M02_L129
       mov       rdx,r9
       xor       esi,esi
       call      00007F31E1674060
       mov       rdx,[rbp-2C8]
       cmp       rax,rdx
       mov       eax,[rbp-0BC]
       mov       r8,[rbp-2C0]
       jne       near ptr M02_L100
       mov       [rbp-0B8],rdx
       mov       eax,[rbp-0AC]
       mov       rcx,[rbp-2B0]
       jmp       near ptr M02_L10
M02_L15:
       mov       rdi,7F316225B200
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M02_L15
       jmp       near ptr M02_L90
M02_L16:
       mov       rdx,[r12+8]
       mov       rsi,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       cmp       [r15+18],rsi
       je        short M02_L17
       mov       rsi,[rbp-248]
       mov       rdi,[r15+8]
       call      qword ptr [r15+18]
       nop
M02_L17:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M02_L29
M02_L18:
       lea       rdi,[rbp-60]
       mov       rdx,r13
       mov       rcx,[rbp-248]
       mov       r8,[rbp+10]
       mov       r9,r12
       call      qword ptr [7F3163CDE790]; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       rbx,[rbp-60]
       test      rbx,rbx
       jne       near ptr M02_L107
       mov       r14,[rbp-50]
       mov       r15d,[rbp-48]
M02_L19:
       test      r14,r14
       sete      bl
       movzx     ebx,bl
       mov       r13,[r12+30]
       cmp       qword ptr [rbp-40],0
       jne       near ptr M02_L112
M02_L20:
       mov       rsi,[r12+30]
       mov       rdi,7F2979800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M02_L113
M02_L21:
       cmp       byte ptr [r12+64],0
       jne       near ptr M02_L114
       mov       rbx,[r12+8]
M02_L22:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rax,[rsi+28]
       test      rax,rax
       je        near ptr M02_L30
       mov       rdi,rax
M02_L23:
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-248]
       mov       rcx,rbx
       call      qword ptr [7F3163CDE880]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,7F29798013C0
       mov       rbx,[rdi]
       cmp       byte ptr [rbx+24],0
       jne       near ptr M02_L115
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M02_L116
       mov       rdi,rbx
       mov       rsi,r12
       call      qword ptr [7F31641F7450]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItemGuarded(System.__Canon)
       test      eax,eax
       je        near ptr M02_L117
       mov       r12,[rbx+10]
       test      r12,r12
       je        near ptr M02_L124
       mov       rdi,7F31E18A0D68
       mov       rax,7F31E21B6820
       call      rax
       add       rax,40
       mov       r13d,[rax+10]
       test      r13d,r13d
       je        near ptr M02_L118
M02_L24:
       dec       r13d
       mov       eax,[r12+18]
       test      eax,eax
       jl        near ptr M02_L119
       and       r13d,eax
M02_L25:
       xor       eax,eax
       mov       [rbp-1F4],eax
       mov       rdi,[r12+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M02_L123
M02_L26:
       mov       rdi,[r12+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M02_L136
       mov       esi,r13d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-2D8],rcx
       cmp       qword ptr [rcx+50],0
       jne       near ptr M02_L31
       lea       rdi,[rcx+50]
       test      rdi,rdi
       je        near ptr M02_L129
       mov       rsi,[rbp-250]
       xor       edx,edx
       call      00007F31E1674060
       test      rax,rax
       mov       rcx,[rbp-2D8]
       jne       short M02_L31
M02_L27:
       cmp       dword ptr [rbx+1C],0
       jne       near ptr M02_L131
M02_L28:
       test      r14,r14
       jne       near ptr M02_L132
       xor       eax,eax
       mov       edx,r15d
       mov       rdi,1000000000000
       or        rdx,rdi
       add       rsp,2D8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L29:
       mov       rsi,7F31640E3E30
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M02_L18
M02_L30:
       mov       rsi,7F31640E4208
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M02_L23
M02_L31:
       lea       rdi,[rcx+60]
       mov       rsi,[rcx+48]
       mov       rdx,[rdi]
       mov       r8d,edx
       cmp       r8d,0FFFFFFFF
       je        near ptr M02_L121
       mov       r9d,[rsi+8]
M02_L32:
       cmp       r8d,r9d
       jae       near ptr M02_L136
       mov       r10d,r8d
       shl       r10,4
       mov       [rbp-240],r10
       mov       r11d,[rsi+r10+18]
       mov       rax,rdx
       sar       rax,20
       inc       eax
       cdqe
       shl       rax,20
       or        r11,rax
       mov       rax,rdx
       lock cmpxchg [rdi],r11
       cmp       rax,rdx
       jne       near ptr M02_L120
       mov       rdi,[rcx+48]
       mov       [rbp-1F8],r8d
       cmp       r8d,[rdi+8]
       jae       near ptr M02_L136
       lea       rdi,[rdi+r10+10]
       mov       rsi,[rbp-250]
       call      CORINFO_HELP_ASSIGN_REF
       mov       r13,[rbp-2D8]
       lea       rdi,[r13+58]
       mov       rcx,[r13+48]
       mov       r13d,[rbp-1F8]
M02_L33:
       mov       rax,[rdi]
       mov       [rbp-200],rax
       cmp       r13d,[rcx+8]
       jae       near ptr M02_L136
       mov       r12,[rbp-240]
       mov       [rcx+r12+18],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       esi,r13d
       or        rdx,rsi
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-200]
       jne       short M02_L33
       jmp       near ptr M02_L27
M02_L34:
       call      00007F3163238AE0
       mov       rdi,rax
       jmp       near ptr M02_L01
M02_L35:
       cmp       dword ptr [r12+20],0
       je        near ptr M02_L02
       mov       rsi,rbx
       xor       edx,edx
       call      qword ptr [7F3163CDE988]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       cmp       qword ptr [rbp+18],0
       je        near ptr M02_L57
       mov       rdi,r12
       mov       rcx,rbx
       mov       rdx,r14
       xor       esi,esi
       call      qword ptr [7F3163CDE9A0]; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       mov       rbx,rax
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       r15,[rsi+28]
       test      r15,r15
       je        short M02_L36
       jmp       short M02_L37
M02_L36:
       mov       rsi,7F31640E4208
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r15,rax
M02_L37:
       mov       rdi,rbx
       cmp       [rdi],edi
       call      qword ptr [7F3163CDE9B8]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       rcx,rax
       mov       rdi,r15
       mov       rdx,[rbp-248]
       mov       rsi,[rbp+18]
       call      qword ptr [7F3163CDE880]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,7F29798013C0
       mov       r15,[rdi]
       cmp       byte ptr [r15+24],0
       je        short M02_L38
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7F31641F73F0]
       jmp       near ptr M02_L57
M02_L38:
       cmp       dword ptr [r15+1C],0
       je        short M02_L39
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F31622606B8
       call      qword ptr [r11]
       jmp       near ptr M02_L57
M02_L39:
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7F31641F7450]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItemGuarded(System.__Canon)
       test      eax,eax
       jne       short M02_L40
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F31622606C0
       call      qword ptr [r11]
       jmp       near ptr M02_L57
M02_L40:
       mov       r14,[r15+10]
       test      r14,r14
       je        near ptr M02_L51
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M02_L42
M02_L41:
       mov       rdi,7F316225B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M02_L41
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M02_L42:
       dec       r13d
       cmp       dword ptr [r14+18],0
       jl        short M02_L43
       and       r13d,[r14+18]
       jmp       short M02_L44
M02_L43:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r14+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
M02_L44:
       xor       eax,eax
       jmp       short M02_L48
M02_L45:
       mov       rdi,[r14+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M02_L136
       mov       esi,r13d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-258],rcx
       cmp       qword ptr [rcx+50],0
       jne       short M02_L46
       lea       rdi,[rcx+50]
       test      rdi,rdi
       je        near ptr M02_L129
       mov       rsi,rbx
       xor       edx,edx
       call      00007F31E1674060
       test      rax,rax
       mov       rcx,[rbp-258]
       je        short M02_L49
M02_L46:
       mov       rdx,rbx
       mov       rsi,rcx
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F3163CDE058]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M02_L49
       inc       r13d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r13d
       jne       short M02_L47
       xor       r13d,r13d
M02_L47:
       mov       eax,[rbp-94]
       inc       eax
M02_L48:
       mov       rdi,[r14+8]
       mov       [rbp-94],eax
       cmp       [rdi+8],eax
       jg        near ptr M02_L45
       jmp       short M02_L50
M02_L49:
       cmp       dword ptr [r15+1C],0
       je        near ptr M02_L57
       jmp       near ptr M02_L56
M02_L50:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F31622606C8
       call      qword ptr [r11]
       jmp       short M02_L49
M02_L51:
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L53
M02_L52:
       mov       rdi,7F316225B200
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M02_L52
       mov       [rax+10],edi
M02_L53:
       dec       edi
       imul      r14d,edi,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M02_L54
       mov       r13d,r14d
       mov       r14d,[r15+20]
       imul      r14,r13
       shr       r14,20
       jmp       short M02_L55
M02_L54:
       and       r14d,[r15+18]
M02_L55:
       mov       rdi,[r15+8]
       lea       esi,[r14*8+8]
       cmp       esi,[rdi+8]
       jae       near ptr M02_L136
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       je        near ptr M02_L129
       mov       rsi,rbx
       call      00007F31E1674040
       test      rax,rax
       je        near ptr M02_L49
       mov       rdi,r15
       mov       rsi,rbx
       mov       rdx,rax
       mov       ecx,r14d
       call      qword ptr [7F31641F7660]
       jmp       near ptr M02_L49
M02_L56:
       mov       rdi,r15
       call      qword ptr [7F31641F7690]
M02_L57:
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rdi,rbx
       call      qword ptr [7F3164287588]
       lea       rdi,[rbx+70]
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,rbx
       call      qword ptr [7F3163CDEA00]
       mov       rdi,rax
       mov       esi,edx
       call      qword ptr [7F3163CDE910]
       mov       [rbp-228],rax
       mov       [rbp-220],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-228]
       vmovdqu   xmmword ptr [rbp-90],xmm0
       mov       rax,[rbp-90]
       mov       rdx,[rbp-88]
       add       rsp,2D8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L58:
       cmp       dword ptr [rax+1C],0
       je        short M02_L59
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F31641F68F8]
M02_L59:
       mov       rax,[rbp-268]
       lea       rdi,[rax+28]
       mov       rsi,[rdi]
       test      rsi,rsi
       jne       short M02_L60
       mov       rsi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7F3164286CD0]
       mov       rsi,rax
M02_L60:
       mov       rdi,rsi
       cmp       [rdi],edi
       call      qword ptr [7F3164286CE8]
       mov       [rbp-270],rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7F3163245728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       cmp       byte ptr [7F316225B208],0
       je        short M02_L64
       mov       rax,[rbp-270]
       mov       edx,[rax+68]
       mov       rcx,[rax+58]
       test      rcx,rcx
       je        near ptr M02_L67
       xor       esi,esi
       mov       [rax+58],rsi
       cmp       [rax+68],edx
       jne       short M02_L61
       test      dl,1
       je        short M02_L62
M02_L61:
       mov       rdx,rcx
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7F3164286D00]
       mov       rcx,rax
       mov       rax,rcx
       test      rax,rax
       mov       rcx,rax
       je        short M02_L63
M02_L62:
       mov       rax,rcx
       jmp       near ptr M02_L85
M02_L63:
       mov       rax,[rbp-270]
       jmp       short M02_L67
M02_L64:
       mov       rcx,[rbp-270]
       cmp       qword ptr [rcx+58],0
       je        short M02_L65
       lea       rdi,[rcx+58]
       test      rdi,rdi
       jne       short M02_L66
       jmp       near ptr M02_L129
M02_L65:
       mov       rax,rcx
       jmp       short M02_L67
M02_L66:
       xor       esi,esi
       call      00007F31E1674040
       test      rax,rax
       mov       rcx,rax
       jne       short M02_L62
       mov       rax,[rbp-270]
M02_L67:
       cmp       byte ptr [rax+6C],0
       jne       short M02_L68
       mov       byte ptr [rax+6C],1
M02_L68:
       mov       rax,[rbp-268]
       mov       rcx,[rax+10]
       mov       [rbp-280],rcx
       xor       edx,edx
       mov       [rbp-98],edx
       test      rcx,rcx
       jne       near ptr M02_L76
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L70
M02_L69:
       mov       rdi,7F316225B200
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M02_L69
       mov       [rax+10],edi
M02_L70:
       dec       edi
       imul      edi,9E3779B9
       mov       rax,[rbp-268]
       cmp       dword ptr [rax+18],0
       jge       short M02_L71
       mov       edx,edi
       mov       esi,[rax+20]
       imul      rdx,rsi
       shr       rdx,20
       jmp       short M02_L72
M02_L71:
       and       edi,[rax+18]
       mov       edx,edi
M02_L72:
       mov       ecx,edx
       mov       rdi,[rax+8]
       mov       [rbp-98],ecx
       lea       edx,[rcx*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M02_L136
       lea       rdi,[rdi+rdx*8+10]
       mov       r8,[rdi]
       mov       [rbp-288],r8
       test      r8,r8
       je        short M02_L73
       mov       rdx,r8
       xor       esi,esi
       call      00007F31E1674060
       mov       rdi,[rbp-288]
       cmp       rax,rdi
       je        short M02_L74
M02_L73:
       xor       esi,esi
       jmp       short M02_L75
M02_L74:
       mov       rsi,rdi
M02_L75:
       mov       [rbp-0A0],rsi
       jmp       near ptr M02_L82
M02_L76:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M02_L78
M02_L77:
       mov       rax,7F316225B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-0A4],eax
       test      eax,eax
       je        short M02_L77
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-0A4]
       mov       [rax+10],ecx
       mov       eax,ecx
M02_L78:
       dec       eax
       mov       rcx,[rbp-280]
       cmp       dword ptr [rcx+18],0
       jl        short M02_L79
       mov       r8d,eax
       and       r8d,[rcx+18]
       jmp       short M02_L80
M02_L79:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
M02_L80:
       mov       rdi,[rcx+8]
       cmp       r8d,[rdi+8]
       jae       near ptr M02_L136
       mov       [rbp-0A8],r8d
       mov       edx,r8d
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-290],rax
       mov       r9,[rax+50]
       mov       [rbp-298],r9
       test      r9,r9
       je        short M02_L81
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M02_L129
       mov       rdx,r9
       xor       esi,esi
       call      00007F31E1674060
       mov       rdx,[rbp-298]
       cmp       rax,rdx
       mov       rax,[rbp-290]
       jne       short M02_L81
       mov       [rbp-0A0],rdx
       jmp       short M02_L82
M02_L81:
       lea       rdx,[rbp-0A0]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F3163CDDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M02_L82
       lea       rdx,[rbp-0A0]
       mov       rdi,[rbp-280]
       mov       esi,[rbp-0A8]
       call      qword ptr [7F3163CDDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M02_L82:
       mov       rax,[rbp-0A0]
       cmp       qword ptr [rbp-0A0],0
       jne       short M02_L84
       cmp       qword ptr [rbp-280],0
       je        short M02_L83
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-2A0],rax
       mov       rdi,rax
       call      qword ptr [7F31641F69A0]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-2A0]
       jmp       short M02_L84
M02_L83:
       mov       rdi,[rbp-268]
       mov       esi,[rbp-98]
       call      qword ptr [7F31641F6958]
M02_L84:
       xor       edi,edi
       mov       [rbp-0A0],rdi
M02_L85:
       mov       rcx,[rbp-268]
       cmp       dword ptr [rcx+1C],0
       jne       short M02_L86
       jmp       short M02_L87
M02_L86:
       mov       [rbp-278],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-268]
       mov       dil,[rdi+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-278]
       mov       r11,7F31622606D0
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F31641F68F8]
M02_L87:
       mov       rdx,rax
       jmp       near ptr M02_L13
M02_L88:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F31641F68F8]
       jmp       near ptr M02_L03
M02_L89:
       mov       rdi,7F31E18A0D68
       mov       rdx,7F31E21B6820
       call      rdx
       add       rax,30
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L91
       jmp       near ptr M02_L15
M02_L90:
       mov       [rax+10],edi
M02_L91:
       dec       edi
       imul      edi,9E3779B9
       mov       rcx,[rbp-268]
       mov       edx,[rcx+18]
       test      edx,edx
       jge       short M02_L92
       mov       edx,edi
       mov       esi,[rcx+20]
       imul      rdx,rsi
       shr       rdx,20
       jmp       short M02_L93
M02_L92:
       and       edx,edi
M02_L93:
       mov       eax,edx
       mov       rdi,[rcx+8]
       mov       [rbp-0AC],eax
       lea       edx,[rax*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M02_L136
       lea       rdi,[rdi+rdx*8+10]
       mov       r8,[rdi]
       mov       [rbp-2B8],r8
       test      r8,r8
       je        short M02_L95
       mov       rdx,r8
       xor       esi,esi
       call      00007F31E1674060
       mov       rdi,[rbp-2B8]
       cmp       rax,rdi
       mov       eax,[rbp-0AC]
       je        short M02_L96
M02_L94:
       xor       esi,esi
       jmp       short M02_L97
M02_L95:
       mov       eax,[rbp-0AC]
       jmp       short M02_L94
M02_L96:
       mov       r8,rdi
       mov       rsi,r8
M02_L97:
       mov       [rbp-0B8],rsi
       mov       rcx,[rbp-2B0]
       jmp       near ptr M02_L10
M02_L98:
       mov       rax,7F316225B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-0C0],eax
       test      eax,eax
       je        short M02_L98
       mov       rdi,7F31E18A0D68
       mov       rcx,7F31E21B6820
       call      rcx
       add       rax,40
       mov       ecx,[rbp-0C0]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M02_L04
M02_L99:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M02_L05
M02_L100:
       mov       rcx,[rbp-2B0]
       jmp       near ptr M02_L06
M02_L101:
       mov       rsi,[rdx]
       mov       r9d,esi
       cmp       r9d,0FFFFFFFF
       jne       near ptr M02_L07
       mov       eax,[rbp-0BC]
M02_L102:
       xor       edx,edx
       mov       [rbp-0B8],rdx
       jmp       near ptr M02_L09
M02_L103:
       lea       rdx,[rbp-0B8]
       mov       rdi,rcx
       mov       esi,eax
       call      qword ptr [7F3163CDDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       mov       eax,[rbp-0AC]
       mov       rcx,[rbp-2B0]
       jmp       near ptr M02_L10
M02_L104:
       test      rcx,rcx
       je        short M02_L105
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-2D0],rax
       mov       rdi,rax
       call      qword ptr [7F31641F69A0]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-2D0]
       jmp       near ptr M02_L12
M02_L105:
       mov       rdi,[rbp-268]
       mov       esi,eax
       call      qword ptr [7F31641F6958]
       mov       rdx,rax
       jmp       near ptr M02_L11
M02_L106:
       mov       [rbp-2A8],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rcx,[rbp-268]
       mov       dil,[rcx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-2A8]
       mov       r11,7F31622606D8
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F31641F68F8]
       mov       rdx,rax
       jmp       near ptr M02_L13
M02_L107:
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F3163246838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       test      rax,rax
       je        short M02_L108
       mov       rdi,rax
       call      qword ptr [7F31641F7270]
       jmp       short M02_L109
M02_L108:
       mov       rdi,rbx
       movsx     rsi,word ptr [rbp-58]
       mov       r11,7F31622606E0
       call      qword ptr [r11]
       cmp       eax,1
       sete      al
       movzx     eax,al
M02_L109:
       test      eax,eax
       je        near ptr M02_L133
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F3163246838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r15,rax
       test      r15,r15
       je        short M02_L111
       mov       edi,[r15+34]
       and       edi,11000000
       cmp       edi,1000000
       je        short M02_L110
       mov       rdi,r15
       xor       esi,esi
       call      qword ptr [7F3164286598]
M02_L110:
       mov       r14,[r15+38]
       mov       r15d,[r15+40]
       jmp       near ptr M02_L19
M02_L111:
       mov       rdi,rbx
       movsx     rsi,word ptr [rbp-58]
       mov       r11,7F31622606E8
       call      qword ptr [r11]
       mov       r14,rax
       mov       r15d,edx
       jmp       near ptr M02_L19
M02_L112:
       mov       rdi,7F2979800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F3163CDEAD8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M02_L20
       lea       rdi,[rbp-158]
       mov       rsi,r13
       call      qword ptr [7F31641F7330]
       mov       rdx,7F3158A0B6A8
       mov       rdi,7F3158A0B680
       test      ebx,ebx
       cmove     rdx,rdi
       lea       rdi,[rbp-158]
       mov       rsi,7F3158A0B638
       call      qword ptr [7F31641F7348]
       call      00007F3163238AE0
       mov       rsi,rax
       mov       rdi,[rbp-40]
       call      qword ptr [7F3164286E20]
       mov       [rbp-160],rax
       lea       rdi,[rbp-160]
       call      qword ptr [7F31641F7378]
       mov       rdi,7F2979800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-158]
       mov       rdx,r12
       call      qword ptr [7F31641F7390]
       jmp       near ptr M02_L20
M02_L113:
       lea       rdi,[rbp-1F0]
       call      qword ptr [7F31641F7330]
       mov       rdx,7F3158A0B6A8
       mov       rdi,7F3158A0B680
       test      ebx,ebx
       cmove     rdx,rdi
       lea       rdi,[rbp-1F0]
       mov       rsi,7F3158A0B638
       call      qword ptr [7F31641F7348]
       mov       rdi,7F2979800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-1F0]
       mov       rcx,r12
       mov       esi,1
       call      qword ptr [7F31641F73A8]
       jmp       near ptr M02_L21
M02_L114:
       mov       rbx,[r12+10]
       jmp       near ptr M02_L22
M02_L115:
       mov       rdi,rbx
       mov       rsi,r12
       call      qword ptr [7F31641F73F0]
       jmp       near ptr M02_L28
M02_L116:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F31622606F0
       call      qword ptr [r11]
       jmp       near ptr M02_L28
M02_L117:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F31622606F8
       call      qword ptr [r11]
       jmp       near ptr M02_L28
M02_L118:
       mov       rdi,7F316225B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M02_L118
       mov       rdi,7F31E18A0D68
       mov       rax,7F31E21B6820
       call      rax
       add       rax,40
       mov       [rax+10],r13d
       jmp       near ptr M02_L24
M02_L119:
       mov       rdi,[r12+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r12+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
       jmp       near ptr M02_L25
M02_L120:
       mov       rdx,[rdi]
       mov       r8d,edx
       cmp       r8d,0FFFFFFFF
       jne       near ptr M02_L32
M02_L121:
       inc       r13d
       mov       rcx,[r12+8]
       cmp       [rcx+8],r13d
       jne       short M02_L122
       xor       r13d,r13d
M02_L122:
       mov       eax,[rbp-1F4]
       inc       eax
       cmp       [rcx+8],eax
       mov       [rbp-1F4],eax
       jg        near ptr M02_L26
M02_L123:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-250]
       mov       r11,7F3162260700
       call      qword ptr [r11]
       jmp       near ptr M02_L27
M02_L124:
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M02_L126
M02_L125:
       mov       rdi,7F316225B200
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M02_L125
       mov       [rax+10],edi
M02_L126:
       dec       edi
       imul      r13d,edi,9E3779B9
       cmp       dword ptr [rbx+18],0
       jge       short M02_L127
       mov       r12d,r13d
       mov       r13d,[rbx+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M02_L128
M02_L127:
       and       r13d,[rbx+18]
M02_L128:
       mov       rdi,[rbx+8]
       lea       esi,[r13*8+8]
       cmp       esi,[rdi+8]
       jae       near ptr M02_L136
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M02_L130
M02_L129:
       call      qword ptr [7F31642865F8]
       int       3
M02_L130:
       mov       rsi,[rbp-250]
       call      00007F31E1674040
       test      rax,rax
       je        near ptr M02_L27
       mov       rdi,rbx
       mov       rsi,[rbp-250]
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7F31641F7660]
       jmp       near ptr M02_L27
M02_L131:
       mov       rdi,rbx
       call      qword ptr [7F31641F7690]
       jmp       near ptr M02_L28
M02_L132:
       mov       rdi,r14
       mov       esi,r15d
       call      qword ptr [7F3163CDE910]
       mov       [rbp-238],rax
       mov       [rbp-230],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-238]
       vmovdqu   xmmword ptr [rbp-80],xmm0
       mov       rax,[rbp-80]
       mov       rdx,[rbp-78]
       add       rsp,2D8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L133:
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       rax,[rsi+20]
       test      rax,rax
       je        short M02_L134
       mov       rdi,rax
       jmp       short M02_L135
M02_L134:
       mov       rsi,7F31640E3FC8
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M02_L135:
       mov       [rbp-218],rdi
       lea       rdi,[rsp]
       lea       rsi,[rbp-60]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,[rbp-218]
       mov       rsi,r12
       mov       rdx,[rbp-248]
       mov       rcx,[rbp+18]
       mov       r8,[rbp-40]
       call      qword ptr [7F3163CDE838]
       mov       [rbp-210],rax
       mov       [rbp-208],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-210]
       vmovdqu   xmmword ptr [rbp-70],xmm0
       mov       rax,[rbp-70]
       mov       rdx,[rbp-68]
       add       rsp,2D8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M02_L136:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
       sub       rsp,28
       vzeroupper
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-250]
       xor       edx,edx
       call      qword ptr [7F3163CDEA78]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       mov       rdi,[rbp-38]
       mov       rsi,[rdi+18]
       mov       r13,[rsi+28]
       test      r13,r13
       je        short M02_L137
       jmp       short M02_L138
M02_L137:
       mov       rsi,7F31640E4208
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r13,rax
M02_L138:
       mov       rdi,[rbp-250]
       cmp       [rdi],edi
       call      qword ptr [7F3163CDE9B8]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       rcx,rax
       mov       rdi,r13
       mov       rdx,[rbp-248]
       mov       rsi,[rbp+18]
       call      qword ptr [7F3163CDE880]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-250]
       call      qword ptr [7F3163CDE9D0]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 5358
```
```assembly
; PoolContextProbe+<>c.<NestedContext>b__6_0(Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,278
       lea       rbp,[rsp+2A0]
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFE50
M03_L00:
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       add       rax,30
       jne       short M03_L00
       mov       [rbp-30],rax
       mov       rbx,rsi
       mov       rdi,7F2979800AB8
       mov       r15,[rdi]
       mov       rdi,7F2979800400
       mov       r14,[rdi]
       test      r15,r15
       je        near ptr M03_L31
M03_L01:
       mov       r13,rbx
       test      r13,r13
       je        near ptr M03_L32
       mov       rax,[r14+38]
       test      rax,rax
       jne       near ptr M03_L33
       cmp       byte ptr [r14+48],0
       jne       near ptr M03_L34
       mov       rbx,[r14+10]
       mov       r14,[r14+40]
       mov       rdi,7F2979801410
       mov       r12,[rdi]
       test      r12,r12
       je        near ptr M03_L35
M03_L02:
       mov       [rbp-1E8],r14
       mov       rcx,7F2979800BA0
       mov       rcx,[rcx]
       mov       rcx,[rcx+8]
       cmp       qword ptr [rcx+8],0
       jne       near ptr M03_L36
       xor       edi,edi
M03_L03:
       mov       [rbp-50],rdi
       mov       rdx,[r13+68]
       mov       [rbp-280],rdx
       test      rdx,rdx
       jne       near ptr M03_L37
M03_L04:
       mov       r14,[r13+68]
       mov       rdx,[r13+38]
       mov       [rbp-1F8],rdx
       mov       rdi,7F29798013C0
       mov       rsi,[rdi]
       mov       [rbp-208],rsi
       cmp       byte ptr [rsi+24],0
       jne       near ptr M03_L38
       cmp       dword ptr [rsi+1C],0
       jne       near ptr M03_L68
M03_L05:
       mov       rsi,[rbp-208]
       mov       r8,[rsi+10]
       mov       [rbp-250],r8
       xor       r9d,r9d
       mov       [rbp-9C],r9d
       test      r8,r8
       je        near ptr M03_L69
       mov       rdi,7F31E18A0D68
       mov       r10,7F31E21B6820
       call      r10
       add       rax,40
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M03_L78
M03_L06:
       dec       eax
       mov       rcx,[rbp-250]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M03_L79
       and       r8d,eax
M03_L07:
       mov       eax,r8d
       mov       [rbp-0AC],eax
       mov       rdi,[rcx+8]
       cmp       eax,[rdi+8]
       jae       near ptr M03_L100
       mov       edx,eax
       mov       r8,[rdi+rdx*8+10]
       mov       [rbp-260],r8
       mov       r9,[r8+50]
       mov       [rbp-268],r9
       test      r9,r9
       mov       eax,[rbp-0AC]
       mov       rcx,[rbp-250]
       jne       near ptr M03_L26
M03_L08:
       lea       rdx,[r8+58]
       mov       rdi,[r8+48]
       mov       rsi,[rdx]
       mov       r9d,esi
       cmp       r9d,0FFFFFFFF
       je        near ptr M03_L83
M03_L09:
       cmp       r9d,[rdi+8]
       jae       near ptr M03_L100
       mov       r10d,r9d
       shl       r10,4
       mov       r11d,[rdi+r10+18]
       mov       rax,rsi
       sar       rax,20
       inc       eax
       cdqe
       shl       rax,20
       or        r11,rax
       mov       rax,rsi
       lock cmpxchg [rdx],r11
       cmp       rax,rsi
       jne       near ptr M03_L82
       mov       rax,[r8+48]
       mov       rdx,rax
       cmp       r9d,[rdx+8]
       jae       near ptr M03_L100
       mov       rdx,[rdx+r10+10]
       mov       [rbp-0A8],rdx
       cmp       r9d,[rax+8]
       jae       near ptr M03_L100
       lea       rdx,[rax+r10+10]
       xor       eax,eax
       mov       [rdx],rax
       add       r8,60
M03_L10:
       mov       rax,[r8]
       mov       [rbp-0B8],rax
       mov       [rdx+8],eax
       mov       rdi,rax
       sar       rdi,20
       inc       edi
       movsxd    rdi,edi
       shl       rdi,20
       mov       esi,r9d
       or        rdi,rsi
       lock cmpxchg [r8],rdi
       cmp       rax,[rbp-0B8]
       jne       short M03_L10
       cmp       qword ptr [rbp-0A8],0
       setne     dl
       movzx     edx,dl
       mov       eax,[rbp-0AC]
M03_L11:
       test      edx,edx
       je        near ptr M03_L84
       mov       eax,[rbp-9C]
M03_L12:
       mov       rdx,[rbp-0A8]
       cmp       qword ptr [rbp-0A8],0
       je        near ptr M03_L85
M03_L13:
       mov       rax,rdx
M03_L14:
       xor       edi,edi
       mov       [rbp-0A8],rdi
       mov       rcx,[rbp-208]
       cmp       dword ptr [rcx+1C],0
       jne       near ptr M03_L87
       mov       rdx,rax
M03_L15:
       mov       [rbp-200],rdx
       lea       rdi,[rdx+68]
       mov       rsi,r14
       call      CORINFO_HELP_ASSIGN_REF
       xor       edi,edi
       mov       r14,[rbp-200]
       mov       [r14+60],edi
       lea       rdi,[r14+38]
       mov       rsi,[rbp-1F8]
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r14+30]
       mov       rsi,[rbp-1E8]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,0FFFFFFFF00000000
       mov       [r14+58],rdi
       xor       edi,edi
       mov       [r14+40],rdi
       cmp       qword ptr [r14+18],0
       je        near ptr M03_L88
M03_L16:
       mov       rdi,[r13+8]
       mov       rsi,[r14+18]
       cmp       [rdi],edi
       call      qword ptr [7F31641F7960]; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       mov       rdi,[r14+18]
       mov       rsi,[r14+8]
       cmp       [rdi],edi
       call      qword ptr [7F31641F7960]; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       mov       rdi,[r14+8]
       mov       rsi,[r13+8]
       cmp       [rdi],dil
       mov       rax,[rsi+28]
       add       rax,8
       lock inc  dword ptr [rax]
       mov       rsi,[rsi+28]
       lea       rdi,[rdi+28]
       call      CORINFO_HELP_ASSIGN_REF
       mov       byte ptr [r14+65],1
       mov       rdi,7F29798013E0
       mov       rax,[rdi]
       test      rax,rax
       je        near ptr M03_L89
M03_L17:
       mov       [rbp-0D8],rbx
       mov       [rbp-0D0],rax
       mov       [rbp-0C8],r15
       mov       [rbp-0C0],r12
       cmp       qword ptr [rbp-0D0],0
       je        near ptr M03_L90
       cmp       qword ptr [rbp-0D8],0
       jne       near ptr M03_L94
       mov       rbx,[rbp-0D0]
       mov       rdi,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       cmp       [rbx+18],rdi
       jne       near ptr M03_L93
       mov       rdi,[rbx+8]
       mov       rbx,[rbp-0C8]
       mov       r15,[rbp-0C0]
       mov       rdi,[rdi]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M03_L28
M03_L18:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-130],xmm0
       vmovdqu   xmmword ptr [rbp-128],xmm0
       mov       [rbp-118],rbx
       mov       [rbp-110],r15
       mov       [rbp-140],r14
       mov       dword ptr [rbp-138],0FFFFFFFF
       mov       rdi,[rsi+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M03_L29
M03_L19:
       mov       rsi,[rdi+18]
       mov       rax,[rsi+10]
       test      rax,rax
       je        near ptr M03_L30
       mov       rdi,rax
M03_L20:
       lea       rsi,[rbp-140]
       call      qword ptr [7F31641F6DF0]; System.Runtime.CompilerServices.AsyncMethodBuilderCore.Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       mov       rsi,[rbp-130]
       mov       rdx,7F29798013E8
       cmp       rsi,[rdx]
       jne       near ptr M03_L91
       mov       rsi,[rbp-128]
       mov       rdx,[rbp-120]
       lea       rdi,[rbp-1A0]
       call      qword ptr [7F31641F6B50]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.Outcome`1<Int32>)
       vmovdqu   ymm0,ymmword ptr [rbp-1A0]
       vmovdqu   ymmword ptr [rbp-160],ymm0
M03_L21:
       vmovdqu   ymm0,ymmword ptr [rbp-160]
       vmovdqu   ymmword ptr [rbp-0F8],ymm0
M03_L22:
       vmovdqu   ymm0,ymmword ptr [rbp-0F8]
       vmovdqu   ymmword ptr [rbp-70],ymm0
       mov       rbx,[rbp-70]
       test      rbx,rbx
       jne       near ptr M03_L95
M03_L23:
       lea       rdi,[rbp-70]
       call      qword ptr [7F3163CDEA48]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Result()
       mov       rbx,rax
       mov       r15d,edx
       test      rbx,rbx
       sete      dl
       movzx     edx,dl
       mov       rdi,[rbp-50]
       mov       rsi,[rbp-1E8]
       call      qword ptr [7F3163CDE988]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       mov       rdi,r14
       mov       rsi,r13
       call      qword ptr [7F31641F7930]; Kevlar.Internal.ShieldEngine.ReturnChildContext(Kevlar.KevlarContext, Kevlar.KevlarContext)
       test      rbx,rbx
       jne       near ptr M03_L98
       lea       rdi,[rbp-80]
       mov       esi,r15d
       call      qword ptr [7F3163CDEAA8]; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]]..ctor(Int32)
       vmovdqu   xmm0,xmmword ptr [rbp-80]
       vmovdqu   xmmword ptr [rbp-48],xmm0
M03_L24:
       vmovdqu   xmm0,xmmword ptr [rbp-48]
       vmovdqu   xmmword ptr [rbp-38],xmm0
M03_L25:
       mov       rax,[rbp-38]
       mov       rdx,[rbp-30]
       vzeroupper
       add       rsp,278
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M03_L26:
       lea       rdi,[r8+50]
       test      rdi,rdi
       je        near ptr M03_L80
       mov       rdx,r9
       xor       esi,esi
       call      00007F31E1674060
       mov       rdx,[rbp-268]
       cmp       rax,rdx
       mov       eax,[rbp-0AC]
       mov       r8,[rbp-260]
       jne       near ptr M03_L81
       mov       [rbp-0A8],rdx
       mov       eax,[rbp-9C]
       mov       rcx,[rbp-250]
       jmp       near ptr M03_L12
M03_L27:
       mov       rdi,7F316225B200
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M03_L27
       jmp       near ptr M03_L70
M03_L28:
       mov       rsi,7F31641D7240
       call      qword ptr [7F316324F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M03_L18
M03_L29:
       mov       rdi,rsi
       mov       rsi,7F31641D7EB8
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M03_L19
M03_L30:
       mov       rsi,7F31641D8118
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M03_L20
M03_L31:
       mov       rdi,offset MT_System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rsi,7F2979800AA8
       mov       rsi,[rsi]
       mov       rdi,r15
       mov       rdx,offset PoolContextProbe+<>c.<NestedContext>b__6_1(Kevlar.KevlarContext)
       call      qword ptr [7F3163246E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F2979800AB8
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M03_L01
M03_L32:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,910
       mov       rsi,7F3163D0E0F0
       call      qword ptr [7F316324EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F316392E2E0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M03_L33:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       rsi,rbx
       mov       rdx,r15
       cmp       [rdi],edi
       call      qword ptr [7F31641F76D8]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](Kevlar.KevlarContext, System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
       mov       [rbp-1E0],rax
       mov       [rbp-1D8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-1E0]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       jmp       near ptr M03_L25
M03_L34:
       call      qword ptr [7F3163CDE628]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M03_L35:
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       rsi,7F2979801408
       mov       rsi,[rsi]
       mov       rdi,r12
       mov       rdx,offset Kevlar.Shield+<>c__60`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__60_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F3163246E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F2979801410
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M03_L02
M03_L36:
       vzeroupper
       call      00007F3163238AE0
       mov       rdi,rax
       jmp       near ptr M03_L03
M03_L37:
       cmp       dword ptr [rdx+20],0
       je        near ptr M03_L04
       mov       rsi,r14
       xor       edx,edx
       call      qword ptr [7F3163CDE988]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rdi,rbx
       call      qword ptr [7F3164287588]
       lea       rdi,[rbx+70]
       mov       rsi,[rbp-280]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,rbx
       call      qword ptr [7F3163CDEA00]
       mov       rdi,rax
       mov       esi,edx
       call      qword ptr [7F3163CDE910]
       mov       [rbp-1D0],rax
       mov       [rbp-1C8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-1D0]
       vmovdqu   xmmword ptr [rbp-48],xmm0
       jmp       near ptr M03_L24
M03_L38:
       cmp       dword ptr [rsi+1C],0
       je        short M03_L39
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F31641F68F8]
M03_L39:
       mov       rsi,[rbp-208]
       lea       rdi,[rsi+28]
       mov       r8,[rdi]
       test      r8,r8
       jne       short M03_L40
       mov       rsi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7F3164286CD0]
       mov       r8,rax
M03_L40:
       mov       rdi,r8
       cmp       [rdi],edi
       call      qword ptr [7F3164286CE8]
       mov       [rbp-210],rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7F3163245728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       cmp       byte ptr [7F316225B208],0
       je        short M03_L44
       mov       rax,[rbp-210]
       mov       edx,[rax+68]
       mov       rcx,[rax+58]
       test      rcx,rcx
       je        near ptr M03_L47
       xor       esi,esi
       mov       [rax+58],rsi
       cmp       [rax+68],edx
       jne       short M03_L41
       test      dl,1
       je        short M03_L42
M03_L41:
       mov       rdx,rcx
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7F3164286D00]
       mov       rcx,rax
       mov       rax,rcx
       test      rax,rax
       mov       rcx,rax
       je        short M03_L43
M03_L42:
       mov       rax,rcx
       jmp       near ptr M03_L65
M03_L43:
       mov       rax,[rbp-210]
       jmp       short M03_L47
M03_L44:
       mov       rcx,[rbp-210]
       cmp       qword ptr [rcx+58],0
       je        short M03_L45
       lea       rdi,[rcx+58]
       test      rdi,rdi
       jne       short M03_L46
       jmp       near ptr M03_L80
M03_L45:
       mov       rax,rcx
       jmp       short M03_L47
M03_L46:
       xor       esi,esi
       call      00007F31E1674040
       test      rax,rax
       mov       rcx,rax
       jne       short M03_L42
       mov       rax,[rbp-210]
M03_L47:
       cmp       byte ptr [rax+6C],0
       jne       short M03_L48
       mov       byte ptr [rax+6C],1
M03_L48:
       mov       rax,[rbp-208]
       mov       rcx,[rax+10]
       mov       [rbp-220],rcx
       xor       edx,edx
       mov       [rbp-84],edx
       test      rcx,rcx
       jne       near ptr M03_L56
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M03_L50
M03_L49:
       mov       rdi,7F316225B200
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M03_L49
       mov       [rax+10],edi
M03_L50:
       dec       edi
       imul      edi,9E3779B9
       mov       rax,[rbp-208]
       cmp       dword ptr [rax+18],0
       jge       short M03_L51
       mov       edx,edi
       mov       esi,[rax+20]
       imul      rdx,rsi
       shr       rdx,20
       jmp       short M03_L52
M03_L51:
       and       edi,[rax+18]
       mov       edx,edi
M03_L52:
       mov       ecx,edx
       mov       rdi,[rax+8]
       mov       [rbp-84],ecx
       lea       edx,[rcx*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M03_L100
       lea       rdi,[rdi+rdx*8+10]
       mov       r8,[rdi]
       mov       [rbp-228],r8
       test      r8,r8
       je        short M03_L53
       mov       rdx,r8
       xor       esi,esi
       call      00007F31E1674060
       mov       rdi,[rbp-228]
       cmp       rax,rdi
       je        short M03_L54
M03_L53:
       xor       esi,esi
       jmp       short M03_L55
M03_L54:
       mov       rsi,rdi
M03_L55:
       mov       [rbp-90],rsi
       jmp       near ptr M03_L62
M03_L56:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M03_L58
M03_L57:
       mov       rax,7F316225B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-94],eax
       test      eax,eax
       je        short M03_L57
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-94]
       mov       [rax+10],ecx
       mov       eax,ecx
M03_L58:
       dec       eax
       mov       rcx,[rbp-220]
       cmp       dword ptr [rcx+18],0
       jl        short M03_L59
       mov       r8d,eax
       and       r8d,[rcx+18]
       jmp       short M03_L60
M03_L59:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
M03_L60:
       mov       rdi,[rcx+8]
       cmp       r8d,[rdi+8]
       jae       near ptr M03_L100
       mov       [rbp-98],r8d
       mov       edx,r8d
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-230],rax
       mov       r9,[rax+50]
       mov       [rbp-238],r9
       test      r9,r9
       je        short M03_L61
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M03_L80
       mov       rdx,r9
       xor       esi,esi
       call      00007F31E1674060
       mov       rdx,[rbp-238]
       cmp       rax,rdx
       mov       rax,[rbp-230]
       jne       short M03_L61
       mov       [rbp-90],rdx
       jmp       short M03_L62
M03_L61:
       lea       rdx,[rbp-90]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F3163CDDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M03_L62
       lea       rdx,[rbp-90]
       mov       rdi,[rbp-220]
       mov       esi,[rbp-98]
       call      qword ptr [7F3163CDDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M03_L62:
       mov       rax,[rbp-90]
       cmp       qword ptr [rbp-90],0
       jne       short M03_L64
       cmp       qword ptr [rbp-220],0
       je        short M03_L63
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-240],rax
       mov       rdi,rax
       call      qword ptr [7F31641F69A0]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-240]
       jmp       short M03_L64
M03_L63:
       mov       rdi,[rbp-208]
       mov       esi,[rbp-84]
       call      qword ptr [7F31641F6958]
M03_L64:
       xor       edi,edi
       mov       [rbp-90],rdi
M03_L65:
       mov       rcx,[rbp-208]
       cmp       dword ptr [rcx+1C],0
       jne       short M03_L66
       jmp       short M03_L67
M03_L66:
       mov       [rbp-218],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-208]
       mov       dil,[rdi+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-218]
       mov       r11,7F3162260708
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F31641F68F8]
M03_L67:
       mov       rdx,rax
       jmp       near ptr M03_L15
M03_L68:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F31641F68F8]
       jmp       near ptr M03_L05
M03_L69:
       mov       rdi,7F31E18A0D68
       mov       r9,7F31E21B6820
       call      r9
       add       rax,30
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M03_L71
       jmp       near ptr M03_L27
M03_L70:
       mov       [rax+10],edi
M03_L71:
       dec       edi
       imul      edi,9E3779B9
       mov       rcx,[rbp-208]
       mov       edx,[rcx+18]
       test      edx,edx
       jge       short M03_L72
       mov       r9d,edi
       mov       esi,[rcx+20]
       imul      r9,rsi
       shr       r9,20
       jmp       short M03_L73
M03_L72:
       mov       r9d,edi
       and       r9d,edx
M03_L73:
       mov       eax,r9d
       mov       rdi,[rcx+8]
       mov       [rbp-9C],eax
       lea       edx,[rax*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M03_L100
       lea       rdi,[rdi+rdx*8+10]
       mov       r8,[rdi]
       mov       [rbp-258],r8
       test      r8,r8
       je        short M03_L75
       mov       rdx,r8
       xor       esi,esi
       call      00007F31E1674060
       mov       rdi,[rbp-258]
       cmp       rax,rdi
       mov       eax,[rbp-9C]
       je        short M03_L76
M03_L74:
       xor       esi,esi
       jmp       short M03_L77
M03_L75:
       mov       eax,[rbp-9C]
       jmp       short M03_L74
M03_L76:
       mov       r8,rdi
       mov       rsi,r8
M03_L77:
       mov       [rbp-0A8],rsi
       mov       rcx,[rbp-250]
       jmp       near ptr M03_L12
M03_L78:
       mov       rax,7F316225B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-0B0],eax
       test      eax,eax
       je        short M03_L78
       mov       rdi,7F31E18A0D68
       mov       rcx,7F31E21B6820
       call      rcx
       add       rax,40
       mov       ecx,[rbp-0B0]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M03_L06
M03_L79:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M03_L07
M03_L80:
       call      qword ptr [7F31642865F8]
       int       3
M03_L81:
       mov       rcx,[rbp-250]
       jmp       near ptr M03_L08
M03_L82:
       mov       rsi,[rdx]
       mov       r9d,esi
       cmp       r9d,0FFFFFFFF
       jne       near ptr M03_L09
       mov       eax,[rbp-0AC]
M03_L83:
       xor       edx,edx
       mov       [rbp-0A8],rdx
       jmp       near ptr M03_L11
M03_L84:
       lea       rdx,[rbp-0A8]
       mov       rdi,rcx
       mov       esi,eax
       call      qword ptr [7F3163CDDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       mov       eax,[rbp-9C]
       mov       rcx,[rbp-250]
       jmp       near ptr M03_L12
M03_L85:
       test      rcx,rcx
       je        short M03_L86
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-270],rax
       mov       rdi,rax
       call      qword ptr [7F31641F69A0]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-270]
       jmp       near ptr M03_L14
M03_L86:
       mov       rdi,[rbp-208]
       mov       esi,eax
       call      qword ptr [7F31641F6958]
       mov       rdx,rax
       jmp       near ptr M03_L13
M03_L87:
       mov       [rbp-248],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rcx,[rbp-208]
       mov       dil,[rcx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-248]
       mov       r11,7F3162260710
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F31641F68F8]
       mov       rdx,rax
       jmp       near ptr M03_L15
M03_L88:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-1F0],rax
       mov       rdi,rax
       call      qword ptr [7F31641F69B8]; Kevlar.KevlarProperties..ctor()
       lea       rdi,[r14+18]
       mov       rsi,[rbp-1F0]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M03_L16
M03_L89:
       mov       rdi,offset MT_System.Func<Kevlar.Internal.ShieldEngine+ContextAsyncCallback<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, System.Int32>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<Kevlar.Outcome<System.Int32>>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-278],rax
       mov       rsi,7F29798013D8
       mov       rsi,[rsi]
       mov       rdi,rax
       mov       rdx,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       call      qword ptr [7F3163246E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F29798013E0
       mov       rsi,[rbp-278]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-278]
       jmp       near ptr M03_L17
M03_L90:
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rdi,rbx
       mov       rsi,7F3158A0B5D8
       call      qword ptr [7F3163925650]
       mov       rdi,rbx
       call      qword ptr [7F3163CDEA00]
       mov       byte ptr [rbp-0EE],1
       mov       [rbp-0E8],rax
       mov       [rbp-0E0],edx
       jmp       near ptr M03_L22
M03_L91:
       mov       rsi,[rbp-130]
       test      rsi,rsi
       jne       short M03_L92
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rdi,rbx
       call      qword ptr [7F3164286D78]
       mov       [rbp-130],rbx
       mov       rsi,rbx
M03_L92:
       lea       rdi,[rbp-180]
       call      qword ptr [7F31641F71E0]
       vmovdqu   ymm0,ymmword ptr [rbp-180]
       vmovdqu   ymmword ptr [rbp-160],ymm0
       jmp       near ptr M03_L21
M03_L93:
       mov       rdx,[rbp-0C8]
       mov       rcx,[rbp-0C0]
       lea       rsi,[rbp-0F8]
       mov       r8,r14
       mov       rdi,[rbx+8]
       call      qword ptr [rbx+18]
       jmp       near ptr M03_L22
M03_L94:
       lea       rdi,[rbp-0D8]
       lea       rsi,[rbp-0F8]
       mov       r8,r14
       mov       rcx,[rbp-0D8]
       mov       rdx,offset MT_Kevlar.Continuation<System.Int32, Kevlar.Internal.ShieldEngine+ContextAsyncCallback<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, System.Int32>>
       call      qword ptr [7F31641F6B68]
       jmp       near ptr M03_L22
M03_L95:
       mov       rsi,rbx
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F3163246838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       test      rax,rax
       je        short M03_L96
       mov       rdi,rax
       call      qword ptr [7F31641F7270]
       jmp       short M03_L97
M03_L96:
       mov       rdi,rbx
       movsx     rsi,word ptr [rbp-68]
       mov       r11,7F3162260718
       call      qword ptr [r11]
       cmp       eax,1
       sete      al
       movzx     eax,al
M03_L97:
       test      eax,eax
       je        short M03_L99
       jmp       near ptr M03_L23
M03_L98:
       mov       rdi,rbx
       mov       esi,r15d
       call      qword ptr [7F3163CDE910]
       mov       [rbp-1C0],rax
       mov       [rbp-1B8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-1C0]
       vmovdqu   xmmword ptr [rbp-48],xmm0
       jmp       near ptr M03_L24
M03_L99:
       lea       rdi,[rsp]
       lea       rsi,[rbp-70]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,r14
       mov       rsi,r13
       mov       rdx,[rbp-50]
       call      qword ptr [7F31641F7870]
       mov       [rbp-1B0],rax
       mov       [rbp-1A8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-1B0]
       vmovdqu   xmmword ptr [rbp-48],xmm0
       jmp       near ptr M03_L24
M03_L100:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 4097
```
```assembly
; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       push      r15
       push      r14
       push      rbx
       mov       rbx,rdi
       mov       r15,rsi
       mov       r14,rdx
       test      r15,r15
       je        short M04_L00
       mov       rdi,7F31643090DC
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdi,[rbx+8]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       [rbx+18],r14
       pop       rbx
       pop       r14
       pop       r15
       ret
M04_L00:
       mov       rdi,7F31643090D8
       call      CORINFO_HELP_COUNTPROFILE32
       call      qword ptr [7F316428E4F0]
       int       3
; Total bytes of code 78
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       ret
; Total bytes of code 1
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       rax,rsi
       mov       rsi,rdx
       mov       rdi,offset PoolContextProbe+<>c.<NestedContext>b__6_0(Kevlar.KevlarContext)
       cmp       [rax+18],rdi
       jne       short M06_L00
       mov       rdi,[rax+8]
       jmp       qword ptr [7F31641F76C0]; PoolContextProbe+<>c.<NestedContext>b__6_0(Kevlar.KevlarContext)
M06_L00:
       mov       rdi,[rax+8]
       jmp       qword ptr [rax+18]
; Total bytes of code 40
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
M07_L00:
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,58
       lea       rbp,[rsp+80]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       mov       [rbp-30],rsi
       mov       rbx,rsi
       mov       r13,rdx
       mov       r15,rcx
       mov       r14,r8
       mov       r12,r9
       test      r15,r15
       je        near ptr M07_L06
       test      r14,r14
       je        near ptr M07_L07
       mov       rax,[rdi+38]
       test      rax,rax
       jne       near ptr M07_L08
       cmp       byte ptr [rdi+48],0
       jne       near ptr M07_L09
       mov       rax,[rdi+10]
       mov       [rbp-58],rax
       xor       ecx,ecx
       test      rcx,rcx
       cmove     rcx,rdi
       mov       rcx,[rcx+20]
       mov       rdx,7F2979800B00
       test      rcx,rcx
       cmove     rcx,[rdx]
       mov       [rbp-60],rcx
       mov       rdx,[rdi+38]
       test      rdx,rdx
       jne       near ptr M07_L10
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rdi+40]
M07_L01:
       mov       rdi,[rbx+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        short M07_L04
M07_L02:
       mov       rdx,[rdi+18]
       mov       rdx,[rdx+18]
       test      rdx,rdx
       je        near ptr M07_L05
       mov       rdi,rdx
       mov       [rbp-68],rsi
M07_L03:
       mov       [rsp],r14
       xor       edx,edx
       mov       [rsp+8],rdx
       mov       [rsp+10],r12
       mov       rsi,rax
       mov       rdx,rcx
       mov       rcx,[rbp-68]
       mov       r8,r13
       mov       r9,r15
       call      qword ptr [7F3163CDE6B8]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       mov       [rbp-50],rax
       mov       [rbp-48],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-50]
       vmovdqu   xmmword ptr [rbp-40],xmm0
       mov       rax,[rbp-40]
       mov       rdx,[rbp-38]
       add       rsp,58
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M07_L04:
       mov       [rbp-60],rcx
       mov       [rbp-68],rsi
       mov       rdi,rbx
       mov       rsi,7F31640E35E0
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rbp-68]
       jmp       near ptr M07_L02
M07_L05:
       mov       [rbp-60],rcx
       mov       [rbp-68],rsi
       mov       rsi,7F31640E3998
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       jmp       near ptr M07_L03
M07_L06:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,92C
       mov       rsi,7F3163D0E0F0
       call      qword ptr [7F316324EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F316392E2E0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M07_L07:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,902
       mov       rsi,7F3163D0E0F0
       call      qword ptr [7F316324EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F316392E2E0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M07_L08:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       rsi,rbx
       mov       rdx,r13
       mov       rcx,r15
       mov       r8,r14
       mov       r9,r12
       cmp       [rdi],edi
       add       rsp,58
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F3163CDE460]
M07_L09:
       call      qword ptr [7F3163CDE628]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M07_L10:
       mov       rdi,[rdx+8]
       call      qword ptr [rdx+18]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F3163CDE610]; Kevlar.Shield.get_Name()
       mov       [rbp-68],rax
       mov       rax,[rbp-58]
       mov       rcx,[rbp-60]
       mov       rsi,[rbp-68]
       jmp       near ptr M07_L01
; Total bytes of code 583
```
```assembly
; Kevlar.Shield.get_Name()
       push      rbp
       mov       rbp,rsp
M08_L00:
       mov       rax,[rdi+38]
       test      rax,rax
       jne       short M08_L01
       mov       rax,[rdi+40]
       pop       rbp
       ret
M08_L01:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       jmp       short M08_L00
; Total bytes of code 31
```
```assembly
; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       push      rbp
       mov       rbp,rsp
       test      rsi,rsi
       je        short M09_L02
       mov       rax,[rsi]
       cmp       rax,rdi
       je        short M09_L02
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
M09_L00:
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       jne       short M09_L03
M09_L01:
       xor       esi,esi
M09_L02:
       mov       rax,rsi
       pop       rbp
       ret
M09_L03:
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       test      rax,rax
       je        short M09_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M09_L02
       jmp       short M09_L00
; Total bytes of code 91
```
```assembly
; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,128
       lea       rbp,[rsp+150]
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFF10
M10_L00:
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       add       rax,30
       jne       short M10_L00
       mov       [rbp-30],rsi
       mov       [rbp-128],r8
       mov       rbx,rdi
       mov       r15,rsi
       mov       r13,rdx
       mov       r12,rcx
       mov       r14,r9
       mov       rdi,[r15+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M10_L19
M10_L01:
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rax+8]
       test      rax,rax
       je        near ptr M10_L24
M10_L02:
       mov       [rbp-50],r13
       mov       [rbp-48],rax
       mov       [rbp-40],r12
       mov       r13,[rbp-128]
       mov       [rbp-38],r13
       mov       rdi,[r15+18]
       mov       rdx,[rdi+28]
       test      rdx,rdx
       je        near ptr M10_L20
M10_L03:
       mov       rax,[rbp-48]
       test      rax,rax
       je        near ptr M10_L31
       cmp       qword ptr [rbp-50],0
       jne       near ptr M10_L36
       mov       rdi,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       cmp       [rax+18],rdi
       jne       near ptr M10_L35
       mov       rdi,[rax+8]
       mov       r15,[rbp-40]
       mov       r13,[rbp-38]
       mov       rdi,[rdi]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M10_L21
M10_L04:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0B0],xmm0
       vmovdqu   xmmword ptr [rbp-0A8],xmm0
       mov       [rbp-98],r15
       mov       [rbp-90],r13
       mov       [rbp-0C0],r14
       mov       dword ptr [rbp-0B8],0FFFFFFFF
       mov       rdi,[rsi+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M10_L22
M10_L05:
       mov       rsi,[rdi+18]
       mov       r14,[rsi+10]
       test      r14,r14
       je        near ptr M10_L23
M10_L06:
       mov       rdi,7F31E18A0D68
       mov       rax,7F31E21B6820
       call      rax
       cmp       dword ptr [rax],4
       jle       near ptr M10_L32
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        near ptr M10_L32
M10_L07:
       mov       r15,[rax+10]
       test      r15,r15
       jne       short M10_L08
       call      qword ptr [7F316392C420]; System.Threading.Thread.InitializeCurrentThread()
       mov       r15,rax
M10_L08:
       mov       [rbp-138],r15
       mov       rsi,[r15+8]
       mov       [rbp-140],rsi
       mov       rsi,[r15+10]
       mov       [rbp-148],rsi
       mov       rdi,[r14+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M10_L10
M10_L09:
       lea       rdi,[rbp-0C0]
       call      rax
       jmp       short M10_L11
M10_L10:
       mov       rdi,r14
       mov       rsi,7F31641D82A0
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M10_L09
M10_L11:
       mov       rsi,[rbp-148]
       cmp       rsi,[r15+10]
       je        short M10_L12
       lea       rdi,[r15+10]
       call      CORINFO_HELP_ASSIGN_REF
M10_L12:
       mov       rdi,[r15+8]
       mov       r14,rdi
       mov       rsi,[rbp-140]
       cmp       rsi,r14
       je        short M10_L14
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      r14,r14
       je        short M10_L13
       cmp       qword ptr [r14+10],0
       jne       near ptr M10_L18
M10_L13:
       cmp       qword ptr [rbp-140],0
       jne       near ptr M10_L17
M10_L14:
       mov       rdi,[rbp-0B0]
       mov       rax,7F29798013E8
       cmp       rdi,[rax]
       jne       near ptr M10_L33
       vmovdqu   xmm0,xmmword ptr [rbp-0A8]
       vmovdqu   xmmword ptr [rbp-110],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-120]
       vmovdqu   ymmword ptr [rbp-0E0],ymm0
       xor       r15d,r15d
M10_L15:
       vmovdqu   ymm0,ymmword ptr [rbp-0E0]
       vmovdqu   ymmword ptr [rbp-78],ymm0
       xor       r14d,r14d
       mov       r13d,1
M10_L16:
       mov       [rbp-78],r15
       vmovdqu   ymm0,ymmword ptr [rbp-78]
       vmovdqu   ymmword ptr [rbx],ymm0
       mov       [rbx+8],r14w
       mov       [rbx+0A],r13b
       mov       rax,rbx
       vzeroupper
       add       rsp,128
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M10_L17:
       mov       rsi,[rbp-140]
       cmp       qword ptr [rsi+10],0
       je        near ptr M10_L14
M10_L18:
       mov       rdi,r14
       mov       rsi,[rbp-140]
       call      qword ptr [7F3164287330]
       jmp       near ptr M10_L14
M10_L19:
       mov       rdi,r15
       mov       rsi,7F31641D6958
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M10_L01
M10_L20:
       mov       rdi,r15
       mov       rsi,7F31641D6A70
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdx,rax
       jmp       near ptr M10_L03
M10_L21:
       mov       rsi,7F31641D7240
       call      qword ptr [7F316324F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M10_L04
M10_L22:
       mov       rdi,rsi
       mov       rsi,7F31641D7EB8
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M10_L05
M10_L23:
       mov       rsi,7F31641D8118
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r14,rax
       jmp       near ptr M10_L06
M10_L24:
       mov       rdi,[r15+18]
       mov       rax,[rdi+18]
       test      rax,rax
       je        short M10_L25
       mov       [rbp-58],rax
       jmp       short M10_L26
M10_L25:
       mov       rdi,r15
       mov       rsi,7F31641D6958
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-58],rax
M10_L26:
       mov       rdi,[r15+18]
       mov       rdi,[rdi+30]
       test      rdi,rdi
       je        short M10_L27
       jmp       short M10_L28
M10_L27:
       mov       rdi,r15
       mov       rsi,7F31641D6C50
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M10_L28:
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-130],rax
       mov       rdi,[rbp-58]
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rax]
       mov       rdi,[rbp-130]
       mov       rdx,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       call      qword ptr [7F3163246E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,[r15+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        short M10_L29
       jmp       short M10_L30
M10_L29:
       mov       rdi,r15
       mov       rsi,7F31641D6958
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
M10_L30:
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       lea       rdi,[rax+8]
       mov       rsi,[rbp-130]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-130]
       jmp       near ptr M10_L02
M10_L31:
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       mov       rsi,7F3158A0B5D8
       call      qword ptr [7F3163925650]
       mov       rdi,r15
       call      qword ptr [7F3163CDEA00]
       xor       r15d,r15d
       xor       r14d,r14d
       mov       r13d,1
       mov       [rbp-68],rax
       mov       [rbp-60],edx
       jmp       near ptr M10_L16
M10_L32:
       mov       edi,4
       call      qword ptr [7F3164286610]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       near ptr M10_L07
M10_L33:
       mov       r15,[rbp-0B0]
       test      r15,r15
       jne       short M10_L34
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       call      qword ptr [7F3164286D78]
       mov       [rbp-0B0],r15
M10_L34:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0F0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-100]
       vmovdqu   ymmword ptr [rbp-0E0],ymm0
       jmp       near ptr M10_L15
M10_L35:
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-38]
       lea       rsi,[rbp-78]
       mov       r8,r14
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       jmp       short M10_L37
M10_L36:
       lea       rdi,[rbp-50]
       lea       rsi,[rbp-78]
       mov       rcx,[rbp-50]
       mov       r8,r14
       call      qword ptr [7F31641F6B68]
M10_L37:
       mov       r15,[rbp-78]
       movsx     r14,word ptr [rbp-70]
       movzx     r13d,byte ptr [rbp-6E]
       jmp       near ptr M10_L16
       push      rax
       mov       rsi,[rbp-148]
       mov       rax,[rbp-138]
       cmp       rsi,[rax+10]
       je        short M10_L38
       lea       rdi,[rax+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-138]
M10_L38:
       mov       rbx,[rax+8]
       mov       rsi,[rbp-140]
       cmp       rsi,rbx
       je        short M10_L41
       lea       rdi,[rax+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      rbx,rbx
       je        short M10_L39
       cmp       qword ptr [rbx+10],0
       jne       short M10_L40
M10_L39:
       cmp       qword ptr [rbp-140],0
       je        short M10_L41
       mov       rsi,[rbp-140]
       cmp       qword ptr [rsi+10],0
       je        short M10_L41
M10_L40:
       mov       rdi,rbx
       mov       rsi,[rbp-140]
       call      qword ptr [7F3164287330]
M10_L41:
       nop
       vzeroupper
       add       rsp,8
       ret
; Total bytes of code 1394
```
```assembly
; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       push      rbp
       mov       rbp,rsp
       mov       rax,rsi
       test      rax,rax
       je        short M11_L00
       mov       rsi,rdx
       mov       rdx,rcx
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       nop
M11_L00:
       pop       rbp
       ret
       push      rax
       lea       rax,[M11_L00]
       add       rsp,8
       ret
; Total bytes of code 41
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItemGuarded(System.__Canon)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,0A8
       lea       rbp,[rsp+0D0]
       xor       eax,eax
       mov       [rbp-68],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-30],rdi
       mov       [rbp-78],rdi
       mov       [rbp-80],rsi
       cmp       [rdi],dil
       xor       eax,eax
       mov       [rsi+68],rax
       mov       [rsi+60],eax
       mov       [rsi+30],rax
       mov       rax,0FFFFFFFF00000000
       mov       [rsi+58],rax
       xor       eax,eax
       mov       [rsi+40],rax
       mov       [rsi+48],rax
       mov       [rsi+50],rax
       mov       rax,[rsi+28]
       test      rax,rax
       jne       near ptr M12_L11
M12_L00:
       mov       rax,7F2979800B00
       mov       rsi,[rax]
       mov       rbx,[rbp-80]
       lea       rdi,[rbx+38]
       call      CORINFO_HELP_ASSIGN_REF
       mov       r15,[rbx+8]
       xor       edi,edi
       mov       [r15+20],rdi
       cmp       byte ptr [r15+34],0
       jne       near ptr M12_L12
M12_L01:
       mov       rdi,[r15+28]
       mov       rax,[r15+8]
       cmp       rdi,rax
       jne       short M12_L07
       cmp       dword ptr [rax+8],1
       jne       near ptr M12_L33
M12_L02:
       mov       rdi,[r15+8]
       xor       eax,eax
       mov       [rdi+0C],eax
       mov       [rdi+10],eax
       mov       rdi,[rbx+8]
       cmp       [rdi],edi
       call      qword ptr [7F31641F74E0]; Kevlar.KevlarProperties.Clear()
       cmp       qword ptr [rbx+10],0
       jne       near ptr M12_L81
M12_L03:
       mov       r15,[rbx+18]
       test      r15,r15
       je        short M12_L06
       cmp       byte ptr [r15+34],0
       jne       near ptr M12_L82
M12_L04:
       mov       rdi,[r15+28]
       mov       rax,[r15+8]
       cmp       rdi,rax
       jne       short M12_L09
       cmp       dword ptr [rax+8],1
       jne       near ptr M12_L83
M12_L05:
       mov       rdi,[r15+8]
       cmp       [rdi],edi
       call      qword ptr [7F31641F7558]; Kevlar.KevlarProperties+AdditionalAttemptState.Reset()
       mov       rdi,[rbx+18]
       cmp       [rdi],edi
       call      qword ptr [7F31641F74E0]; Kevlar.KevlarProperties.Clear()
M12_L06:
       mov       word ptr [rbx+64],0
       jmp       near ptr M12_L111
M12_L07:
       mov       r14,[r15+28]
       lea       rdi,[r14+8]
       mov       eax,0FFFFFFFF
       lock xadd [rdi],eax
       dec       eax
       je        short M12_L13
M12_L08:
       mov       rsi,[r15+8]
       lea       rdi,[r15+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M12_L02
M12_L09:
       mov       rdi,[r15+28]
       call      qword ptr [7F31641F7510]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
M12_L10:
       mov       rsi,[r15+8]
       lea       rdi,[r15+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M12_L05
M12_L11:
       mov       rdi,rax
       call      qword ptr [7F31642206F8]
       jmp       near ptr M12_L00
M12_L12:
       mov       rdi,[r15+28]
       cmp       [rdi],edi
       call      qword ptr [7F31641F74F8]
       mov       byte ptr [r15+34],0
       jmp       near ptr M12_L01
M12_L13:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F29798013D0
       mov       r13,[rdi]
       cmp       byte ptr [r13+24],0
       je        short M12_L14
       mov       rdi,r13
       mov       rsi,r14
       call      qword ptr [7F3164286C58]
       jmp       short M12_L08
M12_L14:
       cmp       dword ptr [r13+1C],0
       je        short M12_L15
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r13+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F3162260560
       call      qword ptr [r11]
       jmp       near ptr M12_L08
M12_L15:
       mov       rdi,r13
       mov       rsi,r14
       call      qword ptr [7F3164286C70]
       test      eax,eax
       jne       short M12_L16
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r13+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F3162260568
       call      qword ptr [r11]
       jmp       near ptr M12_L08
M12_L16:
       mov       r12,[r13+10]
       test      r12,r12
       je        near ptr M12_L27
       mov       edi,38
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L18
M12_L17:
       mov       rax,7F316225B1E8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-3C],eax
       test      eax,eax
       je        short M12_L17
       mov       edi,38
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-3C]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L18:
       dec       eax
       cmp       dword ptr [r12+18],0
       jl        short M12_L19
       and       eax,[r12+18]
       jmp       short M12_L20
M12_L19:
       mov       rdi,[r12+8]
       mov       edi,[rdi+8]
       mov       eax,eax
       imul      rax,[r12+10]
       shr       rax,20
       inc       rax
       imul      rax,rdi
       shr       rax,20
M12_L20:
       xor       ecx,ecx
       jmp       near ptr M12_L24
M12_L21:
       mov       rdi,[r12+8]
       cmp       eax,[rdi+8]
       jae       near ptr M12_L108
       mov       [rbp-34],eax
       mov       esi,eax
       mov       r8,[rdi+rsi*8+10]
       mov       [rbp-90],r8
       cmp       qword ptr [r8+50],0
       jne       short M12_L22
       lea       rdi,[r8+50]
       test      rdi,rdi
       je        near ptr M12_L95
       mov       rsi,r14
       xor       edx,edx
       call      00007F31E1674060
       test      rax,rax
       mov       r8,[rbp-90]
       je        short M12_L25
M12_L22:
       mov       rdx,r14
       mov       rsi,r8
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F3163CDE058]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M12_L25
       mov       eax,[rbp-34]
       inc       eax
       mov       edi,eax
       mov       rax,[r12+8]
       cmp       [rax+8],edi
       jne       short M12_L23
       xor       edi,edi
M12_L23:
       mov       ecx,[rbp-38]
       inc       ecx
       mov       eax,edi
M12_L24:
       mov       rdi,[r12+8]
       mov       [rbp-38],ecx
       cmp       [rdi+8],ecx
       jg        near ptr M12_L21
       jmp       short M12_L26
M12_L25:
       cmp       dword ptr [r13+1C],0
       je        near ptr M12_L08
       jmp       near ptr M12_L32
M12_L26:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r13+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F3162260570
       call      qword ptr [r11]
       jmp       short M12_L25
M12_L27:
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M12_L29
M12_L28:
       mov       rdi,7F316225B1E0
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M12_L28
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M12_L29:
       dec       r12d
       imul      r12d,9E3779B9
       cmp       dword ptr [r13+18],0
       jge       short M12_L30
       mov       eax,[r13+20]
       imul      r12,rax
       shr       r12,20
       jmp       short M12_L31
M12_L30:
       and       r12d,[r13+18]
M12_L31:
       mov       rdi,[r13+8]
       lea       esi,[r12*8+8]
       cmp       esi,[rdi+8]
       jae       near ptr M12_L108
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       je        near ptr M12_L95
       mov       rsi,r14
       call      00007F31E1674040
       test      rax,rax
       je        near ptr M12_L25
       mov       rdi,r13
       mov       rsi,r14
       mov       rdx,rax
       mov       ecx,r12d
       call      qword ptr [7F3164286C88]
       jmp       near ptr M12_L25
M12_L32:
       mov       rdi,r13
       call      qword ptr [7F3164286CA0]
       jmp       near ptr M12_L08
M12_L33:
       mov       rdi,[r15+8]
       call      qword ptr [7F31641F7510]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F29798013D0
       mov       r14,[rdi]
       cmp       byte ptr [r14+24],0
       je        near ptr M12_L60
       cmp       dword ptr [r14+1C],0
       je        short M12_L34
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F3164286CB8]
M12_L34:
       lea       rdi,[r14+28]
       mov       rsi,[rdi]
       test      rsi,rsi
       jne       short M12_L35
       mov       rsi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F3164286CD0]
       mov       rsi,rax
M12_L35:
       mov       rdi,rsi
       cmp       [rdi],edi
       call      qword ptr [7F3164286CE8]
       mov       r13,rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F3163245728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       cmp       byte ptr [7F316225B1F8],0
       je        short M12_L38
       mov       edx,[r13+68]
       mov       rax,[r13+58]
       mov       r12,rax
       test      r12,r12
       je        short M12_L39
       xor       esi,esi
       mov       [r13+58],rsi
       cmp       [r13+68],edx
       jne       short M12_L36
       test      dl,1
       je        short M12_L37
M12_L36:
       mov       rdx,r12
       mov       rsi,r13
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F3164286D00]
       mov       r12,rax
       test      r12,r12
       je        short M12_L39
M12_L37:
       jmp       near ptr M12_L57
M12_L38:
       cmp       qword ptr [r13+58],0
       je        short M12_L39
       lea       rdi,[r13+58]
       test      rdi,rdi
       je        near ptr M12_L95
       xor       esi,esi
       call      00007F31E1674040
       mov       r12,rax
       test      r12,r12
       jne       short M12_L37
M12_L39:
       cmp       byte ptr [r13+6C],0
       jne       short M12_L40
       mov       byte ptr [r13+6C],1
M12_L40:
       mov       r12,[r14+10]
       xor       r13d,r13d
       test      r12,r12
       jne       near ptr M12_L47
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M12_L42
M12_L41:
       mov       rdi,7F316225B1E0
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M12_L41
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M12_L42:
       dec       r13d
       imul      edi,r13d,9E3779B9
       cmp       dword ptr [r14+18],0
       jge       short M12_L43
       mov       r13d,edi
       mov       edx,[r14+20]
       imul      r13,rdx
       shr       r13,20
       jmp       short M12_L44
M12_L43:
       and       edi,[r14+18]
       mov       r13d,edi
M12_L44:
       mov       rdi,[r14+8]
       lea       edx,[r13*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M12_L108
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       [rbp-98],rax
       test      rax,rax
       je        short M12_L45
       mov       rdx,rax
       xor       esi,esi
       call      00007F31E1674060
       mov       rdi,[rbp-98]
       cmp       rax,rdi
       je        short M12_L46
M12_L45:
       xor       edi,edi
M12_L46:
       mov       [rbp-48],rdi
       jmp       near ptr M12_L53
M12_L47:
       mov       edi,38
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L49
M12_L48:
       mov       rax,7F316225B1E8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-4C],eax
       test      eax,eax
       je        short M12_L48
       mov       edi,38
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-4C]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L49:
       dec       eax
       cmp       dword ptr [r12+18],0
       jl        short M12_L50
       mov       ecx,eax
       and       ecx,[r12+18]
       jmp       short M12_L51
M12_L50:
       mov       rcx,[r12+8]
       mov       edi,[rcx+8]
       mov       ecx,eax
       imul      rcx,[r12+10]
       shr       rcx,20
       inc       rcx
       imul      rcx,rdi
       shr       rcx,20
       mov       eax,ecx
       mov       ecx,eax
M12_L51:
       mov       rdi,[r12+8]
       cmp       ecx,[rdi+8]
       jae       near ptr M12_L108
       mov       [rbp-50],ecx
       mov       edx,ecx
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-0A0],rax
       mov       r8,[rax+50]
       mov       [rbp-0A8],r8
       test      r8,r8
       je        short M12_L52
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M12_L95
       mov       rdx,r8
       xor       esi,esi
       call      00007F31E1674060
       mov       rdx,[rbp-0A8]
       cmp       rax,rdx
       mov       rax,[rbp-0A0]
       jne       short M12_L52
       mov       [rbp-48],rdx
       jmp       short M12_L53
M12_L52:
       lea       rdx,[rbp-48]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F3163CDDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M12_L53
       lea       rdx,[rbp-48]
       mov       rdi,r12
       mov       esi,[rbp-50]
       call      qword ptr [7F3163CDDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M12_L53:
       mov       rax,[rbp-48]
       cmp       qword ptr [rbp-48],0
       jne       short M12_L55
       test      r12,r12
       je        short M12_L54
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       dword ptr [rax+8],1
       mov       r12,rax
       jmp       short M12_L56
M12_L54:
       mov       rdi,r14
       mov       esi,r13d
       call      qword ptr [7F3164286D18]
M12_L55:
       mov       r12,rax
M12_L56:
       xor       edi,edi
       mov       [rbp-48],rdi
M12_L57:
       cmp       dword ptr [r14+1C],0
       jne       short M12_L58
       mov       rsi,r12
       jmp       short M12_L59
M12_L58:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F3162260578
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F3164286CB8]
       mov       rsi,rax
M12_L59:
       jmp       near ptr M12_L80
M12_L60:
       cmp       dword ptr [r14+1C],0
       je        short M12_L61
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F3164286CB8]
M12_L61:
       mov       r13,[r14+10]
       xor       r12d,r12d
       test      r13,r13
       jne       near ptr M12_L68
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M12_L63
M12_L62:
       mov       rdi,7F316225B1E0
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M12_L62
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M12_L63:
       dec       r12d
       imul      edi,r12d,9E3779B9
       cmp       dword ptr [r14+18],0
       jge       short M12_L64
       mov       r12d,edi
       mov       edx,[r14+20]
       imul      r12,rdx
       shr       r12,20
       jmp       short M12_L65
M12_L64:
       and       edi,[r14+18]
       mov       r12d,edi
M12_L65:
       mov       rdi,[r14+8]
       lea       edx,[r12*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M12_L108
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       [rbp-0B0],rax
       test      rax,rax
       je        short M12_L66
       mov       rdx,rax
       xor       esi,esi
       call      00007F31E1674060
       mov       rdi,[rbp-0B0]
       cmp       rax,rdi
       je        short M12_L67
M12_L66:
       xor       edi,edi
M12_L67:
       mov       [rbp-58],rdi
       jmp       near ptr M12_L74
M12_L68:
       mov       edi,38
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M12_L70
M12_L69:
       mov       rax,7F316225B1E8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-5C],eax
       test      eax,eax
       je        short M12_L69
       mov       edi,38
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-5C]
       mov       [rax+10],ecx
       mov       eax,ecx
M12_L70:
       dec       eax
       cmp       dword ptr [r13+18],0
       jl        short M12_L71
       mov       ecx,eax
       and       ecx,[r13+18]
       jmp       short M12_L72
M12_L71:
       mov       rcx,[r13+8]
       mov       edi,[rcx+8]
       mov       ecx,eax
       imul      rcx,[r13+10]
       shr       rcx,20
       inc       rcx
       imul      rcx,rdi
       shr       rcx,20
       mov       eax,ecx
       mov       ecx,eax
M12_L72:
       mov       rdi,[r13+8]
       cmp       ecx,[rdi+8]
       jae       near ptr M12_L108
       mov       [rbp-60],ecx
       mov       edx,ecx
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-0B8],rax
       mov       r8,[rax+50]
       mov       [rbp-0C0],r8
       test      r8,r8
       je        short M12_L73
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M12_L95
       mov       rdx,r8
       xor       esi,esi
       call      00007F31E1674060
       mov       rdx,[rbp-0C0]
       cmp       rax,rdx
       mov       rax,[rbp-0B8]
       jne       short M12_L73
       mov       [rbp-58],rdx
       jmp       short M12_L74
M12_L73:
       lea       rdx,[rbp-58]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F3163CDDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M12_L74
       lea       rdx,[rbp-58]
       mov       rdi,r13
       mov       esi,[rbp-60]
       call      qword ptr [7F3163CDDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M12_L74:
       mov       rax,[rbp-58]
       cmp       qword ptr [rbp-58],0
       jne       short M12_L75
       test      r13,r13
       je        short M12_L76
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       dword ptr [r12+8],1
       jmp       short M12_L78
M12_L75:
       mov       r13,rax
       jmp       short M12_L77
M12_L76:
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7F3164286D18]
       mov       r13,rax
M12_L77:
       mov       r12,r13
M12_L78:
       xor       edi,edi
       mov       [rbp-58],rdi
       cmp       dword ptr [r14+1C],0
       jne       short M12_L79
       mov       rsi,r12
       jmp       short M12_L80
M12_L79:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F3162260580
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F3164286CB8]
       mov       rsi,rax
M12_L80:
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M12_L08
M12_L81:
       mov       rdi,[rbx+10]
       cmp       [rdi],edi
       call      qword ptr [7F31641F74C8]; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       mov       rdi,[rbx+10]
       cmp       [rdi],edi
       call      qword ptr [7F31641F74E0]; Kevlar.KevlarProperties.Clear()
       jmp       near ptr M12_L03
M12_L82:
       mov       rdi,[r15+28]
       cmp       [rdi],edi
       call      qword ptr [7F31641F74F8]
       mov       byte ptr [r15+34],0
       jmp       near ptr M12_L04
M12_L83:
       mov       rdi,[r15+8]
       call      qword ptr [7F31641F7510]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F29798013D0
       mov       r14,[rdi]
       cmp       byte ptr [r14+24],0
       je        near ptr M12_L106
       cmp       dword ptr [r14+1C],0
       je        short M12_L84
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F3164286CB8]
M12_L84:
       lea       rdi,[r14+28]
       mov       rsi,[rdi]
       test      rsi,rsi
       jne       short M12_L85
       mov       rsi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F3164286CD0]
       mov       rsi,rax
M12_L85:
       mov       rdi,rsi
       cmp       [rdi],edi
       call      qword ptr [7F3164286CE8]
       mov       r13,rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F3163245728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       cmp       byte ptr [7F316225B1F8],0
       je        short M12_L88
       mov       edx,[r13+68]
       mov       rax,[r13+58]
       mov       r12,rax
       test      r12,r12
       je        short M12_L89
       xor       esi,esi
       mov       [r13+58],rsi
       cmp       [r13+68],edx
       jne       short M12_L86
       test      dl,1
       je        short M12_L87
M12_L86:
       mov       rdx,r12
       mov       rsi,r13
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F3164286D00]
       mov       r12,rax
       test      r12,r12
       je        short M12_L89
M12_L87:
       jmp       near ptr M12_L103
M12_L88:
       cmp       qword ptr [r13+58],0
       je        short M12_L89
       lea       rdi,[r13+58]
       test      rdi,rdi
       je        near ptr M12_L95
       xor       esi,esi
       call      00007F31E1674040
       mov       r12,rax
       test      r12,r12
       jne       short M12_L87
M12_L89:
       cmp       byte ptr [r13+6C],0
       jne       short M12_L90
       mov       byte ptr [r13+6C],1
M12_L90:
       mov       r12,[r14+10]
       xor       r13d,r13d
       test      r12,r12
       jne       near ptr M12_L98
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M12_L92
M12_L91:
       mov       rdi,7F316225B1E0
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M12_L91
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M12_L92:
       dec       r13d
       imul      edi,r13d,9E3779B9
       cmp       dword ptr [r14+18],0
       jge       short M12_L93
       mov       r13d,edi
       mov       edx,[r14+20]
       imul      r13,rdx
       shr       r13,20
       jmp       short M12_L94
M12_L93:
       and       edi,[r14+18]
       mov       r13d,edi
M12_L94:
       mov       rdi,[r14+8]
       lea       edx,[r13*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M12_L108
       lea       rdi,[rdi+rdx*8+10]
       mov       rax,[rdi]
       mov       [rbp-0C8],rax
       test      rax,rax
       je        short M12_L96
       mov       rdx,rax
       xor       esi,esi
       call      00007F31E1674060
       mov       rdi,[rbp-0C8]
       cmp       rax,rdi
       je        short M12_L97
       jmp       short M12_L96
M12_L95:
       call      qword ptr [7F31642865F8]
       int       3
M12_L96:
       xor       edi,edi
M12_L97:
       mov       [rbp-68],rdi
       jmp       short M12_L99
M12_L98:
       mov       rdi,r12
       call      qword ptr [7F3163CDDCF8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-6C],eax
       lea       rdx,[rbp-68]
       mov       rdi,r12
       mov       esi,eax
       call      qword ptr [7F3163CDDD10]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       jne       short M12_L99
       lea       rdx,[rbp-68]
       mov       rdi,r12
       mov       esi,[rbp-6C]
       call      qword ptr [7F3163CDDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M12_L99:
       mov       rax,[rbp-68]
       cmp       qword ptr [rbp-68],0
       jne       short M12_L101
       test      r12,r12
       je        short M12_L100
       mov       rdi,r14
       call      qword ptr [7F3164287180]
       mov       r12,rax
       jmp       short M12_L102
M12_L100:
       mov       rdi,r14
       mov       esi,r13d
       call      qword ptr [7F3164286D18]
M12_L101:
       mov       r12,rax
M12_L102:
       xor       edi,edi
       mov       [rbp-68],rdi
M12_L103:
       cmp       dword ptr [r14+1C],0
       jne       short M12_L104
       mov       rsi,r12
       jmp       short M12_L105
M12_L104:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r12
       mov       r11,7F3162260588
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F3164286CB8]
       mov       rsi,rax
M12_L105:
       jmp       short M12_L110
M12_L106:
       cmp       dword ptr [r14+1C],0
       je        short M12_L107
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F3164286CB8]
M12_L107:
       mov       rdi,r14
       call      qword ptr [7F3164287198]
       mov       rsi,rax
       cmp       dword ptr [r14+1C],0
       jne       short M12_L109
       jmp       short M12_L110
M12_L108:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M12_L109:
       mov       rdi,r14
       call      qword ptr [7F31642871B0]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F3164286CB8]
       mov       rsi,rax
M12_L110:
       lea       rdi,[r15+8]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M12_L10
M12_L111:
       mov       eax,1
       add       rsp,0A8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
       push      rax
       mov       rbx,rdi
       mov       rdi,offset MT_System.Exception[]
       mov       esi,2
       call      CORINFO_HELP_NEWARR_1_PTR
       mov       r15,rax
       lea       rdi,[r15+10]
       mov       rsi,[rbp-88]
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r15+18]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,offset MT_System.AggregateException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,0C1
       mov       rsi,7F31636C54F0
       call      qword ptr [7F316324EF88]
       mov       rsi,rax
       mov       rdi,rbx
       mov       rdx,r15
       call      qword ptr [7F3163CDDFC8]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
       push      rax
       mov       rsi,rdi
       mov       [rbp-88],rsi
       mov       rdi,[rbp-78]
       mov       rsi,[rdi]
       mov       rax,[rsi+30]
       mov       rax,[rax]
       mov       rbx,[rax+48]
       test      rbx,rbx
       je        short M12_L112
       jmp       short M12_L113
M12_L112:
       mov       rdi,rsi
       mov       rsi,7F316426E680
       call      qword ptr [7F316324F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rbx,rax
M12_L113:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-78]
       mov       r11b,[rdi+30]
       mov       [rax+8],r11b
       mov       rdi,rax
       mov       r11,rbx
       mov       rsi,[rbp-80]
       call      qword ptr [rbx]
       nop
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 3570
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F3162DEEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F3162DEEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       push      rbp
       push      r15
       push      r14
       push      rbx
       sub       rsp,128
       vzeroupper
       lea       rbp,[rsp+140]
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFEE0
M14_L00:
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       vmovdqa   xmmword ptr [rax+rbp],xmm8
       add       rax,30
       jne       short M14_L00
       mov       [rbp-20],rax
       mov       rbx,rdi
       mov       r15,rsi
       mov       r14d,edx
       xor       edi,edi
       mov       [rbp-0B0],rdi
       test      rbx,rbx
       jne       short M14_L03
M14_L01:
       mov       rdi,7F2979800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M14_L04
M14_L02:
       add       rsp,128
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M14_L03:
       mov       rdi,7F2979800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F3163CDEAD8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        short M14_L01
       lea       rdi,[rbp-0A8]
       mov       rsi,r15
       call      qword ptr [7F31641F7330]
       mov       rdx,7F3158A0B6A8
       mov       rdi,7F3158A0B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-0A8]
       mov       rsi,7F3158A0B638
       call      qword ptr [7F31641F7348]
       call      00007F3163238AE0
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F3164286E20]
       mov       [rbp-0B0],rax
       lea       rdi,[rbp-0B0]
       call      qword ptr [7F31641F7378]
       mov       rdi,7F2979800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-0A8]
       xor       edx,edx
       call      qword ptr [7F31641F7390]
       jmp       near ptr M14_L01
M14_L04:
       lea       rdi,[rbp-140]
       mov       rsi,r15
       call      qword ptr [7F31641F7330]
       mov       rdx,7F3158A0B6A8
       mov       rdi,7F3158A0B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-140]
       mov       rsi,7F3158A0B638
       call      qword ptr [7F31641F7348]
       mov       rdi,7F2979800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-140]
       mov       esi,1
       xor       ecx,ecx
       call      qword ptr [7F31641F73A8]
       jmp       near ptr M14_L02
; Total bytes of code 394
```
```assembly
; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,0A8
       lea       rbp,[rsp+0D0]
       xor       eax,eax
       mov       [rbp-38],rax
       mov       [rbp-50],rax
       mov       r13,rdi
       mov       r14d,esi
       mov       rbx,rdx
       mov       r15,rcx
       mov       rdi,7F29798013C0
       mov       r12,[rdi]
       cmp       byte ptr [r12+24],0
       jne       near ptr M15_L13
       cmp       dword ptr [r12+1C],0
       jne       near ptr M15_L43
M15_L00:
       mov       rax,[r12+10]
       mov       [rbp-0A8],rax
       xor       ecx,ecx
       mov       [rbp-44],ecx
       test      rax,rax
       je        near ptr M15_L44
       mov       rdi,7F31E18A0D68
       mov       rdx,7F31E21B6820
       call      rdx
       add       rax,40
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M15_L53
M15_L01:
       dec       eax
       mov       rcx,[rbp-0A8]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M15_L54
       and       r8d,eax
M15_L02:
       mov       eax,r8d
       mov       [rbp-54],eax
       mov       rdi,[rcx+8]
       cmp       eax,[rdi+8]
       jae       near ptr M15_L63
       mov       edx,eax
       mov       r8,[rdi+rdx*8+10]
       mov       [rbp-0B8],r8
       mov       r9,[r8+50]
       mov       [rbp-0C0],r9
       test      r9,r9
       mov       eax,[rbp-54]
       mov       rcx,[rbp-0A8]
       jne       near ptr M15_L11
M15_L03:
       lea       rdx,[r8+58]
       mov       rdi,[r8+48]
       mov       rsi,[rdx]
       mov       r9d,esi
       cmp       r9d,0FFFFFFFF
       je        near ptr M15_L58
M15_L04:
       cmp       r9d,[rdi+8]
       jae       near ptr M15_L63
       mov       r10d,r9d
       shl       r10,4
       mov       r11d,[rdi+r10+18]
       mov       rax,rsi
       sar       rax,20
       inc       eax
       cdqe
       shl       rax,20
       or        r11,rax
       mov       rax,rsi
       lock cmpxchg [rdx],r11
       cmp       rax,rsi
       jne       near ptr M15_L57
       mov       rax,[r8+48]
       mov       rdx,rax
       mov       edi,[rdx+8]
       cmp       r9d,edi
       jae       near ptr M15_L63
       mov       rdx,[rdx+r10+10]
       mov       [rbp-50],rdx
       cmp       r9d,edi
       jae       near ptr M15_L63
       lea       rdx,[rax+r10+10]
       xor       eax,eax
       mov       [rdx],rax
       add       r8,60
M15_L05:
       mov       rax,[r8]
       mov       [rbp-60],rax
       mov       [rdx+8],eax
       mov       rdi,rax
       sar       rdi,20
       inc       edi
       movsxd    rdi,edi
       shl       rdi,20
       mov       esi,r9d
       or        rdi,rsi
       lock cmpxchg [r8],rdi
       cmp       rax,[rbp-60]
       jne       short M15_L05
       cmp       qword ptr [rbp-50],0
       setne     dl
       movzx     edx,dl
       mov       eax,[rbp-54]
M15_L06:
       test      edx,edx
       je        near ptr M15_L59
       mov       eax,[rbp-44]
M15_L07:
       mov       rdx,[rbp-50]
       cmp       qword ptr [rbp-50],0
       je        near ptr M15_L60
M15_L08:
       mov       rax,rdx
M15_L09:
       xor       edi,edi
       mov       [rbp-50],rdi
       cmp       dword ptr [r12+1C],0
       jne       near ptr M15_L62
       mov       r12,rax
M15_L10:
       lea       rdi,[r12+68]
       mov       rsi,r13
       call      CORINFO_HELP_ASSIGN_REF
       mov       [r12+60],r14d
       lea       rdi,[r12+38]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r12+30]
       mov       rsi,r15
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,0FFFFFFFF00000000
       mov       [r12+58],rax
       xor       eax,eax
       mov       [r12+40],rax
       mov       rax,r12
       add       rsp,0A8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M15_L11:
       lea       rdi,[r8+50]
       test      rdi,rdi
       je        near ptr M15_L55
       mov       rdx,r9
       xor       esi,esi
       call      00007F31E1674060
       mov       rdx,[rbp-0C0]
       cmp       rax,rdx
       mov       eax,[rbp-54]
       mov       r8,[rbp-0B8]
       jne       near ptr M15_L56
       mov       [rbp-50],rdx
       mov       eax,[rbp-44]
       mov       rcx,[rbp-0A8]
       jmp       near ptr M15_L07
M15_L12:
       mov       rdi,7F316225B200
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M15_L12
       jmp       near ptr M15_L45
M15_L13:
       cmp       dword ptr [r12+1C],0
       je        short M15_L14
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F31641F68F8]
M15_L14:
       lea       rdi,[r12+28]
       mov       rsi,[rdi]
       test      rsi,rsi
       jne       short M15_L15
       mov       rsi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7F3164286CD0]
       mov       rsi,rax
M15_L15:
       mov       rdi,rsi
       cmp       [rdi],edi
       call      qword ptr [7F3164286CE8]
       mov       [rbp-68],rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7F3163245728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       cmp       byte ptr [7F316225B208],0
       je        short M15_L19
       mov       rax,[rbp-68]
       mov       edx,[rax+68]
       mov       rcx,[rax+58]
       test      rcx,rcx
       je        short M15_L22
       xor       esi,esi
       mov       [rax+58],rsi
       cmp       [rax+68],edx
       jne       short M15_L16
       test      dl,1
       je        short M15_L17
M15_L16:
       mov       rdx,rcx
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7F3164286D00]
       mov       rcx,rax
       mov       rax,rcx
       test      rax,rax
       mov       rcx,rax
       je        short M15_L18
M15_L17:
       mov       rax,rcx
       jmp       near ptr M15_L40
M15_L18:
       mov       rax,[rbp-68]
       jmp       short M15_L22
M15_L19:
       mov       rcx,[rbp-68]
       cmp       qword ptr [rcx+58],0
       je        short M15_L20
       lea       rdi,[rcx+58]
       test      rdi,rdi
       jne       short M15_L21
       jmp       near ptr M15_L55
M15_L20:
       mov       rax,rcx
       jmp       short M15_L22
M15_L21:
       xor       esi,esi
       call      00007F31E1674040
       test      rax,rax
       mov       rcx,rax
       jne       short M15_L17
       mov       rax,[rbp-68]
M15_L22:
       cmp       byte ptr [rax+6C],0
       jne       short M15_L23
       mov       byte ptr [rax+6C],1
M15_L23:
       mov       rax,[r12+10]
       mov       [rbp-78],rax
       xor       ecx,ecx
       mov       [rbp-2C],ecx
       test      rax,rax
       jne       near ptr M15_L31
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M15_L25
M15_L24:
       mov       rdi,7F316225B200
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M15_L24
       mov       [rax+10],edi
M15_L25:
       dec       edi
       imul      edi,9E3779B9
       cmp       dword ptr [r12+18],0
       jge       short M15_L26
       mov       ecx,edi
       mov       edx,[r12+20]
       imul      rcx,rdx
       shr       rcx,20
       jmp       short M15_L27
M15_L26:
       and       edi,[r12+18]
       mov       ecx,edi
M15_L27:
       mov       eax,ecx
       mov       rdi,[r12+8]
       mov       [rbp-2C],eax
       lea       edx,[rax*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M15_L63
       lea       rdi,[rdi+rdx*8+10]
       mov       rcx,[rdi]
       mov       [rbp-80],rcx
       test      rcx,rcx
       je        short M15_L28
       mov       rdx,rcx
       xor       esi,esi
       call      00007F31E1674060
       mov       rdi,[rbp-80]
       cmp       rax,rdi
       je        short M15_L29
M15_L28:
       xor       esi,esi
       jmp       short M15_L30
M15_L29:
       mov       rsi,rdi
M15_L30:
       mov       [rbp-38],rsi
       jmp       near ptr M15_L37
M15_L31:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M15_L33
M15_L32:
       mov       rax,7F316225B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-3C],eax
       test      eax,eax
       je        short M15_L32
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-3C]
       mov       [rax+10],ecx
       mov       eax,ecx
M15_L33:
       dec       eax
       mov       rcx,[rbp-78]
       cmp       dword ptr [rcx+18],0
       jl        short M15_L34
       mov       r8d,eax
       and       r8d,[rcx+18]
       jmp       short M15_L35
M15_L34:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
M15_L35:
       mov       rdi,[rcx+8]
       cmp       r8d,[rdi+8]
       jae       near ptr M15_L63
       mov       [rbp-40],r8d
       mov       edx,r8d
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-88],rax
       mov       r9,[rax+50]
       mov       [rbp-90],r9
       test      r9,r9
       je        short M15_L36
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M15_L55
       mov       rdx,r9
       xor       esi,esi
       call      00007F31E1674060
       mov       rdx,[rbp-90]
       cmp       rax,rdx
       mov       rax,[rbp-88]
       jne       short M15_L36
       mov       [rbp-38],rdx
       jmp       short M15_L37
M15_L36:
       lea       rdx,[rbp-38]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F3163CDDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M15_L37
       lea       rdx,[rbp-38]
       mov       rdi,[rbp-78]
       mov       esi,[rbp-40]
       call      qword ptr [7F3163CDDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M15_L37:
       mov       rax,[rbp-38]
       cmp       qword ptr [rbp-38],0
       jne       short M15_L39
       cmp       qword ptr [rbp-78],0
       je        short M15_L38
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-98],rax
       mov       rdi,rax
       call      qword ptr [7F31641F69A0]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-98]
       jmp       short M15_L39
M15_L38:
       mov       rdi,r12
       mov       esi,[rbp-2C]
       call      qword ptr [7F31641F6958]
M15_L39:
       xor       edi,edi
       mov       [rbp-38],rdi
M15_L40:
       cmp       dword ptr [r12+1C],0
       jne       short M15_L41
       mov       r12,rax
       jmp       short M15_L42
M15_L41:
       mov       [rbp-70],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r12+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-70]
       mov       r11,7F31622605C8
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F31641F68F8]
       mov       r12,rax
M15_L42:
       jmp       near ptr M15_L10
M15_L43:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F31641F68F8]
       jmp       near ptr M15_L00
M15_L44:
       mov       rdi,7F31E18A0D68
       mov       rcx,7F31E21B6820
       call      rcx
       add       rax,30
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M15_L46
       jmp       near ptr M15_L12
M15_L45:
       mov       [rax+10],edi
M15_L46:
       dec       edi
       imul      edi,9E3779B9
       mov       edx,[r12+18]
       test      edx,edx
       jge       short M15_L47
       mov       ecx,edi
       mov       esi,[r12+20]
       imul      rcx,rsi
       shr       rcx,20
       jmp       short M15_L48
M15_L47:
       mov       ecx,edi
       and       ecx,edx
M15_L48:
       mov       eax,ecx
       mov       rdi,[r12+8]
       mov       [rbp-44],eax
       lea       edx,[rax*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M15_L63
       lea       rdi,[rdi+rdx*8+10]
       mov       rcx,[rdi]
       mov       [rbp-0B0],rcx
       test      rcx,rcx
       je        short M15_L50
       mov       rdx,rcx
       xor       esi,esi
       call      00007F31E1674060
       mov       rdi,[rbp-0B0]
       cmp       rax,rdi
       mov       eax,[rbp-44]
       je        short M15_L51
M15_L49:
       xor       esi,esi
       jmp       short M15_L52
M15_L50:
       mov       eax,[rbp-44]
       jmp       short M15_L49
M15_L51:
       mov       rcx,rdi
       mov       rsi,rcx
M15_L52:
       mov       [rbp-50],rsi
       mov       rcx,[rbp-0A8]
       jmp       near ptr M15_L07
M15_L53:
       mov       rax,7F316225B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-58],eax
       test      eax,eax
       je        short M15_L53
       mov       rdi,7F31E18A0D68
       mov       rcx,7F31E21B6820
       call      rcx
       add       rax,40
       mov       ecx,[rbp-58]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M15_L01
M15_L54:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M15_L02
M15_L55:
       call      qword ptr [7F31642865F8]
       int       3
M15_L56:
       mov       rcx,[rbp-0A8]
       jmp       near ptr M15_L03
M15_L57:
       mov       rsi,[rdx]
       mov       r9d,esi
       cmp       r9d,0FFFFFFFF
       jne       near ptr M15_L04
       mov       eax,[rbp-54]
M15_L58:
       xor       edx,edx
       mov       [rbp-50],rdx
       jmp       near ptr M15_L06
M15_L59:
       lea       rdx,[rbp-50]
       mov       rdi,rcx
       mov       esi,eax
       call      qword ptr [7F3163CDDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       mov       eax,[rbp-44]
       mov       rcx,[rbp-0A8]
       jmp       near ptr M15_L07
M15_L60:
       test      rcx,rcx
       je        short M15_L61
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-0C8],rax
       mov       rdi,rax
       call      qword ptr [7F31641F69A0]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-0C8]
       jmp       near ptr M15_L09
M15_L61:
       mov       rdi,r12
       mov       esi,eax
       call      qword ptr [7F31641F6958]
       mov       rdx,rax
       jmp       near ptr M15_L08
M15_L62:
       mov       [rbp-0A0],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r12+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-0A0]
       mov       r11,7F31622605D0
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F31641F68F8]
       mov       r12,rax
       jmp       near ptr M15_L10
M15_L63:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 2050
```
```assembly
; Kevlar.KevlarContext.get_PropertiesForCompletion()
       cmp       byte ptr [rdi+64],0
       jne       short M16_L00
       mov       rax,[rdi+8]
       ret
M16_L00:
       mov       rax,[rdi+10]
       ret
; Total bytes of code 16
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       push      rbp
       push      r15
       push      r14
       push      rbx
       sub       rsp,18
       lea       rbp,[rsp+30]
       mov       rbx,rsi
       lea       rdi,[rbx+60]
       mov       rsi,[rbx+48]
       mov       rax,[rdi]
       mov       r15d,eax
       cmp       r15d,0FFFFFFFF
       je        near ptr M17_L03
       mov       ecx,[rsi+8]
M17_L00:
       cmp       r15d,ecx
       jae       near ptr M17_L04
       mov       r14d,r15d
       shl       r14,4
       mov       r8d,[rsi+r14+18]
       mov       r9,rax
       sar       r9,20
       inc       r9d
       movsxd    r9,r9d
       shl       r9,20
       or        r8,r9
       mov       [rbp-20],rax
       lock cmpxchg [rdi],r8
       cmp       rax,[rbp-20]
       jne       short M17_L02
       mov       rdi,[rbx+48]
       cmp       r15d,[rdi+8]
       jae       short M17_L04
       lea       rdi,[rdi+r14+10]
       mov       rsi,rdx
       call      CORINFO_HELP_ASSIGN_REF
       lea       rcx,[rbx+58]
       mov       rdx,[rbx+48]
M17_L01:
       mov       rax,[rcx]
       mov       [rbp-28],rax
       cmp       r15d,[rdx+8]
       jae       short M17_L04
       mov       [rdx+r14+18],eax
       mov       rdi,rax
       sar       rdi,20
       inc       edi
       movsxd    rdi,edi
       shl       rdi,20
       mov       esi,r15d
       or        rdi,rsi
       lock cmpxchg [rcx],rdi
       cmp       rax,[rbp-28]
       jne       short M17_L01
       mov       eax,1
       add       rsp,18
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M17_L02:
       mov       rax,[rdi]
       mov       r15d,eax
       cmp       r15d,0FFFFFFFF
       jne       near ptr M17_L00
M17_L03:
       xor       eax,eax
       add       rsp,18
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M17_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 234
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      r15
       push      rbx
       push      rax
       mov       rbx,rdi
       mov       rdi,[rbx+20]
       mov       r15,[rdi-10]
       mov       rdi,r15
       test      dil,1
       jne       short M18_L00
       mov       rdi,7F31642DD7EC
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,r15
       add       rsp,8
       pop       rbx
       pop       r15
       ret
M18_L00:
       mov       rdi,7F31642DD7E8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,rbx
       add       rsp,8
       pop       rbx
       pop       r15
       jmp       qword ptr [7F316363EA48]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 81
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+30]
       mov       rbx,rsi
       mov       r15,rdx
       lea       rdi,[rbx+58]
       mov       rsi,[rbx+48]
       mov       rax,[rdi]
       mov       r14d,eax
       cmp       r14d,0FFFFFFFF
       je        near ptr M19_L03
       mov       ecx,[rsi+8]
M19_L00:
       cmp       r14d,ecx
       jae       near ptr M19_L04
       mov       r13d,r14d
       shl       r13,4
       mov       edx,[rsi+r13+18]
       mov       r8,rax
       sar       r8,20
       inc       r8d
       movsxd    r8,r8d
       shl       r8,20
       or        rdx,r8
       mov       [rbp-28],rax
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-28]
       jne       short M19_L02
       mov       rdi,[rbx+48]
       cmp       r14d,[rdi+8]
       jae       near ptr M19_L04
       mov       rsi,[rdi+r13+10]
       mov       rdi,r15
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbx+48]
       cmp       r14d,[rax+8]
       jae       short M19_L04
       lea       rcx,[rax+r13+10]
       xor       eax,eax
       mov       [rcx],rax
       add       rbx,60
M19_L01:
       mov       rax,[rbx]
       mov       [rbp-30],rax
       mov       [rcx+8],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       edi,r14d
       or        rdx,rdi
       lock cmpxchg [rbx],rdx
       cmp       rax,[rbp-30]
       jne       short M19_L01
       cmp       qword ptr [r15],0
       setne     al
       movzx     eax,al
       add       rsp,10
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M19_L02:
       mov       rax,[rdi]
       mov       r14d,eax
       cmp       r14d,0FFFFFFFF
       jne       near ptr M19_L00
M19_L03:
       xor       eax,eax
       mov       [r15],rax
       add       rsp,10
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M19_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 263
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       push      rbp
       sub       rsp,60
       lea       rbp,[rsp+60]
       xor       eax,eax
       mov       [rbp-54],rax
       mov       [rbp-4C],eax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-3C],esi
       mov       [rbp-48],rdx
       mov       dword ptr [rbp-60],3E8
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7F3163CDDD40]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       eax,[rax+14]
       dec       eax
       mov       [rbp-4C],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-4C]
       jbe       short M20_L02
       mov       eax,[rbp-4C]
       cmp       eax,[rbp-3C]
       je        short M20_L01
       mov       rdi,[rbp-38]
       mov       esi,[rbp-4C]
       mov       rdx,[rbp-48]
       call      qword ptr [7F3163CDDD10]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       je        short M20_L00
       mov       rdi,7F31640D72E0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,60
       pop       rbp
       ret
M20_L00:
       mov       rdi,7F31640D72E4
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       short M20_L02
M20_L01:
       mov       rdi,7F31640D72E8
       call      CORINFO_HELP_COUNTPROFILE32
M20_L02:
       mov       eax,[rbp-3C]
       mov       [rbp-50],eax
       mov       dword ptr [rbp-54],1
       jmp       near ptr M20_L06
M20_L03:
       mov       eax,[rbp-50]
       inc       eax
       mov       [rbp-58],eax
       mov       eax,[rbp-50]
       inc       eax
       mov       [rbp-50],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-58]
       jne       short M20_L04
       mov       rdi,7F31640D72EC
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-50],eax
M20_L04:
       mov       rdi,[rbp-38]
       mov       esi,[rbp-50]
       mov       rdx,[rbp-48]
       call      qword ptr [7F3163CDDD10]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       test      eax,eax
       je        short M20_L05
       mov       rdi,7F31640D72F0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7F3163CDDD40]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       ecx,[rbp-50]
       inc       ecx
       mov       [rax+14],ecx
       mov       eax,1
       add       rsp,60
       pop       rbp
       ret
M20_L05:
       mov       rdi,7F31640D72F4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-54]
       inc       eax
       mov       [rbp-54],eax
M20_L06:
       mov       eax,[rbp-60]
       dec       eax
       mov       [rbp-60],eax
       cmp       dword ptr [rbp-60],0
       jg        short M20_L07
       lea       rdi,[rbp-60]
       mov       esi,52
       call      CORINFO_HELP_PATCHPOINT
M20_L07:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-54]
       jg        near ptr M20_L03
       mov       rdi,7F31640D72F8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-48]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,60
       pop       rbp
       ret
; Total bytes of code 406
```
```assembly
; Kevlar.KevlarContext..ctor()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F31641F69B8]; Kevlar.KevlarProperties..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,offset MT_System.Object
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-18],rax
       mov       rdi,[rbp-18]
       call      qword ptr [7F316324C240]; System.Object..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+20]
       mov       rsi,[rbp-18]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-8]
       mov       dword ptr [rax+5C],0FFFFFFFF
       call      qword ptr [7F3163CDE658]; System.TimeProvider.get_System()
       mov       rcx,[rbp-8]
       lea       rdi,[rcx+38]
       mov       rsi,rax
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-8]
       call      qword ptr [7F316324C240]; System.Object..ctor()
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 166
```
```assembly
; System.Diagnostics.Metrics.Instrument.get_Enabled()
       mov       rax,[rdi+8]
       cmp       qword ptr [rax+8],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 16
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,130
       vzeroupper
       lea       rbp,[rsp+150]
       xor       eax,eax
       mov       [rbp-148],rax
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFEE0
M23_L00:
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       vmovdqa   xmmword ptr [rax+rbp],xmm8
       add       rax,30
       jne       short M23_L00
       mov       r15,rdi
       mov       rbx,rsi
       mov       r14d,edx
       mov       r13,[rbx+30]
       xor       edi,edi
       mov       [rbp-0B8],rdi
       test      r15,r15
       jne       short M23_L03
M23_L01:
       mov       rsi,[rbx+30]
       mov       rdi,7F2979800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M23_L04
M23_L02:
       add       rsp,130
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M23_L03:
       mov       rdi,7F2979800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F3163CDEAD8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        short M23_L01
       lea       rdi,[rbp-0B0]
       mov       rsi,r13
       call      qword ptr [7F31641F7330]
       mov       rdx,7F3158A0B6A8
       mov       rdi,7F3158A0B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-0B0]
       mov       rsi,7F3158A0B638
       call      qword ptr [7F31641F7348]
       call      00007F3163238AE0
       mov       rsi,rax
       mov       rdi,r15
       call      qword ptr [7F3164286E20]
       mov       [rbp-0B8],rax
       lea       rdi,[rbp-0B8]
       call      qword ptr [7F31641F7378]
       mov       rdi,7F2979800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-0B0]
       mov       rdx,rbx
       call      qword ptr [7F31641F7390]
       jmp       near ptr M23_L01
M23_L04:
       lea       rdi,[rbp-148]
       call      qword ptr [7F31641F7330]
       mov       rdx,7F3158A0B6A8
       mov       rdi,7F3158A0B680
       test      r14b,r14b
       cmove     rdx,rdi
       lea       rdi,[rbp-148]
       mov       rsi,7F3158A0B638
       call      qword ptr [7F31641F7348]
       mov       rdi,7F2979800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-148]
       mov       rcx,rbx
       mov       esi,1
       call      qword ptr [7F31641F73A8]
       jmp       near ptr M23_L02
; Total bytes of code 410
```
```assembly
; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+50]
       mov       rbx,rdi
       mov       rdi,7F29798013C0
       mov       r15,[rdi]
       test      rbx,rbx
       je        near ptr M24_L07
       cmp       byte ptr [r15+24],0
       jne       near ptr M24_L08
       cmp       dword ptr [r15+1C],0
       jne       near ptr M24_L09
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7F31641F7450]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItemGuarded(System.__Canon)
       test      eax,eax
       je        near ptr M24_L10
       mov       r14,[r15+10]
       test      r14,r14
       je        near ptr M24_L17
       mov       rdi,7F31E18A0D68
       mov       rax,7F31E21B6820
       call      rax
       add       rax,40
       mov       r13d,[rax+10]
       test      r13d,r13d
       je        near ptr M24_L11
M24_L00:
       dec       r13d
       mov       r12d,[r14+18]
       test      r12d,r12d
       jl        near ptr M24_L12
       and       r12d,r13d
M24_L01:
       xor       r13d,r13d
       mov       rdi,[r14+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M24_L16
M24_L02:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M24_L25
       mov       esi,r12d
       mov       rax,[rdi+rsi*8+10]
       mov       [rbp-48],rax
       cmp       qword ptr [rax+50],0
       jne       short M24_L04
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M24_L22
       mov       rsi,rbx
       xor       edx,edx
       call      00007F31E1674060
       test      rax,rax
       mov       rax,[rbp-48]
       jne       short M24_L04
M24_L03:
       cmp       dword ptr [r15+1C],0
       jne       near ptr M24_L24
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M24_L04:
       lea       rdi,[rax+60]
       mov       rsi,[rax+48]
       mov       rcx,[rdi]
       mov       edx,ecx
       cmp       edx,0FFFFFFFF
       je        near ptr M24_L14
       mov       r8d,[rsi+8]
M24_L05:
       cmp       edx,r8d
       jae       near ptr M24_L25
       mov       r9d,edx
       shl       r9,4
       mov       [rbp-40],r9
       mov       r10d,[rsi+r9+18]
       mov       r11,rcx
       sar       r11,20
       inc       r11d
       movsxd    r11,r11d
       shl       r11,20
       or        r10,r11
       mov       rax,rcx
       lock cmpxchg [rdi],r10
       cmp       rax,rcx
       jne       near ptr M24_L13
       mov       r14,[rbp-48]
       mov       rdi,[r14+48]
       mov       [rbp-2C],edx
       cmp       edx,[rdi+8]
       jae       near ptr M24_L25
       lea       rdi,[rdi+r9+10]
       mov       rsi,rbx
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r14+58]
       mov       rcx,[r14+48]
       mov       ebx,[rbp-2C]
M24_L06:
       mov       rax,[rdi]
       mov       [rbp-38],rax
       cmp       ebx,[rcx+8]
       jae       near ptr M24_L25
       mov       r14,[rbp-40]
       mov       [rcx+r14+18],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       esi,ebx
       or        rdx,rsi
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-38]
       jne       short M24_L06
       jmp       near ptr M24_L03
M24_L07:
       mov       edi,29
       mov       rsi,7F31636C54F0
       call      qword ptr [7F316324EF88]
       mov       rdi,rax
       call      qword ptr [7F31642865C8]
       int       3
M24_L08:
       mov       rdi,r15
       mov       rsi,rbx
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F31641F73F0]
M24_L09:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F3162260548
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M24_L10:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F3162260550
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M24_L11:
       mov       rdi,7F316225B1A8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M24_L11
       mov       rdi,7F31E18A0D68
       mov       rax,7F31E21B6820
       call      rax
       add       rax,40
       mov       [rax+10],r13d
       jmp       near ptr M24_L00
M24_L12:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r13d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
       jmp       near ptr M24_L01
M24_L13:
       mov       rcx,[rdi]
       mov       edx,ecx
       cmp       edx,0FFFFFFFF
       jne       near ptr M24_L05
M24_L14:
       inc       r12d
       mov       rdx,[r14+8]
       cmp       [rdx+8],r12d
       jne       short M24_L15
       xor       r12d,r12d
M24_L15:
       inc       r13d
       cmp       [rdx+8],r13d
       jg        near ptr M24_L02
M24_L16:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F3162260558
       call      qword ptr [r11]
       jmp       near ptr M24_L03
M24_L17:
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r14d,[rax+10]
       test      r14d,r14d
       jne       short M24_L19
M24_L18:
       mov       rdi,7F316225B200
       mov       eax,1
       mov       r14d,eax
       lock xadd [rdi],r14d
       inc       r14d
       je        short M24_L18
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r14d
M24_L19:
       dec       r14d
       imul      r14d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M24_L20
       mov       r13d,r14d
       mov       r12d,[r15+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M24_L21
M24_L20:
       and       r14d,[r15+18]
       mov       r13d,r14d
M24_L21:
       mov       rdi,[r15+8]
       lea       esi,[r13*8+8]
       cmp       esi,[rdi+8]
       jae       short M24_L25
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M24_L23
M24_L22:
       call      qword ptr [7F31642865F8]
       int       3
M24_L23:
       mov       rsi,rbx
       call      00007F31E1674040
       test      rax,rax
       je        near ptr M24_L03
       mov       rdi,r15
       mov       rsi,rbx
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7F31641F7660]
       jmp       near ptr M24_L03
M24_L24:
       mov       rdi,r15
       add       rsp,28
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F31641F7690]
M24_L25:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 1021
```
```assembly
; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,50
       lea       rbp,[rsp+60]
       xor       eax,eax
       mov       [rbp-58],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       rbx,rdi
       mov       r15,rsi
       mov       rdi,[rbx+28]
       cmp       dword ptr [rdi+0C],0
       jne       short M25_L02
M25_L00:
       cmp       qword ptr [rbx+10],0
       jne       short M25_L03
M25_L01:
       add       rsp,50
       pop       rbx
       pop       r15
       pop       rbp
       ret
M25_L02:
       mov       rdi,[r15+28]
       mov       esi,1
       cmp       [rdi],edi
       call      qword ptr [7F3164286D30]
       jmp       short M25_L00
M25_L03:
       mov       rdi,[rbx+10]
       mov       rdx,[rbx+38]
       mov       rcx,[rbx+40]
       mov       rsi,r15
       mov       rax,[rdi]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
       cmp       qword ptr [rbx+18],0
       je        short M25_L01
       mov       rdi,[rbx+18]
       lea       rsi,[rbp-40]
       cmp       [rdi],edi
       call      qword ptr [7F31641F7A08]
       jmp       short M25_L05
M25_L04:
       mov       rdi,[rbp-28]
       vmovdqu   xmm0,xmmword ptr [rbp-28]
       vmovdqu   xmmword ptr [rbp-58],xmm0
       mov       rdx,[rbp-18]
       mov       [rbp-48],rdx
       mov       rdx,[rbp-50]
       mov       rcx,[rbp-48]
       mov       rsi,r15
       mov       rax,[rdi]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
M25_L05:
       lea       rdi,[rbp-40]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F31641F7A68]
       test      eax,eax
       jne       short M25_L04
       jmp       near ptr M25_L01
; Total bytes of code 207
```
```assembly
; Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,0D0
       lea       rbp,[rsp+0F0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       xor       eax,eax
       mov       [rbp-30],rax
       mov       [rbp-28],rdi
       mov       [rbp-0D8],rdi
       mov       rbx,rsi
       mov       r14,rdx
       mov       r13,rcx
       mov       r15,r8
       mov       rsi,[rdi]
       mov       rax,[rsi+30]
       mov       rax,[rax]
       mov       rax,[rax+18]
       test      rax,rax
       je        near ptr M26_L14
M26_L00:
       mov       [rbp-48],r14
       mov       [rbp-40],r13
       mov       [rbp-70],r15
       mov       dword ptr [rbp-68],0FFFFFFFF
       mov       rsi,[rax+18]
       mov       rcx,[rsi+18]
       test      rcx,rcx
       je        near ptr M26_L15
M26_L01:
       mov       rsi,[rcx+18]
       mov       r15,[rsi+10]
       test      r15,r15
       je        near ptr M26_L16
M26_L02:
       mov       rdi,7F31E18A0D68
       mov       rax,7F31E21B6820
       call      rax
       cmp       dword ptr [rax],4
       jle       near ptr M26_L17
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        near ptr M26_L17
M26_L03:
       mov       r14,[rax+10]
       test      r14,r14
       jne       short M26_L04
       call      qword ptr [7F316392C420]; System.Threading.Thread.InitializeCurrentThread()
       mov       r14,rax
M26_L04:
       mov       [rbp-0E0],r14
       mov       rsi,[r14+8]
       mov       [rbp-0E8],rsi
       mov       rsi,[r14+10]
       mov       [rbp-0F0],rsi
       mov       rdi,[r15+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M26_L06
M26_L05:
       lea       rdi,[rbp-70]
       call      rax
       jmp       short M26_L07
M26_L06:
       mov       rdi,r15
       mov       rsi,7F31641D82A0
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M26_L05
M26_L07:
       mov       rsi,[rbp-0F0]
       cmp       rsi,[r14+10]
       je        short M26_L08
       lea       rdi,[r14+10]
       call      CORINFO_HELP_ASSIGN_REF
M26_L08:
       mov       rdi,[r14+8]
       mov       r15,rdi
       mov       rsi,[rbp-0E8]
       cmp       rsi,r15
       je        short M26_L10
       lea       rdi,[r14+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      r15,r15
       je        short M26_L09
       cmp       qword ptr [r15+10],0
       jne       near ptr M26_L13
M26_L09:
       cmp       qword ptr [rbp-0E8],0
       jne       short M26_L12
M26_L10:
       mov       rdi,[rbp-60]
       mov       rax,7F29798013E8
       cmp       rdi,[rax]
       jne       near ptr M26_L18
       vmovdqu   xmm0,xmmword ptr [rbp-58]
       vmovdqu   xmmword ptr [rbp-0C0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-0D0]
       vmovdqu   ymmword ptr [rbp-90],ymm0
       xor       r15d,r15d
M26_L11:
       mov       [rbp-90],r15
       vmovdqu   ymm0,ymmword ptr [rbp-90]
       vmovdqu   ymmword ptr [rbx],ymm0
       mov       word ptr [rbx+8],0
       mov       byte ptr [rbx+0A],1
       mov       rax,rbx
       vzeroupper
       add       rsp,0D0
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M26_L12:
       mov       rsi,[rbp-0E8]
       cmp       qword ptr [rsi+10],0
       je        short M26_L10
M26_L13:
       mov       rdi,r15
       mov       rsi,[rbp-0E8]
       call      qword ptr [7F3164287330]
       jmp       near ptr M26_L10
M26_L14:
       mov       rdi,rsi
       mov       rsi,7F31641D7240
       call      qword ptr [7F316324F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       jmp       near ptr M26_L00
M26_L15:
       mov       rdi,rax
       mov       rsi,7F31641D7EB8
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       mov       rcx,rdi
       jmp       near ptr M26_L01
M26_L16:
       mov       rdi,rcx
       mov       rsi,7F31641D8118
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       r15,rax
       jmp       near ptr M26_L02
M26_L17:
       mov       edi,4
       call      qword ptr [7F3164286610]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       near ptr M26_L03
M26_L18:
       mov       r15,[rbp-60]
       test      r15,r15
       jne       short M26_L19
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r15,rax
       mov       rdi,r15
       call      qword ptr [7F3164286D78]
       mov       [rbp-60],r15
M26_L19:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-0A0],xmm0
       vmovdqu   ymm0,ymmword ptr [rbp-0B0]
       vmovdqu   ymmword ptr [rbp-90],ymm0
       jmp       near ptr M26_L11
       push      rax
       mov       rsi,[rbp-0F0]
       mov       rax,[rbp-0E0]
       cmp       rsi,[rax+10]
       je        short M26_L20
       lea       rdi,[rax+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-0E0]
M26_L20:
       mov       rbx,[rax+8]
       mov       rsi,[rbp-0E8]
       cmp       rsi,rbx
       je        short M26_L23
       lea       rdi,[rax+8]
       call      CORINFO_HELP_ASSIGN_REF
       test      rbx,rbx
       je        short M26_L21
       cmp       qword ptr [rbx+10],0
       jne       short M26_L22
M26_L21:
       cmp       qword ptr [rbp-0E8],0
       je        short M26_L23
       mov       rsi,[rbp-0E8]
       cmp       qword ptr [rsi+10],0
       je        short M26_L23
M26_L22:
       mov       rdi,rbx
       mov       rsi,[rbp-0E8]
       call      qword ptr [7F3164287330]
M26_L23:
       nop
       vzeroupper
       add       rsp,8
       ret
; Total bytes of code 814
```
```assembly
; System.Runtime.CompilerServices.AsyncMethodBuilderCore.Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       push      rbp
       push      r15
       push      r14
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+40]
       mov       [rbp-20],rdi
       mov       rbx,rdi
       mov       r15,rsi
       cmp       [r15],r15b
       mov       rdi,7F31E18A0D68
       mov       rax,7F31E21B6820
       call      rax
       cmp       dword ptr [rax],4
       jle       short M27_L07
       mov       rdi,[rax+8]
       mov       rax,[rdi+20]
       test      rax,rax
       je        short M27_L07
M27_L00:
       mov       r14,[rax+10]
       test      r14,r14
       jne       short M27_L01
       call      qword ptr [7F316392C420]; System.Threading.Thread.InitializeCurrentThread()
       mov       r14,rax
M27_L01:
       mov       [rbp-28],r14
       mov       rsi,[r14+8]
       mov       [rbp-30],rsi
       mov       rsi,[r14+10]
       mov       [rbp-38],rsi
       mov       rdi,[rbx+18]
       mov       rax,[rdi+10]
       test      rax,rax
       je        short M27_L03
M27_L02:
       mov       rdi,r15
       call      rax
       jmp       short M27_L04
M27_L03:
       mov       rdi,rbx
       mov       rsi,7F31641D82A0
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       jmp       short M27_L02
M27_L04:
       mov       rsi,[rbp-38]
       cmp       rsi,[r14+10]
       jne       short M27_L08
M27_L05:
       mov       rdx,[r14+8]
       cmp       [rbp-30],rdx
       jne       short M27_L09
M27_L06:
       add       rsp,28
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M27_L07:
       mov       edi,4
       call      qword ptr [7F3164286610]; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       jmp       short M27_L00
M27_L08:
       lea       rdi,[r14+10]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M27_L05
M27_L09:
       mov       rdi,r14
       mov       rsi,[rbp-30]
       call      qword ptr [7F31641F6E98]
       jmp       short M27_L06
       push      rax
       mov       rsi,[rbp-38]
       mov       rdi,[rbp-28]
       cmp       rsi,[rdi+10]
       je        short M27_L10
       lea       rdi,[rdi+10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-28]
M27_L10:
       mov       rdx,[rdi+8]
       cmp       [rbp-30],rdx
       je        short M27_L11
       mov       rsi,[rbp-30]
       call      qword ptr [7F31641F6E98]
M27_L11:
       nop
       add       rsp,8
       ret
; Total bytes of code 271
```
```assembly
; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.Outcome`1<Int32>)
       push      r15
       push      rbx
       mov       rbx,rdi
       mov       r15d,edx
       lea       rdi,[rbx+10]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       [rbx+18],r15d
       xor       eax,eax
       mov       [rbx],rax
       mov       byte ptr [rbx+0A],1
       mov       word ptr [rbx+8],0
       pop       rbx
       pop       r15
       ret
; Total bytes of code 41
```
```assembly
; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Result()
       push      rbp
       push      r15
       push      r14
       push      rbx
       push      rax
       lea       rbp,[rsp+20]
       mov       rbx,rdi
       mov       r15,[rbx]
       test      r15,r15
       jne       short M29_L00
       mov       rax,[rbx+10]
       mov       edx,[rbx+18]
       add       rsp,8
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M29_L00:
       mov       rsi,r15
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F3163246838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r14,rax
       test      r14,r14
       je        short M29_L02
       mov       edi,[r14+34]
       and       edi,11000000
       cmp       edi,1000000
       je        short M29_L01
       mov       rdi,r14
       xor       esi,esi
       call      qword ptr [7F3164286598]
M29_L01:
       mov       rax,[r14+38]
       mov       edx,[r14+40]
       add       rsp,8
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M29_L02:
       movsx     rsi,word ptr [rbx+8]
       mov       rdi,r15
       mov       r11,7F3162260540
       add       rsp,8
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
; Total bytes of code 147
```
```assembly
; Kevlar.Internal.ShieldEngine.ReturnChildContext(Kevlar.KevlarContext, Kevlar.KevlarContext)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,108
       lea       rbp,[rsp+130]
       xor       eax,eax
       mov       [rbp-0D8],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       mov       [rbp-100],rdi
       mov       rbx,rdi
       mov       r15,rsi
       mov       rdi,[rbx+20]
       mov       [rbp-108],rdi
       xor       eax,eax
       mov       [rbp-2C],eax
       test      rdi,rdi
       je        near ptr M30_L09
       call      00007F31E14E6020
       test      eax,eax
       je        near ptr M30_L10
M30_L00:
       mov       dword ptr [rbp-2C],1
       cmp       byte ptr [rbx+64],0
       jne       near ptr M30_L11
       mov       r14,[rbx+8]
M30_L01:
       mov       r13,[rbx+18]
       mov       r15,[r15+8]
       mov       rdi,[r14+28]
       cmp       dword ptr [rdi+0C],0
       jne       near ptr M30_L12
M30_L02:
       mov       r12,[r13+10]
       mov       rax,[r13+38]
       mov       [rbp-118],rax
       mov       rcx,[r13+40]
       mov       [rbp-120],rcx
       test      r12,r12
       jne       near ptr M30_L13
M30_L03:
       cmp       qword ptr [r13+18],0
       jne       near ptr M30_L15
M30_L04:
       mov       r12,[r14+10]
       mov       rax,[r14+38]
       mov       [rbp-128],rax
       mov       rcx,[r14+40]
       mov       [rbp-130],rcx
       cmp       qword ptr [r13+10],0
       jne       near ptr M30_L18
M30_L05:
       cmp       qword ptr [r13+18],0
       jne       near ptr M30_L19
M30_L06:
       xor       edx,edx
M30_L07:
       xor       edi,edi
       mov       [rbp-0C8],rdi
       test      r12,r12
       mov       [rbp-110],rdx
       jne       near ptr M30_L20
M30_L08:
       cmp       qword ptr [r14+18],0
       je        near ptr M30_L24
       jmp       near ptr M30_L21
M30_L09:
       xor       edi,edi
       call      qword ptr [7F31642865C8]
       int       3
M30_L10:
       mov       rdi,[rbp-108]
       call      qword ptr [7F31642845E8]; System.Threading.Monitor.Enter_Slowpath(System.Object)
       jmp       near ptr M30_L00
M30_L11:
       mov       r14,[rbx+10]
       jmp       near ptr M30_L01
M30_L12:
       mov       rdi,[r13+28]
       cmp       dword ptr [rdi+0C],0
       jne       near ptr M30_L02
       mov       rdi,[r15+28]
       cmp       dword ptr [rdi+0C],0
       jne       near ptr M30_L02
       mov       rdi,[r15+28]
       mov       esi,1
       cmp       [rdi],edi
       call      qword ptr [7F3164286D30]
       jmp       near ptr M30_L02
M30_L13:
       mov       rdi,r12
       mov       rdx,[r12]
       mov       rdx,[rdx+40]
       call      qword ptr [rdx+20]
       test      eax,eax
       je        near ptr M30_L03
       mov       rsi,[rbp-118]
       mov       rdx,[rbp-120]
       mov       rdi,r14
       call      qword ptr [7F31641F7BA0]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       test      rax,rax
       je        short M30_L14
       mov       rdi,rax
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       jne       near ptr M30_L03
M30_L14:
       mov       rsi,[rbp-118]
       mov       rdx,[rbp-120]
       mov       rdi,r15
       cmp       [rdi],edi
       call      qword ptr [7F31641F7BA0]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,r12
       call      qword ptr [7F31641F7BB8]
       test      eax,eax
       je        near ptr M30_L03
       mov       rsi,[rbp-118]
       mov       rdx,[rbp-120]
       mov       rdi,r15
       call      qword ptr [7F31641F7BD0]
       jmp       near ptr M30_L03
M30_L15:
       mov       rdi,[r13+18]
       lea       rsi,[rbp-60]
       cmp       [rdi],edi
       call      qword ptr [7F31641F7A08]
       jmp       short M30_L17
M30_L16:
       mov       rdi,[rbp-48]
       vmovdqu   xmm0,xmmword ptr [rbp-48]
       vmovdqu   xmmword ptr [rbp-78],xmm0
       mov       rsi,[rbp-38]
       mov       [rbp-68],rsi
       mov       rsi,[rbp-70]
       mov       rdx,[rbp-68]
       mov       rcx,r14
       mov       r8,r15
       call      qword ptr [7F31641F7B70]; Kevlar.KevlarProperties.RemoveMissingValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
M30_L17:
       lea       rdi,[rbp-60]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F31641F7A68]
       test      eax,eax
       jne       short M30_L16
       jmp       near ptr M30_L04
M30_L18:
       vmovdqu   xmm0,xmmword ptr [r13+38]
       vmovdqu   xmmword ptr [rbp-0D8],xmm0
       mov       rsi,rax
       mov       rdx,rcx
       lea       rdi,[rbp-0D8]
       call      qword ptr [7F31642875E8]
       test      eax,eax
       mov       rax,[rbp-128]
       mov       rcx,[rbp-130]
       je        near ptr M30_L05
       mov       rdx,[r13+10]
       mov       [rbp-110],rdx
       mov       rdx,[rbp-110]
       jmp       near ptr M30_L07
M30_L19:
       mov       rdi,[r13+18]
       mov       rsi,rax
       mov       rdx,rcx
       lea       rcx,[rbp-0C8]
       cmp       [rdi],edi
       call      qword ptr [7F3164222660]
       test      eax,eax
       mov       rax,[rbp-128]
       mov       rcx,[rbp-130]
       je        near ptr M30_L06
       mov       rdx,[rbp-0C8]
       jmp       near ptr M30_L07
M30_L20:
       mov       rdi,r12
       mov       rsi,[r12]
       mov       rsi,[rsi+40]
       call      qword ptr [rsi+20]
       test      eax,eax
       je        near ptr M30_L08
       mov       rdi,r12
       mov       rsi,[rbp-110]
       call      qword ptr [7F31641F7BB8]
       test      eax,eax
       jne       near ptr M30_L08
       mov       rsi,[rbp-128]
       mov       rdx,[rbp-130]
       mov       rdi,r15
       cmp       [rdi],edi
       call      qword ptr [7F31641F7BA0]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,[rbp-110]
       call      qword ptr [7F31641F7BB8]
       test      eax,eax
       je        near ptr M30_L08
       mov       rdx,[rbp-128]
       mov       rcx,[rbp-130]
       mov       rdi,r12
       mov       rsi,r15
       mov       rax,[r12]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
       jmp       near ptr M30_L08
M30_L21:
       mov       rdi,[r14+18]
       lea       rsi,[rbp-0A8]
       cmp       [rdi],edi
       call      qword ptr [7F31641F7A08]
       jmp       short M30_L23
M30_L22:
       mov       rdi,[rbp-90]
       vmovdqu   xmm0,xmmword ptr [rbp-90]
       vmovdqu   xmmword ptr [rbp-0C0],xmm0
       mov       rsi,[rbp-80]
       mov       [rbp-0B0],rsi
       mov       rsi,[rbp-0B8]
       mov       rdx,[rbp-0B0]
       mov       rcx,r13
       mov       r8,r15
       call      qword ptr [7F31641F7BE8]; Kevlar.KevlarProperties.CopyChangedValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
M30_L23:
       lea       rdi,[rbp-0A8]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F31641F7A68]
       test      eax,eax
       jne       short M30_L22
M30_L24:
       mov       rdi,[rbp-108]
       call      00007F31E14E6790
       test      eax,eax
       je        short M30_L25
       mov       edi,eax
       mov       rsi,[rbp-108]
       call      qword ptr [7F3164286658]
       nop
M30_L25:
       call      M30_L28
       nop
       add       rsp,108
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
       push      rax
       cmp       dword ptr [rbp-2C],0
       je        short M30_L27
       cmp       qword ptr [rbp-108],0
       jne       short M30_L26
       xor       edi,edi
       call      qword ptr [7F31642865C8]
       int       3
M30_L26:
       mov       rdi,[rbp-108]
       call      00007F31E14E6790
       test      eax,eax
       je        short M30_L27
       mov       edi,eax
       mov       rsi,[rbp-108]
       call      qword ptr [7F3164286658]
M30_L27:
       nop
       add       rsp,8
       ret
M30_L28:
       push      rax
       mov       rdi,7F29798013C0
       mov       rbx,[rdi]
       cmp       qword ptr [rbp-100],0
       jne       short M30_L29
       mov       edi,29
       mov       rsi,7F31636C54F0
       call      qword ptr [7F316324EF88]
       mov       rdi,rax
       call      qword ptr [7F31642865C8]
       int       3
M30_L29:
       cmp       byte ptr [rbx+24],0
       je        short M30_L30
       mov       rdi,rbx
       mov       rsi,[rbp-100]
       call      qword ptr [7F31641F73F0]
       jmp       near ptr M30_L56
M30_L30:
       cmp       dword ptr [rbx+1C],0
       je        short M30_L31
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-100]
       mov       r11,7F3162260668
       call      qword ptr [r11]
       jmp       near ptr M30_L56
M30_L31:
       mov       rdi,rbx
       mov       rsi,[rbp-100]
       call      qword ptr [7F31641F7450]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItemGuarded(System.__Canon)
       test      eax,eax
       jne       short M30_L32
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-100]
       mov       r11,7F3162260670
       call      qword ptr [r11]
       jmp       near ptr M30_L56
M30_L32:
       mov       r15,[rbx+10]
       test      r15,r15
       je        near ptr M30_L47
       mov       rdi,7F31E18A0D68
       mov       rax,7F31E21B6820
       call      rax
       add       rax,40
       mov       r14d,[rax+10]
       test      r14d,r14d
       jne       short M30_L34
M30_L33:
       mov       rdi,7F316225B1A8
       mov       eax,1
       mov       r14d,eax
       lock xadd [rdi],r14d
       inc       r14d
       je        short M30_L33
       mov       rdi,7F31E18A0D68
       mov       rax,7F31E21B6820
       call      rax
       add       rax,40
       mov       [rax+10],r14d
M30_L34:
       dec       r14d
       mov       r13d,[r15+18]
       test      r13d,r13d
       jl        short M30_L35
       and       r13d,r14d
       jmp       short M30_L36
M30_L35:
       mov       rdi,[r15+8]
       mov       edi,[rdi+8]
       mov       r13d,r14d
       imul      r13,[r15+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
M30_L36:
       xor       r14d,r14d
       mov       rdi,[r15+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M30_L46
M30_L37:
       mov       rdi,[r15+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M30_L54
       mov       esi,r13d
       mov       r12,[rdi+rsi*8+10]
       cmp       qword ptr [r12+50],0
       jne       short M30_L38
       lea       rdi,[r12+50]
       test      rdi,rdi
       je        near ptr M30_L52
       mov       rsi,[rbp-100]
       xor       edx,edx
       call      00007F31E1674060
       test      rax,rax
       je        near ptr M30_L45
M30_L38:
       lea       rdi,[r12+60]
       mov       rsi,[r12+48]
       mov       rax,[rdi]
       mov       ecx,eax
       cmp       ecx,0FFFFFFFF
       je        short M30_L41
       mov       edx,[rsi+8]
       jmp       short M30_L40
M30_L39:
       mov       rax,[rdi]
       mov       ecx,eax
       cmp       ecx,0FFFFFFFF
       je        short M30_L41
M30_L40:
       cmp       ecx,edx
       jae       near ptr M30_L54
       mov       r8d,ecx
       shl       r8,4
       mov       [rbp-0F8],r8
       mov       r9d,[rsi+r8+18]
       mov       r10,rax
       sar       r10,20
       inc       r10d
       movsxd    r10,r10d
       shl       r10,20
       or        r9,r10
       mov       [rbp-0E8],rax
       lock cmpxchg [rdi],r9
       cmp       rax,[rbp-0E8]
       jne       short M30_L39
       jmp       short M30_L43
M30_L41:
       inc       r13d
       mov       rcx,[r15+8]
       cmp       [rcx+8],r13d
       jne       short M30_L42
       xor       r13d,r13d
M30_L42:
       inc       r14d
       cmp       [rcx+8],r14d
       jg        near ptr M30_L37
       jmp       near ptr M30_L46
M30_L43:
       mov       rdi,[r12+48]
       mov       [rbp-0DC],ecx
       cmp       ecx,[rdi+8]
       jae       near ptr M30_L54
       lea       rdi,[rdi+r8+10]
       mov       rsi,[rbp-100]
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r12+58]
       mov       rcx,[r12+48]
       mov       r15d,[rbp-0DC]
M30_L44:
       mov       rax,[rdi]
       mov       [rbp-0F0],rax
       cmp       r15d,[rcx+8]
       jae       near ptr M30_L54
       mov       r14,[rbp-0F8]
       mov       [rcx+r14+18],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       esi,r15d
       or        rdx,rsi
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-0F0]
       jne       short M30_L44
M30_L45:
       cmp       dword ptr [rbx+1C],0
       je        near ptr M30_L56
       jmp       near ptr M30_L55
M30_L46:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-100]
       mov       r11,7F3162260678
       call      qword ptr [r11]
       jmp       short M30_L45
M30_L47:
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r15d,[rax+10]
       test      r15d,r15d
       jne       short M30_L49
M30_L48:
       mov       rdi,7F316225B200
       mov       eax,1
       mov       r15d,eax
       lock xadd [rdi],r15d
       inc       r15d
       je        short M30_L48
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r15d
M30_L49:
       dec       r15d
       imul      r15d,9E3779B9
       cmp       dword ptr [rbx+18],0
       jge       short M30_L50
       mov       r14d,r15d
       mov       r13d,[rbx+20]
       imul      r14,r13
       shr       r14,20
       jmp       short M30_L51
M30_L50:
       and       r15d,[rbx+18]
       mov       r14d,r15d
M30_L51:
       mov       rdi,[rbx+8]
       lea       esi,[r14*8+8]
       cmp       esi,[rdi+8]
       jae       short M30_L54
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M30_L53
M30_L52:
       call      qword ptr [7F31642865F8]
       int       3
M30_L53:
       mov       rsi,[rbp-100]
       call      00007F31E1674040
       test      rax,rax
       je        near ptr M30_L45
       mov       rdi,rbx
       mov       rsi,[rbp-100]
       mov       rdx,rax
       mov       ecx,r14d
       call      qword ptr [7F31641F7660]
       jmp       near ptr M30_L45
M30_L54:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M30_L55:
       mov       rdi,rbx
       call      qword ptr [7F31641F7690]
M30_L56:
       nop
       add       rsp,8
       ret
; Total bytes of code 2093
```
```assembly
; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]]..ctor(Int32)
       mov       [rdi+8],esi
       xor       eax,eax
       mov       [rdi],rax
       mov       byte ptr [rdi+0E],1
       mov       word ptr [rdi+0C],0
       ret
; Total bytes of code 19
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F3162DEEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F3162DEEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; PoolContextProbe+<>c.<NestedContext>b__6_1(Kevlar.KevlarContext)
       xor       eax,eax
       mov       rdx,100000000002A
       ret
; Total bytes of code 13
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](Kevlar.KevlarContext, System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
M34_L00:
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,368
       vzeroupper
       lea       rbp,[rsp+390]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-370],xmm8
       mov       rax,0FFFFFFFFFFFFFCD0
M34_L01:
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       add       rax,30
       jne       short M34_L01
       mov       [rbp-30],rax
       mov       rbx,rsi
       mov       r15,rdx
       test      r15,r15
       je        near ptr M34_L41
       test      rbx,rbx
       je        near ptr M34_L42
       mov       rax,[rdi+38]
       test      rax,rax
       jne       near ptr M34_L43
       cmp       byte ptr [rdi+48],0
       jne       near ptr M34_L44
       mov       r14,[rdi+10]
       mov       r13,[rdi+40]
       mov       rdi,7F2979801410
       mov       r12,[rdi]
       test      r12,r12
       je        near ptr M34_L45
M34_L02:
       mov       [rbp-2C0],r13
       mov       rcx,7F2979800BA0
       mov       rcx,[rcx]
       mov       rcx,[rcx+8]
       cmp       qword ptr [rcx+8],0
       jne       near ptr M34_L46
       xor       edi,edi
M34_L03:
       mov       [rbp-40],rdi
       mov       rdx,[rbx+68]
       mov       [rbp-368],rdx
       test      rdx,rdx
       jne       near ptr M34_L47
M34_L04:
       mov       r13,[rbx+68]
       mov       rdx,[rbx+38]
       mov       [rbp-2D8],rdx
       mov       rdi,7F29798013C0
       mov       rsi,[rdi]
       mov       [rbp-2E8],rsi
       cmp       byte ptr [rsi+24],0
       jne       near ptr M34_L48
       cmp       dword ptr [rsi+1C],0
       jne       near ptr M34_L78
M34_L05:
       mov       rsi,[rbp-2E8]
       mov       r8,[rsi+10]
       mov       [rbp-330],r8
       xor       r9d,r9d
       mov       [rbp-7C],r9d
       test      r8,r8
       je        near ptr M34_L79
       mov       rdi,7F31E18A0D68
       mov       r10,7F31E21B6820
       call      r10
       add       rax,40
       mov       eax,[rax+10]
       test      eax,eax
       je        near ptr M34_L88
M34_L06:
       dec       eax
       mov       rcx,[rbp-330]
       mov       r8d,[rcx+18]
       test      r8d,r8d
       jl        near ptr M34_L89
       and       r8d,eax
M34_L07:
       mov       eax,r8d
       mov       [rbp-8C],eax
       mov       rdi,[rcx+8]
       cmp       eax,[rdi+8]
       jae       near ptr M34_L116
       mov       edx,eax
       mov       r8,[rdi+rdx*8+10]
       mov       [rbp-340],r8
       mov       r9,[r8+50]
       mov       [rbp-348],r9
       test      r9,r9
       mov       eax,[rbp-8C]
       mov       rcx,[rbp-330]
       jne       near ptr M34_L36
M34_L08:
       lea       rdx,[r8+58]
       mov       rdi,[r8+48]
       mov       rsi,[rdx]
       mov       r9d,esi
       cmp       r9d,0FFFFFFFF
       je        near ptr M34_L93
M34_L09:
       cmp       r9d,[rdi+8]
       jae       near ptr M34_L116
       mov       r10d,r9d
       shl       r10,4
       mov       r11d,[rdi+r10+18]
       mov       rax,rsi
       sar       rax,20
       inc       eax
       cdqe
       shl       rax,20
       or        r11,rax
       mov       rax,rsi
       lock cmpxchg [rdx],r11
       cmp       rax,rsi
       jne       near ptr M34_L92
       mov       rax,[r8+48]
       mov       rdx,rax
       cmp       r9d,[rdx+8]
       jae       near ptr M34_L116
       mov       rdx,[rdx+r10+10]
       mov       [rbp-88],rdx
       cmp       r9d,[rax+8]
       jae       near ptr M34_L116
       lea       rdx,[rax+r10+10]
       xor       eax,eax
       mov       [rdx],rax
       add       r8,60
M34_L10:
       mov       rax,[r8]
       mov       [rbp-98],rax
       mov       [rdx+8],eax
       mov       rdi,rax
       sar       rdi,20
       inc       edi
       movsxd    rdi,edi
       shl       rdi,20
       mov       esi,r9d
       or        rdi,rsi
       lock cmpxchg [r8],rdi
       cmp       rax,[rbp-98]
       jne       short M34_L10
       cmp       qword ptr [rbp-88],0
       setne     dl
       movzx     edx,dl
       mov       eax,[rbp-8C]
M34_L11:
       test      edx,edx
       je        near ptr M34_L94
       mov       eax,[rbp-7C]
M34_L12:
       mov       rdx,[rbp-88]
       cmp       qword ptr [rbp-88],0
       je        near ptr M34_L95
M34_L13:
       mov       rax,rdx
M34_L14:
       xor       edi,edi
       mov       [rbp-88],rdi
       mov       rcx,[rbp-2E8]
       cmp       dword ptr [rcx+1C],0
       jne       near ptr M34_L97
       mov       rdx,rax
M34_L15:
       mov       [rbp-2E0],rdx
       lea       rdi,[rdx+68]
       mov       rsi,r13
       call      CORINFO_HELP_ASSIGN_REF
       xor       edi,edi
       mov       r13,[rbp-2E0]
       mov       [r13+60],edi
       lea       rdi,[r13+38]
       mov       rsi,[rbp-2D8]
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r13+30]
       mov       rsi,[rbp-2C0]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,0FFFFFFFF00000000
       mov       [r13+58],rdi
       xor       edi,edi
       mov       [r13+40],rdi
       cmp       qword ptr [r13+18],0
       je        near ptr M34_L98
M34_L16:
       mov       rdi,[rbx+8]
       mov       rsi,[r13+18]
       cmp       [rdi],edi
       call      qword ptr [7F31641F7960]; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       mov       rdi,[r13+18]
       mov       rsi,[r13+8]
       cmp       [rdi],edi
       call      qword ptr [7F31641F7960]; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       mov       rdi,[r13+8]
       mov       rsi,[rbx+8]
       cmp       [rdi],dil
       mov       rax,[rsi+28]
       add       rax,8
       lock inc  dword ptr [rax]
       mov       rsi,[rsi+28]
       lea       rdi,[rdi+28]
       call      CORINFO_HELP_ASSIGN_REF
       mov       byte ptr [r13+65],1
       mov       [rbp-2C8],r13
       mov       rdi,7F29798013E0
       mov       rax,[rdi]
       test      rax,rax
       je        near ptr M34_L99
M34_L17:
       mov       [rbp-0B8],r14
       mov       [rbp-0B0],rax
       mov       [rbp-0A8],r15
       mov       [rbp-0A0],r12
       cmp       qword ptr [rbp-0B0],0
       je        near ptr M34_L100
       cmp       qword ptr [rbp-0B8],0
       jne       near ptr M34_L105
       mov       r15,[rbp-0B0]
       mov       rdi,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       cmp       [r15+18],rdi
       jne       near ptr M34_L104
       mov       rdi,[r15+8]
       mov       r15,[rbp-0A8]
       mov       r14,[rbp-0A0]
       mov       rdi,[rdi]
       mov       rsi,[rdi+30]
       mov       rsi,[rsi]
       mov       rsi,[rsi+18]
       test      rsi,rsi
       je        near ptr M34_L38
M34_L18:
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-110],xmm0
       vmovdqu   xmmword ptr [rbp-108],xmm0
       mov       [rbp-0F8],r15
       mov       [rbp-0F0],r14
       mov       [rbp-120],r13
       mov       dword ptr [rbp-118],0FFFFFFFF
       mov       rdi,[rsi+18]
       mov       rdi,[rdi+18]
       test      rdi,rdi
       je        near ptr M34_L39
M34_L19:
       mov       rsi,[rdi+18]
       mov       rax,[rsi+10]
       test      rax,rax
       je        near ptr M34_L40
       mov       rdi,rax
M34_L20:
       lea       rsi,[rbp-120]
       call      qword ptr [7F31641F6DF0]; System.Runtime.CompilerServices.AsyncMethodBuilderCore.Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       mov       rdi,[rbp-110]
       mov       rax,7F29798013E8
       cmp       rdi,[rax]
       jne       near ptr M34_L101
       mov       r15,[rbp-108]
       mov       r14d,[rbp-100]
       xor       r12d,r12d
M34_L21:
       xor       eax,eax
       mov       ecx,1
M34_L22:
       test      r12,r12
       jne       near ptr M34_L107
M34_L23:
       mov       [rbp-370],r15
       mov       [rbp-264],r14d
       test      r15,r15
       sete      r12b
       movzx     r12d,r12b
       mov       r15,[rbp-40]
       test      r15,r15
       jne       near ptr M34_L112
M34_L24:
       mov       rdi,7F2979800B48
       mov       rdi,[rdi]
       mov       rdi,[rdi+8]
       cmp       qword ptr [rdi+8],0
       jne       near ptr M34_L113
M34_L25:
       mov       rdi,[r13+20]
       mov       [rbp-360],rdi
       xor       edi,edi
       mov       [rbp-24C],edi
       cmp       qword ptr [rbp-360],0
       je        short M34_L29
       mov       rdi,[rbp-360]
       call      00007F31E14E6020
       test      eax,eax
       je        short M34_L30
M34_L26:
       mov       dword ptr [rbp-24C],1
       cmp       byte ptr [r13+64],0
       jne       short M34_L31
       mov       r15,[r13+8]
M34_L27:
       mov       r13,[r13+18]
       mov       rbx,[rbx+8]
       mov       rdi,[r15+28]
       cmp       dword ptr [rdi+0C],0
       jne       short M34_L32
M34_L28:
       mov       rdi,r13
       mov       rsi,r15
       mov       rdx,rbx
       cmp       [rdi],edi
       call      qword ptr [7F31641F7B40]; Kevlar.KevlarProperties.RemoveMissingValuesFrom(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       mov       rdi,r15
       mov       rsi,r13
       mov       rdx,rbx
       call      qword ptr [7F31641F7B58]; Kevlar.KevlarProperties.CopyChangedValuesTo(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       jmp       short M34_L33
M34_L29:
       xor       edi,edi
       call      qword ptr [7F31642865C8]
       int       3
M34_L30:
       mov       rdi,[rbp-360]
       call      qword ptr [7F31642845E8]; System.Threading.Monitor.Enter_Slowpath(System.Object)
       jmp       short M34_L26
M34_L31:
       mov       r15,[r13+10]
       jmp       short M34_L27
M34_L32:
       mov       rdi,[r13+28]
       cmp       dword ptr [rdi+0C],0
       jne       short M34_L28
       mov       rdi,[rbx+28]
       cmp       dword ptr [rdi+0C],0
       jne       short M34_L28
       mov       rdi,[rbx+28]
       mov       esi,1
       cmp       [rdi],edi
       call      qword ptr [7F3164286D30]
       jmp       short M34_L28
M34_L33:
       mov       rdi,[rbp-360]
       call      00007F31E14E6790
       test      eax,eax
       je        short M34_L34
       mov       edi,eax
       mov       rsi,[rbp-360]
       call      qword ptr [7F3164286658]
       nop
M34_L34:
       call      M34_L119
       nop
       cmp       qword ptr [rbp-370],0
       jne       near ptr M34_L114
       mov       esi,[rbp-264]
       mov       [rbp-30],esi
       mov       byte ptr [rbp-2A],1
M34_L35:
       mov       rax,[rbp-38]
       mov       rdx,[rbp-30]
       add       rsp,368
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M34_L36:
       lea       rdi,[r8+50]
       test      rdi,rdi
       je        near ptr M34_L90
       mov       rdx,r9
       xor       esi,esi
       call      00007F31E1674060
       mov       rdx,[rbp-348]
       cmp       rax,rdx
       mov       eax,[rbp-8C]
       mov       r8,[rbp-340]
       jne       near ptr M34_L91
       mov       [rbp-88],rdx
       mov       eax,[rbp-7C]
       mov       rcx,[rbp-330]
       jmp       near ptr M34_L12
M34_L37:
       mov       rdi,7F316225B200
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M34_L37
       jmp       near ptr M34_L80
M34_L38:
       mov       rsi,7F31641D7240
       call      qword ptr [7F316324F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       rsi,rax
       jmp       near ptr M34_L18
M34_L39:
       mov       rdi,rsi
       mov       rsi,7F31641D7EB8
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M34_L19
M34_L40:
       mov       rsi,7F31641D8118
       call      qword ptr [7F316324F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       rdi,rax
       jmp       near ptr M34_L20
M34_L41:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,902
       mov       rsi,7F3163D0E0F0
       call      qword ptr [7F316324EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F316392E2E0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M34_L42:
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       edi,910
       mov       rsi,7F3163D0E0F0
       call      qword ptr [7F316324EF88]
       mov       rsi,rax
       mov       rdi,rbx
       call      qword ptr [7F316392E2E0]
       mov       rdi,rbx
       call      CORINFO_HELP_THROW
       int       3
M34_L43:
       mov       rdi,[rax+8]
       call      qword ptr [rax+18]
       mov       rdi,rax
       mov       rsi,rbx
       mov       rdx,r15
       cmp       [rdi],edi
       call      qword ptr [7F31641F76D8]
       mov       [rbp-2B0],rax
       mov       [rbp-2A8],rdx
       mov       rax,[rbp-2B0]
       mov       rdx,[rbp-2A8]
       add       rsp,368
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M34_L44:
       call      qword ptr [7F3163CDE628]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M34_L45:
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       rsi,7F2979801408
       mov       rsi,[rsi]
       mov       rdi,r12
       mov       rdx,offset Kevlar.Shield+<>c__60`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__60_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F3163246E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F2979801410
       mov       rsi,r12
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M34_L02
M34_L46:
       call      00007F3163238AE0
       mov       rdi,rax
       jmp       near ptr M34_L03
M34_L47:
       cmp       dword ptr [rdx+20],0
       je        near ptr M34_L04
       mov       rsi,r13
       xor       edx,edx
       call      qword ptr [7F3163CDE988]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       rbx,rax
       mov       rdi,rbx
       call      qword ptr [7F3164287588]
       lea       rdi,[rbx+70]
       mov       rsi,[rbp-368]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,rbx
       call      qword ptr [7F3163CDEA00]
       mov       rdi,rax
       mov       esi,edx
       call      qword ptr [7F3163CDE910]
       mov       [rbp-2A0],rax
       mov       [rbp-298],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-2A0]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       jmp       near ptr M34_L35
M34_L48:
       cmp       dword ptr [rsi+1C],0
       je        short M34_L49
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F31641F68F8]
M34_L49:
       mov       rsi,[rbp-2E8]
       lea       rdi,[rsi+28]
       mov       r8,[rdi]
       test      r8,r8
       jne       short M34_L50
       mov       rsi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7F3164286CD0]
       mov       r8,rax
M34_L50:
       mov       rdi,r8
       cmp       [rdi],edi
       call      qword ptr [7F3164286CE8]
       mov       [rbp-2F0],rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7F3163245728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       cmp       byte ptr [7F316225B208],0
       je        short M34_L54
       mov       rax,[rbp-2F0]
       mov       edx,[rax+68]
       mov       rcx,[rax+58]
       test      rcx,rcx
       je        near ptr M34_L57
       xor       esi,esi
       mov       [rax+58],rsi
       cmp       [rax+68],edx
       jne       short M34_L51
       test      dl,1
       je        short M34_L52
M34_L51:
       mov       rdx,rcx
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarContext>
       call      qword ptr [7F3164286D00]
       mov       rcx,rax
       mov       rax,rcx
       test      rax,rax
       mov       rcx,rax
       je        short M34_L53
M34_L52:
       mov       rax,rcx
       jmp       near ptr M34_L75
M34_L53:
       mov       rax,[rbp-2F0]
       jmp       short M34_L57
M34_L54:
       mov       rcx,[rbp-2F0]
       cmp       qword ptr [rcx+58],0
       je        short M34_L55
       lea       rdi,[rcx+58]
       test      rdi,rdi
       jne       short M34_L56
       jmp       near ptr M34_L90
M34_L55:
       mov       rax,rcx
       jmp       short M34_L57
M34_L56:
       xor       esi,esi
       call      00007F31E1674040
       test      rax,rax
       mov       rcx,rax
       jne       short M34_L52
       mov       rax,[rbp-2F0]
M34_L57:
       cmp       byte ptr [rax+6C],0
       jne       short M34_L58
       mov       byte ptr [rax+6C],1
M34_L58:
       mov       rax,[rbp-2E8]
       mov       rcx,[rax+10]
       mov       [rbp-300],rcx
       xor       edx,edx
       mov       [rbp-64],edx
       test      rcx,rcx
       jne       near ptr M34_L66
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M34_L60
M34_L59:
       mov       rdi,7F316225B200
       mov       edx,1
       lock xadd [rdi],edx
       lea       edi,[rdx+1]
       test      edi,edi
       je        short M34_L59
       mov       [rax+10],edi
M34_L60:
       dec       edi
       imul      edi,9E3779B9
       mov       rax,[rbp-2E8]
       cmp       dword ptr [rax+18],0
       jge       short M34_L61
       mov       edx,edi
       mov       esi,[rax+20]
       imul      rdx,rsi
       shr       rdx,20
       jmp       short M34_L62
M34_L61:
       and       edi,[rax+18]
       mov       edx,edi
M34_L62:
       mov       ecx,edx
       mov       rdi,[rax+8]
       mov       [rbp-64],ecx
       lea       edx,[rcx*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M34_L116
       lea       rdi,[rdi+rdx*8+10]
       mov       r8,[rdi]
       mov       [rbp-308],r8
       test      r8,r8
       je        short M34_L63
       mov       rdx,r8
       xor       esi,esi
       call      00007F31E1674060
       mov       rdi,[rbp-308]
       cmp       rax,rdi
       je        short M34_L64
M34_L63:
       xor       esi,esi
       jmp       short M34_L65
M34_L64:
       mov       rsi,rdi
M34_L65:
       mov       [rbp-70],rsi
       jmp       near ptr M34_L72
M34_L66:
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       eax,[rax+10]
       test      eax,eax
       jne       short M34_L68
M34_L67:
       mov       rax,7F316225B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-74],eax
       test      eax,eax
       je        short M34_L67
       mov       edi,40
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       ecx,[rbp-74]
       mov       [rax+10],ecx
       mov       eax,ecx
M34_L68:
       dec       eax
       mov       rcx,[rbp-300]
       cmp       dword ptr [rcx+18],0
       jl        short M34_L69
       mov       r8d,eax
       and       r8d,[rcx+18]
       jmp       short M34_L70
M34_L69:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
M34_L70:
       mov       rdi,[rcx+8]
       cmp       r8d,[rdi+8]
       jae       near ptr M34_L116
       mov       [rbp-78],r8d
       mov       edx,r8d
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-310],rax
       mov       r9,[rax+50]
       mov       [rbp-318],r9
       test      r9,r9
       je        short M34_L71
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M34_L90
       mov       rdx,r9
       xor       esi,esi
       call      00007F31E1674060
       mov       rdx,[rbp-318]
       cmp       rax,rdx
       mov       rax,[rbp-310]
       jne       short M34_L71
       mov       [rbp-70],rdx
       jmp       short M34_L72
M34_L71:
       lea       rdx,[rbp-70]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarContext>
       call      qword ptr [7F3163CDDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M34_L72
       lea       rdx,[rbp-70]
       mov       rdi,[rbp-300]
       mov       esi,[rbp-78]
       call      qword ptr [7F3163CDDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M34_L72:
       mov       rax,[rbp-70]
       cmp       qword ptr [rbp-70],0
       jne       short M34_L74
       cmp       qword ptr [rbp-300],0
       je        short M34_L73
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-320],rax
       mov       rdi,rax
       call      qword ptr [7F31641F69A0]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-320]
       jmp       short M34_L74
M34_L73:
       mov       rdi,[rbp-2E8]
       mov       esi,[rbp-64]
       call      qword ptr [7F31641F6958]
M34_L74:
       xor       edi,edi
       mov       [rbp-70],rdi
M34_L75:
       mov       rcx,[rbp-2E8]
       cmp       dword ptr [rcx+1C],0
       jne       short M34_L76
       jmp       short M34_L77
M34_L76:
       mov       [rbp-2F8],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rdi,[rbp-2E8]
       mov       dil,[rdi+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-2F8]
       mov       r11,7F3162260720
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F31641F68F8]
M34_L77:
       mov       rdx,rax
       jmp       near ptr M34_L15
M34_L78:
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F31641F68F8]
       jmp       near ptr M34_L05
M34_L79:
       mov       rdi,7F31E18A0D68
       mov       r9,7F31E21B6820
       call      r9
       add       rax,30
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M34_L81
       jmp       near ptr M34_L37
M34_L80:
       mov       [rax+10],edi
M34_L81:
       dec       edi
       imul      edi,9E3779B9
       mov       rcx,[rbp-2E8]
       mov       edx,[rcx+18]
       test      edx,edx
       jge       short M34_L82
       mov       r9d,edi
       mov       esi,[rcx+20]
       imul      r9,rsi
       shr       r9,20
       jmp       short M34_L83
M34_L82:
       mov       r9d,edi
       and       r9d,edx
M34_L83:
       mov       eax,r9d
       mov       rdi,[rcx+8]
       mov       [rbp-7C],eax
       lea       edx,[rax*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M34_L116
       lea       rdi,[rdi+rdx*8+10]
       mov       r8,[rdi]
       mov       [rbp-338],r8
       test      r8,r8
       je        short M34_L85
       mov       rdx,r8
       xor       esi,esi
       call      00007F31E1674060
       mov       rdi,[rbp-338]
       cmp       rax,rdi
       mov       eax,[rbp-7C]
       je        short M34_L86
M34_L84:
       xor       esi,esi
       jmp       short M34_L87
M34_L85:
       mov       eax,[rbp-7C]
       jmp       short M34_L84
M34_L86:
       mov       r8,rdi
       mov       rsi,r8
M34_L87:
       mov       [rbp-88],rsi
       mov       rcx,[rbp-330]
       jmp       near ptr M34_L12
M34_L88:
       mov       rax,7F316225B1A8
       mov       edi,1
       lock xadd [rax],edi
       lea       eax,[rdi+1]
       mov       [rbp-90],eax
       test      eax,eax
       je        short M34_L88
       mov       rdi,7F31E18A0D68
       mov       rcx,7F31E21B6820
       call      rcx
       add       rax,40
       mov       ecx,[rbp-90]
       mov       [rax+10],ecx
       mov       eax,ecx
       jmp       near ptr M34_L06
M34_L89:
       mov       r8,[rcx+8]
       mov       edi,[r8+8]
       mov       r8d,eax
       imul      r8,[rcx+10]
       shr       r8,20
       inc       r8
       imul      r8,rdi
       shr       r8,20
       mov       eax,r8d
       mov       r8d,eax
       jmp       near ptr M34_L07
M34_L90:
       call      qword ptr [7F31642865F8]
       int       3
M34_L91:
       mov       rcx,[rbp-330]
       jmp       near ptr M34_L08
M34_L92:
       mov       rsi,[rdx]
       mov       r9d,esi
       cmp       r9d,0FFFFFFFF
       jne       near ptr M34_L09
       mov       eax,[rbp-8C]
M34_L93:
       xor       edx,edx
       mov       [rbp-88],rdx
       jmp       near ptr M34_L11
M34_L94:
       lea       rdx,[rbp-88]
       mov       rdi,rcx
       mov       esi,eax
       call      qword ptr [7F3163CDDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
       mov       eax,[rbp-7C]
       mov       rcx,[rbp-330]
       jmp       near ptr M34_L12
M34_L95:
       test      rcx,rcx
       je        short M34_L96
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-350],rax
       mov       rdi,rax
       call      qword ptr [7F31641F69A0]; Kevlar.KevlarContext..ctor()
       mov       rax,[rbp-350]
       jmp       near ptr M34_L14
M34_L96:
       mov       rdi,[rbp-2E8]
       mov       esi,eax
       call      qword ptr [7F31641F6958]
       mov       rdx,rax
       jmp       near ptr M34_L13
M34_L97:
       mov       [rbp-328],rax
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       rcx,[rbp-2E8]
       mov       dil,[rcx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-328]
       mov       r11,7F3162260728
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarContext, Kevlar.KevlarContext+PoolPolicy>
       call      qword ptr [7F31641F68F8]
       mov       rdx,rax
       jmp       near ptr M34_L15
M34_L98:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-2D0],rax
       mov       rdi,rax
       call      qword ptr [7F31641F69B8]; Kevlar.KevlarProperties..ctor()
       lea       rdi,[r13+18]
       mov       rsi,[rbp-2D0]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M34_L16
M34_L99:
       mov       rdi,offset MT_System.Func<Kevlar.Internal.ShieldEngine+ContextAsyncCallback<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, System.Int32>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<Kevlar.Outcome<System.Int32>>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-358],rax
       mov       rsi,7F29798013D8
       mov       rsi,[rsi]
       mov       rdi,rax
       mov       rdx,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       call      qword ptr [7F3163246E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,7F29798013E0
       mov       rsi,[rbp-358]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-358]
       jmp       near ptr M34_L17
M34_L100:
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       rdi,r12
       mov       rsi,7F3158A0B5D8
       call      qword ptr [7F3163925650]
       mov       rdi,r12
       call      qword ptr [7F3163CDEA00]
       mov       esi,edx
       xor       r12d,r12d
       xor       r15d,r15d
       mov       [rbp-268],r15d
       mov       dword ptr [rbp-26C],1
       mov       r14d,esi
       mov       r15,rax
       mov       eax,[rbp-268]
       mov       ecx,[rbp-26C]
       jmp       near ptr M34_L22
M34_L101:
       mov       r12,[rbp-110]
       test      r12,r12
       jne       short M34_L102
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       r12,rax
       mov       rdi,r12
       call      qword ptr [7F3164286D78]
       mov       [rbp-110],r12
M34_L102:
       test      r12,r12
       jne       short M34_L103
       mov       edi,9
       call      qword ptr [7F316324FAE0]
       int       3
M34_L103:
       xor       r15d,r15d
       xor       r14d,r14d
       jmp       near ptr M34_L21
M34_L104:
       mov       rdx,[rbp-0A8]
       mov       rcx,[rbp-0A0]
       lea       rsi,[rbp-0D8]
       mov       r8,r13
       mov       rdi,[r15+8]
       call      qword ptr [r15+18]
       jmp       short M34_L106
M34_L105:
       lea       rdi,[rbp-0B8]
       lea       rsi,[rbp-0D8]
       mov       r8,r13
       mov       rcx,[rbp-0B8]
       mov       rdx,offset MT_Kevlar.Continuation<System.Int32, Kevlar.Internal.ShieldEngine+ContextAsyncCallback<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, System.Int32>>
       call      qword ptr [7F31641F6B68]
M34_L106:
       mov       r12,[rbp-0D8]
       movsx     rax,word ptr [rbp-0D0]
       mov       r15d,eax
       movzx     ecx,byte ptr [rbp-0CE]
       mov       r14d,ecx
       mov       rdi,[rbp-0C8]
       mov       rax,rdi
       mov       edi,[rbp-0C0]
       mov       esi,edi
       mov       ecx,r14d
       mov       r14d,esi
       mov       rdx,rax
       mov       eax,r15d
       mov       r15,rdx
       jmp       near ptr M34_L22
M34_L107:
       mov       [rbp-268],eax
       mov       [rbp-26C],ecx
       mov       rsi,r12
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F3163246838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       test      rax,rax
       je        short M34_L108
       mov       rdi,rax
       call      qword ptr [7F31641F7270]
       jmp       short M34_L109
M34_L108:
       mov       rdi,r12
       mov       esi,[rbp-268]
       mov       r11,7F3162260730
       call      qword ptr [r11]
       cmp       eax,1
       sete      al
       movzx     eax,al
M34_L109:
       test      eax,eax
       je        near ptr M34_L115
       mov       rsi,r12
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F3163246838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       r15,rax
       test      r15,r15
       je        short M34_L111
       mov       edi,[r15+34]
       and       edi,11000000
       cmp       edi,1000000
       je        short M34_L110
       mov       rdi,r15
       xor       esi,esi
       call      qword ptr [7F3164286598]
M34_L110:
       mov       rdi,[r15+38]
       mov       r14d,[r15+40]
       mov       r15,rdi
       jmp       near ptr M34_L23
M34_L111:
       mov       rdi,r12
       mov       esi,[rbp-268]
       mov       r11,7F3162260738
       call      qword ptr [r11]
       mov       rdi,rax
       mov       r14d,edx
       mov       r15,rdi
       jmp       near ptr M34_L23
M34_L112:
       mov       rdi,7F2979800BA0
       mov       rdi,[rdi]
       call      qword ptr [7F3163CDEAD8]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M34_L24
       lea       rdi,[rbp-1B0]
       mov       rsi,[rbp-2C0]
       call      qword ptr [7F31641F7330]
       mov       rdx,7F3158A0B6A8
       mov       rdi,7F3158A0B680
       test      r12d,r12d
       cmove     rdx,rdi
       lea       rdi,[rbp-1B0]
       mov       rsi,7F3158A0B638
       call      qword ptr [7F31641F7348]
       call      00007F3163238AE0
       mov       rsi,rax
       mov       rdi,r15
       call      qword ptr [7F3164286E20]
       mov       [rbp-1B8],rax
       lea       rdi,[rbp-1B8]
       call      qword ptr [7F31641F7378]
       mov       rdi,7F2979800BA0
       mov       rdi,[rdi]
       lea       rsi,[rbp-1B0]
       xor       edx,edx
       call      qword ptr [7F31641F7390]
       jmp       near ptr M34_L24
M34_L113:
       lea       rdi,[rbp-248]
       mov       rsi,[rbp-2C0]
       call      qword ptr [7F31641F7330]
       mov       rdx,7F3158A0B6A8
       mov       rdi,7F3158A0B680
       test      r12d,r12d
       cmove     rdx,rdi
       lea       rdi,[rbp-248]
       mov       rsi,7F3158A0B638
       call      qword ptr [7F31641F7348]
       mov       rdi,7F2979800B48
       mov       rdi,[rdi]
       lea       rdx,[rbp-248]
       mov       esi,1
       xor       ecx,ecx
       call      qword ptr [7F31641F73A8]
       jmp       near ptr M34_L25
M34_L114:
       mov       rdi,[rbp-370]
       mov       esi,[rbp-264]
       call      qword ptr [7F3163CDE910]
       mov       [rbp-290],rax
       mov       [rbp-288],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-290]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       jmp       near ptr M34_L35
M34_L115:
       mov       [rbp-60],r12
       mov       r12d,[rbp-268]
       mov       [rbp-58],r12w
       mov       r12d,[rbp-26C]
       mov       [rbp-56],r12b
       mov       [rbp-50],r15
       mov       [rbp-48],r14d
       lea       rdi,[rsp]
       lea       rsi,[rbp-60]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,r13
       mov       rsi,rbx
       mov       rdx,[rbp-40]
       call      qword ptr [7F31641F7870]
       mov       [rbp-280],rax
       mov       [rbp-278],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-280]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       jmp       near ptr M34_L35
M34_L116:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
       sub       rsp,28
       vzeroupper
       cmp       dword ptr [rbp-24C],0
       je        short M34_L118
       cmp       qword ptr [rbp-360],0
       jne       short M34_L117
       xor       edi,edi
       call      qword ptr [7F31642865C8]
       int       3
M34_L117:
       mov       rdi,[rbp-360]
       call      00007F31E14E6790
       test      eax,eax
       je        short M34_L118
       mov       edi,eax
       mov       rsi,[rbp-360]
       call      qword ptr [7F3164286658]
M34_L118:
       nop
       add       rsp,28
       ret
M34_L119:
       sub       rsp,28
       vzeroupper
       mov       rdi,7F29798013C0
       mov       rbx,[rdi]
       cmp       qword ptr [rbp-2C8],0
       jne       short M34_L120
       mov       edi,29
       mov       rsi,7F31636C54F0
       call      qword ptr [7F316324EF88]
       mov       rdi,rax
       call      qword ptr [7F31642865C8]
       int       3
M34_L120:
       cmp       byte ptr [rbx+24],0
       je        short M34_L121
       mov       rdi,rbx
       mov       rsi,[rbp-2C8]
       call      qword ptr [7F31641F73F0]
       jmp       near ptr M34_L147
M34_L121:
       cmp       dword ptr [rbx+1C],0
       je        short M34_L122
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-2C8]
       mov       r11,7F3162260740
       call      qword ptr [r11]
       jmp       near ptr M34_L147
M34_L122:
       mov       rdi,rbx
       mov       rsi,[rbp-2C8]
       call      qword ptr [7F31641F7450]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItemGuarded(System.__Canon)
       test      eax,eax
       jne       short M34_L123
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-2C8]
       mov       r11,7F3162260748
       call      qword ptr [r11]
       jmp       near ptr M34_L147
M34_L123:
       mov       r15,[rbx+10]
       test      r15,r15
       je        near ptr M34_L138
       mov       rdi,7F31E18A0D68
       mov       rax,7F31E21B6820
       call      rax
       add       rax,40
       mov       r14d,[rax+10]
       test      r14d,r14d
       jne       short M34_L125
M34_L124:
       mov       rdi,7F316225B1A8
       mov       eax,1
       mov       r14d,eax
       lock xadd [rdi],r14d
       inc       r14d
       je        short M34_L124
       mov       rdi,7F31E18A0D68
       mov       rax,7F31E21B6820
       call      rax
       add       rax,40
       mov       [rax+10],r14d
M34_L125:
       dec       r14d
       mov       r13d,[r15+18]
       test      r13d,r13d
       jl        short M34_L126
       and       r13d,r14d
       jmp       short M34_L127
M34_L126:
       mov       rdi,[r15+8]
       mov       edi,[rdi+8]
       mov       r13d,r14d
       imul      r13,[r15+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
M34_L127:
       xor       r14d,r14d
       mov       rdi,[r15+8]
       cmp       dword ptr [rdi+8],0
       jle       near ptr M34_L137
M34_L128:
       mov       rdi,[r15+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M34_L145
       mov       esi,r13d
       mov       r12,[rdi+rsi*8+10]
       cmp       qword ptr [r12+50],0
       jne       short M34_L129
       lea       rdi,[r12+50]
       test      rdi,rdi
       je        near ptr M34_L143
       mov       rsi,[rbp-2C8]
       xor       edx,edx
       call      00007F31E1674060
       test      rax,rax
       je        near ptr M34_L136
M34_L129:
       lea       rdi,[r12+60]
       mov       rsi,[r12+48]
       mov       rax,[rdi]
       mov       ecx,eax
       cmp       ecx,0FFFFFFFF
       je        short M34_L132
       mov       edx,[rsi+8]
       jmp       short M34_L131
M34_L130:
       mov       rax,[rdi]
       mov       ecx,eax
       cmp       ecx,0FFFFFFFF
       je        short M34_L132
M34_L131:
       cmp       ecx,edx
       jae       near ptr M34_L145
       mov       r8d,ecx
       shl       r8,4
       mov       [rbp-2B8],r8
       mov       r9d,[rsi+r8+18]
       mov       r10,rax
       sar       r10,20
       inc       r10d
       movsxd    r10,r10d
       shl       r10,20
       or        r9,r10
       mov       [rbp-258],rax
       lock cmpxchg [rdi],r9
       cmp       rax,[rbp-258]
       jne       short M34_L130
       jmp       short M34_L134
M34_L132:
       inc       r13d
       mov       rcx,[r15+8]
       cmp       [rcx+8],r13d
       jne       short M34_L133
       xor       r13d,r13d
M34_L133:
       inc       r14d
       cmp       [rcx+8],r14d
       jg        near ptr M34_L128
       jmp       near ptr M34_L137
M34_L134:
       mov       rdi,[r12+48]
       mov       [rbp-250],ecx
       cmp       ecx,[rdi+8]
       jae       near ptr M34_L145
       lea       rdi,[rdi+r8+10]
       mov       rsi,[rbp-2C8]
       call      CORINFO_HELP_ASSIGN_REF
       lea       rdi,[r12+58]
       mov       rcx,[r12+48]
       mov       r15d,[rbp-250]
M34_L135:
       mov       rax,[rdi]
       mov       [rbp-260],rax
       cmp       r15d,[rcx+8]
       jae       near ptr M34_L145
       mov       r14,[rbp-2B8]
       mov       [rcx+r14+18],eax
       mov       rdx,rax
       sar       rdx,20
       inc       edx
       movsxd    rdx,edx
       shl       rdx,20
       mov       esi,r15d
       or        rdx,rsi
       lock cmpxchg [rdi],rdx
       cmp       rax,[rbp-260]
       jne       short M34_L135
M34_L136:
       cmp       dword ptr [rbx+1C],0
       je        near ptr M34_L147
       jmp       near ptr M34_L146
M34_L137:
       mov       rdi,offset MT_Kevlar.KevlarContext+PoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[rbx+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,[rbp-2C8]
       mov       r11,7F3162260750
       call      qword ptr [r11]
       jmp       short M34_L136
M34_L138:
       mov       edi,30
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       edi,[rax+10]
       test      edi,edi
       jne       short M34_L140
M34_L139:
       mov       rdi,7F316225B200
       mov       esi,1
       lock xadd [rdi],esi
       lea       edi,[rsi+1]
       test      edi,edi
       je        short M34_L139
       mov       [rax+10],edi
M34_L140:
       dec       edi
       imul      r15d,edi,9E3779B9
       cmp       dword ptr [rbx+18],0
       jge       short M34_L141
       mov       r14d,r15d
       mov       r13d,[rbx+20]
       imul      r14,r13
       shr       r14,20
       jmp       short M34_L142
M34_L141:
       and       r15d,[rbx+18]
       mov       r14d,r15d
M34_L142:
       mov       rdi,[rbx+8]
       lea       esi,[r14*8+8]
       cmp       esi,[rdi+8]
       jae       short M34_L145
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M34_L144
M34_L143:
       call      qword ptr [7F31642865F8]
       int       3
M34_L144:
       mov       rsi,[rbp-2C8]
       call      00007F31E1674040
       test      rax,rax
       je        near ptr M34_L136
       mov       rdi,rbx
       mov       rsi,[rbp-2C8]
       mov       rdx,rax
       mov       ecx,r14d
       call      qword ptr [7F31641F7660]
       jmp       near ptr M34_L136
M34_L145:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
M34_L146:
       mov       rdi,rbx
       call      qword ptr [7F31641F7690]
M34_L147:
       nop
       add       rsp,28
       ret
; Total bytes of code 5737
```
```assembly
; Kevlar.Shield+<>c__60`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__60_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       rcx,rsi
       mov       rsi,rdx
       mov       rax,offset PoolContextProbe+<>c.<NestedContext>b__6_1(Kevlar.KevlarContext)
       cmp       [rcx+18],rax
       jne       short M35_L00
       xor       eax,eax
       mov       rdx,100000000002A
       ret
M35_L00:
       mov       rdi,[rcx+8]
       jmp       qword ptr [rcx+18]
; Total bytes of code 43
```
```assembly
; Kevlar.KevlarProperties..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F31641F69D0]; Kevlar.KevlarProperties+AdditionalAttemptState..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-8]
       call      qword ptr [7F316324C240]; System.Object..ctor()
       mov       rax,[rbp-8]
       mov       rsi,[rax+8]
       mov       rax,[rbp-8]
       lea       rdi,[rax+28]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 104
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-18]
       mov       rcx,rax
       test      cl,1
       jne       short M37_L00
       ret
M37_L00:
       jmp       qword ptr [7F3163245C20]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 23
```
```assembly
; System.Threading.Thread.InitializeCurrentThread()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,68
       lea       rbp,[rsp+90]
       xor       eax,eax
       mov       [rbp-30],rax
       lea       rdi,[rbp-30]
       mov       [rbp-90],rdi
       lea       rdi,[rbp-88]
       call      qword ptr [7F3162DEEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-90]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7F3162DEEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rbx,[rbp-30]
       call      qword ptr [7F3162DF0B98]
       lea       rdi,[rax+10]
       mov       rsi,[rbp-30]
       call      qword ptr [7F3162DEEEB8]; CORINFO_HELP_ASSIGN_REF
       mov       rax,rbx
       add       rsp,68
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 123
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetOptimizedGCThreadStaticBase(Int32)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       ebx,edi
       call      qword ptr [7F3162E06AF0]; Precode of System.Threading.Thread.GetThreadStaticsBase()
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M39_L01
       cmp       [rax],edi
       jle       short M39_L03
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M39_L03
M39_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M39_L01:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M39_L02
       movsxd    rcx,ecx
       add       rax,rcx
       jmp       short M39_L00
M39_L02:
       cmp       [rax+4],ecx
       jle       short M39_L03
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M39_L03
       mov       rax,[rdi]
       test      rax,rax
       je        short M39_L03
       jmp       short M39_L00
M39_L03:
       mov       edi,ebx
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
; Total bytes of code 133
```
```assembly
; Kevlar.KevlarProperties.Clear()
       push      rbp
       push      rbx
       sub       rsp,18
       lea       rbp,[rsp+20]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       rbx,rdi
       cmp       qword ptr [rbx+10],0
       jne       short M40_L01
M40_L00:
       add       rsp,18
       pop       rbx
       pop       rbp
       ret
M40_L01:
       xor       edi,edi
       mov       [rbx+30],edi
       mov       rdi,[rbx+18]
       test      rdi,rdi
       je        short M40_L02
       mov       eax,[rdi+38]
       sub       eax,[rdi+40]
       cmp       eax,20
       jl        short M40_L02
       xor       edi,edi
       mov       [rbx+38],rdi
       mov       [rbx+40],rdi
       mov       [rbx+10],rdi
       mov       [rbx+18],rdi
       jmp       short M40_L00
M40_L02:
       mov       rdi,[rbx+10]
       mov       rax,[rdi]
       mov       rax,[rax+40]
       call      qword ptr [rax+28]
       cmp       qword ptr [rbx+18],0
       je        short M40_L00
       mov       rdi,[rbx+18]
       cmp       [rdi],edi
       call      qword ptr [7F31641F75E8]
       mov       rdi,rax
       lea       rsi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F31641F7600]
       jmp       short M40_L04
M40_L03:
       mov       rdi,[rbp-18]
       mov       rax,[rbp-18]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+28]
M40_L04:
       lea       rdi,[rbp-20]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+ValueCollection+Enumerator
       call      qword ptr [7F31641F7630]
       test      eax,eax
       jne       short M40_L03
       jmp       near ptr M40_L00
; Total bytes of code 186
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState.Reset()
       xor       eax,eax
       mov       [rdi+0C],eax
       mov       [rdi+10],eax
       ret
; Total bytes of code 9
```
```assembly
; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       push      rax
       lea       rbp,[rsp+30]
       mov       rbx,rdi
       lea       rdi,[rbx+8]
       mov       eax,0FFFFFFFF
       lock xadd [rdi],eax
       dec       eax
       je        short M42_L01
M42_L00:
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M42_L01:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F29798013D0
       mov       r15,[rdi]
       cmp       byte ptr [r15+24],0
       je        short M42_L02
       mov       rdi,r15
       mov       rsi,rbx
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F3164286C58]
M42_L02:
       cmp       dword ptr [r15+1C],0
       je        short M42_L03
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F3162260680
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M42_L03:
       mov       rdi,r15
       mov       rsi,rbx
       call      qword ptr [7F3164286C70]
       test      eax,eax
       jne       short M42_L04
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F3162260688
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M42_L04:
       mov       r14,[r15+10]
       test      r14,r14
       je        near ptr M42_L15
       mov       edi,38
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M42_L06
M42_L05:
       mov       rdi,7F316225B1E8
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M42_L05
       mov       edi,38
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M42_L06:
       dec       r13d
       cmp       dword ptr [r14+18],0
       jl        short M42_L07
       and       r13d,[r14+18]
       jmp       short M42_L08
M42_L07:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r13d,r13d
       imul      r13,[r14+10]
       shr       r13,20
       inc       r13
       imul      r13,rdi
       shr       r13,20
M42_L08:
       xor       r12d,r12d
       jmp       short M42_L12
M42_L09:
       mov       rdi,[r14+8]
       cmp       r13d,[rdi+8]
       jae       near ptr M42_L23
       mov       esi,r13d
       mov       rax,[rdi+rsi*8+10]
       mov       [rbp-30],rax
       cmp       qword ptr [rax+50],0
       jne       short M42_L10
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M42_L20
       mov       rsi,rbx
       xor       edx,edx
       call      00007F31E1674060
       test      rax,rax
       mov       rax,[rbp-30]
       je        short M42_L13
M42_L10:
       mov       rdx,rbx
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F3163CDE058]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M42_L13
       inc       r13d
       mov       rdi,[r14+8]
       cmp       [rdi+8],r13d
       jne       short M42_L11
       xor       r13d,r13d
M42_L11:
       inc       r12d
M42_L12:
       mov       rdi,[r14+8]
       cmp       [rdi+8],r12d
       jg        short M42_L09
       jmp       short M42_L14
M42_L13:
       cmp       dword ptr [r15+1C],0
       je        near ptr M42_L00
       jmp       near ptr M42_L22
M42_L14:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,rbx
       mov       r11,7F3162260690
       call      qword ptr [r11]
       jmp       short M42_L13
M42_L15:
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r14d,[rax+10]
       test      r14d,r14d
       jne       short M42_L17
M42_L16:
       mov       rdi,7F316225B1E0
       mov       eax,1
       mov       r14d,eax
       lock xadd [rdi],r14d
       inc       r14d
       je        short M42_L16
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r14d
M42_L17:
       dec       r14d
       imul      r14d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M42_L18
       mov       r13d,r14d
       mov       r12d,[r15+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M42_L19
M42_L18:
       and       r14d,[r15+18]
       mov       r13d,r14d
M42_L19:
       mov       rdi,[r15+8]
       lea       esi,[r13*8+8]
       cmp       esi,[rdi+8]
       jae       short M42_L23
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       jne       short M42_L21
M42_L20:
       call      qword ptr [7F31642865F8]
       int       3
M42_L21:
       mov       rsi,rbx
       call      00007F31E1674040
       test      rax,rax
       je        near ptr M42_L13
       mov       rdi,r15
       mov       rsi,rbx
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7F3164286C88]
       jmp       near ptr M42_L13
M42_L22:
       mov       rdi,r15
       add       rsp,8
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F3164286CA0]
M42_L23:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 759
```
```assembly
; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,48
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-38],rax
       mov       [rbp-40],rax
       mov       rbx,rdi
       cmp       byte ptr [rbx+34],0
       jne       short M43_L04
M43_L00:
       mov       rdi,[rbx+28]
       mov       rax,[rbx+8]
       cmp       rdi,rax
       jne       short M43_L02
       cmp       dword ptr [rax+8],1
       jne       near ptr M43_L25
M43_L01:
       mov       rax,[rbx+8]
       xor       ecx,ecx
       mov       [rax+0C],ecx
       mov       [rax+10],ecx
       add       rsp,48
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M43_L02:
       mov       r15,[rbx+28]
       lea       rdi,[r15+8]
       mov       eax,0FFFFFFFF
       lock xadd [rdi],eax
       dec       eax
       je        short M43_L05
M43_L03:
       mov       rsi,[rbx+8]
       lea       rdi,[rbx+28]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       short M43_L01
M43_L04:
       mov       rdi,[rbx+28]
       cmp       [rdi],edi
       call      qword ptr [7F31641F74F8]
       mov       byte ptr [rbx+34],0
       jmp       short M43_L00
M43_L05:
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F29798013D0
       mov       r14,[rdi]
       cmp       byte ptr [r14+24],0
       je        short M43_L06
       mov       rdi,r14
       mov       rsi,r15
       call      qword ptr [7F3164286C58]
       jmp       short M43_L03
M43_L06:
       cmp       dword ptr [r14+1C],0
       je        short M43_L07
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r15
       mov       r11,7F3162260500
       call      qword ptr [r11]
       jmp       near ptr M43_L03
M43_L07:
       mov       rdi,r14
       mov       rsi,r15
       call      qword ptr [7F3164286C70]
       test      eax,eax
       jne       short M43_L08
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r15
       mov       r11,7F3162260508
       call      qword ptr [r11]
       jmp       near ptr M43_L03
M43_L08:
       mov       r13,[r14+10]
       test      r13,r13
       je        near ptr M43_L19
       mov       edi,38
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M43_L10
M43_L09:
       mov       rdi,7F316225B1E8
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M43_L09
       mov       edi,38
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M43_L10:
       dec       r12d
       cmp       dword ptr [r13+18],0
       jl        short M43_L11
       and       r12d,[r13+18]
       jmp       short M43_L12
M43_L11:
       mov       rdi,[r13+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r13+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
M43_L12:
       xor       eax,eax
       jmp       short M43_L16
M43_L13:
       mov       rdi,[r13+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M43_L74
       mov       esi,r12d
       mov       rcx,[rdi+rsi*8+10]
       mov       [rbp-48],rcx
       cmp       qword ptr [rcx+50],0
       jne       short M43_L14
       lea       rdi,[rcx+50]
       test      rdi,rdi
       je        near ptr M43_L65
       mov       rsi,r15
       xor       edx,edx
       call      00007F31E1674060
       test      rax,rax
       mov       rcx,[rbp-48]
       je        short M43_L17
M43_L14:
       mov       rdx,r15
       mov       rsi,rcx
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F3163CDE058]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       jne       short M43_L17
       inc       r12d
       mov       rdi,[r13+8]
       cmp       [rdi+8],r12d
       jne       short M43_L15
       xor       r12d,r12d
M43_L15:
       mov       eax,[rbp-2C]
       inc       eax
M43_L16:
       mov       rdi,[r13+8]
       mov       [rbp-2C],eax
       cmp       [rdi+8],eax
       jg        short M43_L13
       jmp       short M43_L18
M43_L17:
       cmp       dword ptr [r14+1C],0
       je        near ptr M43_L03
       jmp       near ptr M43_L24
M43_L18:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r14+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r15
       mov       r11,7F3162260510
       call      qword ptr [r11]
       jmp       short M43_L17
M43_L19:
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M43_L21
M43_L20:
       mov       rdi,7F316225B1E0
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M43_L20
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M43_L21:
       dec       r13d
       imul      r13d,9E3779B9
       cmp       dword ptr [r14+18],0
       jge       short M43_L22
       mov       r12d,r13d
       mov       r13d,[r14+20]
       imul      r13,r12
       shr       r13,20
       jmp       short M43_L23
M43_L22:
       and       r13d,[r14+18]
M43_L23:
       mov       rdi,[r14+8]
       lea       esi,[r13*8+8]
       cmp       esi,[rdi+8]
       jae       near ptr M43_L74
       lea       rdi,[rdi+rsi*8+10]
       test      rdi,rdi
       je        near ptr M43_L65
       mov       rsi,r15
       call      00007F31E1674040
       test      rax,rax
       je        near ptr M43_L17
       mov       rdi,r14
       mov       rsi,r15
       mov       rdx,rax
       mov       ecx,r13d
       call      qword ptr [7F3164286C88]
       jmp       near ptr M43_L17
M43_L24:
       mov       rdi,r14
       call      qword ptr [7F3164286CA0]
       jmp       near ptr M43_L03
M43_L25:
       mov       rdi,[rbx+8]
       call      qword ptr [7F31641F7510]; Kevlar.KevlarProperties.ReleaseAdditionalAttemptState(AdditionalAttemptState)
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,7F29798013D0
       mov       r15,[rdi]
       cmp       byte ptr [r15+24],0
       je        near ptr M43_L52
       cmp       dword ptr [r15+1C],0
       je        short M43_L26
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F3164286CB8]
M43_L26:
       lea       rdi,[r15+28]
       mov       rsi,[rdi]
       test      rsi,rsi
       jne       short M43_L27
       mov       rsi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F3164286CD0]
       mov       rsi,rax
M43_L27:
       mov       rdi,rsi
       cmp       [rdi],edi
       call      qword ptr [7F3164286CE8]
       mov       r14,rax
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F3163245728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       cmp       byte ptr [7F316225B1F8],0
       je        short M43_L30
       mov       edx,[r14+68]
       mov       rax,[r14+58]
       mov       r13,rax
       test      r13,r13
       je        short M43_L31
       xor       esi,esi
       mov       [r14+58],rsi
       cmp       [r14+68],edx
       jne       short M43_L28
       test      dl,1
       je        short M43_L29
M43_L28:
       mov       rdx,r13
       mov       rsi,r14
       mov       rdi,offset MT_Reservoir.TrackedInstanceThreadLocalFrontTier<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F3164286D00]
       mov       r13,rax
       test      r13,r13
       je        short M43_L31
M43_L29:
       jmp       near ptr M43_L49
M43_L30:
       cmp       qword ptr [r14+58],0
       je        short M43_L31
       lea       rdi,[r14+58]
       test      rdi,rdi
       je        near ptr M43_L65
       xor       esi,esi
       call      00007F31E1674040
       mov       r13,rax
       test      r13,r13
       jne       short M43_L29
M43_L31:
       cmp       byte ptr [r14+6C],0
       jne       short M43_L32
       mov       byte ptr [r14+6C],1
M43_L32:
       mov       r13,[r15+10]
       xor       r14d,r14d
       test      r13,r13
       jne       near ptr M43_L39
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r14d,[rax+10]
       test      r14d,r14d
       jne       short M43_L34
M43_L33:
       mov       rdi,7F316225B1E0
       mov       eax,1
       mov       r14d,eax
       lock xadd [rdi],r14d
       inc       r14d
       je        short M43_L33
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r14d
M43_L34:
       dec       r14d
       imul      edi,r14d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M43_L35
       mov       r14d,edi
       mov       edx,[r15+20]
       imul      r14,rdx
       shr       r14,20
       jmp       short M43_L36
M43_L35:
       and       edi,[r15+18]
       mov       r14d,edi
M43_L36:
       mov       rdi,[r15+8]
       lea       edx,[r14*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M43_L74
       lea       rdi,[rdi+rdx*8+10]
       mov       r12,[rdi]
       test      r12,r12
       je        short M43_L37
       mov       rdx,r12
       xor       esi,esi
       call      00007F31E1674060
       cmp       rax,r12
       je        short M43_L38
M43_L37:
       xor       r12d,r12d
M43_L38:
       mov       [rbp-38],r12
       jmp       near ptr M43_L45
M43_L39:
       mov       edi,38
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M43_L41
M43_L40:
       mov       rdi,7F316225B1E8
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M43_L40
       mov       edi,38
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M43_L41:
       dec       r12d
       cmp       dword ptr [r13+18],0
       jl        short M43_L42
       and       r12d,[r13+18]
       jmp       short M43_L43
M43_L42:
       mov       rdi,[r13+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r13+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
M43_L43:
       mov       rdi,[r13+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M43_L74
       mov       edx,r12d
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-50],rax
       mov       rcx,[rax+50]
       mov       [rbp-58],rcx
       test      rcx,rcx
       je        short M43_L44
       lea       rdi,[rax+50]
       test      rdi,rdi
       je        near ptr M43_L65
       mov       rdx,rcx
       xor       esi,esi
       call      00007F31E1674060
       mov       rdx,[rbp-58]
       cmp       rax,rdx
       mov       rax,[rbp-50]
       jne       short M43_L44
       mov       [rbp-38],rdx
       jmp       short M43_L45
M43_L44:
       lea       rdx,[rbp-38]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F3163CDDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M43_L45
       lea       rdx,[rbp-38]
       mov       rdi,r13
       mov       esi,r12d
       call      qword ptr [7F3163CDDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M43_L45:
       mov       r12,[rbp-38]
       cmp       qword ptr [rbp-38],0
       jne       short M43_L47
       test      r13,r13
       je        short M43_L46
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       dword ptr [rax+8],1
       mov       r13,rax
       jmp       short M43_L48
M43_L46:
       mov       rdi,r15
       mov       esi,r14d
       call      qword ptr [7F3164286D18]
       mov       r12,rax
M43_L47:
       mov       r13,r12
M43_L48:
       xor       edi,edi
       mov       [rbp-38],rdi
M43_L49:
       cmp       dword ptr [r15+1C],0
       jne       short M43_L50
       mov       rsi,r13
       jmp       short M43_L51
M43_L50:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r13
       mov       r11,7F3162260518
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F3164286CB8]
       mov       rsi,rax
M43_L51:
       jmp       near ptr M43_L73
M43_L52:
       cmp       dword ptr [r15+1C],0
       je        short M43_L53
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F3164286CB8]
M43_L53:
       mov       r14,[r15+10]
       xor       r13d,r13d
       test      r14,r14
       jne       near ptr M43_L60
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r13d,[rax+10]
       test      r13d,r13d
       jne       short M43_L55
M43_L54:
       mov       rdi,7F316225B1E0
       mov       eax,1
       mov       r13d,eax
       lock xadd [rdi],r13d
       inc       r13d
       je        short M43_L54
       mov       edi,34
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r13d
M43_L55:
       dec       r13d
       imul      edi,r13d,9E3779B9
       cmp       dword ptr [r15+18],0
       jge       short M43_L56
       mov       r13d,edi
       mov       edx,[r15+20]
       imul      r13,rdx
       shr       r13,20
       jmp       short M43_L57
M43_L56:
       and       edi,[r15+18]
       mov       r13d,edi
M43_L57:
       mov       rdi,[r15+8]
       lea       edx,[r13*8+8]
       cmp       edx,[rdi+8]
       jae       near ptr M43_L74
       lea       rdi,[rdi+rdx*8+10]
       mov       r12,[rdi]
       test      r12,r12
       je        short M43_L58
       mov       rdx,r12
       xor       esi,esi
       call      00007F31E1674060
       cmp       rax,r12
       je        short M43_L59
M43_L58:
       xor       r12d,r12d
M43_L59:
       mov       [rbp-40],r12
       jmp       near ptr M43_L68
M43_L60:
       mov       edi,38
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       r12d,[rax+10]
       test      r12d,r12d
       jne       short M43_L62
M43_L61:
       mov       rdi,7F316225B1E8
       mov       eax,1
       mov       r12d,eax
       lock xadd [rdi],r12d
       inc       r12d
       je        short M43_L61
       mov       edi,38
       call      CORINFO_HELP_GETDYNAMIC_NONGCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED2
       mov       [rax+10],r12d
M43_L62:
       dec       r12d
       cmp       dword ptr [r14+18],0
       jl        short M43_L63
       and       r12d,[r14+18]
       jmp       short M43_L64
M43_L63:
       mov       rdi,[r14+8]
       mov       edi,[rdi+8]
       mov       r12d,r12d
       imul      r12,[r14+10]
       shr       r12,20
       inc       r12
       imul      r12,rdi
       shr       r12,20
M43_L64:
       mov       rdi,[r14+8]
       cmp       r12d,[rdi+8]
       jae       near ptr M43_L74
       mov       edx,r12d
       mov       rax,[rdi+rdx*8+10]
       mov       [rbp-60],rax
       mov       rcx,[rax+50]
       mov       [rbp-68],rcx
       test      rcx,rcx
       je        short M43_L67
       lea       rdi,[rax+50]
       test      rdi,rdi
       jne       short M43_L66
M43_L65:
       call      qword ptr [7F31642865F8]
       int       3
M43_L66:
       mov       rdx,rcx
       xor       esi,esi
       call      00007F31E1674060
       mov       rdx,[rbp-68]
       cmp       rax,rdx
       mov       rax,[rbp-60]
       jne       short M43_L67
       mov       [rbp-40],rdx
       jmp       short M43_L68
M43_L67:
       lea       rdx,[rbp-40]
       mov       rsi,rax
       mov       rdi,offset MT_Reservoir.StripedObjectStore<Kevlar.KevlarProperties+AdditionalAttemptState>
       call      qword ptr [7F3163CDDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       jne       short M43_L68
       lea       rdx,[rbp-40]
       mov       rdi,r14
       mov       esi,r12d
       call      qword ptr [7F3163CDDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopSlow(Int32, System.__Canon ByRef)
M43_L68:
       mov       r12,[rbp-40]
       cmp       qword ptr [rbp-40],0
       jne       short M43_L70
       test      r14,r14
       je        short M43_L69
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       r14,rax
       mov       dword ptr [r14+8],1
       jmp       short M43_L71
M43_L69:
       mov       rdi,r15
       mov       esi,r13d
       call      qword ptr [7F3164286D18]
       mov       r12,rax
M43_L70:
       mov       r14,r12
M43_L71:
       xor       edi,edi
       mov       [rbp-40],rdi
       cmp       dword ptr [r15+1C],0
       jne       short M43_L72
       mov       rsi,r14
       jmp       short M43_L73
M43_L72:
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy
       call      CORINFO_HELP_NEWSFAST
       mov       dil,[r15+30]
       mov       [rax+8],dil
       mov       rdi,rax
       mov       rsi,r14
       mov       r11,7F3162260520
       call      qword ptr [r11]
       mov       rdi,offset MT_Reservoir.ObjectPool<Kevlar.KevlarProperties+AdditionalAttemptState, Kevlar.KevlarProperties+AdditionalAttemptStatePoolPolicy>
       call      qword ptr [7F3164286CB8]
       mov       rsi,rax
M43_L73:
       lea       rdi,[rbx+8]
       call      CORINFO_HELP_ASSIGN_REF
       jmp       near ptr M43_L03
M43_L74:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 2215
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rdi
       mov       rdi,[rbx]
       call      qword ptr [7F3163CDDD40]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       r15d,[rax+10]
       test      r15d,r15d
       je        short M44_L02
M44_L00:
       dec       r15d
       mov       eax,[rbx+18]
       test      eax,eax
       jl        short M44_L03
       and       eax,r15d
M44_L01:
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
M44_L02:
       mov       rdi,[rbx]
       call      qword ptr [7F3163245728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       edi,1
       mov       r15d,edi
       lock xadd [rax],r15d
       inc       r15d
       je        short M44_L02
       mov       rdi,[rbx]
       call      qword ptr [7F3163CDDD40]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       [rax+10],r15d
       jmp       short M44_L00
M44_L03:
       mov       rax,[rbx+8]
       mov       eax,[rax+8]
       mov       ecx,r15d
       imul      rcx,[rbx+10]
       shr       rcx,20
       inc       rcx
       imul      rax,rcx
       shr       rax,20
       jmp       short M44_L01
; Total bytes of code 134
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPopAt(Int32, System.__Canon ByRef)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+30]
       mov       [rbp-28],rdi
       mov       rbx,rdi
       mov       r15,rdx
       mov       rdi,[rbx+8]
       cmp       esi,[rdi+8]
       jae       short M45_L03
       mov       edx,esi
       mov       r14,[rdi+rdx*8+10]
       mov       r13,[r14+50]
       test      r13,r13
       jne       short M45_L01
M45_L00:
       mov       rdi,[rbx]
       mov       rsi,r14
       mov       rdx,r15
       add       rsp,10
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [7F3163CDDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
M45_L01:
       lea       rdi,[r14+50]
       test      rdi,rdi
       je        short M45_L02
       mov       rdx,r13
       xor       esi,esi
       call      00007F31E1674060
       cmp       rax,r13
       jne       short M45_L00
       mov       rdi,r15
       mov       rsi,r13
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       eax,1
       add       rsp,10
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M45_L02:
       call      qword ptr [7F31642865F8]
       int       3
M45_L03:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 145
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7F3162DF4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7F3162DEEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7F3162DFF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M46_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M46_L00
       mov       rsi,rax
       call      qword ptr [7F3162DEEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M46_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbx
       sub       rsp,10
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rbx,rdi
       mov       rdi,rbx
       call      qword ptr [7F3162E09718]; Precode of System.Runtime.CompilerServices.InitHelpers.InitClassSlow(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rbx+20]
       mov       rax,[rax-10]
       mov       [rsp+8],rax
       mov       rax,[rsp+8]
       and       rax,0FFFFFFFFFFFFFFFE
       xor       ecx,ecx
       mov       [rsp+8],rcx
       add       rsp,10
       pop       rbx
       ret
; Total bytes of code 59
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rax,[rdi+20]
       mov       ebx,[rax-28]
       cmp       ebx,0FFFFFFFF
       je        near ptr M48_L04
       mov       rdi,7F31E18A0D68
       mov       rax,7F31E21B6820
       call      rax
       add       rax,8
       add       rax,0FFFFFFFFFFFFFFF8
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M48_L01
       cmp       [rax],edi
       jle       short M48_L03
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M48_L03
M48_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M48_L01:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M48_L02
       movsxd    rdi,ecx
       add       rax,rdi
       jmp       short M48_L00
M48_L02:
       cmp       [rax+4],ecx
       jle       short M48_L03
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M48_L03
       mov       rax,[rdi]
       test      rax,rax
       je        short M48_L03
       jmp       short M48_L00
M48_L03:
       mov       edi,ebx
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7F31642864A8]
M48_L04:
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [7F3163CDDD88]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
; Total bytes of code 179
```
```assembly
; System.Object..ctor()
       ret
; Total bytes of code 1
```
```assembly
; System.TimeProvider.get_System()
       mov       rax,7F2979800B00
       mov       rax,[rax]
       ret
; Total bytes of code 14
```
```assembly
; System.Threading.Monitor.Enter_Slowpath(System.Object)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,68
       lea       rbp,[rsp+90]
       mov       [rbp-30],rdi
       lea       rdi,[rbp-30]
       mov       [rbp-90],rdi
       lea       rdi,[rbp-88]
       call      qword ptr [7F3162DEEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-90]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7F3162DEEF08]; CORINFO_HELP_JIT_PINVOKE_END
       nop
       add       rsp,68
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; Kevlar.KevlarProperties.Find(PropertyIdentity)
       push      rbp
       push      rbx
       sub       rsp,28
       lea       rbp,[rsp+30]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-28],rsi
       mov       [rbp-30],rdx
       mov       rbx,rdi
       cmp       qword ptr [rbx+10],0
       jne       short M52_L02
M52_L00:
       cmp       qword ptr [rbx+18],0
       jne       short M52_L03
M52_L01:
       xor       eax,eax
       add       rsp,28
       pop       rbx
       pop       rbp
       ret
M52_L02:
       vmovdqu   xmm0,xmmword ptr [rbx+38]
       vmovdqu   xmmword ptr [rbp-20],xmm0
       mov       rsi,[rbp-28]
       mov       rdx,[rbp-30]
       lea       rdi,[rbp-20]
       call      qword ptr [7F31642875E8]
       test      eax,eax
       je        short M52_L00
       mov       rax,[rbx+10]
       add       rsp,28
       pop       rbx
       pop       rbp
       ret
M52_L03:
       mov       rdi,[rbx+18]
       mov       rsi,[rbp-28]
       mov       rdx,[rbp-30]
       lea       rcx,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F3164222660]
       test      eax,eax
       je        short M52_L01
       mov       rax,[rbp-10]
       add       rsp,28
       pop       rbx
       pop       rbp
       ret
; Total bytes of code 143
```
```assembly
; Kevlar.KevlarProperties.RemoveMissingValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       push      r15
       push      r14
       push      rbx
       sub       rsp,18
       lea       rbp,[rsp+30]
       mov       [rbp-20],rsi
       mov       [rbp-28],rdx
       mov       rbx,rdi
       mov       r14,rcx
       mov       r15,r8
       test      rbx,rbx
       jne       short M53_L01
M53_L00:
       add       rsp,18
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M53_L01:
       mov       rdi,rbx
       mov       rax,[rbx]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       je        short M53_L00
       mov       rsi,[rbp-20]
       mov       rdx,[rbp-28]
       mov       rdi,r14
       cmp       [rdi],edi
       call      qword ptr [7F31641F7BA0]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       test      rax,rax
       je        short M53_L02
       mov       rdi,rax
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       jne       short M53_L00
M53_L02:
       mov       rsi,[rbp-20]
       mov       rdx,[rbp-28]
       mov       rdi,r15
       cmp       [rdi],edi
       call      qword ptr [7F31641F7BA0]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,rbx
       call      qword ptr [7F31641F7BB8]
       test      eax,eax
       je        short M53_L00
       mov       rsi,[rbp-20]
       mov       rdx,[rbp-28]
       mov       rdi,r15
       call      qword ptr [7F31641F7BD0]
       jmp       short M53_L00
; Total bytes of code 160
```
```assembly
; Kevlar.KevlarProperties.CopyChangedValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      rbx
       sub       rsp,30
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-38],xmm8
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       r15,rdi
       mov       rbx,rcx
       mov       r14,r8
       cmp       qword ptr [rbx+10],0
       jne       short M54_L04
M54_L00:
       cmp       qword ptr [rbx+18],0
       jne       short M54_L05
M54_L01:
       xor       r13d,r13d
M54_L02:
       xor       edi,edi
       mov       [rbp-28],rdi
       test      r15,r15
       jne       short M54_L06
M54_L03:
       add       rsp,30
       pop       rbx
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M54_L04:
       vmovdqu   xmm0,xmmword ptr [rbx+38]
       vmovdqu   xmmword ptr [rbp-38],xmm0
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-48]
       lea       rdi,[rbp-38]
       call      qword ptr [7F31642875E8]
       test      eax,eax
       je        short M54_L00
       mov       r13,[rbx+10]
       jmp       short M54_L02
M54_L05:
       mov       rdi,[rbx+18]
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-48]
       lea       rcx,[rbp-28]
       cmp       [rdi],edi
       call      qword ptr [7F3164222660]
       test      eax,eax
       je        short M54_L01
       mov       r13,[rbp-28]
       jmp       short M54_L02
M54_L06:
       mov       rdi,r15
       mov       rax,[r15]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       je        short M54_L03
       mov       rdi,r15
       mov       rsi,r13
       call      qword ptr [7F31641F7BB8]
       test      eax,eax
       jne       short M54_L03
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-48]
       mov       rdi,r14
       cmp       [rdi],edi
       call      qword ptr [7F31641F7BA0]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,r13
       call      qword ptr [7F31641F7BB8]
       test      eax,eax
       je        near ptr M54_L03
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-48]
       mov       rdi,r15
       mov       rsi,r14
       mov       rax,[r15]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
       jmp       near ptr M54_L03
; Total bytes of code 264
```
```assembly
; Kevlar.KevlarProperties.RemoveMissingValuesFrom(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,58
       lea       rbp,[rsp+80]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       xor       eax,eax
       mov       [rbp-30],rax
       mov       rbx,rdi
       mov       r14,rsi
       mov       r15,rdx
       mov       r13,[rbx+10]
       mov       r12,[rbx+38]
       mov       rax,[rbx+40]
       mov       [rbp-78],rax
       test      r13,r13
       jne       short M55_L02
M55_L00:
       cmp       qword ptr [rbx+18],0
       jne       near ptr M55_L04
M55_L01:
       add       rsp,58
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M55_L02:
       mov       rdi,r13
       mov       rcx,[r13]
       mov       rcx,[rcx+40]
       call      qword ptr [rcx+20]
       test      eax,eax
       je        short M55_L00
       mov       rsi,r12
       mov       rdx,[rbp-78]
       mov       rdi,r14
       cmp       [rdi],edi
       call      qword ptr [7F31641F7BA0]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       test      rax,rax
       je        short M55_L03
       mov       rdi,rax
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       jne       short M55_L00
M55_L03:
       mov       rsi,r12
       mov       rdx,[rbp-78]
       mov       rdi,r15
       cmp       [rdi],edi
       call      qword ptr [7F31641F7BA0]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,r13
       call      qword ptr [7F31641F7BB8]
       test      eax,eax
       je        short M55_L00
       mov       rsi,r12
       mov       rdx,[rbp-78]
       mov       rdi,r15
       call      qword ptr [7F31641F7BD0]
       jmp       near ptr M55_L00
M55_L04:
       mov       rdi,[rbx+18]
       lea       rsi,[rbp-58]
       cmp       [rdi],edi
       call      qword ptr [7F31641F7A08]
       jmp       short M55_L06
M55_L05:
       mov       rdi,[rbp-40]
       vmovdqu   xmm0,xmmword ptr [rbp-40]
       vmovdqu   xmmword ptr [rbp-70],xmm0
       mov       rsi,[rbp-30]
       mov       [rbp-60],rsi
       mov       rsi,[rbp-68]
       mov       rdx,[rbp-60]
       mov       rcx,r14
       mov       r8,r15
       call      qword ptr [7F31641F7B70]; Kevlar.KevlarProperties.RemoveMissingValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
M55_L06:
       lea       rdi,[rbp-58]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F31641F7A68]
       test      eax,eax
       jne       short M55_L05
       jmp       near ptr M55_L01
; Total bytes of code 301
```
```assembly
; Kevlar.KevlarProperties.CopyChangedValuesTo(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-88],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       vmovdqa   xmmword ptr [rbp-40],xmm8
       mov       [rbp-30],rax
       mov       rbx,rdi
       mov       r15,rsi
       mov       r14,rdx
       mov       r13,[rbx+10]
       mov       r12,[rbx+38]
       mov       rax,[rbx+40]
       mov       [rbp-98],rax
       cmp       qword ptr [r15+10],0
       jne       short M56_L05
M56_L00:
       cmp       qword ptr [r15+18],0
       jne       short M56_L06
M56_L01:
       xor       ecx,ecx
M56_L02:
       xor       edi,edi
       mov       [rbp-78],rdi
       test      r13,r13
       mov       [rbp-90],rcx
       jne       near ptr M56_L07
M56_L03:
       cmp       qword ptr [rbx+18],0
       jne       near ptr M56_L08
M56_L04:
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
M56_L05:
       vmovdqu   xmm0,xmmword ptr [r15+38]
       vmovdqu   xmmword ptr [rbp-88],xmm0
       mov       rsi,r12
       mov       rdx,rax
       lea       rdi,[rbp-88]
       call      qword ptr [7F31642875E8]
       test      eax,eax
       mov       rax,[rbp-98]
       je        short M56_L00
       mov       rcx,[r15+10]
       mov       [rbp-90],rcx
       mov       rcx,[rbp-90]
       jmp       short M56_L02
M56_L06:
       mov       rdi,[r15+18]
       mov       rsi,r12
       mov       rdx,rax
       lea       rcx,[rbp-78]
       cmp       [rdi],edi
       call      qword ptr [7F3164222660]
       test      eax,eax
       mov       rax,[rbp-98]
       je        near ptr M56_L01
       mov       rcx,[rbp-78]
       jmp       near ptr M56_L02
M56_L07:
       mov       rdi,r13
       mov       rdx,[r13]
       mov       rdx,[rdx+40]
       call      qword ptr [rdx+20]
       test      eax,eax
       je        near ptr M56_L03
       mov       rdi,r13
       mov       rsi,[rbp-90]
       call      qword ptr [7F31641F7BB8]
       test      eax,eax
       jne       near ptr M56_L03
       mov       rsi,r12
       mov       rdx,[rbp-98]
       mov       rdi,r14
       cmp       [rdi],edi
       call      qword ptr [7F31641F7BA0]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       rdi,rax
       mov       rsi,[rbp-90]
       call      qword ptr [7F31641F7BB8]
       test      eax,eax
       je        near ptr M56_L03
       mov       rdx,r12
       mov       rcx,[rbp-98]
       mov       rdi,r13
       mov       rsi,r14
       mov       rax,[r13]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
       jmp       near ptr M56_L03
M56_L08:
       mov       rdi,[rbx+18]
       lea       rsi,[rbp-58]
       cmp       [rdi],edi
       call      qword ptr [7F31641F7A08]
       jmp       short M56_L10
M56_L09:
       mov       rdi,[rbp-40]
       vmovdqu   xmm0,xmmword ptr [rbp-40]
       vmovdqu   xmmword ptr [rbp-70],xmm0
       mov       rsi,[rbp-30]
       mov       [rbp-60],rsi
       mov       rsi,[rbp-68]
       mov       rdx,[rbp-60]
       mov       rcx,r15
       mov       r8,r14
       call      qword ptr [7F31641F7BE8]; Kevlar.KevlarProperties.CopyChangedValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
M56_L10:
       lea       rdi,[rbp-58]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F31641F7A68]
       test      eax,eax
       jne       short M56_L09
       jmp       near ptr M56_L04
; Total bytes of code 469
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       dword ptr [rax+8],1
       mov       rdi,[rbp-8]
       call      qword ptr [7F316324C240]; System.Object..ctor()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbx
       sub       rsp,10
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rbx,rdi
       mov       rdi,rbx
       call      qword ptr [7F3162E09718]; Precode of System.Runtime.CompilerServices.InitHelpers.InitClassSlow(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rbx+20]
       mov       rax,[rax-18]
       mov       [rsp+8],rax
       mov       rax,[rsp+8]
       and       rax,0FFFFFFFFFFFFFFFE
       xor       ecx,ecx
       mov       [rsp+8],rcx
       add       rsp,10
       pop       rbx
       ret
; Total bytes of code 59
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBaseSlow(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,78
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       rsi,rdi
       lea       rdi,[rbp-30]
       mov       [rbp-94],rdi
       mov       [rbp-9C],rsi
       xor       edx,edx
       mov       [rbp-8C],edx
       lea       rdi,[rbp-88]
       call      qword ptr [7F3162DEEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       edx,[rbp-8C]
       call      qword ptr [rax]
       lea       rdi,[rbp-88]
       call      qword ptr [7F3162DEEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,[rbp-30]
       add       rsp,78
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 131
```

