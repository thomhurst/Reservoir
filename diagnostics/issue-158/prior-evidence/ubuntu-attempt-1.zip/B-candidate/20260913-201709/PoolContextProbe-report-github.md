```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.62GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]      : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  B-candidate : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

Job=B-candidate  EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.9.0,DOTNET_TieredPGO=1  Arguments=/p:ReservoirVersion=1.9.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll  
IterationCount=10  LaunchCount=3  WarmupCount=5  

```
| Method           | Mean      | Error    | StdDev   | Median    | Code Size | Allocated |
|----------------- |----------:|---------:|---------:|----------:|----------:|----------:|
| SingleRentReturn |  19.18 ns | 2.383 ns | 3.340 ns |  16.71 ns |   9,419 B |         - |
| NestedRentReturn |  38.80 ns | 0.263 ns | 0.377 ns |  38.77 ns |  11,723 B |         - |
| SingleContext    | 104.92 ns | 1.030 ns | 1.443 ns | 105.15 ns |  21,336 B |         - |
| NestedContext    | 249.95 ns | 5.184 ns | 7.268 ns | 253.45 ns |  37,079 B |         - |
