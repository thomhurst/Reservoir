## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: dry-1.4.0(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.4.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.4.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=1, LaunchCount=1, RunStrategy=ColdStart, UnrollFactor=1, WarmupCount=1))

```assembly
; PoolContextProbe.SingleRentReturn()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rdi,[rax+8]
       cmp       [rdi],edi
       call      qword ptr [7FD2EE8CDB90]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Rent()
       mov       [rbp-10],rax
       mov       rax,[rbp-10]
       mov       eax,[rax+8]
       mov       [rbp-14],eax
       mov       rax,[rbp-8]
       mov       rdi,[rax+8]
       mov       rsi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7FD2EE8CDBA8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Return(System.__Canon)
       mov       eax,[rbp-14]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 79
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Rent()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rdi,[rbp-10]
       call      qword ptr [7FD2EE8CDBC0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ThrowIfDisposed()
       mov       rdi,[rbp-10]
       call      qword ptr [7FD2EE8CDBD8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].RentWithoutLifecycle()
       mov       [rbp-18],rax
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+1C],0
       jne       short M01_L00
       mov       rax,[rbp-18]
       add       rsp,20
       pop       rbp
       ret
M01_L00:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7FD2EE8CDBF0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       call      qword ptr [7FD2EE8CDC08]
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 102
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Return(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rdi,[rbp-10]
       mov       rsi,7FD2E8A044E0
       call      qword ptr [7FD2EE515830]; System.ArgumentNullException.ThrowIfNull(System.Object, System.String)
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+1C],0
       je        short M02_L00
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FD2EE8CDBF0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
       add       rsp,10
       pop       rbp
       ret
M02_L00:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FD2EE8CDE90]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       test      eax,eax
       jne       short M02_L01
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FD2EE8CDBF0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
       add       rsp,10
       pop       rbp
       ret
M02_L01:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FD2EE8CDEA8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ReturnWithoutReset(System.__Canon)
       mov       rdi,[rbp-8]
       call      qword ptr [7FD2EE8CDEC0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ClearIfDisposed()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 139
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ThrowIfDisposed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+1C],0
       je        short M03_L00
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       call      qword ptr [7FD2EE8CDC08]
M03_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 48
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].RentWithoutLifecycle()
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-18],rax
       xor       eax,eax
       mov       [rbp-1C],eax
       cmp       qword ptr [rbp-18],0
       jne       near ptr M04_L05
       mov       rdi,[rbp-10]
       call      qword ptr [7FD2EE8CDC80]
       mov       [rbp-1C],eax
       mov       rdi,[rbp-10]
       mov       esi,[rbp-1C]
       call      qword ptr [7FD2EE8CDC98]
       mov       [rbp-30],rax
       mov       rax,[rbp-30]
       mov       rax,[rax]
       mov       [rbp-38],rax
       cmp       qword ptr [rbp-38],0
       je        short M04_L02
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-60],rax
       mov       rax,[rbp-60]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+30]
       mov       [rbp-68],rax
       cmp       qword ptr [rbp-68],0
       je        short M04_L00
       mov       rax,[rbp-68]
       mov       [rbp-58],rax
       jmp       short M04_L01
M04_L00:
       mov       rdi,[rbp-60]
       mov       rsi,7FD2EEC1F8F0
       call      qword ptr [7FD2EDE3F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-58],rax
M04_L01:
       mov       rdi,[rbp-58]
       mov       rsi,[rbp-30]
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-38]
       call      qword ptr [7FD2EE22E820]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       cmp       rax,[rbp-38]
       je        short M04_L03
M04_L02:
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-40]
       mov       [rbp-50],rax
       jmp       short M04_L04
M04_L03:
       mov       rax,[rbp-38]
       mov       [rbp-50],rax
M04_L04:
       mov       rax,[rbp-50]
       mov       [rbp-28],rax
       jmp       short M04_L06
M04_L05:
       lea       rsi,[rbp-28]
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7FD2EE8CDCB0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
M04_L06:
       mov       rax,[rbp-28]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-28],0
       jne       short M04_L08
       cmp       qword ptr [rbp-18],0
       je        short M04_L07
       mov       rdi,[rbp-10]
       call      qword ptr [7FD2EE8CDCC8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].CreateItem()
       nop
       add       rsp,70
       pop       rbp
       ret
M04_L07:
       mov       rdi,[rbp-10]
       mov       esi,[rbp-1C]
       call      qword ptr [7FD2EE8CDCE0]
       mov       [rbp-48],rax
M04_L08:
       mov       rax,[rbp-48]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 330
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7FD2EEE7C2B8]; PoolContextProbe+Policy.Destroy(Item)
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 49
```
```assembly
; System.ArgumentNullException.ThrowIfNull(System.Object, System.String)
       push      rax
       test      rdi,rdi
       je        short M06_L00
       add       rsp,8
       ret
M06_L00:
       mov       rdi,rsi
       call      qword ptr [7FD2ED9F1208]
       int       3
; Total bytes of code 21
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-14],eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7FD2EE8CDEF0]; PoolContextProbe+Policy.TryReset(Item)
       mov       [rbp-14],eax
       mov       eax,[rbp-14]
       add       rsp,20
       pop       rbp
       ret
       push      rax
       mov       [rbp-20],rdi
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FD2EE8CDBF0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 88
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ReturnWithoutReset(System.__Canon)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-20],0
       je        short M08_L01
       mov       rdi,[rbp-20]
       mov       rsi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7FD2EE8CDF50]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(System.__Canon)
       test      eax,eax
       jne       short M08_L00
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7FD2EE8CDBF0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
M08_L00:
       nop
       add       rsp,50
       pop       rbp
       ret
M08_L01:
       mov       rdi,[rbp-10]
       call      qword ptr [7FD2EE8CDC80]
       mov       [rbp-24],eax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-48],rax
       mov       rax,[rbp-48]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+38]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       je        short M08_L02
       mov       rax,[rbp-50]
       mov       [rbp-38],rax
       jmp       short M08_L03
M08_L02:
       mov       rdi,[rbp-48]
       mov       rsi,7FD2EECD01A8
       call      qword ptr [7FD2EDE3F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-38],rax
M08_L03:
       mov       rdi,[rbp-10]
       mov       esi,[rbp-24]
       call      qword ptr [7FD2EE8CDC98]
       mov       [rbp-40],rax
       mov       rsi,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rdx,[rbp-18]
       call      qword ptr [7FD2EE8CDF08]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-30],0
       jne       short M08_L04
       add       rsp,50
       pop       rbp
       ret
M08_L04:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-30]
       mov       ecx,[rbp-24]
       call      qword ptr [7FD2EE8CDF68]
       nop
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 262
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ClearIfDisposed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+1C],0
       je        short M09_L00
       mov       rdi,[rbp-8]
       call      qword ptr [7FD2EE8CDFB0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
M09_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 41
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7FD2ED9DEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7FD2ED9DEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       push      rax
       mov       rax,rdx
       test      rsi,rsi
       je        short M11_L00
       mov       rdx,rcx
       mov       rdi,rsi
       mov       rsi,rax
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       jmp       qword ptr [rax]
M11_L00:
       call      qword ptr [7FD2ED9F4288]
       int       3
; Total bytes of code 39
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       dword ptr [rbp-80],3E8
       mov       rdi,[rbp-38]
       call      qword ptr [7FD2EE8CDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-44],eax
       xor       eax,eax
       mov       [rbp-48],eax
       jmp       near ptr M12_L07
M12_L00:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       ecx,[rbp-44]
       cmp       ecx,[rax+8]
       jae       near ptr M12_L09
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       rax,[rax]
       mov       [rbp-50],rax
       mov       rax,[rbp-50]
       mov       rax,[rax+10]
       mov       [rbp-58],rax
       cmp       qword ptr [rbp-58],0
       je        near ptr M12_L04
       mov       rax,[rbp-50]
       cmp       [rax],al
       mov       rax,[rbp-50]
       add       rax,10
       mov       [rbp-70],rax
       xor       eax,eax
       mov       [rbp-60],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-88],rax
       mov       rax,[rbp-88]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+20]
       mov       [rbp-90],rax
       cmp       qword ptr [rbp-90],0
       je        short M12_L01
       mov       rax,[rbp-90]
       mov       [rbp-78],rax
       jmp       short M12_L02
M12_L01:
       mov       rdi,[rbp-88]
       mov       rsi,7FD2EEC1F9F0
       call      qword ptr [7FD2EDE3F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-78],rax
M12_L02:
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-70]
       mov       rdx,[rbp-60]
       mov       rcx,[rbp-58]
       call      qword ptr [7FD2EE22E820]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       cmp       rax,[rbp-58]
       jne       short M12_L03
       mov       rdi,7FD2EECC64D8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-58]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       eax,1
       add       rsp,90
       pop       rbp
       ret
M12_L03:
       mov       rdi,7FD2EECC64DC
       call      CORINFO_HELP_COUNTPROFILE32
M12_L04:
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       mov       rsi,[rbp-50]
       mov       rdx,[rbp-40]
       call      qword ptr [7FD2EE8CDD40]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       je        short M12_L05
       mov       rdi,7FD2EECC64E0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,90
       pop       rbp
       ret
M12_L05:
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-64],eax
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-44],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-64]
       jne       short M12_L06
       mov       rdi,7FD2EECC64E4
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-44],eax
M12_L06:
       mov       rdi,7FD2EECC64E8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-48]
       inc       eax
       mov       [rbp-48],eax
M12_L07:
       mov       eax,[rbp-80]
       dec       eax
       mov       [rbp-80],eax
       cmp       dword ptr [rbp-80],0
       jg        short M12_L08
       lea       rdi,[rbp-80]
       mov       esi,74
       call      CORINFO_HELP_PATCHPOINT
M12_L08:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-48]
       jg        near ptr M12_L00
       mov       rdi,7FD2EECC64EC
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-40]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,90
       pop       rbp
       ret
M12_L09:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 546
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].CreateItem()
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       call      qword ptr [7FD2EE8CDE60]; PoolContextProbe+Policy.Create()
       mov       [rbp-18],rax
       mov       rax,[rbp-18]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-18],0
       jne       short M13_L00
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-28],rax
       mov       edi,67
       mov       rsi,7FD2EE2B56B0
       call      qword ptr [7FD2EDE3EF88]
       mov       [rbp-30],rax
       mov       rsi,[rbp-30]
       mov       rdi,[rbp-28]
       call      qword ptr [7FD2EE515638]
       mov       rdi,[rbp-28]
       call      CORINFO_HELP_THROW
       int       3
M13_L00:
       mov       rax,[rbp-20]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 147
```
```assembly
; PoolContextProbe+Policy.Destroy(Item)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 24
```
```assembly
; PoolContextProbe+Policy.TryReset(Item)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       eax,1
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 29
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(System.__Canon)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       dword ptr [rbp-78],3E8
       mov       rdi,[rbp-38]
       call      qword ptr [7FD2EE8CDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-44],eax
       xor       eax,eax
       mov       [rbp-48],eax
       jmp       near ptr M16_L06
M16_L00:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       ecx,[rbp-44]
       cmp       ecx,[rax+8]
       jae       near ptr M16_L08
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       rax,[rax]
       mov       [rbp-50],rax
       mov       rax,[rbp-50]
       cmp       [rax],al
       mov       rax,[rbp-50]
       add       rax,10
       mov       [rbp-60],rax
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-80],rax
       mov       rax,[rbp-80]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+20]
       mov       [rbp-88],rax
       cmp       qword ptr [rbp-88],0
       je        short M16_L01
       mov       rax,[rbp-88]
       mov       [rbp-68],rax
       jmp       short M16_L02
M16_L01:
       mov       rdi,[rbp-80]
       mov       rsi,7FD2EEC1F9F0
       call      qword ptr [7FD2EDE3F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-68],rax
M16_L02:
       mov       rdi,[rbp-68]
       mov       rsi,[rbp-60]
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-58]
       call      qword ptr [7FD2EE22E820]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       test      rax,rax
       je        short M16_L03
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       mov       rsi,[rbp-50]
       mov       rdx,[rbp-40]
       call      qword ptr [7FD2EE8CDF80]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       je        short M16_L04
       mov       rdi,7FD2EECC6938
       call      CORINFO_HELP_COUNTPROFILE32
M16_L03:
       mov       rdi,7FD2EECC693C
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,90
       pop       rbp
       ret
M16_L04:
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-6C],eax
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-44],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-6C]
       jne       short M16_L05
       mov       rdi,7FD2EECC6940
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-44],eax
M16_L05:
       mov       rdi,7FD2EECC6944
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-48]
       inc       eax
       mov       [rbp-48],eax
M16_L06:
       mov       eax,[rbp-78]
       dec       eax
       mov       [rbp-78],eax
       cmp       dword ptr [rbp-78],0
       jg        short M16_L07
       lea       rdi,[rbp-78]
       mov       esi,50
       call      CORINFO_HELP_PATCHPOINT
M16_L07:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-48]
       jg        near ptr M16_L00
       mov       rdi,7FD2EECC6948
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,90
       pop       rbp
       ret
M16_L08:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 457
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       push      rbp
       sub       rsp,0B0
       lea       rbp,[rsp+0B0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       dword ptr [rbp-88],3E8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-98],rax
       mov       rax,[rbp-98]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+40]
       mov       [rbp-0A0],rax
       cmp       qword ptr [rbp-0A0],0
       je        short M17_L00
       mov       rax,[rbp-0A0]
       mov       [rbp-68],rax
       jmp       short M17_L01
M17_L00:
       mov       rdi,[rbp-98]
       mov       rsi,7FD2EEEB1C28
       call      qword ptr [7FD2EDE3F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-68],rax
M17_L01:
       mov       rax,[rbp-38]
       cmp       [rax],al
       mov       rax,[rbp-38]
       lea       rdi,[rax+28]
       mov       rsi,[rbp-68]
       mov       rdx,[rbp-38]
       call      qword ptr [7FD2EEE7C108]; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       nop
M17_L02:
       mov       rax,[rbp-38]
       mov       rax,[rax+10]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-48],0
       je        near ptr M17_L07
M17_L03:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M17_L04
       lea       rdi,[rbp-88]
       mov       esi,1D
       call      CORINFO_HELP_PATCHPOINT
M17_L04:
       lea       rsi,[rbp-50]
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7FD2EE8CDCB0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       test      eax,eax
       je        short M17_L05
       mov       rdi,7FD2EEEABEFC
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-50]
       call      qword ptr [7FD2EEE7C150]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       jmp       short M17_L03
M17_L05:
       cmp       qword ptr [rbp-40],0
       je        short M17_L06
       mov       rdi,7FD2EEEABF00
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7FD2EEE7C168]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FD2EEE7C180]
M17_L06:
       mov       rdi,7FD2EEEABF04
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M17_L07:
       xor       eax,eax
       mov       [rbp-54],eax
       jmp       near ptr M17_L11
M17_L08:
       mov       rdi,7FD2EEEABF08
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-38]
       mov       esi,[rbp-54]
       call      qword ptr [7FD2EE8CDC98]
       mov       [rbp-70],rax
       xor       eax,eax
       mov       [rbp-60],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-0A8],rax
       mov       rax,[rbp-0A8]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+38]
       mov       [rbp-0B0],rax
       cmp       qword ptr [rbp-0B0],0
       je        short M17_L09
       mov       rax,[rbp-0B0]
       mov       [rbp-78],rax
       jmp       short M17_L10
M17_L09:
       mov       rdi,[rbp-0A8]
       mov       rsi,7FD2EECD01A8
       call      qword ptr [7FD2EDE3F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-78],rax
M17_L10:
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-70]
       mov       rdx,[rbp-60]
       call      qword ptr [7FD2EE8CDF08]
       mov       [rbp-90],rax
       mov       rsi,[rbp-90]
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       call      qword ptr [7FD2EEE7C150]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       mov       eax,[rbp-54]
       inc       eax
       mov       [rbp-54],eax
M17_L11:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M17_L12
       lea       rdi,[rbp-88]
       mov       esi,67
       call      CORINFO_HELP_PATCHPOINT
M17_L12:
       mov       rdi,[rbp-38]
       call      qword ptr [7FD2EEE7C198]
       cmp       eax,[rbp-54]
       jg        near ptr M17_L08
       cmp       qword ptr [rbp-40],0
       je        short M17_L13
       mov       rdi,7FD2EEEABF0C
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7FD2EEE7C168]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FD2EEE7C180]
M17_L13:
       mov       rdi,7FD2EEEABF10
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
       push      rax
       mov       [rbp-80],rdi
       mov       rdi,7FD2EEEABEF8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-80]
       mov       [rbp-40],rax
       lea       rax,[M17_L02]
       add       rsp,8
       ret
; Total bytes of code 731
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7FD2ED9E4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7FD2ED9DEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7FD2ED9EF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M18_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M18_L00
       mov       rsi,rax
       call      qword ptr [7FD2ED9DEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M18_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp-3C],eax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       dword ptr [rbp-48],3E8
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FD2EE8CDD58]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       eax,[rax+10]
       mov       [rbp-3C],eax
       cmp       dword ptr [rbp-3C],0
       jne       short M19_L02
M19_L00:
       mov       eax,[rbp-48]
       dec       eax
       mov       [rbp-48],eax
       cmp       dword ptr [rbp-48],0
       jg        short M19_L01
       lea       rdi,[rbp-48]
       mov       esi,9
       call      CORINFO_HELP_PATCHPOINT
M19_L01:
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FD2EDE35728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,rax
       call      qword ptr [7FD2EE8CDD70]; System.Threading.Interlocked.Increment(Int32 ByRef)
       mov       [rbp-3C],eax
       cmp       dword ptr [rbp-3C],0
       je        short M19_L03
       mov       rdi,7FD2EECC6540
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FD2EE8CDD58]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       ecx,[rbp-3C]
       mov       [rax+10],ecx
M19_L02:
       mov       rdi,7FD2EECC6544
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-3C]
       lea       esi,[rax-1]
       mov       rdi,[rbp-38]
       call      qword ptr [7FD2EE8CDD88]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetAffinityIndex(UInt32)
       nop
       add       rsp,50
       pop       rbp
       ret
M19_L03:
       mov       rdi,7FD2EECC6548
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M19_L00
; Total bytes of code 206
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+18]
       mov       rdi,[rbp-10]
       call      qword ptr [7FD2EE8CDDE8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M20_L00
       mov       rax,[rbp-20]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M20_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M20_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rax]
       mov       rdi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M20_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       xor       ecx,ecx
       mov       [rax],rcx
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+20]
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7FD2EE8CDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       rax,[rbp-20]
       cmp       qword ptr [rax],0
       setne     al
       movzx     eax,al
       add       rsp,30
       pop       rbp
       ret
M20_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 221
```
```assembly
; PoolContextProbe+Policy.Create()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_PoolContextProbe+Item
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7FD2EE8CDE78]; PoolContextProbe+Item..ctor()
       mov       rax,[rbp-10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 59
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+20]
       mov       rdi,[rbp-10]
       call      qword ptr [7FD2EE8CDDE8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M22_L00
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M22_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M22_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rbp-20]
       mov       rdi,rax
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+18]
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7FD2EE8CDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       eax,1
       add       rsp,30
       pop       rbp
       ret
M22_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 171
```
```assembly
; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       push      rbp
       sub       rsp,110
       lea       rbp,[rsp+110]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0F0],ymm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       xor       eax,eax
       mov       [rbp-50],rax
       mov       [rbp-30],rsi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       dword ptr [rbp-0C8],3E8
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       jne       short M23_L00
       mov       rdi,7FD2EEEAD7E0
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,110
       pop       rbp
       ret
M23_L00:
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+10]
       mov       [rbp-0F8],rax
       cmp       qword ptr [rbp-0F8],0
       je        short M23_L01
       mov       rax,[rbp-0F8]
       mov       [rbp-80],rax
       jmp       short M23_L02
M23_L01:
       mov       rdi,[rbp-40]
       mov       rsi,7FD2EEEB3F88
       call      qword ptr [7FD2EDE3F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-80],rax
M23_L02:
       mov       rdi,[rbp-50]
       cmp       [rdi],edi
       call      qword ptr [7FD2EEE7C270]
       mov       [rbp-0A8],rax
       mov       rdi,[rbp-0A8]
       mov       rsi,7FD2EEEAD7E8
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0A8]
       mov       [rbp-0D0],rax
       mov       rdi,[rbp-0D0]
       mov       r11,[rbp-80]
       mov       rax,[rbp-80]
       call      qword ptr [rax]
       mov       [rbp-60],rax
       jmp       near ptr M23_L09
M23_L03:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-100],rax
       cmp       qword ptr [rbp-100],0
       je        short M23_L04
       mov       rax,[rbp-100]
       mov       [rbp-88],rax
       jmp       short M23_L05
M23_L04:
       mov       rdi,[rbp-40]
       mov       rsi,7FD2EEEB3FC0
       call      qword ptr [7FD2EDE3F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-88],rax
M23_L05:
       mov       rax,[rbp-60]
       mov       [rbp-0B0],rax
       mov       rdi,[rbp-0B0]
       mov       rsi,7FD2EEEAD8F0
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0B0]
       mov       [rbp-0E0],rax
       mov       rdi,[rbp-0E0]
       mov       r11,[rbp-88]
       mov       rax,[rbp-88]
       call      qword ptr [rax]
       mov       [rbp-0D8],rax
       mov       rax,[rbp-0D8]
       cmp       [rax],al
       mov       rax,[rbp-0D8]
       add       rax,8
       mov       [rbp-90],rax
       xor       eax,eax
       mov       [rbp-70],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-108],rax
       cmp       qword ptr [rbp-108],0
       je        short M23_L06
       mov       rax,[rbp-108]
       mov       [rbp-98],rax
       jmp       short M23_L07
M23_L06:
       mov       rdi,[rbp-40]
       mov       rsi,7FD2EEEB4010
       call      qword ptr [7FD2EDE3F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-98],rax
M23_L07:
       mov       rdi,[rbp-98]
       mov       rsi,[rbp-90]
       mov       rdx,[rbp-70]
       call      qword ptr [7FD2EE8CDF08]
       mov       [rbp-68],rax
       cmp       qword ptr [rbp-68],0
       je        short M23_L08
       mov       rdi,7FD2EEEAD9F8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-48]
       mov       rsi,[rbp-68]
       cmp       [rdi],edi
       call      qword ptr [7FD2EEE7C288]
       jmp       short M23_L09
M23_L08:
       mov       rdi,7FD2EEEAD9FC
       call      CORINFO_HELP_COUNTPROFILE32
M23_L09:
       mov       eax,[rbp-0C8]
       dec       eax
       mov       [rbp-0C8],eax
       cmp       dword ptr [rbp-0C8],0
       jg        short M23_L10
       lea       rdi,[rbp-0C8]
       mov       esi,57
       call      CORINFO_HELP_PATCHPOINT
M23_L10:
       mov       rax,[rbp-60]
       mov       [rbp-0B8],rax
       mov       rdi,[rbp-0B8]
       mov       rsi,7FD2EEEADA08
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0B8]
       mov       [rbp-0E8],rax
       mov       rdi,[rbp-0E8]
       mov       r11,7FD2ECE505E8
       call      qword ptr [r11]
       test      eax,eax
       jne       near ptr M23_L03
       call      M23_L13
       nop
       cmp       qword ptr [rbp-58],0
       je        short M23_L11
       mov       rdi,7FD2EEEADC24
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-58]
       call      qword ptr [7FD2EEE7C168]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FD2EEE7C180]
M23_L11:
       mov       rdi,7FD2EEEADC28
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,110
       pop       rbp
       ret
       push      rax
       mov       [rbp-0A0],rdi
       mov       rax,[rbp-0A0]
       mov       [rbp-78],rax
       cmp       qword ptr [rbp-58],0
       jne       short M23_L12
       mov       rdi,7FD2EEEADA00
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-78]
       mov       [rbp-58],rax
M23_L12:
       mov       rdi,7FD2EEEADA04
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rax,[M23_L09]
       add       rsp,8
       ret
M23_L13:
       push      rax
       cmp       qword ptr [rbp-60],0
       je        short M23_L14
       mov       rdi,7FD2EEEADB10
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-60]
       mov       [rbp-0C0],rax
       mov       rdi,[rbp-0C0]
       mov       rsi,7FD2EEEADB18
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0C0]
       mov       [rbp-0F0],rax
       mov       rdi,[rbp-0F0]
       mov       r11,7FD2ECE505F0
       call      qword ptr [r11]
M23_L14:
       mov       rdi,7FD2EEEADC20
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
; Total bytes of code 999
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       cmp       qword ptr [rbp-10],0
       jne       short M24_L00
       add       rsp,30
       pop       rbp
       ret
M24_L00:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FD2EE8CDBF0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
M24_L01:
       add       rsp,30
       pop       rbp
       ret
       push      rax
       mov       [rbp-28],rdi
       mov       rax,[rbp-28]
       mov       [rbp-20],rax
       mov       rax,[rbp-18]
       cmp       qword ptr [rax],0
       jne       short M24_L02
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
M24_L02:
       lea       rax,[M24_L01]
       add       rsp,8
       ret
; Total bytes of code 114
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rax,[rdi+20]
       mov       ebx,[rax-28]
       cmp       ebx,0FFFFFFFF
       jne       short M25_L00
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
M25_L00:
       call      qword ptr [7FD2ED9F6AF0]; Precode of System.Threading.Thread.GetThreadStaticsBase()
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M25_L02
       cmp       [rax],edi
       jle       short M25_L04
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M25_L04
M25_L01:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M25_L02:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M25_L03
       movsxd    rcx,ecx
       add       rax,rcx
       jmp       short M25_L01
M25_L03:
       cmp       [rax+4],ecx
       jle       short M25_L04
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M25_L04
       mov       rax,[rdi]
       test      rax,rax
       je        short M25_L04
       jmp       short M25_L01
M25_L04:
       mov       edi,ebx
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
; Total bytes of code 159
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-10]
       mov       rcx,rax
       test      cl,1
       jne       short M26_L00
       ret
M26_L00:
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       jmp       qword ptr [rax]
; Total bytes of code 27
```
```assembly
; System.Threading.Interlocked.Increment(Int32 ByRef)
       mov       eax,1
       lock xadd [rdi],eax
       inc       eax
       ret
; Total bytes of code 12
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetAffinityIndex(UInt32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-18],eax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-14],esi
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+18],0
       jl        short M28_L00
       mov       rax,[rbp-10]
       mov       eax,[rax+18]
       and       eax,[rbp-14]
       add       rsp,20
       pop       rbp
       ret
M28_L00:
       mov       rax,[rbp-10]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       mov       [rbp-18],eax
       call      qword ptr [7FD2EE8CDDB8]
       cmp       eax,8
       jne       short M28_L01
       mov       rax,[rbp-10]
       mov       rcx,[rax+10]
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       mov       esi,[rbp-14]
       mov       edx,[rbp-18]
       call      qword ptr [7FD2EE8CDDD0]
       nop
       add       rsp,20
       pop       rbp
       ret
M28_L01:
       mov       eax,[rbp-14]
       xor       edx,edx
       div       dword ptr [rbp-18]
       mov       eax,edx
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 127
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-50],rcx
       mov       dword ptr [rbp-70],3E8
M29_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M29_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M29_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7FD2EE8CDE18]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-50]
       mov       [rcx],eax
       mov       rax,[rbp-50]
       cmp       dword ptr [rax],0FFFFFFFF
       jne       short M29_L02
       mov       rdi,7FD2EECC66B0
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,70
       pop       rbp
       ret
M29_L02:
       mov       rax,[rbp-50]
       mov       eax,[rax]
       mov       rcx,[rbp-48]
       cmp       eax,[rcx+8]
       jae       short M29_L04
       mov       edx,eax
       imul      rdx,10
       lea       rcx,[rcx+rdx+10]
       mov       eax,[rcx+8]
       mov       [rbp-5C],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-5C]
       call      qword ptr [7FD2EE8CDE30]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-68],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-68]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M29_L03
       mov       rdi,7FD2EECC66B4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,70
       pop       rbp
       ret
M29_L03:
       mov       rdi,7FD2EECC66B8
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M29_L00
M29_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 269
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-4C],ecx
       mov       dword ptr [rbp-70],3E8
M30_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M30_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M30_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rax,[rbp-48]
       mov       ecx,[rbp-4C]
       cmp       ecx,[rax+8]
       jae       near ptr M30_L03
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       add       rax,8
       mov       [rbp-68],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7FD2EE8CDE18]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-68]
       mov       [rcx],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-4C]
       call      qword ptr [7FD2EE8CDE30]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-60],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-60]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M30_L02
       mov       rdi,7FD2EECC6BA8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,70
       pop       rbp
       ret
M30_L02:
       mov       rdi,7FD2EECC6BAC
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M30_L00
M30_L03:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 235
```
```assembly
; PoolContextProbe+Item..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       dword ptr [rax+8],2A
       mov       rdi,[rbp-8]
       call      qword ptr [7FD2EDE3C240]; System.Object..ctor()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7FD2ED9DEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7FD2ED9DEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       eax,[rbp-10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 27
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-1C],edx
       mov       rax,[rbp-18]
       sar       rax,20
       lea       esi,[rax+1]
       mov       rdi,[rbp-10]
       mov       edx,[rbp-1C]
       call      qword ptr [7FD2EE22E100]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 56
```
```assembly
; System.Object..ctor()
       ret
; Total bytes of code 1
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-10],edx
       movsxd    rax,dword ptr [rbp-0C]
       shl       rax,20
       mov       ecx,[rbp-10]
       or        rax,rcx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 40
```

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: dry-1.4.0(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.4.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.4.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=1, LaunchCount=1, RunStrategy=ColdStart, UnrollFactor=1, WarmupCount=1))

```assembly
; PoolContextProbe.NestedRentReturn()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rdi,[rax+8]
       cmp       [rdi],edi
       call      qword ptr [7FA7470BDB90]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Rent()
       mov       [rbp-10],rax
       mov       rax,[rbp-8]
       mov       rdi,[rax+8]
       cmp       [rdi],edi
       call      qword ptr [7FA7470BDB90]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Rent()
       mov       [rbp-18],rax
       mov       rax,[rbp-10]
       mov       eax,[rax+8]
       mov       rcx,[rbp-18]
       add       eax,[rcx+8]
       mov       [rbp-1C],eax
       mov       rax,[rbp-8]
       mov       rdi,[rax+8]
       mov       rsi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7FA7470BDBA8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Return(System.__Canon)
       mov       rax,[rbp-8]
       mov       rdi,[rax+8]
       mov       rsi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7FA7470BDBA8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Return(System.__Canon)
       mov       eax,[rbp-1C]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 130
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Rent()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rdi,[rbp-10]
       call      qword ptr [7FA7470BDBC0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ThrowIfDisposed()
       mov       rdi,[rbp-10]
       call      qword ptr [7FA7470BDBD8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].RentWithoutLifecycle()
       mov       [rbp-18],rax
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+1C],0
       jne       short M01_L00
       mov       rax,[rbp-18]
       add       rsp,20
       pop       rbp
       ret
M01_L00:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7FA7470BDBF0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       call      qword ptr [7FA7470BDC08]
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 102
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Return(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rdi,[rbp-10]
       mov       rsi,7FA7442044E0
       call      qword ptr [7FA746D05830]; System.ArgumentNullException.ThrowIfNull(System.Object, System.String)
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+1C],0
       je        short M02_L00
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FA7470BDBF0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
       add       rsp,10
       pop       rbp
       ret
M02_L00:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FA7470BDE90]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       test      eax,eax
       jne       short M02_L01
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FA7470BDBF0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
       add       rsp,10
       pop       rbp
       ret
M02_L01:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FA7470BDEA8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ReturnWithoutReset(System.__Canon)
       mov       rdi,[rbp-8]
       call      qword ptr [7FA7470BDEC0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ClearIfDisposed()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 139
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ThrowIfDisposed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+1C],0
       je        short M03_L00
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       call      qword ptr [7FA7470BDC08]
M03_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 48
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].RentWithoutLifecycle()
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-18],rax
       xor       eax,eax
       mov       [rbp-1C],eax
       cmp       qword ptr [rbp-18],0
       jne       near ptr M04_L05
       mov       rdi,[rbp-10]
       call      qword ptr [7FA7470BDC80]
       mov       [rbp-1C],eax
       mov       rdi,[rbp-10]
       mov       esi,[rbp-1C]
       call      qword ptr [7FA7470BDC98]
       mov       [rbp-30],rax
       mov       rax,[rbp-30]
       mov       rax,[rax]
       mov       [rbp-38],rax
       cmp       qword ptr [rbp-38],0
       je        short M04_L02
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-60],rax
       mov       rax,[rbp-60]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+30]
       mov       [rbp-68],rax
       cmp       qword ptr [rbp-68],0
       je        short M04_L00
       mov       rax,[rbp-68]
       mov       [rbp-58],rax
       jmp       short M04_L01
M04_L00:
       mov       rdi,[rbp-60]
       mov       rsi,7FA74740F8F0
       call      qword ptr [7FA74662F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-58],rax
M04_L01:
       mov       rdi,[rbp-58]
       mov       rsi,[rbp-30]
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-38]
       call      qword ptr [7FA746A1E820]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       cmp       rax,[rbp-38]
       je        short M04_L03
M04_L02:
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-40]
       mov       [rbp-50],rax
       jmp       short M04_L04
M04_L03:
       mov       rax,[rbp-38]
       mov       [rbp-50],rax
M04_L04:
       mov       rax,[rbp-50]
       mov       [rbp-28],rax
       jmp       short M04_L06
M04_L05:
       lea       rsi,[rbp-28]
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7FA7470BDCB0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
M04_L06:
       mov       rax,[rbp-28]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-28],0
       jne       short M04_L08
       cmp       qword ptr [rbp-18],0
       je        short M04_L07
       mov       rdi,[rbp-10]
       call      qword ptr [7FA7470BDCC8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].CreateItem()
       nop
       add       rsp,70
       pop       rbp
       ret
M04_L07:
       mov       rdi,[rbp-10]
       mov       esi,[rbp-1C]
       call      qword ptr [7FA7470BDCE0]
       mov       [rbp-48],rax
M04_L08:
       mov       rax,[rbp-48]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 330
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7FA74766C3A8]; PoolContextProbe+Policy.Destroy(Item)
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 49
```
```assembly
; System.ArgumentNullException.ThrowIfNull(System.Object, System.String)
       push      rax
       test      rdi,rdi
       je        short M06_L00
       add       rsp,8
       ret
M06_L00:
       mov       rdi,rsi
       call      qword ptr [7FA7461E1208]
       int       3
; Total bytes of code 21
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].TryResetItem(System.__Canon)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-14],eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7FA7470BDEF0]; PoolContextProbe+Policy.TryReset(Item)
       mov       [rbp-14],eax
       mov       eax,[rbp-14]
       add       rsp,20
       pop       rbp
       ret
       push      rax
       mov       [rbp-20],rdi
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FA7470BDBF0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 88
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ReturnWithoutReset(System.__Canon)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-20],0
       je        short M08_L01
       mov       rdi,[rbp-20]
       mov       rsi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7FA7470BDF50]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(System.__Canon)
       test      eax,eax
       jne       short M08_L00
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7FA7470BDBF0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
M08_L00:
       nop
       add       rsp,50
       pop       rbp
       ret
M08_L01:
       mov       rdi,[rbp-10]
       call      qword ptr [7FA7470BDC80]
       mov       [rbp-24],eax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-48],rax
       mov       rax,[rbp-48]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+38]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       je        short M08_L02
       mov       rax,[rbp-50]
       mov       [rbp-38],rax
       jmp       short M08_L03
M08_L02:
       mov       rdi,[rbp-48]
       mov       rsi,7FA7474C01A8
       call      qword ptr [7FA74662F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-38],rax
M08_L03:
       mov       rdi,[rbp-10]
       mov       esi,[rbp-24]
       call      qword ptr [7FA7470BDC98]
       mov       [rbp-40],rax
       mov       rsi,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rdx,[rbp-18]
       call      qword ptr [7FA7470BDF08]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-30],0
       jne       short M08_L04
       add       rsp,50
       pop       rbp
       ret
M08_L04:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-30]
       mov       ecx,[rbp-24]
       call      qword ptr [7FA7470BDF68]
       nop
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 262
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].ClearIfDisposed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+1C],0
       je        short M09_L00
       mov       rdi,[rbp-8]
       call      qword ptr [7FA7470BDFB0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
M09_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 41
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7FA7461CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7FA7461CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       push      rax
       mov       rax,rdx
       test      rsi,rsi
       je        short M11_L00
       mov       rdx,rcx
       mov       rdi,rsi
       mov       rsi,rax
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       jmp       qword ptr [rax]
M11_L00:
       call      qword ptr [7FA7461E4288]
       int       3
; Total bytes of code 39
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       dword ptr [rbp-80],3E8
       mov       rdi,[rbp-38]
       call      qword ptr [7FA7470BDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-44],eax
       xor       eax,eax
       mov       [rbp-48],eax
       jmp       near ptr M12_L07
M12_L00:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       ecx,[rbp-44]
       cmp       ecx,[rax+8]
       jae       near ptr M12_L09
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       rax,[rax]
       mov       [rbp-50],rax
       mov       rax,[rbp-50]
       mov       rax,[rax+10]
       mov       [rbp-58],rax
       cmp       qword ptr [rbp-58],0
       je        near ptr M12_L04
       mov       rax,[rbp-50]
       cmp       [rax],al
       mov       rax,[rbp-50]
       add       rax,10
       mov       [rbp-70],rax
       xor       eax,eax
       mov       [rbp-60],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-88],rax
       mov       rax,[rbp-88]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+20]
       mov       [rbp-90],rax
       cmp       qword ptr [rbp-90],0
       je        short M12_L01
       mov       rax,[rbp-90]
       mov       [rbp-78],rax
       jmp       short M12_L02
M12_L01:
       mov       rdi,[rbp-88]
       mov       rsi,7FA74740F9F0
       call      qword ptr [7FA74662F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-78],rax
M12_L02:
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-70]
       mov       rdx,[rbp-60]
       mov       rcx,[rbp-58]
       call      qword ptr [7FA746A1E820]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       cmp       rax,[rbp-58]
       jne       short M12_L03
       mov       rdi,7FA7474B64D8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-58]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       eax,1
       add       rsp,90
       pop       rbp
       ret
M12_L03:
       mov       rdi,7FA7474B64DC
       call      CORINFO_HELP_COUNTPROFILE32
M12_L04:
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       mov       rsi,[rbp-50]
       mov       rdx,[rbp-40]
       call      qword ptr [7FA7470BDD40]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       je        short M12_L05
       mov       rdi,7FA7474B64E0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,90
       pop       rbp
       ret
M12_L05:
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-64],eax
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-44],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-64]
       jne       short M12_L06
       mov       rdi,7FA7474B64E4
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-44],eax
M12_L06:
       mov       rdi,7FA7474B64E8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-48]
       inc       eax
       mov       [rbp-48],eax
M12_L07:
       mov       eax,[rbp-80]
       dec       eax
       mov       [rbp-80],eax
       cmp       dword ptr [rbp-80],0
       jg        short M12_L08
       lea       rdi,[rbp-80]
       mov       esi,74
       call      CORINFO_HELP_PATCHPOINT
M12_L08:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-48]
       jg        near ptr M12_L00
       mov       rdi,7FA7474B64EC
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-40]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,90
       pop       rbp
       ret
M12_L09:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 546
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].CreateItem()
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       call      qword ptr [7FA7470BDE60]; PoolContextProbe+Policy.Create()
       mov       [rbp-18],rax
       mov       rax,[rbp-18]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-18],0
       jne       short M13_L00
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-28],rax
       mov       edi,67
       mov       rsi,7FA746AA56B0
       call      qword ptr [7FA74662EF88]
       mov       [rbp-30],rax
       mov       rsi,[rbp-30]
       mov       rdi,[rbp-28]
       call      qword ptr [7FA746D05638]
       mov       rdi,[rbp-28]
       call      CORINFO_HELP_THROW
       int       3
M13_L00:
       mov       rax,[rbp-20]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 147
```
```assembly
; PoolContextProbe+Policy.Destroy(Item)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 24
```
```assembly
; PoolContextProbe+Policy.TryReset(Item)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       eax,1
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 29
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(System.__Canon)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       dword ptr [rbp-78],3E8
       mov       rdi,[rbp-38]
       call      qword ptr [7FA7470BDD28]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-44],eax
       xor       eax,eax
       mov       [rbp-48],eax
       jmp       near ptr M16_L06
M16_L00:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       ecx,[rbp-44]
       cmp       ecx,[rax+8]
       jae       near ptr M16_L08
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       rax,[rax]
       mov       [rbp-50],rax
       mov       rax,[rbp-50]
       cmp       [rax],al
       mov       rax,[rbp-50]
       add       rax,10
       mov       [rbp-60],rax
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-80],rax
       mov       rax,[rbp-80]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+20]
       mov       [rbp-88],rax
       cmp       qword ptr [rbp-88],0
       je        short M16_L01
       mov       rax,[rbp-88]
       mov       [rbp-68],rax
       jmp       short M16_L02
M16_L01:
       mov       rdi,[rbp-80]
       mov       rsi,7FA74740F9F0
       call      qword ptr [7FA74662F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-68],rax
M16_L02:
       mov       rdi,[rbp-68]
       mov       rsi,[rbp-60]
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-58]
       call      qword ptr [7FA746A1E820]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       test      rax,rax
       je        short M16_L03
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       mov       rsi,[rbp-50]
       mov       rdx,[rbp-40]
       call      qword ptr [7FA7470BDF80]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       je        short M16_L04
       mov       rdi,7FA7474B6938
       call      CORINFO_HELP_COUNTPROFILE32
M16_L03:
       mov       rdi,7FA7474B693C
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,90
       pop       rbp
       ret
M16_L04:
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-6C],eax
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-44],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-6C]
       jne       short M16_L05
       mov       rdi,7FA7474B6940
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-44],eax
M16_L05:
       mov       rdi,7FA7474B6944
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-48]
       inc       eax
       mov       [rbp-48],eax
M16_L06:
       mov       eax,[rbp-78]
       dec       eax
       mov       [rbp-78],eax
       cmp       dword ptr [rbp-78],0
       jg        short M16_L07
       lea       rdi,[rbp-78]
       mov       esi,50
       call      CORINFO_HELP_PATCHPOINT
M16_L07:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-48]
       jg        near ptr M16_L00
       mov       rdi,7FA7474B6948
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,90
       pop       rbp
       ret
M16_L08:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 457
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].Clear()
       push      rbp
       sub       rsp,0B0
       lea       rbp,[rsp+0B0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       dword ptr [rbp-88],3E8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-98],rax
       mov       rax,[rbp-98]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+40]
       mov       [rbp-0A0],rax
       cmp       qword ptr [rbp-0A0],0
       je        short M17_L00
       mov       rax,[rbp-0A0]
       mov       [rbp-68],rax
       jmp       short M17_L01
M17_L00:
       mov       rdi,[rbp-98]
       mov       rsi,7FA7476A39B0
       call      qword ptr [7FA74662F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-68],rax
M17_L01:
       mov       rax,[rbp-38]
       cmp       [rax],al
       mov       rax,[rbp-38]
       lea       rdi,[rax+28]
       mov       rsi,[rbp-68]
       mov       rdx,[rbp-38]
       call      qword ptr [7FA74766C1F8]; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       nop
M17_L02:
       mov       rax,[rbp-38]
       mov       rax,[rax+10]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-48],0
       je        near ptr M17_L07
M17_L03:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M17_L04
       lea       rdi,[rbp-88]
       mov       esi,1D
       call      CORINFO_HELP_PATCHPOINT
M17_L04:
       lea       rsi,[rbp-50]
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7FA7470BDCB0]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       test      eax,eax
       je        short M17_L05
       mov       rdi,7FA74769BEFC
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-50]
       call      qword ptr [7FA74766C240]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       jmp       short M17_L03
M17_L05:
       cmp       qword ptr [rbp-40],0
       je        short M17_L06
       mov       rdi,7FA74769BF00
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7FA74766C258]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FA74766C270]
M17_L06:
       mov       rdi,7FA74769BF04
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M17_L07:
       xor       eax,eax
       mov       [rbp-54],eax
       jmp       near ptr M17_L11
M17_L08:
       mov       rdi,7FA74769BF08
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-38]
       mov       esi,[rbp-54]
       call      qword ptr [7FA7470BDC98]
       mov       [rbp-70],rax
       xor       eax,eax
       mov       [rbp-60],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-0A8],rax
       mov       rax,[rbp-0A8]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+38]
       mov       [rbp-0B0],rax
       cmp       qword ptr [rbp-0B0],0
       je        short M17_L09
       mov       rax,[rbp-0B0]
       mov       [rbp-78],rax
       jmp       short M17_L10
M17_L09:
       mov       rdi,[rbp-0A8]
       mov       rsi,7FA7474C01A8
       call      qword ptr [7FA74662F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-78],rax
M17_L10:
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-70]
       mov       rdx,[rbp-60]
       call      qword ptr [7FA7470BDF08]
       mov       [rbp-90],rax
       mov       rsi,[rbp-90]
       lea       rdx,[rbp-40]
       mov       rdi,[rbp-38]
       call      qword ptr [7FA74766C240]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       mov       eax,[rbp-54]
       inc       eax
       mov       [rbp-54],eax
M17_L11:
       mov       eax,[rbp-88]
       dec       eax
       mov       [rbp-88],eax
       cmp       dword ptr [rbp-88],0
       jg        short M17_L12
       lea       rdi,[rbp-88]
       mov       esi,67
       call      CORINFO_HELP_PATCHPOINT
M17_L12:
       mov       rdi,[rbp-38]
       call      qword ptr [7FA74766C288]
       cmp       eax,[rbp-54]
       jg        near ptr M17_L08
       cmp       qword ptr [rbp-40],0
       je        short M17_L13
       mov       rdi,7FA74769BF0C
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       call      qword ptr [7FA74766C258]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FA74766C270]
M17_L13:
       mov       rdi,7FA74769BF10
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
       push      rax
       mov       [rbp-80],rdi
       mov       rdi,7FA74769BEF8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-80]
       mov       [rbp-40],rax
       lea       rax,[M17_L02]
       add       rsp,8
       ret
; Total bytes of code 731
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7FA7461D4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7FA7461CEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7FA7461DF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M18_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M18_L00
       mov       rsi,rax
       call      qword ptr [7FA7461CEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M18_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp-3C],eax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       dword ptr [rbp-48],3E8
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FA7470BDD58]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       eax,[rax+10]
       mov       [rbp-3C],eax
       cmp       dword ptr [rbp-3C],0
       jne       short M19_L02
M19_L00:
       mov       eax,[rbp-48]
       dec       eax
       mov       [rbp-48],eax
       cmp       dword ptr [rbp-48],0
       jg        short M19_L01
       lea       rdi,[rbp-48]
       mov       esi,9
       call      CORINFO_HELP_PATCHPOINT
M19_L01:
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FA746625728]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rdi,rax
       call      qword ptr [7FA7470BDD70]; System.Threading.Interlocked.Increment(Int32 ByRef)
       mov       [rbp-3C],eax
       cmp       dword ptr [rbp-3C],0
       je        short M19_L03
       mov       rdi,7FA7474B6540
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       call      qword ptr [7FA7470BDD58]; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       ecx,[rbp-3C]
       mov       [rax+10],ecx
M19_L02:
       mov       rdi,7FA7474B6544
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-3C]
       lea       esi,[rax-1]
       mov       rdi,[rbp-38]
       call      qword ptr [7FA7470BDD88]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetAffinityIndex(UInt32)
       nop
       add       rsp,50
       pop       rbp
       ret
M19_L03:
       mov       rdi,7FA7474B6548
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M19_L00
; Total bytes of code 206
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+18]
       mov       rdi,[rbp-10]
       call      qword ptr [7FA7470BDDE8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M20_L00
       mov       rax,[rbp-20]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M20_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M20_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rax]
       mov       rdi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M20_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       xor       ecx,ecx
       mov       [rax],rcx
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+20]
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7FA7470BDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       rax,[rbp-20]
       cmp       qword ptr [rax],0
       setne     al
       movzx     eax,al
       add       rsp,30
       pop       rbp
       ret
M20_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 221
```
```assembly
; PoolContextProbe+Policy.Create()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_PoolContextProbe+Item
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7FA7470BDE78]; PoolContextProbe+Item..ctor()
       mov       rax,[rbp-10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 59
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       lea       rcx,[rbp-28]
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+20]
       mov       rdi,[rbp-10]
       call      qword ptr [7FA7470BDDE8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       test      eax,eax
       jne       short M22_L00
       xor       eax,eax
       add       rsp,30
       pop       rbp
       ret
M22_L00:
       mov       rax,[rbp-18]
       mov       rax,[rax+8]
       mov       ecx,[rbp-28]
       cmp       ecx,[rax+8]
       jae       short M22_L01
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rsi,[rbp-20]
       mov       rdi,rax
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       cmp       [rax],al
       mov       rax,[rbp-18]
       lea       rsi,[rax+18]
       mov       rax,[rbp-18]
       mov       rdx,[rax+8]
       mov       rdi,[rbp-10]
       mov       ecx,[rbp-28]
       call      qword ptr [7FA7470BDE00]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       mov       eax,1
       add       rsp,30
       pop       rbp
       ret
M22_L01:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 171
```
```assembly
; Reservoir.TrackedInstanceThreadLocalFrontTier`1[[System.__Canon, System.Private.CoreLib]].Clear[[PoolContextProbe+Policy, Probe]](Reservoir.ObjectPool`2<System.__Canon,Policy>)
       push      rbp
       sub       rsp,110
       lea       rbp,[rsp+110]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0F0],ymm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       xor       eax,eax
       mov       [rbp-50],rax
       mov       [rbp-30],rsi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       dword ptr [rbp-0C8],3E8
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       jne       short M23_L00
       mov       rdi,7FA74769D7E0
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,110
       pop       rbp
       ret
M23_L00:
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+10]
       mov       [rbp-0F8],rax
       cmp       qword ptr [rbp-0F8],0
       je        short M23_L01
       mov       rax,[rbp-0F8]
       mov       [rbp-80],rax
       jmp       short M23_L02
M23_L01:
       mov       rdi,[rbp-40]
       mov       rsi,7FA7476A4040
       call      qword ptr [7FA74662F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-80],rax
M23_L02:
       mov       rdi,[rbp-50]
       cmp       [rdi],edi
       call      qword ptr [7FA74766C360]
       mov       [rbp-0A8],rax
       mov       rdi,[rbp-0A8]
       mov       rsi,7FA74769D7E8
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0A8]
       mov       [rbp-0D0],rax
       mov       rdi,[rbp-0D0]
       mov       r11,[rbp-80]
       mov       rax,[rbp-80]
       call      qword ptr [rax]
       mov       [rbp-60],rax
       jmp       near ptr M23_L09
M23_L03:
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-100],rax
       cmp       qword ptr [rbp-100],0
       je        short M23_L04
       mov       rax,[rbp-100]
       mov       [rbp-88],rax
       jmp       short M23_L05
M23_L04:
       mov       rdi,[rbp-40]
       mov       rsi,7FA7476A4078
       call      qword ptr [7FA74662F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-88],rax
M23_L05:
       mov       rax,[rbp-60]
       mov       [rbp-0B0],rax
       mov       rdi,[rbp-0B0]
       mov       rsi,7FA74769D8F0
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0B0]
       mov       [rbp-0E0],rax
       mov       rdi,[rbp-0E0]
       mov       r11,[rbp-88]
       mov       rax,[rbp-88]
       call      qword ptr [rax]
       mov       [rbp-0D8],rax
       mov       rax,[rbp-0D8]
       cmp       [rax],al
       mov       rax,[rbp-0D8]
       add       rax,8
       mov       [rbp-90],rax
       xor       eax,eax
       mov       [rbp-70],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-108],rax
       cmp       qword ptr [rbp-108],0
       je        short M23_L06
       mov       rax,[rbp-108]
       mov       [rbp-98],rax
       jmp       short M23_L07
M23_L06:
       mov       rdi,[rbp-40]
       mov       rsi,7FA7476A40C8
       call      qword ptr [7FA74662F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-98],rax
M23_L07:
       mov       rdi,[rbp-98]
       mov       rsi,[rbp-90]
       mov       rdx,[rbp-70]
       call      qword ptr [7FA7470BDF08]
       mov       [rbp-68],rax
       cmp       qword ptr [rbp-68],0
       je        short M23_L08
       mov       rdi,7FA74769D9F8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-48]
       mov       rsi,[rbp-68]
       cmp       [rdi],edi
       call      qword ptr [7FA74766C378]
       jmp       short M23_L09
M23_L08:
       mov       rdi,7FA74769D9FC
       call      CORINFO_HELP_COUNTPROFILE32
M23_L09:
       mov       eax,[rbp-0C8]
       dec       eax
       mov       [rbp-0C8],eax
       cmp       dword ptr [rbp-0C8],0
       jg        short M23_L10
       lea       rdi,[rbp-0C8]
       mov       esi,57
       call      CORINFO_HELP_PATCHPOINT
M23_L10:
       mov       rax,[rbp-60]
       mov       [rbp-0B8],rax
       mov       rdi,[rbp-0B8]
       mov       rsi,7FA74769DA08
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0B8]
       mov       [rbp-0E8],rax
       mov       rdi,[rbp-0E8]
       mov       r11,7FA7456405E8
       call      qword ptr [r11]
       test      eax,eax
       jne       near ptr M23_L03
       call      M23_L13
       nop
       cmp       qword ptr [rbp-58],0
       je        short M23_L11
       mov       rdi,7FA74769DC24
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-58]
       call      qword ptr [7FA74766C258]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7FA74766C270]
M23_L11:
       mov       rdi,7FA74769DC28
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,110
       pop       rbp
       ret
       push      rax
       mov       [rbp-0A0],rdi
       mov       rax,[rbp-0A0]
       mov       [rbp-78],rax
       cmp       qword ptr [rbp-58],0
       jne       short M23_L12
       mov       rdi,7FA74769DA00
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-78]
       mov       [rbp-58],rax
M23_L12:
       mov       rdi,7FA74769DA04
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rax,[M23_L09]
       add       rsp,8
       ret
M23_L13:
       push      rax
       cmp       qword ptr [rbp-60],0
       je        short M23_L14
       mov       rdi,7FA74769DB10
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-60]
       mov       [rbp-0C0],rax
       mov       rdi,[rbp-0C0]
       mov       rsi,7FA74769DB18
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0C0]
       mov       [rbp-0F0],rax
       mov       rdi,[rbp-0F0]
       mov       r11,7FA7456405F0
       call      qword ptr [r11]
M23_L14:
       mov       rdi,7FA74769DC20
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,8
       ret
; Total bytes of code 999
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeRetained(System.__Canon, System.Exception ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       cmp       qword ptr [rbp-10],0
       jne       short M24_L00
       add       rsp,30
       pop       rbp
       ret
M24_L00:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7FA7470BDBF0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[PoolContextProbe+Policy, Probe]].DisposeItem(System.__Canon)
       nop
M24_L01:
       add       rsp,30
       pop       rbp
       ret
       push      rax
       mov       [rbp-28],rdi
       mov       rax,[rbp-28]
       mov       [rbp-20],rax
       mov       rax,[rbp-18]
       cmp       qword ptr [rax],0
       jne       short M24_L02
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
M24_L02:
       lea       rax,[M24_L01]
       add       rsp,8
       ret
; Total bytes of code 114
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCThreadStaticBase(System.Runtime.CompilerServices.MethodTable*)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rax,[rdi+20]
       mov       ebx,[rax-28]
       cmp       ebx,0FFFFFFFF
       jne       short M25_L00
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
M25_L00:
       call      qword ptr [7FA7461E6AF0]; Precode of System.Threading.Thread.GetThreadStaticsBase()
       mov       edi,ebx
       and       edi,0FFFFFF
       mov       ecx,edi
       mov       edx,ebx
       sar       edx,18
       jne       short M25_L02
       cmp       [rax],edi
       jle       short M25_L04
       mov       rax,[rax+8]
       cmp       [rax],al
       add       ecx,0FFFFFFFE
       movsxd    rdi,ecx
       mov       rax,[rax+rdi*8+10]
       test      rax,rax
       je        short M25_L04
M25_L01:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M25_L02:
       mov       edi,ebx
       sar       edi,18
       cmp       edi,2
       jne       short M25_L03
       movsxd    rcx,ecx
       add       rax,rcx
       jmp       short M25_L01
M25_L03:
       cmp       [rax+4],ecx
       jle       short M25_L04
       mov       rdi,[rax+10]
       movsxd    rax,ecx
       mov       rdi,[rdi+rax*8]
       test      rdi,rdi
       je        short M25_L04
       mov       rax,[rdi]
       test      rax,rax
       je        short M25_L04
       jmp       short M25_L01
M25_L04:
       mov       edi,ebx
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
; Total bytes of code 159
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetNonGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-10]
       mov       rcx,rax
       test      cl,1
       jne       short M26_L00
       ret
M26_L00:
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       jmp       qword ptr [rax]
; Total bytes of code 27
```
```assembly
; System.Threading.Interlocked.Increment(Int32 ByRef)
       mov       eax,1
       lock xadd [rdi],eax
       inc       eax
       ret
; Total bytes of code 12
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetAffinityIndex(UInt32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-18],eax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-14],esi
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+18],0
       jl        short M28_L00
       mov       rax,[rbp-10]
       mov       eax,[rax+18]
       and       eax,[rbp-14]
       add       rsp,20
       pop       rbp
       ret
M28_L00:
       mov       rax,[rbp-10]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       mov       [rbp-18],eax
       call      qword ptr [7FA7470BDDB8]
       cmp       eax,8
       jne       short M28_L01
       mov       rax,[rbp-10]
       mov       rcx,[rax+10]
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       mov       esi,[rbp-14]
       mov       edx,[rbp-18]
       call      qword ptr [7FA7470BDDD0]
       nop
       add       rsp,20
       pop       rbp
       ret
M28_L01:
       mov       eax,[rbp-14]
       xor       edx,edx
       div       dword ptr [rbp-18]
       mov       eax,edx
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 127
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryTakeNode(Int64 ByRef, Node<System.__Canon>[], Int32 ByRef)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-50],rcx
       mov       dword ptr [rbp-70],3E8
M29_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M29_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M29_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7FA7470BDE18]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-50]
       mov       [rcx],eax
       mov       rax,[rbp-50]
       cmp       dword ptr [rax],0FFFFFFFF
       jne       short M29_L02
       mov       rdi,7FA7474B66B0
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,70
       pop       rbp
       ret
M29_L02:
       mov       rax,[rbp-50]
       mov       eax,[rax]
       mov       rcx,[rbp-48]
       cmp       eax,[rcx+8]
       jae       short M29_L04
       mov       edx,eax
       imul      rdx,10
       lea       rcx,[rcx+rdx+10]
       mov       eax,[rcx+8]
       mov       [rbp-5C],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-5C]
       call      qword ptr [7FA7470BDE30]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-68],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-68]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M29_L03
       mov       rdi,7FA7474B66B4
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,70
       pop       rbp
       ret
M29_L03:
       mov       rdi,7FA7474B66B8
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M29_L00
M29_L04:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 269
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PublishNode(Int64 ByRef, Node<System.__Canon>[], Int32)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   xmmword ptr [rbp-68],xmm8
       xor       eax,eax
       mov       [rbp-58],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       [rbp-48],rdx
       mov       [rbp-4C],ecx
       mov       dword ptr [rbp-70],3E8
M30_L00:
       mov       eax,[rbp-70]
       dec       eax
       mov       [rbp-70],eax
       cmp       dword ptr [rbp-70],0
       jg        short M30_L01
       lea       rdi,[rbp-70]
       xor       esi,esi
       call      CORINFO_HELP_PATCHPOINT
M30_L01:
       mov       rax,[rbp-40]
       mov       rax,[rax]
       mov       [rbp-58],rax
       mov       rax,[rbp-48]
       mov       ecx,[rbp-4C]
       cmp       ecx,[rax+8]
       jae       near ptr M30_L03
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       add       rax,8
       mov       [rbp-68],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       call      qword ptr [7FA7470BDE18]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       mov       rcx,[rbp-68]
       mov       [rcx],eax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-58]
       mov       edx,[rbp-4C]
       call      qword ptr [7FA7470BDE30]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       mov       [rbp-60],rax
       mov       rcx,[rbp-40]
       mov       rdx,[rbp-60]
       mov       rax,[rbp-58]
       lock cmpxchg [rcx],rdx
       cmp       rax,[rbp-58]
       jne       short M30_L02
       mov       rdi,7FA7474B6BA8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,70
       pop       rbp
       ret
M30_L02:
       mov       rdi,7FA7474B6BAC
       call      CORINFO_HELP_COUNTPROFILE32
       jmp       near ptr M30_L00
M30_L03:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 235
```
```assembly
; PoolContextProbe+Item..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       dword ptr [rax+8],2A
       mov       rdi,[rbp-8]
       call      qword ptr [7FA74662C240]; System.Object..ctor()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7FA7461CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7FA7461CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetIndex(Int64)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       eax,[rbp-10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 27
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].NextHead(Int64, Int32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-1C],edx
       mov       rax,[rbp-18]
       sar       rax,20
       lea       esi,[rax+1]
       mov       rdi,[rbp-10]
       mov       edx,[rbp-1C]
       call      qword ptr [7FA746A1E100]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 56
```
```assembly
; System.Object..ctor()
       ret
; Total bytes of code 1
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].PackHead(Int32, Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-10],edx
       movsxd    rax,dword ptr [rbp-0C]
       shl       rax,20
       mov       ecx,[rbp-10]
       or        rax,rcx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 40
```

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: dry-1.4.0(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.4.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.4.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=1, LaunchCount=1, RunStrategy=ColdStart, UnrollFactor=1, WarmupCount=1))

```assembly
; PoolContextProbe.SingleContext()
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_PoolContextProbe
       call      qword ptr [7F7F0AA25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F7725800400
       mov       rax,[rax]
       mov       [rbp-20],rax
       mov       rdi,offset MT_PoolContextProbe+<>c
       call      qword ptr [7F7F0AA25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F7725800AB0
       mov       rax,[rax]
       mov       [rbp-18],rax
       mov       rax,[rbp-20]
       mov       [rbp-28],rax
       mov       rax,[rbp-18]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-18],0
       jne       short M00_L00
       mov       rdi,offset MT_System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-48],rax
       mov       rdi,offset MT_PoolContextProbe+<>c
       call      qword ptr [7F7F0AA25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F7725800AA8
       mov       rax,[rax]
       mov       [rbp-50],rax
       mov       rsi,[rbp-50]
       mov       rdi,[rbp-48]
       mov       rdx,offset PoolContextProbe+<>c.<SingleContext>b__5_0(Kevlar.KevlarContext)
       call      qword ptr [7F7F0AA26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,offset MT_PoolContextProbe+<>c
       call      qword ptr [7F7F0AA25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rbp-48]
       mov       rdi,7F7725800AB0
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-48]
       mov       [rbp-30],rax
M00_L00:
       xor       eax,eax
       mov       [rbp-10],rax
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-30]
       mov       rdx,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B4BE028]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       mov       [rbp-40],rax
       mov       [rbp-38],rdx
       mov       rax,[rbp-40]
       mov       rdx,[rbp-38]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 291
```
```assembly
; BenchmarkDotNet.Helpers.AwaitHelper.GetResult[[System.Int32, System.Private.CoreLib]](System.Threading.Tasks.ValueTask`1<Int32>)
       push      rbp
       sub       rsp,60
       lea       rbp,[rsp+60]
       xor       eax,eax
       mov       [rbp-58],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-10],rdi
       mov       [rbp-8],rsi
       lea       rdi,[rbp-10]
       xor       esi,esi
       call      qword ptr [7F7F0B9C6E80]; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]].ConfigureAwait(Boolean)
       mov       [rbp-40],rax
       mov       [rbp-38],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-40]
       vmovdqu   xmmword ptr [rbp-30],xmm0
       lea       rdi,[rbp-30]
       call      qword ptr [7F7F0B9C6E98]; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1[[System.Int32, System.Private.CoreLib]].GetAwaiter()
       mov       [rbp-50],rax
       mov       [rbp-48],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-50]
       vmovdqu   xmmword ptr [rbp-20],xmm0
       lea       rdi,[rbp-20]
       call      qword ptr [7F7F0B9C6EB0]; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[[System.Int32, System.Private.CoreLib]].get_IsCompleted()
       test      eax,eax
       jne       short M01_L00
       call      qword ptr [7F7F0B9CD8C0]
       mov       [rbp-58],rax
       mov       rdi,[rbp-58]
       mov       rsi,[rbp-20]
       mov       rdx,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9CD890]
M01_L00:
       lea       rdi,[rbp-20]
       call      qword ptr [7F7F0B9C6EC8]; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[[System.Int32, System.Private.CoreLib]].GetResult()
       nop
       add       rsp,60
       pop       rbp
       ret
; Total bytes of code 158
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-18]
       mov       rcx,rax
       test      cl,1
       jne       short M02_L00
       ret
M02_L00:
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       jmp       qword ptr [rax]
; Total bytes of code 27
```
```assembly
; PoolContextProbe+<>c.<SingleContext>b__5_0(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-20],xmm0
       lea       rdi,[rbp-20]
       mov       esi,2A
       call      qword ptr [7F7F0B4BE9E8]; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]]..ctor(Int32)
       mov       rax,[rbp-20]
       mov       rdx,[rbp-18]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 62
```
```assembly
; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       push      r15
       push      rbx
       push      rax
       mov       rbx,rdi
       mov       r15,rdx
       test      rsi,rsi
       je        short M04_L00
       lea       rdi,[rbx+8]
       call      qword ptr [7F7F0A5CEEB8]; CORINFO_HELP_ASSIGN_REF
       mov       [rbx+18],r15
       add       rsp,8
       pop       rbx
       pop       r15
       ret
M04_L00:
       call      qword ptr [7F7F0A5E0120]
       int       3
; Total bytes of code 44
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqa   xmmword ptr [rbp-30],xmm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       rdi,[rbp-10]
       mov       rsi,7F7F08608560
       call      qword ptr [7F7F0B4BE478]; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F7F0AA25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F7725800AF0
       mov       rax,[rax]
       mov       [rbp-20],rax
       mov       rax,[rbp-8]
       mov       [rbp-28],rax
       mov       rax,[rbp-10]
       mov       [rbp-30],rax
       mov       rax,[rbp-20]
       mov       [rbp-38],rax
       cmp       qword ptr [rbp-20],0
       jne       near ptr M05_L00
       mov       rdi,offset MT_System.Action<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarProperties>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-80],rax
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F7F0AA25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F7725800AE8
       mov       rax,[rax]
       mov       [rbp-88],rax
       mov       rsi,[rbp-88]
       mov       rdi,[rbp-80]
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       call      qword ptr [7F7F0AA26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F7F0AA25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rbp-80]
       mov       rdi,7F7725800AF0
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-80]
       mov       [rbp-38],rax
M05_L00:
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F7F0AA25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F7725800AF8
       mov       rax,[rax]
       mov       [rbp-40],rax
       mov       rax,[rbp-28]
       mov       [rbp-48],rax
       mov       rax,[rbp-30]
       mov       [rbp-50],rax
       mov       rax,[rbp-38]
       mov       [rbp-58],rax
       mov       rax,[rbp-40]
       mov       [rbp-60],rax
       cmp       qword ptr [rbp-40],0
       jne       near ptr M05_L01
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-78],rax
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F7F0AA25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F7725800AE8
       mov       rax,[rax]
       mov       [rbp-90],rax
       mov       rsi,[rbp-90]
       mov       rdi,[rbp-78]
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F7F0AA26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F7F0AA25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rbp-78]
       mov       rdi,7F7725800AF8
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-78]
       mov       [rbp-60],rax
M05_L01:
       mov       rdi,[rbp-48]
       mov       r9,[rbp-18]
       mov       rdx,[rbp-50]
       mov       rcx,[rbp-58]
       mov       r8,[rbp-60]
       mov       rsi,7F7F0B8BB1D0
       call      qword ptr [7F7F0B4BE3A0]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       mov       [rbp-70],rax
       mov       [rbp-68],rdx
       mov       rax,[rbp-70]
       mov       rdx,[rbp-68]
       add       rsp,90
       pop       rbp
       ret
; Total bytes of code 537
```
```assembly
; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]].ConfigureAwait(Boolean)
       mov       rax,[rdi]
       mov       edx,[rdi+8]
       movsx     rcx,word ptr [rdi+0C]
       movzx     edi,sil
       movzx     ecx,cx
       shl       rcx,20
       or        rdx,rcx
       mov       ecx,edi
       shl       rcx,30
       or        rdx,rcx
       ret
; Total bytes of code 35
```
```assembly
; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1[[System.Int32, System.Private.CoreLib]].GetAwaiter()
       sub       rsp,18
       xor       eax,eax
       mov       [rsp+8],rax
       movups    xmm0,[rdi]
       movups    [rsp+8],xmm0
       mov       rax,[rsp+8]
       mov       rdx,[rsp+10]
       add       rsp,18
       ret
; Total bytes of code 34
```
```assembly
; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[[System.Int32, System.Private.CoreLib]].get_IsCompleted()
       push      rbp
       push      r15
       push      rbx
       lea       rbp,[rsp+10]
       mov       rbx,rdi
       mov       r15,[rbx]
       test      r15,r15
       je        short M08_L04
       mov       rdi,r15
       call      qword ptr [7F7F0A5DCE98]
       test      rax,rax
       jne       short M08_L03
       movsx     rsi,word ptr [rbx+0C]
       mov       rdi,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       cmp       rdi,[r15]
       je        short M08_L02
       mov       rdi,r15
       lea       r11,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       call      qword ptr [r11]
M08_L00:
       test      eax,eax
       setne     al
       movzx     eax,al
M08_L01:
       pop       rbx
       pop       r15
       pop       rbp
       ret
M08_L02:
       lea       rdi,[r15+40]
       call      qword ptr [7F7F0A5EF4C0]
       jmp       short M08_L00
M08_L03:
       test      dword ptr [rax+34],1600000
       setne     al
       movzx     eax,al
       jmp       short M08_L01
M08_L04:
       mov       eax,1
       jmp       short M08_L01
; Total bytes of code 111
```
```assembly
; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[[System.Int32, System.Private.CoreLib]].GetResult()
       push      rbp
       push      r15
       push      r14
       push      rbx
       push      rax
       lea       rbp,[rsp+20]
       mov       rbx,rdi
       mov       r15,[rbx]
       test      r15,r15
       je        short M09_L03
       mov       rdi,r15
       call      qword ptr [7F7F0A5DCE98]
       mov       r14,rax
       test      r14,r14
       jne       short M09_L01
       movsx     rsi,word ptr [rbx+0C]
       mov       rdi,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       cmp       rdi,[r15]
       je        short M09_L00
       mov       rdi,r15
       lea       r11,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M09_L00:
       mov       rdi,r15
       call      qword ptr [7F7F0A5DF2E8]
       jmp       short M09_L04
M09_L01:
       mov       edi,[r14+34]
       and       edi,11000000
       cmp       edi,1000000
       jne       short M09_L05
M09_L02:
       mov       eax,[r14+38]
       jmp       short M09_L04
M09_L03:
       mov       eax,[rbx+8]
M09_L04:
       add       rsp,8
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M09_L05:
       mov       rdi,r14
       xor       esi,esi
       call      qword ptr [7F7F0A5E99B0]
       jmp       short M09_L02
; Total bytes of code 142
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7F7F0A5D4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7F7F0A5CEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7F7F0A5DF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M10_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M10_L00
       mov       rsi,rax
       call      qword ptr [7F7F0A5CEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M10_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]]..ctor(Int32)
       mov       [rdi+8],esi
       xor       eax,eax
       mov       [rdi],rax
       mov       byte ptr [rdi+0E],1
       mov       word ptr [rdi+0C],0
       ret
; Total bytes of code 19
```
```assembly
; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       cmp       qword ptr [rbp-8],0
       jne       short M12_L00
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-18],rax
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-10]
       call      qword ptr [7F7F0B10E2E0]
       mov       rdi,[rbp-18]
       call      CORINFO_HELP_THROW
       int       3
M12_L00:
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 80
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 28
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       rax,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdi,[rax+8]
       mov       rax,[rbp-10]
       call      qword ptr [rax+18]
       mov       [rbp-28],rax
       mov       [rbp-20],rdx
       mov       rax,[rbp-28]
       mov       rdx,[rbp-20]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 69
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
M15_L00:
       push      rbp
       sub       rsp,0A0
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-88],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-40],rax
       mov       [rbp-8],rsi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       mov       rdi,[rbp-28]
       mov       rsi,7F7F08608588
       call      qword ptr [7F7F0B4BE478]; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       mov       rdi,[rbp-30]
       mov       rsi,7F7F08608560
       call      qword ptr [7F7F0B4BE478]; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       mov       rax,[rbp-10]
       mov       rax,[rax+38]
       mov       [rbp-40],rax
       cmp       qword ptr [rbp-40],0
       je        short M15_L01
       mov       rax,[rbp-40]
       mov       rdi,[rax+8]
       mov       rax,[rbp-40]
       call      qword ptr [rax+18]
       mov       [rbp-80],rax
       mov       rdi,[rbp-80]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-20]
       mov       rcx,[rbp-28]
       mov       r8,[rbp-30]
       mov       r9,[rbp-38]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B4BE3A0]
       mov       [rbp-78],rax
       mov       [rbp-70],rdx
       mov       rax,[rbp-78]
       mov       rdx,[rbp-70]
       add       rsp,0A0
       pop       rbp
       ret
M15_L01:
       mov       rdi,[rbp-10]
       call      qword ptr [7F7F0B4BE520]; Kevlar.Shield.ThrowIfVoidFallbackResultExecution()
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-48],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F7F0B4BE538]; Kevlar.Shield.get_TimeOrSystem()
       mov       [rbp-50],rax
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-90],rax
       cmp       qword ptr [rbp-90],0
       je        short M15_L02
       mov       rax,[rbp-90]
       mov       [rbp-58],rax
       jmp       short M15_L03
M15_L02:
       mov       rdi,[rbp-18]
       mov       rsi,7F7F0B8C2DB0
       call      qword ptr [7F7F0AA2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-58],rax
M15_L03:
       mov       rdi,[rbp-10]
       call      qword ptr [7F7F0B4BE550]; Kevlar.Shield.get_Name()
       mov       [rbp-88],rax
       mov       rax,[rbp-30]
       mov       [rsp],rax
       mov       rax,[rbp-38]
       mov       [rsp+8],rax
       mov       rcx,[rbp-88]
       mov       rsi,[rbp-48]
       mov       rdx,[rbp-50]
       mov       rdi,[rbp-58]
       mov       r8,[rbp-20]
       mov       r9,[rbp-28]
       call      qword ptr [7F7F0B4BE4C0]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       mov       [rbp-68],rax
       mov       [rbp-60],rdx
       mov       rax,[rbp-68]
       mov       rdx,[rbp-60]
       add       rsp,0A0
       pop       rbp
       ret
; Total bytes of code 401
```
```assembly
; Kevlar.Shield.ThrowIfVoidFallbackResultExecution()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       movzx     eax,byte ptr [rax+48]
       test      eax,eax
       je        short M16_L00
       call      qword ptr [7F7F0B4BE568]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M16_L00:
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 47
```
```assembly
; Kevlar.Shield.get_TimeOrSystem()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       rdi,[rbp-8]
       call      qword ptr [7F7F0B4BE580]; Kevlar.Shield.get_CurrentSnapshot()
       mov       rax,[rax+20]
       mov       [rbp-10],rax
       mov       rax,[rbp-10]
       mov       [rbp-18],rax
       cmp       qword ptr [rbp-10],0
       jne       short M17_L00
       call      qword ptr [7F7F0B4BE598]; System.TimeProvider.get_System()
       mov       [rbp-18],rax
M17_L00:
       mov       rax,[rbp-18]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 77
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F7F0A5CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F7F0A5CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; Kevlar.Shield.get_Name()
M19_L00:
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+38]
       mov       [rbp-10],rax
       cmp       qword ptr [rbp-10],0
       jne       short M19_L01
       mov       rax,[rbp-8]
       mov       rax,[rax+40]
       add       rsp,10
       pop       rbp
       ret
M19_L01:
       mov       rax,[rbp-10]
       mov       rdi,[rax+8]
       mov       rax,[rbp-10]
       call      qword ptr [rax+18]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F7F0B4BE550]
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 86
```
```assembly
; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-50],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-58],rax
       cmp       qword ptr [rbp-58],0
       je        short M20_L00
       mov       rax,[rbp-58]
       mov       [rbp-40],rax
       jmp       short M20_L01
M20_L00:
       mov       rdi,[rbp-10]
       mov       rsi,7F7F0B8C3168
       call      qword ptr [7F7F0AA2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-40],rax
M20_L01:
       mov       rax,[rbp+10]
       mov       [rsp],rax
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rax,[rbp+18]
       mov       [rsp+10],rax
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-20]
       mov       rcx,[rbp-28]
       mov       r8,[rbp-30]
       mov       r9,[rbp-38]
       call      qword ptr [7F7F0B4BE5F8]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       mov       [rbp-50],rax
       mov       [rbp-48],rdx
       mov       rax,[rbp-50]
       mov       rdx,[rbp-48]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 177
```
```assembly
; Kevlar.Shield.get_CurrentSnapshot()
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+38]
       mov       [rbp-10],rax
       mov       rax,[rbp-10]
       mov       [rbp-18],rax
       cmp       qword ptr [rbp-10],0
       jne       short M21_L00
       xor       eax,eax
       mov       [rbp-20],rax
       jmp       short M21_L01
M21_L00:
       mov       rax,[rbp-18]
       mov       rdi,[rax+8]
       mov       rax,[rbp-18]
       call      qword ptr [rax+18]
       mov       [rbp-20],rax
M21_L01:
       mov       rax,[rbp-20]
       mov       [rbp-28],rax
       cmp       qword ptr [rbp-20],0
       jne       short M21_L02
       mov       rax,[rbp-8]
       mov       [rbp-28],rax
M21_L02:
       mov       rax,[rbp-28]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 121
```
```assembly
; System.TimeProvider.get_System()
       push      rax
       call      qword ptr [7F7F0A5CF5B8]
       mov       rax,[rax]
       add       rsp,8
       ret
; Total bytes of code 15
```
```assembly
; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       push      rbp
       sub       rsp,1A0
       lea       rbp,[rsp+1A0]
       xor       eax,eax
       mov       [rbp-148],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-140],xmm8
       mov       rax,0FFFFFFFFFFFFFF10
M23_L00:
       vmovdqa   xmmword ptr [rbp+rax-40],xmm8
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       add       rax,30
       jne       short M23_L00
       mov       [rbp-40],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       call      qword ptr [7F7F0B4BE880]; Kevlar.Internal.KevlarMetrics.get_DurationEnabled()
       test      eax,eax
       jne       short M23_L01
       xor       eax,eax
       mov       [rbp-88],rax
       jmp       short M23_L02
M23_L01:
       call      qword ptr [7F7F0B4BE898]
       mov       [rbp-88],rax
M23_L02:
       mov       rax,[rbp-88]
       mov       [rbp-40],rax
       lea       rdi,[rbp+20]
       call      qword ptr [7F7F0B4BE8B0]; System.Threading.CancellationToken.get_IsCancellationRequested()
       test      eax,eax
       je        near ptr M23_L06
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-28]
       xor       edx,edx
       call      qword ptr [7F7F0B4BE8C8]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       cmp       qword ptr [rbp+18],0
       je        near ptr M23_L05
       mov       rdi,[rbp+20]
       mov       rcx,[rbp-28]
       mov       rdx,[rbp-20]
       xor       esi,esi
       call      qword ptr [7F7F0B4BE8E0]; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       mov       [rbp-70],rax
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-158],rax
       cmp       qword ptr [rbp-158],0
       je        short M23_L03
       mov       rax,[rbp-158]
       mov       [rbp-120],rax
       jmp       short M23_L04
M23_L03:
       mov       rdi,[rbp-10]
       mov       rsi,7F7F0B8C39D8
       call      qword ptr [7F7F0AA2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-120],rax
M23_L04:
       mov       rdi,[rbp-70]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B4BE8F8]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       [rbp-128],rax
       mov       rcx,[rbp-128]
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-30]
       mov       rdi,[rbp-120]
       call      qword ptr [7F7F0B4BE7C0]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-70]
       call      qword ptr [7F7F0B4BE910]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
M23_L05:
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-0F8],rax
       mov       rdi,[rbp-0F8]
       mov       rsi,[rbp+20]
       call      qword ptr [7F7F0B4BE928]
       mov       rdi,[rbp-0F8]
       call      qword ptr [7F7F0B4BE940]
       mov       [rbp-108],rax
       mov       [rbp-100],rdx
       mov       rdi,[rbp-108]
       mov       rsi,[rbp-100]
       call      qword ptr [7F7F0B4BE850]
       mov       [rbp-118],rax
       mov       [rbp-110],rdx
       mov       rax,[rbp-118]
       mov       rdx,[rbp-110]
       add       rsp,1A0
       pop       rbp
       ret
M23_L06:
       mov       rdi,[rbp+20]
       mov       rcx,[rbp-28]
       mov       rdx,[rbp-20]
       xor       esi,esi
       call      qword ptr [7F7F0B4BE8E0]; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       mov       [rbp-48],rax
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B4BE958]; Kevlar.KevlarContext.get_Properties()
       mov       [rbp-130],rax
       mov       rdx,[rbp-130]
       mov       rsi,[rbp-30]
       mov       rax,[rbp-38]
       mov       rdi,[rax+8]
       mov       rax,[rbp-38]
       call      qword ptr [rax+18]
       nop
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-160],rax
       cmp       qword ptr [rbp-160],0
       je        short M23_L07
       mov       rax,[rbp-160]
       mov       [rbp-90],rax
       jmp       short M23_L08
M23_L07:
       mov       rdi,[rbp-10]
       mov       rsi,7F7F0B8C3600
       call      qword ptr [7F7F0AA2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-90],rax
M23_L08:
       lea       rdi,[rbp-68]
       mov       rsi,[rbp-90]
       mov       rdx,[rbp-18]
       mov       rcx,[rbp-30]
       mov       r8,[rbp+10]
       mov       r9,[rbp-48]
       call      qword ptr [7F7F0B4BE6D0]; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       lea       rdi,[rbp-68]
       call      qword ptr [7F7F0B4BE970]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_IsCompletedSuccessfully()
       test      eax,eax
       je        near ptr M23_L12
       lea       rdi,[rbp-68]
       call      qword ptr [7F7F0B4BE988]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Result()
       mov       [rbp-0B8],rax
       mov       [rbp-0B0],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-0B8]
       vmovdqu   xmmword ptr [rbp-80],xmm0
       lea       rdi,[rbp-80]
       call      qword ptr [7F7F0B4BE9A0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_IsSuccess()
       mov       [rbp-13C],eax
       mov       edx,[rbp-13C]
       mov       rsi,[rbp-48]
       mov       rdi,[rbp-40]
       call      qword ptr [7F7F0B4BE9B8]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-168],rax
       cmp       qword ptr [rbp-168],0
       je        short M23_L09
       mov       rax,[rbp-168]
       mov       [rbp-0C0],rax
       jmp       short M23_L10
M23_L09:
       mov       rdi,[rbp-10]
       mov       rsi,7F7F0B8C39D8
       call      qword ptr [7F7F0AA2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0C0],rax
M23_L10:
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B4BE8F8]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       [rbp-148],rax
       mov       rcx,[rbp-148]
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-30]
       mov       rdi,[rbp-0C0]
       call      qword ptr [7F7F0B4BE7C0]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-48]
       call      qword ptr [7F7F0B4BE910]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       lea       rdi,[rbp-80]
       call      qword ptr [7F7F0B4BE9A0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_IsSuccess()
       test      eax,eax
       jne       short M23_L11
       mov       rdi,[rbp-80]
       mov       rsi,[rbp-78]
       call      qword ptr [7F7F0B4BE850]
       mov       [rbp-0E0],rax
       mov       [rbp-0D8],rdx
       mov       rax,[rbp-0E0]
       mov       rdx,[rbp-0D8]
       add       rsp,1A0
       pop       rbp
       ret
M23_L11:
       lea       rdi,[rbp-80]
       call      qword ptr [7F7F0B4BE9D0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_Result()
       mov       [rbp-14C],eax
       mov       esi,[rbp-14C]
       lea       rdi,[rbp-0D0]
       call      qword ptr [7F7F0B4BE9E8]; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]]..ctor(Int32)
       mov       rax,[rbp-0D0]
       mov       rdx,[rbp-0C8]
       add       rsp,1A0
       pop       rbp
       ret
M23_L12:
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-170],rax
       cmp       qword ptr [rbp-170],0
       je        short M23_L13
       mov       rax,[rbp-170]
       mov       [rbp-98],rax
       jmp       short M23_L14
M23_L13:
       mov       rdi,[rbp-10]
       mov       rsi,7F7F0B8C3798
       call      qword ptr [7F7F0AA2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-98],rax
M23_L14:
       lea       rdi,[rsp]
       lea       rsi,[rbp-68]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,[rbp-98]
       mov       rsi,[rbp-48]
       mov       rdx,[rbp-30]
       mov       rcx,[rbp+18]
       mov       r8,[rbp-40]
       call      qword ptr [7F7F0B4BE778]
       mov       [rbp-0A8],rax
       mov       [rbp-0A0],rdx
       mov       rax,[rbp-0A8]
       mov       rdx,[rbp-0A0]
       add       rsp,1A0
       pop       rbp
       ret
       sub       rsp,28
       mov       [rbp-0E8],rdi
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-48]
       xor       edx,edx
       call      qword ptr [7F7F0B4BE9B8]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-178],rax
       cmp       qword ptr [rbp-178],0
       je        short M23_L15
       mov       rax,[rbp-178]
       mov       [rbp-0F0],rax
       jmp       short M23_L16
M23_L15:
       mov       rdi,[rbp-10]
       mov       rsi,7F7F0B8C39D8
       call      qword ptr [7F7F0AA2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0F0],rax
M23_L16:
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B4BE8F8]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       [rbp-138],rax
       mov       rcx,[rbp-138]
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-30]
       mov       rdi,[rbp-0F0]
       call      qword ptr [7F7F0B4BE7C0]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-48]
       call      qword ptr [7F7F0B4BE910]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 1331
```
```assembly
; Kevlar.Internal.KevlarMetrics.get_DurationEnabled()
       push      rbp
       mov       rbp,rsp
       mov       rdi,offset MT_Kevlar.Internal.KevlarMetrics
       call      qword ptr [7F7F0AA25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F7725800BA0
       mov       rdi,[rax]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B4BEA18]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       nop
       pop       rbp
       ret
; Total bytes of code 44
```
```assembly
; System.Threading.CancellationToken.get_IsCancellationRequested()
       cmp       qword ptr [rdi],0
       jne       short M25_L00
       xor       eax,eax
       ret
M25_L00:
       mov       rax,[rdi]
       cmp       dword ptr [rax+20],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 23
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       movzx     edx,byte ptr [rbp-14]
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       xor       ecx,ecx
       call      qword ptr [7F7F0B9C7210]; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       movzx     esi,byte ptr [rbp-14]
       mov       rdi,[rbp-10]
       xor       edx,edx
       call      qword ptr [7F7F0B9C7228]; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 65
```
```assembly
; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-18],rdx
       mov       [rbp-20],rcx
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      qword ptr [7F7F0AA25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F77258013C0
       mov       rdi,[rax]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C6550]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Rent()
       mov       [rbp-28],rax
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C6568]; Kevlar.KevlarContext.set_CancellationToken(System.Threading.CancellationToken)
       mov       rdi,[rbp-28]
       mov       esi,[rbp-0C]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C6580]; Kevlar.KevlarContext.set_SynchronousExecutionKind(Kevlar.Internal.SynchronousExecutionKind)
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C6598]; Kevlar.KevlarContext.set_TimeProvider(System.TimeProvider)
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C65B0]; Kevlar.KevlarContext.set_ShieldName(System.String)
       mov       rdi,[rbp-28]
       mov       esi,0FFFFFFFF
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C65C8]; Kevlar.KevlarContext.set_StrategyIndex(Int32)
       mov       rdi,[rbp-28]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C65E0]; Kevlar.KevlarContext.set_AttemptNumber(Int32)
       mov       rdi,[rbp-28]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C65F8]; Kevlar.KevlarContext.set_TelemetryListener(Kevlar.IKevlarTelemetryListener)
       mov       rax,[rbp-28]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 190
```
```assembly
; Kevlar.KevlarContext.get_PropertiesForCompletion()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       movzx     eax,byte ptr [rax+64]
       test      eax,eax
       jne       short M28_L00
       mov       rax,[rbp-8]
       mov       rax,[rax+8]
       add       rsp,10
       pop       rbp
       ret
M28_L00:
       mov       rax,[rbp-8]
       mov       rax,[rax+10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 54
```
```assembly
; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       [rbp-20],rcx
       cmp       qword ptr [rbp-10],0
       je        short M29_L00
       mov       rax,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-20]
       mov       rdi,[rax+8]
       mov       rax,[rbp-10]
       call      qword ptr [rax+18]
M29_L00:
       nop
M29_L01:
       add       rsp,30
       pop       rbp
       ret
       push      rax
       mov       [rbp-28],rdi
       lea       rax,[M29_L01]
       add       rsp,8
       ret
; Total bytes of code 86
```
```assembly
; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,7F77258013C0
       mov       rdi,[rax]
       mov       rsi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C7300]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Return(System.__Canon)
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 46
```
```assembly
; Kevlar.KevlarContext.get_Properties()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+8]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 28
```
```assembly
; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,110
       lea       rbp,[rsp+110]
       xor       eax,eax
       mov       [rbp-0D8],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       mov       [rbp-40],rax
       mov       [rbp-8],rsi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-0E0],rax
       cmp       qword ptr [rbp-0E0],0
       je        short M32_L00
       mov       rax,[rbp-0E0]
       mov       [rbp-68],rax
       jmp       short M32_L01
M32_L00:
       mov       rdi,[rbp-18]
       mov       rsi,7F7F0B9B6718
       call      qword ptr [7F7F0AA2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-68],rax
M32_L01:
       mov       rdi,[rbp-68]
       call      qword ptr [7F7F0AA25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rax+8]
       mov       [rbp-70],rax
       lea       rax,[rbp-58]
       mov       [rbp-78],rax
       mov       rax,[rbp-20]
       mov       [rbp-80],rax
       mov       rax,[rbp-70]
       mov       [rbp-88],rax
       cmp       qword ptr [rbp-70],0
       jne       near ptr M32_L08
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-0E8],rax
       cmp       qword ptr [rbp-0E8],0
       je        short M32_L02
       mov       rax,[rbp-0E8]
       mov       [rbp-0B8],rax
       jmp       short M32_L03
M32_L02:
       mov       rdi,[rbp-18]
       mov       rsi,7F7F0B9B6718
       call      qword ptr [7F7F0AA2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0B8],rax
M32_L03:
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+30]
       mov       [rbp-0F0],rax
       cmp       qword ptr [rbp-0F0],0
       je        short M32_L04
       mov       rax,[rbp-0F0]
       mov       [rbp-0C8],rax
       jmp       short M32_L05
M32_L04:
       mov       rdi,[rbp-18]
       mov       rsi,7F7F0B9B6A10
       call      qword ptr [7F7F0AA2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0C8],rax
M32_L05:
       mov       rdi,[rbp-0C8]
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-0C0],rax
       mov       rdi,[rbp-0B8]
       call      qword ptr [7F7F0AA25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rax]
       mov       [rbp-0D8],rax
       mov       rsi,[rbp-0D8]
       mov       rdi,[rbp-0C0]
       mov       rdx,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       call      qword ptr [7F7F0AA26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-0F8],rax
       cmp       qword ptr [rbp-0F8],0
       je        short M32_L06
       mov       rax,[rbp-0F8]
       mov       [rbp-0D0],rax
       jmp       short M32_L07
M32_L06:
       mov       rdi,[rbp-18]
       mov       rsi,7F7F0B9B6718
       call      qword ptr [7F7F0AA2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0D0],rax
M32_L07:
       mov       rdi,[rbp-0D0]
       call      qword ptr [7F7F0AA25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       lea       rdi,[rax+8]
       mov       rsi,[rbp-0C0]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-0C0]
       mov       [rbp-60],rax
       mov       rax,[rbp-60]
       mov       [rbp-88],rax
M32_L08:
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-100],rax
       cmp       qword ptr [rbp-100],0
       je        short M32_L09
       mov       rax,[rbp-100]
       mov       [rbp-0A0],rax
       jmp       short M32_L10
M32_L09:
       mov       rdi,[rbp-18]
       mov       rsi,7F7F0B9B67B8
       call      qword ptr [7F7F0AA2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0A0],rax
M32_L10:
       lea       rdi,[rbp-98]
       mov       rsi,[rbp-0A0]
       mov       rdx,[rbp-28]
       mov       rcx,[rbp-30]
       call      qword ptr [7F7F0B9C69A0]; Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]]..ctor(System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-108],rax
       cmp       qword ptr [rbp-108],0
       je        short M32_L11
       mov       rax,[rbp-108]
       mov       [rbp-0A8],rax
       jmp       short M32_L12
M32_L11:
       mov       rdi,[rbp-18]
       mov       rsi,7F7F0B9B6830
       call      qword ptr [7F7F0AA2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0A8],rax
M32_L12:
       mov       r8,[rbp-98]
       mov       r9,[rbp-90]
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-0A8]
       mov       rdx,[rbp-80]
       mov       rcx,[rbp-88]
       call      qword ptr [7F7F0B9C69B8]; Kevlar.Continuation`2[[System.Int32, System.Private.CoreLib],[Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.StrategyNode, System.Func`3<ContextAsyncCallback`2<System.__Canon,Int32>,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Kevlar.Outcome`1<Int32>>>, ContextAsyncCallback`2<System.__Canon,Int32>)
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-110],rax
       cmp       qword ptr [rbp-110],0
       je        short M32_L13
       mov       rax,[rbp-110]
       mov       [rbp-0B0],rax
       jmp       short M32_L14
M32_L13:
       mov       rdi,[rbp-18]
       mov       rsi,7F7F0B9B6830
       call      qword ptr [7F7F0AA2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0B0],rax
M32_L14:
       lea       rdi,[rbp-58]
       mov       rsi,[rbp-10]
       mov       rdx,[rbp-0B0]
       mov       rcx,[rbp-38]
       call      qword ptr [7F7F0B9C69D0]; Kevlar.Continuation`2[[System.Int32, System.Private.CoreLib],[Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]].InvokeAsync(Kevlar.KevlarContext)
       mov       rax,[rbp-10]
       add       rsp,110
       pop       rbp
       ret
; Total bytes of code 881
```
```assembly
; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_IsCompletedSuccessfully()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       [rbp-10],rax
       cmp       qword ptr [rbp-10],0
       jne       short M33_L00
       mov       eax,1
       add       rsp,20
       pop       rbp
       ret
M33_L00:
       mov       rsi,[rbp-10]
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F7F0AA26838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       [rbp-18],rax
       cmp       qword ptr [rbp-18],0
       je        short M33_L01
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C7198]
       nop
       add       rsp,20
       pop       rbp
       ret
M33_L01:
       mov       rax,[rbp-10]
       mov       [rbp-20],rax
       mov       rax,[rbp-8]
       movsx     rsi,word ptr [rax+8]
       mov       rdi,[rbp-20]
       mov       r11,7F7F09A40358
       call      qword ptr [r11]
       cmp       eax,1
       sete      al
       movzx     eax,al
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 158
```
```assembly
; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Result()
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       [rbp-10],rax
       cmp       qword ptr [rbp-10],0
       jne       short M34_L00
       mov       rax,[rbp-8]
       vmovdqu   xmm0,xmmword ptr [rax+10]
       vmovdqu   xmmword ptr [rbp-50],xmm0
       mov       rax,[rbp-50]
       mov       rdx,[rbp-48]
       add       rsp,50
       pop       rbp
       ret
M34_L00:
       mov       rsi,[rbp-10]
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F7F0AA26838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       [rbp-18],rax
       cmp       qword ptr [rbp-18],0
       je        short M34_L01
       mov       rdi,[rbp-18]
       xor       esi,esi
       call      qword ptr [7F7F0B9C71C8]
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C71E0]
       mov       [rbp-40],rax
       mov       [rbp-38],rdx
       mov       rax,[rbp-40]
       mov       rdx,[rbp-38]
       add       rsp,50
       pop       rbp
       ret
M34_L01:
       mov       rax,[rbp-10]
       mov       [rbp-20],rax
       mov       rax,[rbp-8]
       movsx     rsi,word ptr [rax+8]
       mov       rdi,[rbp-20]
       mov       r11,7F7F09A40360
       call      qword ptr [r11]
       mov       [rbp-30],rax
       mov       [rbp-28],rdx
       mov       rax,[rbp-30]
       mov       rdx,[rbp-28]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 214
```
```assembly
; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_IsSuccess()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       qword ptr [rax],0
       sete      al
       movzx     eax,al
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 34
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       mov       rdi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C71F8]; Kevlar.KevlarContext.get_ShieldName()
       mov       [rbp-20],rax
       mov       rsi,[rbp-20]
       movzx     edx,byte ptr [rbp-14]
       mov       rdi,[rbp-8]
       mov       rcx,[rbp-10]
       call      qword ptr [7F7F0B9C7210]; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       mov       rdi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C71F8]; Kevlar.KevlarContext.get_ShieldName()
       mov       [rbp-28],rax
       mov       rdi,[rbp-28]
       movzx     esi,byte ptr [rbp-14]
       mov       rdx,[rbp-10]
       call      qword ptr [7F7F0B9C7228]; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 111
```
```assembly
; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_Result()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       eax,[rax+8]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 27
```
```assembly
; System.Diagnostics.Metrics.Instrument.get_Enabled()
       mov       rax,[rdi+8]
       cmp       qword ptr [rax+8],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 16
```
```assembly
; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,0F0
       lea       rbp,[rsp+0F0]
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFF40
M39_L00:
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       vmovdqa   xmmword ptr [rax+rbp],xmm8
       add       rax,30
       jne       short M39_L00
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       mov       [rbp-20],rcx
       cmp       qword ptr [rbp-8],0
       je        near ptr M39_L03
       mov       rax,7F7725800BA0
       mov       rdi,[rax]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B4BEA18]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M39_L03
       lea       rdi,[rbp-0B0]
       mov       rsi,[rbp-10]
       call      qword ptr [7F7F0B9C7258]
       lea       rax,[rbp-0B0]
       mov       [rbp-0C0],rax
       mov       rax,7F7F0860B630
       mov       [rbp-0C8],rax
       movzx     eax,byte ptr [rbp-14]
       test      eax,eax
       jne       short M39_L01
       mov       rax,[rbp-0C0]
       mov       [rbp-0D0],rax
       mov       rax,[rbp-0C8]
       mov       [rbp-0D8],rax
       mov       rax,7F7F0860B678
       mov       [rbp-0E0],rax
       jmp       short M39_L02
M39_L01:
       mov       rax,[rbp-0C0]
       mov       [rbp-0D0],rax
       mov       rax,[rbp-0C8]
       mov       [rbp-0D8],rax
       mov       rax,7F7F0860B6A0
       mov       [rbp-0E0],rax
M39_L02:
       mov       rdi,[rbp-0D0]
       mov       rsi,[rbp-0D8]
       mov       rdx,[rbp-0E0]
       call      qword ptr [7F7F0B9C7270]
       mov       rdi,[rbp-8]
       call      qword ptr [7F7F0B9C7288]
       mov       [rbp-0B8],rax
       lea       rdi,[rbp-0B8]
       call      qword ptr [7F7F0B9C72A0]
       vmovsd    qword ptr [rbp-0E8],xmm0
       vmovsd    xmm0,qword ptr [rbp-0E8]
       lea       rsi,[rbp-0B0]
       mov       rax,7F7725800BA0
       mov       rdi,[rax]
       mov       rdx,[rbp-20]
       call      qword ptr [7F7F0B9C72B8]
M39_L03:
       nop
       add       rsp,0F0
       pop       rbp
       ret
; Total bytes of code 370
```
```assembly
; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,0D0
       lea       rbp,[rsp+0D0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqa   xmmword ptr [rbp-30],xmm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-18],rdx
       mov       rax,7F7725800B48
       mov       rdi,[rax]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B4BEA18]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M40_L02
       lea       rdi,[rbp-0A8]
       mov       rsi,[rbp-8]
       call      qword ptr [7F7F0B9C7258]
       lea       rax,[rbp-0A8]
       mov       [rbp-0B0],rax
       mov       rax,7F7F0860B630
       mov       [rbp-0B8],rax
       movzx     eax,byte ptr [rbp-0C]
       test      eax,eax
       jne       short M40_L00
       mov       rax,[rbp-0B0]
       mov       [rbp-0C0],rax
       mov       rax,[rbp-0B8]
       mov       [rbp-0C8],rax
       mov       rax,7F7F0860B678
       mov       [rbp-0D0],rax
       jmp       short M40_L01
M40_L00:
       mov       rax,[rbp-0B0]
       mov       [rbp-0C0],rax
       mov       rax,[rbp-0B8]
       mov       [rbp-0C8],rax
       mov       rax,7F7F0860B6A0
       mov       [rbp-0D0],rax
M40_L01:
       mov       rdi,[rbp-0C0]
       mov       rsi,[rbp-0C8]
       mov       rdx,[rbp-0D0]
       call      qword ptr [7F7F0B9C7270]
       lea       rdx,[rbp-0A8]
       mov       rax,7F7725800B48
       mov       rdi,[rax]
       mov       rcx,[rbp-18]
       mov       esi,1
       call      qword ptr [7F7F0B9C72D0]
M40_L02:
       nop
       add       rsp,0D0
       pop       rbp
       ret
; Total bytes of code 326
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Rent()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rdi,[rbp-10]
       call      qword ptr [7F7F0B9C67D8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ThrowIfDisposed()
       mov       rdi,[rbp-10]
       call      qword ptr [7F7F0B9C67F0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].RentWithoutLifecycle()
       mov       [rbp-18],rax
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+1C],0
       jne       short M41_L00
       mov       rax,[rbp-18]
       add       rsp,20
       pop       rbp
       ret
M41_L00:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7F7F0B9C6808]
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       call      qword ptr [7F7F0B9C6820]
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 102
```
```assembly
; Kevlar.KevlarContext.set_CancellationToken(System.Threading.CancellationToken)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       lea       rdi,[rax+68]
       lea       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_BYREF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Kevlar.KevlarContext.set_SynchronousExecutionKind(Kevlar.Internal.SynchronousExecutionKind)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       rax,[rbp-8]
       mov       ecx,[rbp-0C]
       mov       [rax+60],ecx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 33
```
```assembly
; Kevlar.KevlarContext.set_TimeProvider(System.TimeProvider)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       lea       rdi,[rax+38]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Kevlar.KevlarContext.set_ShieldName(System.String)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Kevlar.KevlarContext.set_StrategyIndex(Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       rax,[rbp-8]
       mov       ecx,[rbp-0C]
       mov       [rax+5C],ecx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 33
```
```assembly
; Kevlar.KevlarContext.set_AttemptNumber(Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       rax,[rbp-8]
       mov       ecx,[rbp-0C]
       mov       [rax+58],ecx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 33
```
```assembly
; Kevlar.KevlarContext.set_TelemetryListener(Kevlar.IKevlarTelemetryListener)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       lea       rdi,[rax+40]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Return(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rdi,[rbp-10]
       mov       rsi,7F7F086044E0
       call      qword ptr [7F7F0B105830]; System.ArgumentNullException.ThrowIfNull(System.Object, System.String)
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+1C],0
       je        short M49_L00
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F7F0B9C6808]
       nop
       add       rsp,10
       pop       rbp
       ret
M49_L00:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F7F0B9C7318]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       jne       short M49_L01
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F7F0B9C6808]
       nop
       add       rsp,10
       pop       rbp
       ret
M49_L01:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F7F0B9C7330]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ReturnWithoutReset(System.__Canon)
       mov       rdi,[rbp-8]
       call      qword ptr [7F7F0B9C7348]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ClearIfDisposed()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 139
```
```assembly
; Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-28],rdx
       mov       [rbp-20],rcx
       mov       [rbp-30],r8
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-40],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+18]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-48],0
       je        short M50_L00
       mov       rax,[rbp-48]
       mov       [rbp-38],rax
       jmp       short M50_L01
M50_L00:
       mov       rdi,[rbp-40]
       mov       rsi,7F7F0B9B7000
       call      qword ptr [7F7F0AA2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-38],rax
M50_L01:
       mov       rdx,[rbp-28]
       mov       rcx,[rbp-20]
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-38]
       mov       r8,[rbp-30]
       call      qword ptr [7F7F0B9C6AA8]; Kevlar.Internal.ShieldEngine.InvokeWithContextAsync[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]](ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       mov       rax,[rbp-18]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 141
```
```assembly
; Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]]..ctor(System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       [rbp-20],rcx
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-18]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 63
```
```assembly
; Kevlar.Continuation`2[[System.Int32, System.Private.CoreLib],[Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.StrategyNode, System.Func`3<ContextAsyncCallback`2<System.__Canon,Int32>,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Kevlar.Outcome`1<Int32>>>, ContextAsyncCallback`2<System.__Canon,Int32>)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       [rbp-20],rcx
       mov       [rbp-30],r8
       mov       [rbp-28],r9
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-18]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-8]
       lea       rdi,[rax+10]
       lea       rsi,[rbp-30]
       call      CORINFO_HELP_ASSIGN_BYREF
       call      CORINFO_HELP_ASSIGN_BYREF
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 93
```
```assembly
; Kevlar.Continuation`2[[System.Int32, System.Private.CoreLib],[Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]].InvokeAsync(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-68],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       vmovdqa   xmmword ptr [rbp-40],xmm8
       mov       [rbp-30],rax
       mov       [rbp-8],rdx
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       rax,[rbp-10]
       cmp       qword ptr [rax+8],0
       jne       short M53_L00
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-30],rax
       mov       rdi,[rbp-30]
       mov       rsi,7F7F0860B5D0
       call      qword ptr [7F7F0B105638]
       mov       rdi,[rbp-30]
       call      qword ptr [7F7F0B4BE940]
       mov       [rbp-40],rax
       mov       [rbp-38],rdx
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-38]
       lea       rdi,[rbp-60]
       call      qword ptr [7F7F0B9C6A78]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.Outcome`1<Int32>)
       mov       rax,[rbp-18]
       vmovdqu   ymm0,ymmword ptr [rbp-60]
       vmovdqu   ymmword ptr [rax],ymm0
       mov       rax,[rbp-18]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
M53_L00:
       mov       rax,[rbp-10]
       cmp       qword ptr [rax],0
       jne       short M53_L01
       mov       rax,[rbp-10]
       mov       rdx,[rax+10]
       mov       rax,[rbp-10]
       mov       rcx,[rax+18]
       mov       rax,[rbp-10]
       mov       rax,[rax+8]
       mov       [rbp-68],rax
       mov       rax,[rbp-68]
       mov       rsi,[rbp-18]
       mov       r8,[rbp-28]
       mov       rdi,[rax+8]
       mov       rax,[rbp-68]
       call      qword ptr [rax+18]
       mov       rax,[rbp-18]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
M53_L01:
       mov       rax,[rbp-10]
       mov       rcx,[rax]
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-20]
       mov       r8,[rbp-28]
       call      qword ptr [7F7F0B9C6A90]
       mov       rax,[rbp-18]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 283
```
```assembly
; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       push      rbp
       mov       rbp,rsp
       test      rsi,rsi
       je        short M54_L02
       mov       rax,[rsi]
       cmp       rax,rdi
       je        short M54_L02
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M54_L02
M54_L00:
       test      rax,rax
       je        short M54_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M54_L02
       test      rax,rax
       je        short M54_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M54_L02
       test      rax,rax
       jne       short M54_L03
M54_L01:
       xor       esi,esi
M54_L02:
       mov       rax,rsi
       pop       rbp
       ret
M54_L03:
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M54_L02
       test      rax,rax
       je        short M54_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M54_L02
       jmp       short M54_L00
; Total bytes of code 91
```
```assembly
; Kevlar.KevlarContext.get_ShieldName()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+30]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 28
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ThrowIfDisposed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+1C],0
       je        short M56_L00
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       call      qword ptr [7F7F0B9C6820]
M56_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 48
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].RentWithoutLifecycle()
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-18],rax
       xor       eax,eax
       mov       [rbp-1C],eax
       cmp       qword ptr [rbp-18],0
       jne       near ptr M57_L05
       mov       rdi,[rbp-10]
       call      qword ptr [7F7F0B9C6838]
       mov       [rbp-1C],eax
       mov       rdi,[rbp-10]
       mov       esi,[rbp-1C]
       call      qword ptr [7F7F0B9C6850]
       mov       [rbp-30],rax
       mov       rax,[rbp-30]
       mov       rax,[rax]
       mov       [rbp-38],rax
       cmp       qword ptr [rbp-38],0
       je        short M57_L02
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-60],rax
       mov       rax,[rbp-60]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+30]
       mov       [rbp-68],rax
       cmp       qword ptr [rbp-68],0
       je        short M57_L00
       mov       rax,[rbp-68]
       mov       [rbp-58],rax
       jmp       short M57_L01
M57_L00:
       mov       rdi,[rbp-60]
       mov       rsi,7F7F0B9B5AA0
       call      qword ptr [7F7F0AA2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-58],rax
M57_L01:
       mov       rdi,[rbp-58]
       mov       rsi,[rbp-30]
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-38]
       call      qword ptr [7F7F0AE1E820]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       cmp       rax,[rbp-38]
       je        short M57_L03
M57_L02:
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-40]
       mov       [rbp-50],rax
       jmp       short M57_L04
M57_L03:
       mov       rax,[rbp-38]
       mov       [rbp-50],rax
M57_L04:
       mov       rax,[rbp-50]
       mov       [rbp-28],rax
       jmp       short M57_L06
M57_L05:
       lea       rsi,[rbp-28]
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B4BDCC8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
M57_L06:
       mov       rax,[rbp-28]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-28],0
       jne       short M57_L08
       cmp       qword ptr [rbp-18],0
       je        short M57_L07
       mov       rdi,[rbp-10]
       call      qword ptr [7F7F0B9C6868]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].CreateItem()
       nop
       add       rsp,70
       pop       rbp
       ret
M57_L07:
       mov       rdi,[rbp-10]
       mov       esi,[rbp-1C]
       call      qword ptr [7F7F0B9C6880]
       mov       [rbp-48],rax
M57_L08:
       mov       rax,[rbp-48]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 330
```
```assembly
; System.ArgumentNullException.ThrowIfNull(System.Object, System.String)
       push      rax
       test      rdi,rdi
       je        short M58_L00
       add       rsp,8
       ret
M58_L00:
       mov       rdi,rsi
       call      qword ptr [7F7F0A5E1208]
       int       3
; Total bytes of code 21
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-14],eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7F7F0B9C7378]; Kevlar.KevlarContext+PoolPolicy.TryReset(Kevlar.KevlarContext)
       mov       [rbp-14],eax
       mov       eax,[rbp-14]
       add       rsp,20
       pop       rbp
       ret
       push      rax
       mov       [rbp-20],rdi
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F7F0B9C6808]
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 88
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ReturnWithoutReset(System.__Canon)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-20],0
       je        short M60_L01
       mov       rdi,[rbp-20]
       mov       rsi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B4BDF68]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(System.__Canon)
       test      eax,eax
       jne       short M60_L00
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7F7F0B9C6808]
M60_L00:
       nop
       add       rsp,50
       pop       rbp
       ret
M60_L01:
       mov       rdi,[rbp-10]
       call      qword ptr [7F7F0B9C6838]
       mov       [rbp-24],eax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-48],rax
       mov       rax,[rbp-48]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+38]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       je        short M60_L02
       mov       rax,[rbp-50]
       mov       [rbp-38],rax
       jmp       short M60_L03
M60_L02:
       mov       rdi,[rbp-48]
       mov       rsi,7F7F0B9BBA70
       call      qword ptr [7F7F0AA2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-38],rax
M60_L03:
       mov       rdi,[rbp-10]
       mov       esi,[rbp-24]
       call      qword ptr [7F7F0B9C6850]
       mov       [rbp-40],rax
       mov       rsi,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rdx,[rbp-18]
       call      qword ptr [7F7F0B4BDF20]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-30],0
       jne       short M60_L04
       add       rsp,50
       pop       rbp
       ret
M60_L04:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-30]
       mov       ecx,[rbp-24]
       call      qword ptr [7F7F0B9C7558]
       nop
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 262
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ClearIfDisposed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+1C],0
       je        short M61_L00
       mov       rdi,[rbp-8]
       call      qword ptr [7F7F0B9C7588]
M61_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 41
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F7F0A5CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F7F0A5CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; Kevlar.Internal.ShieldEngine.InvokeWithContextAsync[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]](ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       xor       eax,eax
       mov       [rbp-78],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       mov       [rbp-8],rsi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-28],rdx
       mov       [rbp-20],rcx
       mov       [rbp-30],r8
       lea       rdi,[rbp-68]
       call      qword ptr [7F7F0B9C6CD0]; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].Create()
       vmovdqu   xmm0,xmmword ptr [rbp-28]
       vmovdqu   xmmword ptr [rbp-50],xmm0
       mov       rax,[rbp-30]
       mov       [rbp-78],rax
       mov       dword ptr [rbp-70],0FFFFFFFF
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-88],rax
       cmp       qword ptr [rbp-88],0
       je        short M63_L00
       mov       rax,[rbp-88]
       mov       [rbp-80],rax
       jmp       short M63_L01
M63_L00:
       mov       rdi,[rbp-18]
       mov       rsi,7F7F0B9B7C78
       call      qword ptr [7F7F0AA2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-80],rax
M63_L01:
       lea       rdx,[rbp-78]
       lea       rdi,[rbp-68]
       mov       rsi,[rbp-80]
       call      qword ptr [7F7F0B9C6C88]; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       lea       rdi,[rbp-68]
       mov       rsi,[rbp-10]
       call      qword ptr [7F7F0B9C6CE8]; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Task()
       mov       rax,[rbp-10]
       add       rsp,90
       pop       rbp
       ret
; Total bytes of code 207
```
```assembly
; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.Outcome`1<Int32>)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-18],rsi
       mov       [rbp-10],rdx
       mov       rax,[rbp-8]
       lea       rdi,[rax+10]
       lea       rsi,[rbp-18]
       call      CORINFO_HELP_ASSIGN_BYREF
       movsq
       mov       rax,[rbp-8]
       xor       ecx,ecx
       mov       [rax],rcx
       mov       rax,[rbp-8]
       mov       byte ptr [rax+0A],1
       mov       rax,[rbp-8]
       mov       word ptr [rax+8],0
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 74
```
```assembly
; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       push      rax
       mov       rax,rdx
       test      rsi,rsi
       je        short M65_L00
       mov       rdx,rcx
       mov       rdi,rsi
       mov       rsi,rax
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       jmp       qword ptr [rax]
M65_L00:
       call      qword ptr [7F7F0A5E4288]
       int       3
; Total bytes of code 39
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       dword ptr [rbp-80],3E8
       mov       rdi,[rbp-38]
       call      qword ptr [7F7F0B4BDD40]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-44],eax
       xor       eax,eax
       mov       [rbp-48],eax
       jmp       near ptr M66_L07
M66_L00:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       ecx,[rbp-44]
       cmp       ecx,[rax+8]
       jae       near ptr M66_L09
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       rax,[rax]
       mov       [rbp-50],rax
       mov       rax,[rbp-50]
       mov       rax,[rax+10]
       mov       [rbp-58],rax
       cmp       qword ptr [rbp-58],0
       je        near ptr M66_L04
       mov       rax,[rbp-50]
       cmp       [rax],al
       mov       rax,[rbp-50]
       add       rax,10
       mov       [rbp-70],rax
       xor       eax,eax
       mov       [rbp-60],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-88],rax
       mov       rax,[rbp-88]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+20]
       mov       [rbp-90],rax
       cmp       qword ptr [rbp-90],0
       je        short M66_L01
       mov       rax,[rbp-90]
       mov       [rbp-78],rax
       jmp       short M66_L02
M66_L01:
       mov       rdi,[rbp-88]
       mov       rsi,7F7F0B80F9F0
       call      qword ptr [7F7F0AA2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-78],rax
M66_L02:
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-70]
       mov       rdx,[rbp-60]
       mov       rcx,[rbp-58]
       call      qword ptr [7F7F0AE1E820]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       cmp       rax,[rbp-58]
       jne       short M66_L03
       mov       rdi,7F7F0B8B64D8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-58]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       eax,1
       add       rsp,90
       pop       rbp
       ret
M66_L03:
       mov       rdi,7F7F0B8B64DC
       call      CORINFO_HELP_COUNTPROFILE32
M66_L04:
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       mov       rsi,[rbp-50]
       mov       rdx,[rbp-40]
       call      qword ptr [7F7F0B4BDD58]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       je        short M66_L05
       mov       rdi,7F7F0B8B64E0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,90
       pop       rbp
       ret
M66_L05:
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-64],eax
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-44],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-64]
       jne       short M66_L06
       mov       rdi,7F7F0B8B64E4
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-44],eax
M66_L06:
       mov       rdi,7F7F0B8B64E8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-48]
       inc       eax
       mov       [rbp-48],eax
M66_L07:
       mov       eax,[rbp-80]
       dec       eax
       mov       [rbp-80],eax
       cmp       dword ptr [rbp-80],0
       jg        short M66_L08
       lea       rdi,[rbp-80]
       mov       esi,74
       call      CORINFO_HELP_PATCHPOINT
M66_L08:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-48]
       jg        near ptr M66_L00
       mov       rdi,7F7F0B8B64EC
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-40]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,90
       pop       rbp
       ret
M66_L09:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 546
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].CreateItem()
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       call      qword ptr [7F7F0B9C68B0]; Kevlar.KevlarContext+PoolPolicy.Create()
       mov       [rbp-18],rax
       mov       rax,[rbp-18]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-18],0
       jne       short M67_L00
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-28],rax
       mov       edi,67
       mov       rsi,7F7F0AEA56C8
       call      qword ptr [7F7F0AA2EF88]
       mov       [rbp-30],rax
       mov       rsi,[rbp-30]
       mov       rdi,[rbp-28]
       call      qword ptr [7F7F0B105638]
       mov       rdi,[rbp-28]
       call      CORINFO_HELP_THROW
       int       3
M67_L00:
       mov       rax,[rbp-20]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 147
```
```assembly
; Kevlar.KevlarContext+PoolPolicy.TryReset(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       xor       eax,eax
       mov       [rbp-18],rax
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C6568]; Kevlar.KevlarContext.set_CancellationToken(System.Threading.CancellationToken)
       mov       rdi,[rbp-10]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C6580]; Kevlar.KevlarContext.set_SynchronousExecutionKind(Kevlar.Internal.SynchronousExecutionKind)
       mov       rdi,[rbp-10]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C65B0]; Kevlar.KevlarContext.set_ShieldName(System.String)
       mov       rdi,[rbp-10]
       mov       esi,0FFFFFFFF
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C65C8]; Kevlar.KevlarContext.set_StrategyIndex(Int32)
       mov       rdi,[rbp-10]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C65E0]; Kevlar.KevlarContext.set_AttemptNumber(Int32)
       mov       rdi,[rbp-10]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C65F8]; Kevlar.KevlarContext.set_TelemetryListener(Kevlar.IKevlarTelemetryListener)
       mov       rax,[rbp-10]
       xor       ecx,ecx
       mov       [rax+48],rcx
       mov       rax,[rbp-10]
       xor       ecx,ecx
       mov       [rax+50],rcx
       mov       rax,[rbp-10]
       mov       rax,[rax+28]
       mov       [rbp-20],rax
       mov       rax,[rbp-20]
       mov       [rbp-28],rax
       cmp       qword ptr [rbp-20],0
       jne       short M68_L00
       jmp       short M68_L01
M68_L00:
       mov       rdi,[rbp-28]
       call      qword ptr [7F7F0B9FEA88]
M68_L01:
       call      qword ptr [7F7F0B4BE598]; System.TimeProvider.get_System()
       mov       [rbp-30],rax
       mov       rsi,[rbp-30]
       mov       rdi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C6598]; Kevlar.KevlarContext.set_TimeProvider(System.TimeProvider)
       mov       rax,[rbp-10]
       mov       rdi,[rax+8]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C73A8]; Kevlar.KevlarProperties.MirrorMutationsTo(Kevlar.KevlarProperties)
       mov       rax,[rbp-10]
       mov       rdi,[rax+8]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C73C0]; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       mov       rax,[rbp-10]
       mov       rdi,[rax+8]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C73D8]; Kevlar.KevlarProperties.Clear()
       mov       rax,[rbp-10]
       cmp       qword ptr [rax+10],0
       je        short M68_L02
       mov       rax,[rbp-10]
       mov       rdi,[rax+10]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C73C0]; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       mov       rax,[rbp-10]
       mov       rdi,[rax+10]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C73D8]; Kevlar.KevlarProperties.Clear()
M68_L02:
       mov       rax,[rbp-10]
       cmp       qword ptr [rax+18],0
       je        short M68_L03
       mov       rax,[rbp-10]
       mov       rdi,[rax+18]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C73C0]; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       mov       rax,[rbp-10]
       mov       rdi,[rax+18]
       cmp       [rdi],edi
       call      qword ptr [7F7F0B9C73D8]; Kevlar.KevlarProperties.Clear()
M68_L03:
       mov       rax,[rbp-10]
       mov       byte ptr [rax+64],0
       mov       rax,[rbp-10]
       mov       byte ptr [rax+65],0
       mov       eax,1
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 371
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(System.__Canon)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       dword ptr [rbp-78],3E8
       mov       rdi,[rbp-38]
       call      qword ptr [7F7F0B4BDD40]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-44],eax
       xor       eax,eax
       mov       [rbp-48],eax
       jmp       near ptr M69_L06
M69_L00:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       ecx,[rbp-44]
       cmp       ecx,[rax+8]
       jae       near ptr M69_L08
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       rax,[rax]
       mov       [rbp-50],rax
       mov       rax,[rbp-50]
       cmp       [rax],al
       mov       rax,[rbp-50]
       add       rax,10
       mov       [rbp-60],rax
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-80],rax
       mov       rax,[rbp-80]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+20]
       mov       [rbp-88],rax
       cmp       qword ptr [rbp-88],0
       je        short M69_L01
       mov       rax,[rbp-88]
       mov       [rbp-68],rax
       jmp       short M69_L02
M69_L01:
       mov       rdi,[rbp-80]
       mov       rsi,7F7F0B80F9F0
       call      qword ptr [7F7F0AA2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-68],rax
M69_L02:
       mov       rdi,[rbp-68]
       mov       rsi,[rbp-60]
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-58]
       call      qword ptr [7F7F0AE1E820]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       test      rax,rax
       je        short M69_L03
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       mov       rsi,[rbp-50]
       mov       rdx,[rbp-40]
       call      qword ptr [7F7F0B4BDF98]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       je        short M69_L04
       mov       rdi,7F7F0B8B6938
       call      CORINFO_HELP_COUNTPROFILE32
M69_L03:
       mov       rdi,7F7F0B8B693C
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,90
       pop       rbp
       ret
M69_L04:
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-6C],eax
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-44],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-6C]
       jne       short M69_L05
       mov       rdi,7F7F0B8B6940
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-44],eax
M69_L05:
       mov       rdi,7F7F0B8B6944
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-48]
       inc       eax
       mov       [rbp-48],eax
M69_L06:
       mov       eax,[rbp-78]
       dec       eax
       mov       [rbp-78],eax
       cmp       dword ptr [rbp-78],0
       jg        short M69_L07
       lea       rdi,[rbp-78]
       mov       esi,50
       call      CORINFO_HELP_PATCHPOINT
M69_L07:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-48]
       jg        near ptr M69_L00
       mov       rdi,7F7F0B8B6948
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,90
       pop       rbp
       ret
M69_L08:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 457
```
```assembly
; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].Create()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-20],xmm0
       vmovdqu   xmmword ptr [rbp-18],xmm0
       mov       rax,[rbp-8]
       vmovdqu   xmm0,xmmword ptr [rbp-20]
       vmovdqu   xmmword ptr [rax],xmm0
       mov       rcx,[rbp-10]
       mov       [rax+10],rcx
       mov       rax,[rbp-8]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 75
```
```assembly
; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       mov       [rbp-8],rsi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+10]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-30],0
       je        short M71_L00
       mov       rax,[rbp-30]
       mov       [rbp-28],rax
       jmp       short M71_L01
M71_L00:
       mov       rdi,[rbp-18]
       mov       rsi,7F7F0B9B7ED8
       call      qword ptr [7F7F0AA2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-28],rax
M71_L01:
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-20]
       call      qword ptr [7F7F0B9C6D18]; System.Runtime.CompilerServices.AsyncMethodBuilderCore.Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 104
```
```assembly
; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Task()
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       rcx,7F77258013E8
       cmp       rax,[rcx]
       jne       short M72_L00
       mov       rax,[rbp-8]
       mov       rsi,[rax+8]
       mov       rax,[rbp-8]
       mov       rdx,[rax+10]
       lea       rdi,[rbp-70]
       call      qword ptr [7F7F0B9C6A78]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.Outcome`1<Int32>)
       mov       rax,[rbp-10]
       vmovdqu   ymm0,ymmword ptr [rbp-70]
       vmovdqu   ymmword ptr [rax],ymm0
       mov       rax,[rbp-10]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
M72_L00:
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       [rbp-20],rax
       mov       rax,[rbp-20]
       mov       [rbp-28],rax
       cmp       qword ptr [rbp-20],0
       jne       short M72_L01
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-50],rax
       mov       rdi,[rbp-50]
       call      qword ptr [7F7F0B9C70F0]
       mov       rax,[rbp-50]
       mov       [rbp-18],rax
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-50]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       mov       [rbp-28],rax
M72_L01:
       lea       rdi,[rbp-48]
       mov       rsi,[rbp-28]
       call      qword ptr [7F7F0B9C7108]
       mov       rax,[rbp-10]
       vmovdqu   ymm0,ymmword ptr [rbp-48]
       vmovdqu   ymmword ptr [rax],ymm0
       mov       rax,[rbp-10]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 236
```

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: dry-1.4.0(EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.4.0,DOTNET_TieredPGO=1, Arguments=/p:ReservoirVersion=1.4.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll, IterationCount=1, LaunchCount=1, RunStrategy=ColdStart, UnrollFactor=1, WarmupCount=1))

```assembly
; PoolContextProbe.NestedContext()
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,7F272D800AC0
       mov       rax,[rax]
       mov       [rbp-18],rax
       mov       rax,7F272D800400
       mov       rax,[rax]
       mov       [rbp-20],rax
       mov       rax,[rbp-18]
       mov       [rbp-28],rax
       cmp       qword ptr [rbp-18],0
       jne       short M00_L00
       mov       rdi,offset MT_System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-40],rax
       mov       rax,7F272D800AA8
       mov       rsi,[rax]
       mov       rdi,[rbp-40]
       mov       rdx,offset PoolContextProbe+<>c.<NestedContext>b__6_0(Kevlar.KevlarContext)
       call      qword ptr [7F2F12E26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rsi,[rbp-40]
       mov       rdi,7F272D800AC0
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-40]
       mov       [rbp-28],rax
M00_L00:
       xor       eax,eax
       mov       [rbp-10],rax
       mov       rdi,[rbp-20]
       mov       rsi,[rbp-28]
       mov       rdx,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F2F138BE028]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       mov       [rbp-38],rax
       mov       [rbp-30],rdx
       mov       rax,[rbp-38]
       mov       rdx,[rbp-30]
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 211
```
```assembly
; BenchmarkDotNet.Helpers.AwaitHelper.GetResult[[System.Int32, System.Private.CoreLib]](System.Threading.Tasks.ValueTask`1<Int32>)
       push      rbp
       sub       rsp,60
       lea       rbp,[rsp+60]
       xor       eax,eax
       mov       [rbp-58],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-10],rdi
       mov       [rbp-8],rsi
       lea       rdi,[rbp-10]
       xor       esi,esi
       call      qword ptr [7F2F13DC6E80]; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]].ConfigureAwait(Boolean)
       mov       [rbp-40],rax
       mov       [rbp-38],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-40]
       vmovdqu   xmmword ptr [rbp-30],xmm0
       lea       rdi,[rbp-30]
       call      qword ptr [7F2F13DC6E98]; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1[[System.Int32, System.Private.CoreLib]].GetAwaiter()
       mov       [rbp-50],rax
       mov       [rbp-48],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-50]
       vmovdqu   xmmword ptr [rbp-20],xmm0
       lea       rdi,[rbp-20]
       call      qword ptr [7F2F13DC6EB0]; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[[System.Int32, System.Private.CoreLib]].get_IsCompleted()
       test      eax,eax
       jne       short M01_L00
       call      qword ptr [7F2F13DCD8C0]
       mov       [rbp-58],rax
       mov       rdi,[rbp-58]
       mov       rsi,[rbp-20]
       mov       rdx,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DCD890]
M01_L00:
       lea       rdi,[rbp-20]
       call      qword ptr [7F2F13DC6EC8]; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[[System.Int32, System.Private.CoreLib]].GetResult()
       nop
       add       rsp,60
       pop       rbp
       ret
; Total bytes of code 158
```
```assembly
; PoolContextProbe+<>c.<NestedContext>b__6_0(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp-48],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,7F272D800AB8
       mov       rax,[rax]
       mov       [rbp-18],rax
       mov       rax,7F272D800400
       mov       rax,[rax]
       mov       [rbp-20],rax
       mov       rax,[rbp-10]
       mov       [rbp-28],rax
       mov       rax,[rbp-18]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-18],0
       jne       short M02_L00
       mov       rdi,offset MT_System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-48],rax
       mov       rax,7F272D800AA8
       mov       rsi,[rax]
       mov       rdi,[rbp-48]
       mov       rdx,offset PoolContextProbe+<>c.<NestedContext>b__6_1(Kevlar.KevlarContext)
       call      qword ptr [7F2F12E26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rsi,[rbp-48]
       mov       rdi,7F272D800AB8
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-48]
       mov       [rbp-30],rax
M02_L00:
       mov       rdi,[rbp-20]
       mov       rsi,[rbp-28]
       mov       rdx,[rbp-30]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC75D0]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](Kevlar.KevlarContext, System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
       mov       [rbp-40],rax
       mov       [rbp-38],rdx
       mov       rax,[rbp-40]
       mov       rdx,[rbp-38]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 217
```
```assembly
; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       push      r15
       push      rbx
       push      rax
       mov       rbx,rdi
       mov       r15,rdx
       test      rsi,rsi
       je        short M03_L00
       lea       rdi,[rbx+8]
       call      qword ptr [7F2F129CEEB8]; CORINFO_HELP_ASSIGN_REF
       mov       [rbx+18],r15
       add       rsp,8
       pop       rbx
       pop       r15
       ret
M03_L00:
       call      qword ptr [7F2F129E0120]
       int       3
; Total bytes of code 44
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqa   xmmword ptr [rbp-30],xmm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       rdi,[rbp-10]
       mov       rsi,7F2F10A08560
       call      qword ptr [7F2F138BE478]; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F2F12E25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F272D800AF0
       mov       rax,[rax]
       mov       [rbp-20],rax
       mov       rax,[rbp-8]
       mov       [rbp-28],rax
       mov       rax,[rbp-10]
       mov       [rbp-30],rax
       mov       rax,[rbp-20]
       mov       [rbp-38],rax
       cmp       qword ptr [rbp-20],0
       jne       near ptr M04_L00
       mov       rdi,offset MT_System.Action<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarProperties>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-80],rax
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F2F12E25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F272D800AE8
       mov       rax,[rax]
       mov       [rbp-88],rax
       mov       rsi,[rbp-88]
       mov       rdi,[rbp-80]
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       call      qword ptr [7F2F12E26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F2F12E25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rbp-80]
       mov       rdi,7F272D800AF0
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-80]
       mov       [rbp-38],rax
M04_L00:
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F2F12E25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F272D800AF8
       mov       rax,[rax]
       mov       [rbp-40],rax
       mov       rax,[rbp-28]
       mov       [rbp-48],rax
       mov       rax,[rbp-30]
       mov       [rbp-50],rax
       mov       rax,[rbp-38]
       mov       [rbp-58],rax
       mov       rax,[rbp-40]
       mov       [rbp-60],rax
       cmp       qword ptr [rbp-40],0
       jne       near ptr M04_L01
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-78],rax
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F2F12E25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F272D800AE8
       mov       rax,[rax]
       mov       [rbp-90],rax
       mov       rsi,[rbp-90]
       mov       rdi,[rbp-78]
       mov       rdx,offset Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F2F12E26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,offset MT_Kevlar.Shield+<>c__64<System.Int32>
       call      qword ptr [7F2F12E25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rbp-78]
       mov       rdi,7F272D800AF8
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-78]
       mov       [rbp-60],rax
M04_L01:
       mov       rdi,[rbp-48]
       mov       r9,[rbp-18]
       mov       rdx,[rbp-50]
       mov       rcx,[rbp-58]
       mov       r8,[rbp-60]
       mov       rsi,7F2F13CBB1D0
       call      qword ptr [7F2F138BE3A0]; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       mov       [rbp-70],rax
       mov       [rbp-68],rdx
       mov       rax,[rbp-70]
       mov       rdx,[rbp-68]
       add       rsp,90
       pop       rbp
       ret
; Total bytes of code 537
```
```assembly
; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]].ConfigureAwait(Boolean)
       mov       rax,[rdi]
       mov       edx,[rdi+8]
       movsx     rcx,word ptr [rdi+0C]
       movzx     edi,sil
       movzx     ecx,cx
       shl       rcx,20
       or        rdx,rcx
       mov       ecx,edi
       shl       rcx,30
       or        rdx,rcx
       ret
; Total bytes of code 35
```
```assembly
; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1[[System.Int32, System.Private.CoreLib]].GetAwaiter()
       sub       rsp,18
       xor       eax,eax
       mov       [rsp+8],rax
       movups    xmm0,[rdi]
       movups    [rsp+8],xmm0
       mov       rax,[rsp+8]
       mov       rdx,[rsp+10]
       add       rsp,18
       ret
; Total bytes of code 34
```
```assembly
; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[[System.Int32, System.Private.CoreLib]].get_IsCompleted()
       push      rbp
       push      r15
       push      rbx
       lea       rbp,[rsp+10]
       mov       rbx,rdi
       mov       r15,[rbx]
       test      r15,r15
       je        short M07_L04
       mov       rdi,r15
       call      qword ptr [7F2F129DCE98]
       test      rax,rax
       jne       short M07_L03
       movsx     rsi,word ptr [rbx+0C]
       mov       rdi,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       cmp       rdi,[r15]
       je        short M07_L02
       mov       rdi,r15
       lea       r11,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       call      qword ptr [r11]
M07_L00:
       test      eax,eax
       setne     al
       movzx     eax,al
M07_L01:
       pop       rbx
       pop       r15
       pop       rbp
       ret
M07_L02:
       lea       rdi,[r15+40]
       call      qword ptr [7F2F129EF4C0]
       jmp       short M07_L00
M07_L03:
       test      dword ptr [rax+34],1600000
       setne     al
       movzx     eax,al
       jmp       short M07_L01
M07_L04:
       mov       eax,1
       jmp       short M07_L01
; Total bytes of code 111
```
```assembly
; System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[[System.Int32, System.Private.CoreLib]].GetResult()
       push      rbp
       push      r15
       push      r14
       push      rbx
       push      rax
       lea       rbp,[rsp+20]
       mov       rbx,rdi
       mov       r15,[rbx]
       test      r15,r15
       je        short M08_L03
       mov       rdi,r15
       call      qword ptr [7F2F129DCE98]
       mov       r14,rax
       test      r14,r14
       jne       short M08_L01
       movsx     rsi,word ptr [rbx+0C]
       mov       rdi,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       cmp       rdi,[r15]
       je        short M08_L00
       mov       rdi,r15
       lea       r11,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       jmp       qword ptr [r11]
M08_L00:
       mov       rdi,r15
       call      qword ptr [7F2F129DF2E8]
       jmp       short M08_L04
M08_L01:
       mov       edi,[r14+34]
       and       edi,11000000
       cmp       edi,1000000
       jne       short M08_L05
M08_L02:
       mov       eax,[r14+38]
       jmp       short M08_L04
M08_L03:
       mov       eax,[rbx+8]
M08_L04:
       add       rsp,8
       pop       rbx
       pop       r14
       pop       r15
       pop       rbp
       ret
M08_L05:
       mov       rdi,r14
       xor       esi,esi
       call      qword ptr [7F2F129E99B0]
       jmp       short M08_L02
; Total bytes of code 142
```
```assembly
; PoolContextProbe+<>c.<NestedContext>b__6_1(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-20],xmm0
       lea       rdi,[rbp-20]
       mov       esi,2A
       call      qword ptr [7F2F138BE9E8]; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]]..ctor(Int32)
       mov       rax,[rbp-20]
       mov       rdx,[rbp-18]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 62
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib]](Kevlar.KevlarContext, System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
M10_L00:
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqa   xmmword ptr [rbp-30],xmm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       rdi,[rbp-18]
       mov       rsi,7F2F10A08560
       call      qword ptr [7F2F138BE478]; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       mov       rdi,[rbp-10]
       mov       rsi,7F2F10A0B6C8
       call      qword ptr [7F2F138BE478]; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       mov       rax,[rbp-8]
       mov       rax,[rax+38]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-20],0
       je        short M10_L01
       mov       rax,[rbp-20]
       mov       rdi,[rax+8]
       mov       rax,[rbp-20]
       call      qword ptr [rax+18]
       mov       [rbp-88],rax
       mov       rdi,[rbp-88]
       mov       rsi,[rbp-10]
       mov       rdx,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC75D0]
       mov       [rbp-80],rax
       mov       [rbp-78],rdx
       mov       rax,[rbp-80]
       mov       rdx,[rbp-78]
       add       rsp,90
       pop       rbp
       ret
M10_L01:
       mov       rdi,[rbp-8]
       call      qword ptr [7F2F138BE520]; Kevlar.Shield.ThrowIfVoidFallbackResultExecution()
       mov       rax,[rbp-8]
       mov       rax,[rax+10]
       mov       [rbp-28],rax
       mov       rdi,[rbp-8]
       call      qword ptr [7F2F138BE550]; Kevlar.Shield.get_Name()
       mov       [rbp-38],rax
       mov       rdi,offset MT_Kevlar.Shield+<>c__60<System.Int32>
       call      qword ptr [7F2F12E25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F272D801410
       mov       rax,[rax]
       mov       [rbp-30],rax
       mov       rax,[rbp-28]
       mov       [rbp-40],rax
       mov       rax,[rbp-38]
       mov       [rbp-48],rax
       mov       rax,[rbp-18]
       mov       [rbp-50],rax
       mov       rax,[rbp-30]
       mov       [rbp-58],rax
       cmp       qword ptr [rbp-30],0
       jne       near ptr M10_L02
       mov       rdi,offset MT_System.Func<System.Func<Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>, Kevlar.KevlarContext, System.Threading.Tasks.ValueTask<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-70],rax
       mov       rdi,offset MT_Kevlar.Shield+<>c__60<System.Int32>
       call      qword ptr [7F2F12E25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F272D801408
       mov       rax,[rax]
       mov       [rbp-90],rax
       mov       rsi,[rbp-90]
       mov       rdi,[rbp-70]
       mov       rdx,offset Kevlar.Shield+<>c__60`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__60_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       call      qword ptr [7F2F12E26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rdi,offset MT_Kevlar.Shield+<>c__60<System.Int32>
       call      qword ptr [7F2F12E25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rsi,[rbp-70]
       mov       rdi,7F272D801410
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-70]
       mov       [rbp-58],rax
M10_L02:
       mov       r9,[rbp-10]
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-48]
       mov       rcx,[rbp-50]
       mov       r8,[rbp-58]
       mov       rdi,7F2F13E03BA8
       call      qword ptr [7F2F13DC7600]; Kevlar.Internal.ShieldEngine.ExecuteWithParentContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.String, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       mov       [rbp-68],rax
       mov       [rbp-60],rdx
       mov       rax,[rbp-68]
       mov       rdx,[rbp-60]
       add       rsp,90
       pop       rbp
       ret
; Total bytes of code 489
```
```assembly
; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       cmp       qword ptr [rbp-8],0
       jne       short M11_L00
       mov       rdi,offset MT_System.ArgumentNullException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-18],rax
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2F1350E2E0]
       mov       rdi,[rbp-18]
       call      CORINFO_HELP_THROW
       int       3
M11_L00:
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 80
```
```assembly
; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rdi+20]
       mov       rax,[rax-18]
       mov       rcx,rax
       test      cl,1
       jne       short M12_L00
       ret
M12_L00:
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       jmp       qword ptr [rax]
; Total bytes of code 27
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 28
```
```assembly
; Kevlar.Shield+<>c__64`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__64_1(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       rax,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdi,[rax+8]
       mov       rax,[rbp-10]
       call      qword ptr [rax+18]
       mov       [rbp-28],rax
       mov       [rbp-20],rdx
       mov       rax,[rbp-28]
       mov       rdx,[rbp-20]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 69
```
```assembly
; Kevlar.Shield.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
M15_L00:
       push      rbp
       sub       rsp,0A0
       lea       rbp,[rsp+0A0]
       xor       eax,eax
       mov       [rbp-88],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-40],rax
       mov       [rbp-8],rsi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       mov       rdi,[rbp-28]
       mov       rsi,7F2F10A08588
       call      qword ptr [7F2F138BE478]; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       mov       rdi,[rbp-30]
       mov       rsi,7F2F10A08560
       call      qword ptr [7F2F138BE478]; Kevlar.Internal.Throw.IfNull(System.Object, System.String)
       mov       rax,[rbp-10]
       mov       rax,[rax+38]
       mov       [rbp-40],rax
       cmp       qword ptr [rbp-40],0
       je        short M15_L01
       mov       rax,[rbp-40]
       mov       rdi,[rax+8]
       mov       rax,[rbp-40]
       call      qword ptr [rax+18]
       mov       [rbp-80],rax
       mov       rdi,[rbp-80]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-20]
       mov       rcx,[rbp-28]
       mov       r8,[rbp-30]
       mov       r9,[rbp-38]
       cmp       [rdi],edi
       call      qword ptr [7F2F138BE3A0]
       mov       [rbp-78],rax
       mov       [rbp-70],rdx
       mov       rax,[rbp-78]
       mov       rdx,[rbp-70]
       add       rsp,0A0
       pop       rbp
       ret
M15_L01:
       mov       rdi,[rbp-10]
       call      qword ptr [7F2F138BE520]; Kevlar.Shield.ThrowIfVoidFallbackResultExecution()
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-48],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F2F138BE538]; Kevlar.Shield.get_TimeOrSystem()
       mov       [rbp-50],rax
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-90],rax
       cmp       qword ptr [rbp-90],0
       je        short M15_L02
       mov       rax,[rbp-90]
       mov       [rbp-58],rax
       jmp       short M15_L03
M15_L02:
       mov       rdi,[rbp-18]
       mov       rsi,7F2F13CC2DB0
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-58],rax
M15_L03:
       mov       rdi,[rbp-10]
       call      qword ptr [7F2F138BE550]; Kevlar.Shield.get_Name()
       mov       [rbp-88],rax
       mov       rax,[rbp-30]
       mov       [rsp],rax
       mov       rax,[rbp-38]
       mov       [rsp+8],rax
       mov       rcx,[rbp-88]
       mov       rsi,[rbp-48]
       mov       rdx,[rbp-50]
       mov       rdi,[rbp-58]
       mov       r8,[rbp-20]
       mov       r9,[rbp-28]
       call      qword ptr [7F2F138BE4C0]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       mov       [rbp-68],rax
       mov       [rbp-60],rdx
       mov       rax,[rbp-68]
       mov       rdx,[rbp-60]
       add       rsp,0A0
       pop       rbp
       ret
; Total bytes of code 401
```
```assembly
; System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)
       push      rbp
       push      r15
       push      rbx
       sub       rsp,10
       lea       rbp,[rsp+20]
       mov       [rbp-18],rdi
       mov       rbx,rsi
       call      qword ptr [7F2F129D4740]
       mov       r15,rax
       mov       rdi,rax
       call      qword ptr [7F2F129CEF28]; Precode of System.RuntimeTypeHandle.GetRuntimeTypeFromHandle(IntPtr)
       mov       rsi,rax
       mov       rdi,rbx
       mov       edx,1
       call      qword ptr [7F2F129DF690]
       mov       rcx,rax
       test      rcx,rcx
       je        short M16_L00
       mov       rdi,r15
       cmp       [rcx],rdi
       je        short M16_L00
       mov       rsi,rax
       call      qword ptr [7F2F129CEF60]; Precode of System.Runtime.CompilerServices.CastHelpers.ChkCastAny(Void*, System.Object)
       mov       rcx,rax
M16_L00:
       mov       rax,rcx
       add       rsp,10
       pop       rbx
       pop       r15
       pop       rbp
       ret
; Total bytes of code 95
```
```assembly
; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]]..ctor(Int32)
       mov       [rdi+8],esi
       xor       eax,eax
       mov       [rdi],rax
       mov       byte ptr [rdi+0E],1
       mov       word ptr [rdi+0C],0
       ret
; Total bytes of code 19
```
```assembly
; Kevlar.Shield.ThrowIfVoidFallbackResultExecution()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       movzx     eax,byte ptr [rax+48]
       test      eax,eax
       je        short M18_L00
       call      qword ptr [7F2F138BE568]
       mov       rdi,rax
       call      CORINFO_HELP_THROW
       int       3
M18_L00:
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 47
```
```assembly
; Kevlar.Shield.get_Name()
M19_L00:
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+38]
       mov       [rbp-10],rax
       cmp       qword ptr [rbp-10],0
       jne       short M19_L01
       mov       rax,[rbp-8]
       mov       rax,[rax+40]
       add       rsp,10
       pop       rbp
       ret
M19_L01:
       mov       rax,[rbp-10]
       mov       rdi,[rax+8]
       mov       rax,[rbp-10]
       call      qword ptr [rax+18]
       mov       rdi,rax
       cmp       [rdi],edi
       call      qword ptr [7F2F138BE550]
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 86
```
```assembly
; Kevlar.Shield+<>c__60`1[[System.Int32, System.Private.CoreLib]].<ExecuteWithContextAsync>b__60_0(System.Func`2<Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       rax,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdi,[rax+8]
       mov       rax,[rbp-10]
       call      qword ptr [rax+18]
       mov       [rbp-28],rax
       mov       [rbp-20],rdx
       mov       rax,[rbp-28]
       mov       rdx,[rbp-20]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 69
```
```assembly
; Kevlar.Internal.ShieldEngine.ExecuteWithParentContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.String, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,130
       lea       rbp,[rsp+130]
       xor       eax,eax
       mov       [rbp-0F8],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0F0],ymm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       mov       [rbp-40],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       call      qword ptr [7F2F138BE880]; Kevlar.Internal.KevlarMetrics.get_DurationEnabled()
       test      eax,eax
       jne       short M21_L00
       xor       eax,eax
       mov       [rbp-88],rax
       jmp       short M21_L01
M21_L00:
       call      qword ptr [7F2F138BE898]
       mov       [rbp-88],rax
M21_L01:
       mov       rax,[rbp-88]
       mov       [rbp-40],rax
       mov       rdi,[rbp-38]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC77F8]; Kevlar.KevlarContext.get_CancellationToken()
       mov       [rbp-48],rax
       lea       rdi,[rbp-48]
       call      qword ptr [7F2F138BE8B0]; System.Threading.CancellationToken.get_IsCancellationRequested()
       test      eax,eax
       je        near ptr M21_L02
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-20]
       xor       edx,edx
       call      qword ptr [7F2F138BE8C8]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-0D8],rax
       mov       rdi,[rbp-0D8]
       mov       rsi,[rbp-48]
       call      qword ptr [7F2F138BE928]
       mov       rdi,[rbp-0D8]
       call      qword ptr [7F2F138BE940]
       mov       [rbp-0E8],rax
       mov       [rbp-0E0],rdx
       mov       rdi,[rbp-0E8]
       mov       rsi,[rbp-0E0]
       call      qword ptr [7F2F138BE850]
       mov       [rbp-0F8],rax
       mov       [rbp-0F0],rdx
       mov       rax,[rbp-0F8]
       mov       rdx,[rbp-0F0]
       add       rsp,130
       pop       rbp
       ret
M21_L02:
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-20]
       xor       edx,edx
       call      qword ptr [7F2F13DC7810]; Kevlar.KevlarContext.RentChild(Kevlar.KevlarContext, System.String, Kevlar.Internal.SynchronousExecutionKind)
       mov       [rbp-50],rax
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-108],rax
       cmp       qword ptr [rbp-108],0
       je        short M21_L03
       mov       rax,[rbp-108]
       mov       [rbp-90],rax
       jmp       short M21_L04
M21_L03:
       mov       rdi,[rbp-10]
       mov       rsi,7F2F13DBC288
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-90],rax
M21_L04:
       lea       rdi,[rbp-70]
       mov       rsi,[rbp-90]
       mov       rdx,[rbp-18]
       mov       rcx,[rbp-28]
       mov       r8,[rbp-30]
       mov       r9,[rbp-50]
       call      qword ptr [7F2F138BE6D0]; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       lea       rdi,[rbp-70]
       call      qword ptr [7F2F138BE970]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_IsCompletedSuccessfully()
       test      eax,eax
       je        near ptr M21_L06
       lea       rdi,[rbp-70]
       call      qword ptr [7F2F138BE988]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Result()
       mov       [rbp-0B0],rax
       mov       [rbp-0A8],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-0B0]
       vmovdqu   xmmword ptr [rbp-80],xmm0
       lea       rdi,[rbp-80]
       call      qword ptr [7F2F138BE9A0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_IsSuccess()
       mov       [rbp-0FC],eax
       mov       edx,[rbp-0FC]
       mov       rsi,[rbp-20]
       mov       rdi,[rbp-40]
       call      qword ptr [7F2F138BE8C8]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       mov       rdi,[rbp-50]
       mov       rsi,[rbp-38]
       call      qword ptr [7F2F13DC7828]; Kevlar.Internal.ShieldEngine.ReturnChildContext(Kevlar.KevlarContext, Kevlar.KevlarContext)
       lea       rdi,[rbp-80]
       call      qword ptr [7F2F138BE9A0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_IsSuccess()
       test      eax,eax
       jne       short M21_L05
       mov       rdi,[rbp-80]
       mov       rsi,[rbp-78]
       call      qword ptr [7F2F138BE850]
       mov       [rbp-0D0],rax
       mov       [rbp-0C8],rdx
       mov       rax,[rbp-0D0]
       mov       rdx,[rbp-0C8]
       add       rsp,130
       pop       rbp
       ret
M21_L05:
       lea       rdi,[rbp-80]
       call      qword ptr [7F2F138BE9D0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_Result()
       mov       [rbp-100],eax
       mov       esi,[rbp-100]
       lea       rdi,[rbp-0C0]
       call      qword ptr [7F2F138BE9E8]; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]]..ctor(Int32)
       mov       rax,[rbp-0C0]
       mov       rdx,[rbp-0B8]
       add       rsp,130
       pop       rbp
       ret
M21_L06:
       lea       rdi,[rsp]
       lea       rsi,[rbp-70]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,[rbp-50]
       mov       rsi,[rbp-38]
       mov       rdx,[rbp-40]
       call      qword ptr [7F2F13DC7768]
       mov       [rbp-0A0],rax
       mov       [rbp-98],rdx
       mov       rax,[rbp-0A0]
       mov       rdx,[rbp-98]
       add       rsp,130
       pop       rbp
       ret
; Total bytes of code 773
```
```assembly
; Kevlar.Shield.get_TimeOrSystem()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       rdi,[rbp-8]
       call      qword ptr [7F2F138BE580]; Kevlar.Shield.get_CurrentSnapshot()
       mov       rax,[rax+20]
       mov       [rbp-10],rax
       mov       rax,[rbp-10]
       mov       [rbp-18],rax
       cmp       qword ptr [rbp-10],0
       jne       short M22_L00
       call      qword ptr [7F2F138BE598]; System.TimeProvider.get_System()
       mov       [rbp-18],rax
M22_L00:
       mov       rax,[rbp-18]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 77
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       [rbp-8C],rdi
       mov       rdx,rsi
       mov       [rbp-94],rdx
       xor       esi,esi
       mov       [rbp-9C],rsi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F2F129CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdi,[rbp-8C]
       mov       rdx,[rbp-94]
       mov       rsi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F2F129CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 159
```
```assembly
; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Threading.CancellationToken)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-50],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-58],rax
       cmp       qword ptr [rbp-58],0
       je        short M24_L00
       mov       rax,[rbp-58]
       mov       [rbp-40],rax
       jmp       short M24_L01
M24_L00:
       mov       rdi,[rbp-10]
       mov       rsi,7F2F13CC3168
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-40],rax
M24_L01:
       mov       rax,[rbp+10]
       mov       [rsp],rax
       xor       eax,eax
       mov       [rsp+8],rax
       mov       rax,[rbp+18]
       mov       [rsp+10],rax
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-20]
       mov       rcx,[rbp-28]
       mov       r8,[rbp-30]
       mov       r9,[rbp-38]
       call      qword ptr [7F2F138BE5F8]; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       mov       [rbp-50],rax
       mov       [rbp-48],rdx
       mov       rax,[rbp-50]
       mov       rdx,[rbp-48]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 177
```
```assembly
; Kevlar.Internal.KevlarMetrics.get_DurationEnabled()
       push      rbp
       mov       rbp,rsp
       mov       rdi,offset MT_Kevlar.Internal.KevlarMetrics
       call      qword ptr [7F2F12E25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F272D800BA0
       mov       rdi,[rax]
       cmp       [rdi],edi
       call      qword ptr [7F2F138BEA18]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       nop
       pop       rbp
       ret
; Total bytes of code 44
```
```assembly
; Kevlar.KevlarContext.get_CancellationToken()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+68]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 28
```
```assembly
; System.Threading.CancellationToken.get_IsCancellationRequested()
       cmp       qword ptr [rdi],0
       jne       short M27_L00
       xor       eax,eax
       ret
M27_L00:
       mov       rax,[rdi]
       cmp       dword ptr [rax+20],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 23
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       movzx     edx,byte ptr [rbp-14]
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       xor       ecx,ecx
       call      qword ptr [7F2F13DC7210]; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       movzx     esi,byte ptr [rbp-14]
       mov       rdi,[rbp-10]
       xor       edx,edx
       call      qword ptr [7F2F13DC7228]; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 65
```
```assembly
; Kevlar.KevlarContext.RentChild(Kevlar.KevlarContext, System.String, Kevlar.Internal.SynchronousExecutionKind)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-68],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       mov       rdi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC77F8]; Kevlar.KevlarContext.get_CancellationToken()
       mov       [rbp-30],rax
       mov       rdi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7840]; Kevlar.KevlarContext.get_TimeProvider()
       mov       [rbp-50],rax
       mov       rdx,[rbp-50]
       mov       esi,[rbp-14]
       mov       rdi,[rbp-30]
       mov       rcx,[rbp-10]
       call      qword ptr [7F2F138BE8E0]; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       mov       [rbp-20],rax
       mov       rax,[rbp-20]
       mov       [rbp-28],rax
       mov       rax,[rbp-28]
       cmp       qword ptr [rax+18],0
       jne       short M29_L00
       mov       rdi,offset MT_Kevlar.KevlarProperties
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-48],rax
       mov       rdi,[rbp-48]
       call      qword ptr [7F2F13DC68E0]; Kevlar.KevlarProperties..ctor()
       mov       rax,[rbp-28]
       lea       rdi,[rax+18]
       mov       rsi,[rbp-48]
       call      CORINFO_HELP_ASSIGN_REF
M29_L00:
       mov       rdi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F2F138BE958]; Kevlar.KevlarContext.get_Properties()
       mov       [rbp-58],rax
       mov       rdi,[rbp-58]
       mov       rax,[rbp-20]
       mov       rsi,[rax+18]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7858]; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       mov       rax,[rbp-20]
       mov       rax,[rax+18]
       mov       [rbp-38],rax
       mov       rdi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F2F138BE958]; Kevlar.KevlarContext.get_Properties()
       mov       [rbp-60],rax
       mov       rsi,[rbp-60]
       mov       rdi,[rbp-38]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7858]; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       mov       rdi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F2F138BE958]; Kevlar.KevlarContext.get_Properties()
       mov       [rbp-40],rax
       mov       rdi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F2F138BE958]; Kevlar.KevlarContext.get_Properties()
       mov       [rbp-68],rax
       mov       rsi,[rbp-68]
       mov       rdi,[rbp-40]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7870]; Kevlar.KevlarProperties.ShareAdditionalAttemptStateWith(Kevlar.KevlarProperties)
       mov       rax,[rbp-20]
       mov       byte ptr [rax+65],1
       mov       rax,[rbp-20]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 314
```
```assembly
; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,110
       lea       rbp,[rsp+110]
       xor       eax,eax
       mov       [rbp-0D8],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       mov       [rbp-40],rax
       mov       [rbp-8],rsi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-0E0],rax
       cmp       qword ptr [rbp-0E0],0
       je        short M30_L00
       mov       rax,[rbp-0E0]
       mov       [rbp-68],rax
       jmp       short M30_L01
M30_L00:
       mov       rdi,[rbp-18]
       mov       rsi,7F2F13DB6718
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-68],rax
M30_L01:
       mov       rdi,[rbp-68]
       call      qword ptr [7F2F12E25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rax+8]
       mov       [rbp-70],rax
       lea       rax,[rbp-58]
       mov       [rbp-78],rax
       mov       rax,[rbp-20]
       mov       [rbp-80],rax
       mov       rax,[rbp-70]
       mov       [rbp-88],rax
       cmp       qword ptr [rbp-70],0
       jne       near ptr M30_L08
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-0E8],rax
       cmp       qword ptr [rbp-0E8],0
       je        short M30_L02
       mov       rax,[rbp-0E8]
       mov       [rbp-0B8],rax
       jmp       short M30_L03
M30_L02:
       mov       rdi,[rbp-18]
       mov       rsi,7F2F13DB6718
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0B8],rax
M30_L03:
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+30]
       mov       [rbp-0F0],rax
       cmp       qword ptr [rbp-0F0],0
       je        short M30_L04
       mov       rax,[rbp-0F0]
       mov       [rbp-0C8],rax
       jmp       short M30_L05
M30_L04:
       mov       rdi,[rbp-18]
       mov       rsi,7F2F13DB6A10
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0C8],rax
M30_L05:
       mov       rdi,[rbp-0C8]
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-0C0],rax
       mov       rdi,[rbp-0B8]
       call      qword ptr [7F2F12E25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,[rax]
       mov       [rbp-0D8],rax
       mov       rsi,[rbp-0D8]
       mov       rdi,[rbp-0C0]
       mov       rdx,offset Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       call      qword ptr [7F2F12E26E08]; System.MulticastDelegate.CtorClosed(System.Object, IntPtr)
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-0F8],rax
       cmp       qword ptr [rbp-0F8],0
       je        short M30_L06
       mov       rax,[rbp-0F8]
       mov       [rbp-0D0],rax
       jmp       short M30_L07
M30_L06:
       mov       rdi,[rbp-18]
       mov       rsi,7F2F13DB6718
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0D0],rax
M30_L07:
       mov       rdi,[rbp-0D0]
       call      qword ptr [7F2F12E25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       lea       rdi,[rax+8]
       mov       rsi,[rbp-0C0]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rax,[rbp-0C0]
       mov       [rbp-60],rax
       mov       rax,[rbp-60]
       mov       [rbp-88],rax
M30_L08:
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-100],rax
       cmp       qword ptr [rbp-100],0
       je        short M30_L09
       mov       rax,[rbp-100]
       mov       [rbp-0A0],rax
       jmp       short M30_L10
M30_L09:
       mov       rdi,[rbp-18]
       mov       rsi,7F2F13DB67B8
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0A0],rax
M30_L10:
       lea       rdi,[rbp-98]
       mov       rsi,[rbp-0A0]
       mov       rdx,[rbp-28]
       mov       rcx,[rbp-30]
       call      qword ptr [7F2F13DC69A0]; Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]]..ctor(System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-108],rax
       cmp       qword ptr [rbp-108],0
       je        short M30_L11
       mov       rax,[rbp-108]
       mov       [rbp-0A8],rax
       jmp       short M30_L12
M30_L11:
       mov       rdi,[rbp-18]
       mov       rsi,7F2F13DB6830
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0A8],rax
M30_L12:
       mov       r8,[rbp-98]
       mov       r9,[rbp-90]
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-0A8]
       mov       rdx,[rbp-80]
       mov       rcx,[rbp-88]
       call      qword ptr [7F2F13DC69B8]; Kevlar.Continuation`2[[System.Int32, System.Private.CoreLib],[Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.StrategyNode, System.Func`3<ContextAsyncCallback`2<System.__Canon,Int32>,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Kevlar.Outcome`1<Int32>>>, ContextAsyncCallback`2<System.__Canon,Int32>)
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-110],rax
       cmp       qword ptr [rbp-110],0
       je        short M30_L13
       mov       rax,[rbp-110]
       mov       [rbp-0B0],rax
       jmp       short M30_L14
M30_L13:
       mov       rdi,[rbp-18]
       mov       rsi,7F2F13DB6830
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0B0],rax
M30_L14:
       lea       rdi,[rbp-58]
       mov       rsi,[rbp-10]
       mov       rdx,[rbp-0B0]
       mov       rcx,[rbp-38]
       call      qword ptr [7F2F13DC69D0]; Kevlar.Continuation`2[[System.Int32, System.Private.CoreLib],[Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]].InvokeAsync(Kevlar.KevlarContext)
       mov       rax,[rbp-10]
       add       rsp,110
       pop       rbp
       ret
; Total bytes of code 881
```
```assembly
; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_IsCompletedSuccessfully()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       [rbp-10],rax
       cmp       qword ptr [rbp-10],0
       jne       short M31_L00
       mov       eax,1
       add       rsp,20
       pop       rbp
       ret
M31_L00:
       mov       rsi,[rbp-10]
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F2F12E26838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       [rbp-18],rax
       cmp       qword ptr [rbp-18],0
       je        short M31_L01
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7198]
       nop
       add       rsp,20
       pop       rbp
       ret
M31_L01:
       mov       rax,[rbp-10]
       mov       [rbp-20],rax
       mov       rax,[rbp-8]
       movsx     rsi,word ptr [rax+8]
       mov       rdi,[rbp-20]
       mov       r11,7F2F11E40358
       call      qword ptr [r11]
       cmp       eax,1
       sete      al
       movzx     eax,al
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 158
```
```assembly
; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Result()
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       [rbp-10],rax
       cmp       qword ptr [rbp-10],0
       jne       short M32_L00
       mov       rax,[rbp-8]
       vmovdqu   xmm0,xmmword ptr [rax+10]
       vmovdqu   xmmword ptr [rbp-50],xmm0
       mov       rax,[rbp-50]
       mov       rdx,[rbp-48]
       add       rsp,50
       pop       rbp
       ret
M32_L00:
       mov       rsi,[rbp-10]
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      qword ptr [7F2F12E26838]; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       mov       [rbp-18],rax
       cmp       qword ptr [rbp-18],0
       je        short M32_L01
       mov       rdi,[rbp-18]
       xor       esi,esi
       call      qword ptr [7F2F13DC71C8]
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC71E0]
       mov       [rbp-40],rax
       mov       [rbp-38],rdx
       mov       rax,[rbp-40]
       mov       rdx,[rbp-38]
       add       rsp,50
       pop       rbp
       ret
M32_L01:
       mov       rax,[rbp-10]
       mov       [rbp-20],rax
       mov       rax,[rbp-8]
       movsx     rsi,word ptr [rax+8]
       mov       rdi,[rbp-20]
       mov       r11,7F2F11E40360
       call      qword ptr [r11]
       mov       [rbp-30],rax
       mov       [rbp-28],rdx
       mov       rax,[rbp-30]
       mov       rdx,[rbp-28]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 214
```
```assembly
; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_IsSuccess()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       qword ptr [rax],0
       sete      al
       movzx     eax,al
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 34
```
```assembly
; Kevlar.Internal.ShieldEngine.ReturnChildContext(Kevlar.KevlarContext, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7A08]; Kevlar.KevlarContext.CopyChangesToParent(Kevlar.KevlarContext)
       nop
       call      M34_L00
       nop
       add       rsp,10
       pop       rbp
       ret
M34_L00:
       push      rax
       mov       rdi,[rbp-8]
       call      qword ptr [7F2F138BE910]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       nop
       add       rsp,8
       ret
; Total bytes of code 64
```
```assembly
; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_Result()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       eax,[rax+8]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 27
```
```assembly
; Kevlar.Shield.get_CurrentSnapshot()
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+38]
       mov       [rbp-10],rax
       mov       rax,[rbp-10]
       mov       [rbp-18],rax
       cmp       qword ptr [rbp-10],0
       jne       short M36_L00
       xor       eax,eax
       mov       [rbp-20],rax
       jmp       short M36_L01
M36_L00:
       mov       rax,[rbp-18]
       mov       rdi,[rax+8]
       mov       rax,[rbp-18]
       call      qword ptr [rax+18]
       mov       [rbp-20],rax
M36_L01:
       mov       rax,[rbp-20]
       mov       [rbp-28],rax
       cmp       qword ptr [rbp-20],0
       jne       short M36_L02
       mov       rax,[rbp-8]
       mov       [rbp-28],rax
M36_L02:
       mov       rax,[rbp-28]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 121
```
```assembly
; System.TimeProvider.get_System()
       push      rax
       call      qword ptr [7F2F129CF5B8]
       mov       rax,[rax]
       add       rsp,8
       ret
; Total bytes of code 15
```
```assembly
; Kevlar.Internal.ShieldEngine.ExecuteWithContextAsyncCore[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.TimeProvider, System.String, System.__Canon, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.Threading.CancellationToken)
       push      rbp
       sub       rsp,1A0
       lea       rbp,[rsp+1A0]
       xor       eax,eax
       mov       [rbp-148],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-140],xmm8
       mov       rax,0FFFFFFFFFFFFFF10
M38_L00:
       vmovdqa   xmmword ptr [rbp+rax-40],xmm8
       vmovdqa   xmmword ptr [rbp+rax-30],xmm8
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       add       rax,30
       jne       short M38_L00
       mov       [rbp-40],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       [rbp-30],r8
       mov       [rbp-38],r9
       call      qword ptr [7F2F138BE880]; Kevlar.Internal.KevlarMetrics.get_DurationEnabled()
       test      eax,eax
       jne       short M38_L01
       xor       eax,eax
       mov       [rbp-88],rax
       jmp       short M38_L02
M38_L01:
       call      qword ptr [7F2F138BE898]
       mov       [rbp-88],rax
M38_L02:
       mov       rax,[rbp-88]
       mov       [rbp-40],rax
       lea       rdi,[rbp+20]
       call      qword ptr [7F2F138BE8B0]; System.Threading.CancellationToken.get_IsCancellationRequested()
       test      eax,eax
       je        near ptr M38_L06
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-28]
       xor       edx,edx
       call      qword ptr [7F2F138BE8C8]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, System.String, Boolean)
       cmp       qword ptr [rbp+18],0
       je        near ptr M38_L05
       mov       rdi,[rbp+20]
       mov       rcx,[rbp-28]
       mov       rdx,[rbp-20]
       xor       esi,esi
       call      qword ptr [7F2F138BE8E0]; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       mov       [rbp-70],rax
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-158],rax
       cmp       qword ptr [rbp-158],0
       je        short M38_L03
       mov       rax,[rbp-158]
       mov       [rbp-120],rax
       jmp       short M38_L04
M38_L03:
       mov       rdi,[rbp-10]
       mov       rsi,7F2F13CC39D8
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-120],rax
M38_L04:
       mov       rdi,[rbp-70]
       cmp       [rdi],edi
       call      qword ptr [7F2F138BE8F8]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       [rbp-128],rax
       mov       rcx,[rbp-128]
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-30]
       mov       rdi,[rbp-120]
       call      qword ptr [7F2F138BE7C0]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-70]
       call      qword ptr [7F2F138BE910]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
M38_L05:
       mov       rdi,offset MT_System.OperationCanceledException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-0F8],rax
       mov       rdi,[rbp-0F8]
       mov       rsi,[rbp+20]
       call      qword ptr [7F2F138BE928]
       mov       rdi,[rbp-0F8]
       call      qword ptr [7F2F138BE940]
       mov       [rbp-108],rax
       mov       [rbp-100],rdx
       mov       rdi,[rbp-108]
       mov       rsi,[rbp-100]
       call      qword ptr [7F2F138BE850]
       mov       [rbp-118],rax
       mov       [rbp-110],rdx
       mov       rax,[rbp-118]
       mov       rdx,[rbp-110]
       add       rsp,1A0
       pop       rbp
       ret
M38_L06:
       mov       rdi,[rbp+20]
       mov       rcx,[rbp-28]
       mov       rdx,[rbp-20]
       xor       esi,esi
       call      qword ptr [7F2F138BE8E0]; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       mov       [rbp-48],rax
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7F2F138BE958]; Kevlar.KevlarContext.get_Properties()
       mov       [rbp-130],rax
       mov       rdx,[rbp-130]
       mov       rsi,[rbp-30]
       mov       rax,[rbp-38]
       mov       rdi,[rax+8]
       mov       rax,[rbp-38]
       call      qword ptr [rax+18]
       nop
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-160],rax
       cmp       qword ptr [rbp-160],0
       je        short M38_L07
       mov       rax,[rbp-160]
       mov       [rbp-90],rax
       jmp       short M38_L08
M38_L07:
       mov       rdi,[rbp-10]
       mov       rsi,7F2F13CC3600
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-90],rax
M38_L08:
       lea       rdi,[rbp-68]
       mov       rsi,[rbp-90]
       mov       rdx,[rbp-18]
       mov       rcx,[rbp-30]
       mov       r8,[rbp+10]
       mov       r9,[rbp-48]
       call      qword ptr [7F2F138BE6D0]; Kevlar.Internal.ShieldEngine.RunWithContextAsync[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]](Kevlar.StrategyNode, System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>, Kevlar.KevlarContext)
       lea       rdi,[rbp-68]
       call      qword ptr [7F2F138BE970]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_IsCompletedSuccessfully()
       test      eax,eax
       je        near ptr M38_L12
       lea       rdi,[rbp-68]
       call      qword ptr [7F2F138BE988]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Result()
       mov       [rbp-0B8],rax
       mov       [rbp-0B0],rdx
       vmovdqu   xmm0,xmmword ptr [rbp-0B8]
       vmovdqu   xmmword ptr [rbp-80],xmm0
       lea       rdi,[rbp-80]
       call      qword ptr [7F2F138BE9A0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_IsSuccess()
       mov       [rbp-13C],eax
       mov       edx,[rbp-13C]
       mov       rsi,[rbp-48]
       mov       rdi,[rbp-40]
       call      qword ptr [7F2F138BE9B8]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-168],rax
       cmp       qword ptr [rbp-168],0
       je        short M38_L09
       mov       rax,[rbp-168]
       mov       [rbp-0C0],rax
       jmp       short M38_L10
M38_L09:
       mov       rdi,[rbp-10]
       mov       rsi,7F2F13CC39D8
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0C0],rax
M38_L10:
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7F2F138BE8F8]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       [rbp-148],rax
       mov       rcx,[rbp-148]
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-30]
       mov       rdi,[rbp-0C0]
       call      qword ptr [7F2F138BE7C0]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-48]
       call      qword ptr [7F2F138BE910]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       lea       rdi,[rbp-80]
       call      qword ptr [7F2F138BE9A0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_IsSuccess()
       test      eax,eax
       jne       short M38_L11
       mov       rdi,[rbp-80]
       mov       rsi,[rbp-78]
       call      qword ptr [7F2F138BE850]
       mov       [rbp-0E0],rax
       mov       [rbp-0D8],rdx
       mov       rax,[rbp-0E0]
       mov       rdx,[rbp-0D8]
       add       rsp,1A0
       pop       rbp
       ret
M38_L11:
       lea       rdi,[rbp-80]
       call      qword ptr [7F2F138BE9D0]; Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]].get_Result()
       mov       [rbp-14C],eax
       mov       esi,[rbp-14C]
       lea       rdi,[rbp-0D0]
       call      qword ptr [7F2F138BE9E8]; System.Threading.Tasks.ValueTask`1[[System.Int32, System.Private.CoreLib]]..ctor(Int32)
       mov       rax,[rbp-0D0]
       mov       rdx,[rbp-0C8]
       add       rsp,1A0
       pop       rbp
       ret
M38_L12:
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+20]
       mov       [rbp-170],rax
       cmp       qword ptr [rbp-170],0
       je        short M38_L13
       mov       rax,[rbp-170]
       mov       [rbp-98],rax
       jmp       short M38_L14
M38_L13:
       mov       rdi,[rbp-10]
       mov       rsi,7F2F13CC3798
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-98],rax
M38_L14:
       lea       rdi,[rsp]
       lea       rsi,[rbp-68]
       mov       rcx,[rsi]
       mov       [rsp],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rcx,[rsi]
       mov       [rsp+10],rcx
       add       rsi,8
       add       rdi,8
       movsq
       mov       rdi,[rbp-98]
       mov       rsi,[rbp-48]
       mov       rdx,[rbp-30]
       mov       rcx,[rbp+18]
       mov       r8,[rbp-40]
       call      qword ptr [7F2F138BE778]
       mov       [rbp-0A8],rax
       mov       [rbp-0A0],rdx
       mov       rax,[rbp-0A8]
       mov       rdx,[rbp-0A0]
       add       rsp,1A0
       pop       rbp
       ret
       sub       rsp,28
       mov       [rbp-0E8],rdi
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-48]
       xor       edx,edx
       call      qword ptr [7F2F138BE9B8]; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+28]
       mov       [rbp-178],rax
       cmp       qword ptr [rbp-178],0
       je        short M38_L15
       mov       rax,[rbp-178]
       mov       [rbp-0F0],rax
       jmp       short M38_L16
M38_L15:
       mov       rdi,[rbp-10]
       mov       rsi,7F2F13CC39D8
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-0F0],rax
M38_L16:
       mov       rdi,[rbp-48]
       cmp       [rdi],edi
       call      qword ptr [7F2F138BE8F8]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       [rbp-138],rax
       mov       rcx,[rbp-138]
       mov       rsi,[rbp+18]
       mov       rdx,[rbp-30]
       mov       rdi,[rbp-0F0]
       call      qword ptr [7F2F138BE7C0]; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       mov       rdi,[rbp-48]
       call      qword ptr [7F2F138BE910]; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 1331
```
```assembly
; System.Diagnostics.Metrics.Instrument.get_Enabled()
       mov       rax,[rdi+8]
       cmp       qword ptr [rax+8],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 16
```
```assembly
; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,0F0
       lea       rbp,[rsp+0F0]
       vxorps    xmm8,xmm8,xmm8
       mov       rax,0FFFFFFFFFFFFFF40
M40_L00:
       vmovdqa   xmmword ptr [rbp+rax-20],xmm8
       vmovdqa   xmmword ptr [rbp+rax-10],xmm8
       vmovdqa   xmmword ptr [rax+rbp],xmm8
       add       rax,30
       jne       short M40_L00
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       mov       [rbp-20],rcx
       cmp       qword ptr [rbp-8],0
       je        near ptr M40_L03
       mov       rax,7F272D800BA0
       mov       rdi,[rax]
       cmp       [rdi],edi
       call      qword ptr [7F2F138BEA18]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M40_L03
       lea       rdi,[rbp-0B0]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2F13DC7258]
       lea       rax,[rbp-0B0]
       mov       [rbp-0C0],rax
       mov       rax,7F2F10A0B630
       mov       [rbp-0C8],rax
       movzx     eax,byte ptr [rbp-14]
       test      eax,eax
       jne       short M40_L01
       mov       rax,[rbp-0C0]
       mov       [rbp-0D0],rax
       mov       rax,[rbp-0C8]
       mov       [rbp-0D8],rax
       mov       rax,7F2F10A0B678
       mov       [rbp-0E0],rax
       jmp       short M40_L02
M40_L01:
       mov       rax,[rbp-0C0]
       mov       [rbp-0D0],rax
       mov       rax,[rbp-0C8]
       mov       [rbp-0D8],rax
       mov       rax,7F2F10A0B6A0
       mov       [rbp-0E0],rax
M40_L02:
       mov       rdi,[rbp-0D0]
       mov       rsi,[rbp-0D8]
       mov       rdx,[rbp-0E0]
       call      qword ptr [7F2F13DC7270]
       mov       rdi,[rbp-8]
       call      qword ptr [7F2F13DC7288]
       mov       [rbp-0B8],rax
       lea       rdi,[rbp-0B8]
       call      qword ptr [7F2F13DC72A0]
       vmovsd    qword ptr [rbp-0E8],xmm0
       vmovsd    xmm0,qword ptr [rbp-0E8]
       lea       rsi,[rbp-0B0]
       mov       rax,7F272D800BA0
       mov       rdi,[rax]
       mov       rdx,[rbp-20]
       call      qword ptr [7F2F13DC72B8]
M40_L03:
       nop
       add       rsp,0F0
       pop       rbp
       ret
; Total bytes of code 370
```
```assembly
; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,0D0
       lea       rbp,[rsp+0D0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0D0],ymm8
       vmovdqu   ymmword ptr [rbp-0B0],ymm8
       vmovdqu   ymmword ptr [rbp-90],ymm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqa   xmmword ptr [rbp-30],xmm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-18],rdx
       mov       rax,7F272D800B48
       mov       rdi,[rax]
       cmp       [rdi],edi
       call      qword ptr [7F2F138BEA18]; System.Diagnostics.Metrics.Instrument.get_Enabled()
       test      eax,eax
       je        near ptr M41_L02
       lea       rdi,[rbp-0A8]
       mov       rsi,[rbp-8]
       call      qword ptr [7F2F13DC7258]
       lea       rax,[rbp-0A8]
       mov       [rbp-0B0],rax
       mov       rax,7F2F10A0B630
       mov       [rbp-0B8],rax
       movzx     eax,byte ptr [rbp-0C]
       test      eax,eax
       jne       short M41_L00
       mov       rax,[rbp-0B0]
       mov       [rbp-0C0],rax
       mov       rax,[rbp-0B8]
       mov       [rbp-0C8],rax
       mov       rax,7F2F10A0B678
       mov       [rbp-0D0],rax
       jmp       short M41_L01
M41_L00:
       mov       rax,[rbp-0B0]
       mov       [rbp-0C0],rax
       mov       rax,[rbp-0B8]
       mov       [rbp-0C8],rax
       mov       rax,7F2F10A0B6A0
       mov       [rbp-0D0],rax
M41_L01:
       mov       rdi,[rbp-0C0]
       mov       rsi,[rbp-0C8]
       mov       rdx,[rbp-0D0]
       call      qword ptr [7F2F13DC7270]
       lea       rdx,[rbp-0A8]
       mov       rax,7F272D800B48
       mov       rdi,[rax]
       mov       rcx,[rbp-18]
       mov       esi,1
       call      qword ptr [7F2F13DC72D0]
M41_L02:
       nop
       add       rsp,0D0
       pop       rbp
       ret
; Total bytes of code 326
```
```assembly
; Kevlar.KevlarContext.get_TimeProvider()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+38]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 28
```
```assembly
; Kevlar.KevlarContext.Rent(System.Threading.CancellationToken, Kevlar.Internal.SynchronousExecutionKind, System.TimeProvider, System.String)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       [rbp-18],rdx
       mov       [rbp-20],rcx
       mov       rdi,offset MT_Kevlar.KevlarContext
       call      qword ptr [7F2F12E25710]; System.Runtime.CompilerServices.StaticsHelpers.GetGCStaticBase(System.Runtime.CompilerServices.MethodTable*)
       mov       rax,7F272D8013C0
       mov       rdi,[rax]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC6550]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Rent()
       mov       [rbp-28],rax
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC6568]; Kevlar.KevlarContext.set_CancellationToken(System.Threading.CancellationToken)
       mov       rdi,[rbp-28]
       mov       esi,[rbp-0C]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC6580]; Kevlar.KevlarContext.set_SynchronousExecutionKind(Kevlar.Internal.SynchronousExecutionKind)
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC6598]; Kevlar.KevlarContext.set_TimeProvider(System.TimeProvider)
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC65B0]; Kevlar.KevlarContext.set_ShieldName(System.String)
       mov       rdi,[rbp-28]
       mov       esi,0FFFFFFFF
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC65C8]; Kevlar.KevlarContext.set_StrategyIndex(Int32)
       mov       rdi,[rbp-28]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC65E0]; Kevlar.KevlarContext.set_AttemptNumber(Int32)
       mov       rdi,[rbp-28]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC65F8]; Kevlar.KevlarContext.set_TelemetryListener(Kevlar.IKevlarTelemetryListener)
       mov       rax,[rbp-28]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 190
```
```assembly
; Kevlar.KevlarProperties..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rdi,offset MT_Kevlar.KevlarProperties+AdditionalAttemptState
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-10],rax
       mov       rdi,[rbp-10]
       call      qword ptr [7F2F13DC68F8]; Kevlar.KevlarProperties+AdditionalAttemptState..ctor()
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       mov       rdi,[rbp-8]
       call      qword ptr [7F2F12E2C240]; System.Object..ctor()
       mov       rax,[rbp-8]
       mov       rsi,[rax+8]
       mov       rax,[rbp-8]
       lea       rdi,[rax+28]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 104
```
```assembly
; Kevlar.KevlarContext.get_Properties()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+8]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 28
```
```assembly
; Kevlar.KevlarProperties.CopyTo(Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,0C0
       lea       rbp,[rsp+0C0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0C0],ymm8
       vmovdqu   ymmword ptr [rbp-0A0],ymm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       xor       eax,eax
       mov       [rbp-40],rax
       mov       [rbp-30],rdi
       mov       [rbp-38],rsi
       mov       dword ptr [rbp-0B0],3E8
       mov       rdi,[rbp-30]
       call      qword ptr [7F2F13DC78B8]; Kevlar.KevlarProperties.get_SuppressAdditionalAttempts()
       test      eax,eax
       je        short M46_L00
       mov       rdi,7F2F13E05BC0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-38]
       mov       esi,1
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC78D0]
M46_L00:
       mov       rax,[rbp-30]
       cmp       qword ptr [rax+10],0
       jne       short M46_L01
       mov       rdi,7F2F13E05BC4
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0C0
       pop       rbp
       ret
M46_L01:
       mov       rax,[rbp-30]
       mov       rax,[rax+10]
       mov       [rbp-0A0],rax
       mov       rdi,[rbp-0A0]
       mov       rsi,7F2F13E05BC8
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0A0]
       mov       [rbp-0B8],rax
       mov       rdi,[rbp-0B8]
       mov       rax,[rbp-30]
       mov       rdx,[rax+38]
       mov       rax,[rbp-30]
       mov       rcx,[rax+40]
       mov       rsi,[rbp-38]
       mov       rax,[rbp-0B8]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
       mov       rax,[rbp-30]
       cmp       qword ptr [rax+18],0
       je        near ptr M46_L05
       lea       rsi,[rbp-68]
       mov       rax,[rbp-30]
       mov       rdi,[rax+18]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7900]
       nop
       jmp       near ptr M46_L03
M46_L02:
       mov       rdi,7F2F13E05CD0
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rsi,[rbp-80]
       lea       rdi,[rbp-68]
       mov       rdx,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2F13DC7918]
       lea       rdi,[rbp-80]
       mov       rsi,offset MT_System.Collections.Generic.KeyValuePair<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>
       call      qword ptr [7F2F13DC7930]
       mov       [rbp-98],rax
       lea       rdi,[rbp-80]
       mov       rsi,offset MT_System.Collections.Generic.KeyValuePair<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>
       call      qword ptr [7F2F13DC7948]
       mov       [rbp-90],rax
       mov       [rbp-88],rdx
       mov       rax,[rbp-98]
       mov       [rbp-0A8],rax
       mov       rdi,[rbp-0A8]
       mov       rsi,7F2F13E05CD8
       call      CORINFO_HELP_CLASSPROFILE32
       mov       rax,[rbp-0A8]
       mov       [rbp-0C0],rax
       mov       rdi,[rbp-0C0]
       mov       rdx,[rbp-90]
       mov       rcx,[rbp-88]
       mov       rsi,[rbp-38]
       mov       rax,[rbp-0C0]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
M46_L03:
       mov       eax,[rbp-0B0]
       dec       eax
       mov       [rbp-0B0],eax
       cmp       dword ptr [rbp-0B0],0
       jg        short M46_L04
       lea       rdi,[rbp-0B0]
       mov       esi,5C
       call      CORINFO_HELP_PATCHPOINT
M46_L04:
       lea       rdi,[rbp-68]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2F13DC7960]
       test      eax,eax
       jne       near ptr M46_L02
       mov       rdi,7F2F13E05DE0
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       call      M46_L06
       nop
M46_L05:
       mov       rdi,7F2F13E05DE8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0C0
       pop       rbp
       ret
M46_L06:
       push      rax
       mov       rdi,7F2F13E05DE4
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdi,[rbp-68]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2F13DC7978]
       nop
       add       rsp,8
       ret
; Total bytes of code 638
```
```assembly
; Kevlar.KevlarProperties.ShareAdditionalAttemptStateWith(Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-10]
       mov       rdi,[rax+28]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC79A8]; Kevlar.KevlarProperties+AdditionalAttemptState.AddReference()
       mov       rax,[rbp-10]
       mov       rsi,[rax+28]
       mov       rax,[rbp-8]
       lea       rdi,[rax+28]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 62
```
```assembly
; Kevlar.Internal.ShieldEngine+<>c__13`2[[System.Int32, System.Private.CoreLib],[System.__Canon, System.Private.CoreLib]].<RunWithContextAsync>b__13_0(ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-28],rdx
       mov       [rbp-20],rcx
       mov       [rbp-30],r8
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-40],rax
       mov       rax,[rbp-40]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+18]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-48],0
       je        short M48_L00
       mov       rax,[rbp-48]
       mov       [rbp-38],rax
       jmp       short M48_L01
M48_L00:
       mov       rdi,[rbp-40]
       mov       rsi,7F2F13DB7000
       call      qword ptr [7F2F12E2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-38],rax
M48_L01:
       mov       rdx,[rbp-28]
       mov       rcx,[rbp-20]
       mov       rdi,[rbp-18]
       mov       rsi,[rbp-38]
       mov       r8,[rbp-30]
       call      qword ptr [7F2F13DC6AA8]; Kevlar.Internal.ShieldEngine.InvokeWithContextAsync[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]](ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       mov       rax,[rbp-18]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 141
```
```assembly
; Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]]..ctor(System.__Canon, System.Func`3<System.__Canon,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Int32>>)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       [rbp-20],rcx
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-18]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 63
```
```assembly
; Kevlar.Continuation`2[[System.Int32, System.Private.CoreLib],[Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.StrategyNode, System.Func`3<ContextAsyncCallback`2<System.__Canon,Int32>,Kevlar.KevlarContext,System.Threading.Tasks.ValueTask`1<Kevlar.Outcome`1<Int32>>>, ContextAsyncCallback`2<System.__Canon,Int32>)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       [rbp-20],rcx
       mov       [rbp-30],r8
       mov       [rbp-28],r9
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-18]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       mov       rsi,[rbp-20]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-8]
       lea       rdi,[rax+10]
       lea       rsi,[rbp-30]
       call      CORINFO_HELP_ASSIGN_BYREF
       call      CORINFO_HELP_ASSIGN_BYREF
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 93
```
```assembly
; Kevlar.Continuation`2[[System.Int32, System.Private.CoreLib],[Kevlar.Internal.ShieldEngine+ContextAsyncCallback`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]].InvokeAsync(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp-68],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       vmovdqa   xmmword ptr [rbp-40],xmm8
       mov       [rbp-30],rax
       mov       [rbp-8],rdx
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       [rbp-28],rcx
       mov       rax,[rbp-10]
       cmp       qword ptr [rax+8],0
       jne       short M51_L00
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-30],rax
       mov       rdi,[rbp-30]
       mov       rsi,7F2F10A0B5D0
       call      qword ptr [7F2F13505638]
       mov       rdi,[rbp-30]
       call      qword ptr [7F2F138BE940]
       mov       [rbp-40],rax
       mov       [rbp-38],rdx
       mov       rsi,[rbp-40]
       mov       rdx,[rbp-38]
       lea       rdi,[rbp-60]
       call      qword ptr [7F2F13DC6A78]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.Outcome`1<Int32>)
       mov       rax,[rbp-18]
       vmovdqu   ymm0,ymmword ptr [rbp-60]
       vmovdqu   ymmword ptr [rax],ymm0
       mov       rax,[rbp-18]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
M51_L00:
       mov       rax,[rbp-10]
       cmp       qword ptr [rax],0
       jne       short M51_L01
       mov       rax,[rbp-10]
       mov       rdx,[rax+10]
       mov       rax,[rbp-10]
       mov       rcx,[rax+18]
       mov       rax,[rbp-10]
       mov       rax,[rax+8]
       mov       [rbp-68],rax
       mov       rax,[rbp-68]
       mov       rsi,[rbp-18]
       mov       r8,[rbp-28]
       mov       rdi,[rax+8]
       mov       rax,[rbp-68]
       call      qword ptr [rax+18]
       mov       rax,[rbp-18]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
M51_L01:
       mov       rax,[rbp-10]
       mov       rcx,[rax]
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-20]
       mov       r8,[rbp-28]
       call      qword ptr [7F2F13DC6A90]
       mov       rax,[rbp-18]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 283
```
```assembly
; System.Runtime.CompilerServices.CastHelpers.IsInstanceOfClass(Void*, System.Object)
       push      rbp
       mov       rbp,rsp
       test      rsi,rsi
       je        short M52_L02
       mov       rax,[rsi]
       cmp       rax,rdi
       je        short M52_L02
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M52_L02
M52_L00:
       test      rax,rax
       je        short M52_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M52_L02
       test      rax,rax
       je        short M52_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M52_L02
       test      rax,rax
       jne       short M52_L03
M52_L01:
       xor       esi,esi
M52_L02:
       mov       rax,rsi
       pop       rbp
       ret
M52_L03:
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M52_L02
       test      rax,rax
       je        short M52_L01
       mov       rax,[rax+10]
       cmp       rax,rdi
       je        short M52_L02
       jmp       short M52_L00
; Total bytes of code 91
```
```assembly
; Kevlar.KevlarContext.CopyChangesToParent(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp-38],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       mov       rax,[rax+20]
       mov       [rbp-18],rax
       xor       eax,eax
       mov       [rbp-20],eax
       lea       rsi,[rbp-20]
       mov       rdi,[rbp-18]
       call      qword ptr [7F2F12E25980]; System.Threading.Monitor.Enter(System.Object, Boolean ByRef)
       mov       rdi,[rbp-8]
       call      qword ptr [7F2F138BE8F8]; Kevlar.KevlarContext.get_PropertiesForCompletion()
       mov       [rbp-28],rax
       mov       rax,[rbp-8]
       mov       rax,[rax+18]
       mov       [rbp-30],rax
       mov       rdi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F2F138BE958]; Kevlar.KevlarContext.get_Properties()
       mov       [rbp-38],rax
       mov       rdx,[rbp-38]
       mov       rsi,[rbp-30]
       mov       rdi,[rbp-28]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7A20]; Kevlar.KevlarProperties.ApplyChangesSince(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       nop
       call      M53_L00
       nop
       add       rsp,40
       pop       rbp
       ret
M53_L00:
       push      rax
       movzx     eax,byte ptr [rbp-20]
       test      eax,eax
       je        short M53_L01
       mov       rdi,[rbp-18]
       call      qword ptr [7F2F12E26808]; System.Threading.Monitor.Exit(System.Object)
M53_L01:
       nop
       add       rsp,8
       ret
; Total bytes of code 165
```
```assembly
; Kevlar.KevlarContext.Return(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,7F272D8013C0
       mov       rdi,[rax]
       mov       rsi,[rbp-8]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7300]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Return(System.__Canon)
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 46
```
```assembly
; Kevlar.KevlarContext.get_PropertiesForCompletion()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       movzx     eax,byte ptr [rax+64]
       test      eax,eax
       jne       short M55_L00
       mov       rax,[rbp-8]
       mov       rax,[rax+8]
       add       rsp,10
       pop       rbp
       ret
M55_L00:
       mov       rax,[rbp-8]
       mov       rax,[rax+10]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 54
```
```assembly
; Kevlar.Internal.ShieldEngine.NotifyCompleted[[System.__Canon, System.Private.CoreLib]](System.Action`2<System.__Canon,Kevlar.KevlarProperties>, System.__Canon, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       [rbp-20],rcx
       cmp       qword ptr [rbp-10],0
       je        short M56_L00
       mov       rax,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-20]
       mov       rdi,[rax+8]
       mov       rax,[rbp-10]
       call      qword ptr [rax+18]
M56_L00:
       nop
M56_L01:
       add       rsp,30
       pop       rbp
       ret
       push      rax
       mov       [rbp-28],rdi
       lea       rax,[M56_L01]
       add       rsp,8
       ret
; Total bytes of code 86
```
```assembly
; Kevlar.Internal.ShieldEngine.RecordExecution(Int64, Kevlar.KevlarContext, Boolean)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-28],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-14],edx
       mov       rdi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC71F8]; Kevlar.KevlarContext.get_ShieldName()
       mov       [rbp-20],rax
       mov       rsi,[rbp-20]
       movzx     edx,byte ptr [rbp-14]
       mov       rdi,[rbp-8]
       mov       rcx,[rbp-10]
       call      qword ptr [7F2F13DC7210]; Kevlar.Internal.KevlarMetrics.Duration(Int64, System.String, Boolean, Kevlar.KevlarContext)
       mov       rdi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC71F8]; Kevlar.KevlarContext.get_ShieldName()
       mov       [rbp-28],rax
       mov       rdi,[rbp-28]
       movzx     esi,byte ptr [rbp-14]
       mov       rdx,[rbp-10]
       call      qword ptr [7F2F13DC7228]; Kevlar.Internal.KevlarMetrics.Execution(System.String, Boolean, Kevlar.KevlarContext)
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 111
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Rent()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-18],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rdi,[rbp-10]
       call      qword ptr [7F2F13DC67D8]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ThrowIfDisposed()
       mov       rdi,[rbp-10]
       call      qword ptr [7F2F13DC67F0]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].RentWithoutLifecycle()
       mov       [rbp-18],rax
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+1C],0
       jne       short M58_L00
       mov       rax,[rbp-18]
       add       rsp,20
       pop       rbp
       ret
M58_L00:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7F2F13DC6808]
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       call      qword ptr [7F2F13DC6820]
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 102
```
```assembly
; Kevlar.KevlarContext.set_CancellationToken(System.Threading.CancellationToken)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       lea       rdi,[rax+68]
       lea       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_BYREF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Kevlar.KevlarContext.set_SynchronousExecutionKind(Kevlar.Internal.SynchronousExecutionKind)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       rax,[rbp-8]
       mov       ecx,[rbp-0C]
       mov       [rax+60],ecx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 33
```
```assembly
; Kevlar.KevlarContext.set_TimeProvider(System.TimeProvider)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       lea       rdi,[rax+38]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Kevlar.KevlarContext.set_ShieldName(System.String)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Kevlar.KevlarContext.set_StrategyIndex(Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       rax,[rbp-8]
       mov       ecx,[rbp-0C]
       mov       [rax+5C],ecx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 33
```
```assembly
; Kevlar.KevlarContext.set_AttemptNumber(Int32)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-0C],esi
       mov       rax,[rbp-8]
       mov       ecx,[rbp-0C]
       mov       [rax+58],ecx
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 33
```
```assembly
; Kevlar.KevlarContext.set_TelemetryListener(Kevlar.IKevlarTelemetryListener)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       lea       rdi,[rax+40]
       mov       rsi,[rbp-10]
       call      CORINFO_HELP_ASSIGN_REF
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState..ctor()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       dword ptr [rax+8],1
       mov       rdi,[rbp-8]
       call      qword ptr [7F2F12E2C240]; System.Object..ctor()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 42
```
```assembly
; System.Object..ctor()
       ret
; Total bytes of code 1
```
```assembly
; Kevlar.KevlarProperties.get_SuppressAdditionalAttempts()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rdi,[rax+28]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7990]; Kevlar.KevlarProperties+AdditionalAttemptState.get_IsSuppressed()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 37
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState.AddReference()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+8]
       call      qword ptr [7F2F138BDD88]; System.Threading.Interlocked.Increment(Int32 ByRef)
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 41
```
```assembly
; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       push      rbp
       push      r15
       push      r14
       push      r13
       push      r12
       push      rbx
       sub       rsp,88
       lea       rbp,[rsp+0B0]
       mov       rdx,rsi
       mov       [rbp-8C],rdx
       mov       rsi,rdi
       mov       [rbp-94],rsi
       xor       edi,edi
       mov       [rbp-9C],rdi
       mov       ecx,0FFFFFFFF
       mov       [rbp-84],ecx
       xor       r8d,r8d
       mov       [rbp-0A4],r8
       lea       rdi,[rbp-80]
       call      qword ptr [7F2F129CEF00]; CORINFO_HELP_JIT_PINVOKE_BEGIN
       mov       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       mov       rdx,[rbp-8C]
       mov       rsi,[rbp-94]
       mov       rdi,[rbp-9C]
       mov       ecx,[rbp-84]
       mov       r8,[rbp-0A4]
       call      qword ptr [rax]
       mov       rbx,rax
       lea       rdi,[rbp-80]
       call      qword ptr [7F2F129CEF08]; CORINFO_HELP_JIT_PINVOKE_END
       mov       rax,rbx
       add       rsp,88
       pop       rbx
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       pop       rbp
       ret
; Total bytes of code 162
```
```assembly
; Kevlar.Internal.ShieldEngine.InvokeWithContextAsync[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]](ContextAsyncCallback`2<System.__Canon,Int32>, Kevlar.KevlarContext)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       xor       eax,eax
       mov       [rbp-78],rax
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       mov       [rbp-8],rsi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-28],rdx
       mov       [rbp-20],rcx
       mov       [rbp-30],r8
       lea       rdi,[rbp-68]
       call      qword ptr [7F2F13DC6CD0]; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].Create()
       vmovdqu   xmm0,xmmword ptr [rbp-28]
       vmovdqu   xmmword ptr [rbp-50],xmm0
       mov       rax,[rbp-30]
       mov       [rbp-78],rax
       mov       dword ptr [rbp-70],0FFFFFFFF
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+18]
       mov       [rbp-88],rax
       cmp       qword ptr [rbp-88],0
       je        short M71_L00
       mov       rax,[rbp-88]
       mov       [rbp-80],rax
       jmp       short M71_L01
M71_L00:
       mov       rdi,[rbp-18]
       mov       rsi,7F2F13DB7C78
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-80],rax
M71_L01:
       lea       rdx,[rbp-78]
       lea       rdi,[rbp-68]
       mov       rsi,[rbp-80]
       call      qword ptr [7F2F13DC6C88]; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       lea       rdi,[rbp-68]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2F13DC6CE8]; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Task()
       mov       rax,[rbp-10]
       add       rsp,90
       pop       rbp
       ret
; Total bytes of code 207
```
```assembly
; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.Outcome`1<Int32>)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-18],rsi
       mov       [rbp-10],rdx
       mov       rax,[rbp-8]
       lea       rdi,[rax+10]
       lea       rsi,[rbp-18]
       call      CORINFO_HELP_ASSIGN_BYREF
       movsq
       mov       rax,[rbp-8]
       xor       ecx,ecx
       mov       [rax],rcx
       mov       rax,[rbp-8]
       mov       byte ptr [rax+0A],1
       mov       rax,[rbp-8]
       mov       word ptr [rax+8],0
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 74
```
```assembly
; System.Threading.Monitor.Enter(System.Object, Boolean ByRef)
       push      rbp
       push      r15
       push      rbx
       lea       rbp,[rsp+10]
       mov       r15,rdi
       mov       rbx,rsi
       cmp       byte ptr [rbx],0
       je        short M73_L00
       call      qword ptr [7F2F129E69F0]
       int       3
M73_L00:
       test      r15,r15
       je        short M73_L02
       mov       rdi,r15
       call      qword ptr [7F2F129E69B0]
       test      eax,eax
       jne       short M73_L01
       mov       rdi,r15
       call      qword ptr [7F2F129E69C0]
M73_L01:
       mov       byte ptr [rbx],1
       pop       rbx
       pop       r15
       pop       rbp
       ret
M73_L02:
       xor       edi,edi
       call      qword ptr [7F2F129E1208]
       int       3
; Total bytes of code 71
```
```assembly
; Kevlar.KevlarProperties.ApplyChangesSince(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       [rbp-18],rdx
       mov       rdi,[rbp-8]
       call      qword ptr [7F2F13DC78B8]; Kevlar.KevlarProperties.get_SuppressAdditionalAttempts()
       test      eax,eax
       je        short M74_L00
       mov       rdi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC78B8]; Kevlar.KevlarProperties.get_SuppressAdditionalAttempts()
       test      eax,eax
       jne       short M74_L00
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC78B8]; Kevlar.KevlarProperties.get_SuppressAdditionalAttempts()
       test      eax,eax
       jne       short M74_L00
       mov       rdi,[rbp-18]
       mov       esi,1
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC78D0]
M74_L00:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-8]
       mov       rdx,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7A38]; Kevlar.KevlarProperties.RemoveMissingValuesFrom(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       mov       rdx,[rbp-18]
       call      qword ptr [7F2F13DC7A50]; Kevlar.KevlarProperties.CopyChangedValuesTo(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       nop
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 130
```
```assembly
; System.Threading.Monitor.Exit(System.Object)
       push      rbp
       push      rbx
       push      rax
       lea       rbp,[rsp+10]
       mov       rbx,rdi
       test      rbx,rbx
       je        short M75_L01
       mov       rdi,rbx
       call      qword ptr [7F2F129E69F8]
       test      eax,eax
       je        short M75_L00
       mov       rsi,rbx
       mov       edi,eax
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       pop       rbx
       pop       rbp
       jmp       qword ptr [rax]
M75_L00:
       add       rsp,8
       pop       rbx
       pop       rbp
       ret
M75_L01:
       xor       edi,edi
       call      qword ptr [7F2F129E1208]
       int       3
; Total bytes of code 66
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].Return(System.__Canon)
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rdi,[rbp-10]
       mov       rsi,7F2F10A044E0
       call      qword ptr [7F2F13505830]; System.ArgumentNullException.ThrowIfNull(System.Object, System.String)
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+1C],0
       je        short M76_L00
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2F13DC6808]
       nop
       add       rsp,10
       pop       rbp
       ret
M76_L00:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2F13DC7318]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       test      eax,eax
       jne       short M76_L01
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2F13DC6808]
       nop
       add       rsp,10
       pop       rbp
       ret
M76_L01:
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2F13DC7330]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ReturnWithoutReset(System.__Canon)
       mov       rdi,[rbp-8]
       call      qword ptr [7F2F13DC7348]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ClearIfDisposed()
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 139
```
```assembly
; Kevlar.KevlarContext.get_ShieldName()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       mov       rax,[rax+30]
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 28
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ThrowIfDisposed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       cmp       dword ptr [rax+1C],0
       je        short M78_L00
       mov       rax,[rbp-10]
       mov       rdi,[rax]
       call      qword ptr [7F2F13DC6820]
M78_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 48
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].RentWithoutLifecycle()
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-18],rax
       xor       eax,eax
       mov       [rbp-1C],eax
       cmp       qword ptr [rbp-18],0
       jne       near ptr M79_L05
       mov       rdi,[rbp-10]
       call      qword ptr [7F2F13DC6838]
       mov       [rbp-1C],eax
       mov       rdi,[rbp-10]
       mov       esi,[rbp-1C]
       call      qword ptr [7F2F13DC6850]
       mov       [rbp-30],rax
       mov       rax,[rbp-30]
       mov       rax,[rax]
       mov       [rbp-38],rax
       cmp       qword ptr [rbp-38],0
       je        short M79_L02
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-60],rax
       mov       rax,[rbp-60]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+30]
       mov       [rbp-68],rax
       cmp       qword ptr [rbp-68],0
       je        short M79_L00
       mov       rax,[rbp-68]
       mov       [rbp-58],rax
       jmp       short M79_L01
M79_L00:
       mov       rdi,[rbp-60]
       mov       rsi,7F2F13DB5AA0
       call      qword ptr [7F2F12E2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-58],rax
M79_L01:
       mov       rdi,[rbp-58]
       mov       rsi,[rbp-30]
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-38]
       call      qword ptr [7F2F1321E820]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       cmp       rax,[rbp-38]
       je        short M79_L03
M79_L02:
       xor       eax,eax
       mov       [rbp-40],rax
       mov       rax,[rbp-40]
       mov       [rbp-50],rax
       jmp       short M79_L04
M79_L03:
       mov       rax,[rbp-38]
       mov       [rbp-50],rax
M79_L04:
       mov       rax,[rbp-50]
       mov       [rbp-28],rax
       jmp       short M79_L06
M79_L05:
       lea       rsi,[rbp-28]
       mov       rdi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2F138BDCC8]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
M79_L06:
       mov       rax,[rbp-28]
       mov       [rbp-48],rax
       cmp       qword ptr [rbp-28],0
       jne       short M79_L08
       cmp       qword ptr [rbp-18],0
       je        short M79_L07
       mov       rdi,[rbp-10]
       call      qword ptr [7F2F13DC6868]; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].CreateItem()
       nop
       add       rsp,70
       pop       rbp
       ret
M79_L07:
       mov       rdi,[rbp-10]
       mov       esi,[rbp-1C]
       call      qword ptr [7F2F13DC6880]
       mov       [rbp-48],rax
M79_L08:
       mov       rax,[rbp-48]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 330
```
```assembly
; Kevlar.KevlarProperties+AdditionalAttemptState.get_IsSuppressed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+0C],0
       setne     al
       movzx     eax,al
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 34
```
```assembly
; System.Threading.Interlocked.Increment(Int32 ByRef)
       mov       eax,1
       lock xadd [rdi],eax
       inc       eax
       ret
; Total bytes of code 12
```
```assembly
; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].Create()
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       vxorps    xmm8,xmm8,xmm8
       vmovdqa   xmmword ptr [rbp-20],xmm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rbp-20],xmm0
       vmovdqu   xmmword ptr [rbp-18],xmm0
       mov       rax,[rbp-8]
       vmovdqu   xmm0,xmmword ptr [rbp-20]
       vmovdqu   xmmword ptr [rax],xmm0
       mov       rcx,[rbp-10]
       mov       [rax+10],rcx
       mov       rax,[rbp-8]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 75
```
```assembly
; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       mov       [rbp-8],rsi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       [rbp-20],rdx
       mov       rax,[rbp-18]
       mov       rax,[rax+18]
       mov       rax,[rax+10]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-30],0
       je        short M83_L00
       mov       rax,[rbp-30]
       mov       [rbp-28],rax
       jmp       short M83_L01
M83_L00:
       mov       rdi,[rbp-18]
       mov       rsi,7F2F13DB7ED8
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-28],rax
M83_L01:
       mov       rdi,[rbp-28]
       mov       rsi,[rbp-20]
       call      qword ptr [7F2F13DC6D18]; System.Runtime.CompilerServices.AsyncMethodBuilderCore.Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 104
```
```assembly
; System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]].get_Task()
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqu   ymmword ptr [rbp-50],ymm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       rcx,7F272D8013E8
       cmp       rax,[rcx]
       jne       short M84_L00
       mov       rax,[rbp-8]
       mov       rsi,[rax+8]
       mov       rax,[rbp-8]
       mov       rdx,[rax+10]
       lea       rdi,[rbp-70]
       call      qword ptr [7F2F13DC6A78]; System.Threading.Tasks.ValueTask`1[[Kevlar.Outcome`1[[System.Int32, System.Private.CoreLib]], Kevlar]]..ctor(Kevlar.Outcome`1<Int32>)
       mov       rax,[rbp-10]
       vmovdqu   ymm0,ymmword ptr [rbp-70]
       vmovdqu   ymmword ptr [rax],ymm0
       mov       rax,[rbp-10]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
M84_L00:
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       [rbp-20],rax
       mov       rax,[rbp-20]
       mov       [rbp-28],rax
       cmp       qword ptr [rbp-20],0
       jne       short M84_L01
       mov       rdi,offset MT_System.Threading.Tasks.Task<Kevlar.Outcome<System.Int32>>
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-50],rax
       mov       rdi,[rbp-50]
       call      qword ptr [7F2F13DC70F0]
       mov       rax,[rbp-50]
       mov       [rbp-18],rax
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-50]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       rax,[rbp-18]
       mov       [rbp-28],rax
M84_L01:
       lea       rdi,[rbp-48]
       mov       rsi,[rbp-28]
       call      qword ptr [7F2F13DC7108]
       mov       rax,[rbp-10]
       vmovdqu   ymm0,ymmword ptr [rbp-48]
       vmovdqu   ymmword ptr [rax],ymm0
       mov       rax,[rbp-10]
       vzeroupper
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 236
```
```assembly
; Kevlar.KevlarProperties.RemoveMissingValuesFrom(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,0B0
       lea       rbp,[rsp+0B0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0A0],ymm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-30],rdi
       mov       [rbp-38],rsi
       mov       [rbp-40],rdx
       mov       dword ptr [rbp-0A8],3E8
       mov       rax,[rbp-30]
       mov       rsi,[rax+38]
       mov       rax,[rbp-30]
       mov       rdx,[rax+40]
       mov       rax,[rbp-30]
       mov       rdi,[rax+10]
       mov       rcx,[rbp-38]
       mov       r8,[rbp-40]
       call      qword ptr [7F2F13DC7A68]; Kevlar.KevlarProperties.RemoveMissingValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       mov       rax,[rbp-30]
       cmp       qword ptr [rax+18],0
       jne       short M85_L00
       mov       rdi,7F2F13E065E8
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M85_L00:
       lea       rsi,[rbp-70]
       mov       rax,[rbp-30]
       mov       rdi,[rax+18]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7900]
       nop
       jmp       near ptr M85_L02
M85_L01:
       mov       rdi,7F2F13E065EC
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rsi,[rbp-88]
       lea       rdi,[rbp-70]
       mov       rdx,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2F13DC7918]
       lea       rdi,[rbp-88]
       mov       rsi,offset MT_System.Collections.Generic.KeyValuePair<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>
       call      qword ptr [7F2F13DC7930]
       mov       [rbp-0A0],rax
       lea       rdi,[rbp-88]
       mov       rsi,offset MT_System.Collections.Generic.KeyValuePair<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>
       call      qword ptr [7F2F13DC7948]
       mov       [rbp-98],rax
       mov       [rbp-90],rdx
       mov       rsi,[rbp-98]
       mov       rdx,[rbp-90]
       mov       rdi,[rbp-0A0]
       mov       rcx,[rbp-38]
       mov       r8,[rbp-40]
       call      qword ptr [7F2F13DC7A68]; Kevlar.KevlarProperties.RemoveMissingValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
M85_L02:
       mov       eax,[rbp-0A8]
       dec       eax
       mov       [rbp-0A8],eax
       cmp       dword ptr [rbp-0A8],0
       jg        short M85_L03
       lea       rdi,[rbp-0A8]
       mov       esi,47
       call      CORINFO_HELP_PATCHPOINT
M85_L03:
       lea       rdi,[rbp-70]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2F13DC7960]
       test      eax,eax
       jne       near ptr M85_L01
       call      M85_L04
       nop
       mov       rdi,7F2F13E065F4
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M85_L04:
       push      rax
       mov       rdi,7F2F13E065F0
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdi,[rbp-70]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2F13DC7978]
       nop
       add       rsp,8
       ret
; Total bytes of code 446
```
```assembly
; Kevlar.KevlarProperties.CopyChangedValuesTo(Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,0B0
       lea       rbp,[rsp+0B0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-0A0],ymm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-30],rdi
       mov       [rbp-38],rsi
       mov       [rbp-40],rdx
       mov       dword ptr [rbp-0A8],3E8
       mov       rax,[rbp-30]
       mov       rsi,[rax+38]
       mov       rax,[rbp-30]
       mov       rdx,[rax+40]
       mov       rax,[rbp-30]
       mov       rdi,[rax+10]
       mov       rcx,[rbp-38]
       mov       r8,[rbp-40]
       call      qword ptr [7F2F13DC7AE0]; Kevlar.KevlarProperties.CopyChangedValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       mov       rax,[rbp-30]
       cmp       qword ptr [rax+18],0
       jne       short M86_L00
       mov       rdi,7F2F13E06680
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M86_L00:
       lea       rsi,[rbp-70]
       mov       rax,[rbp-30]
       mov       rdi,[rax+18]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7900]
       nop
       jmp       near ptr M86_L02
M86_L01:
       mov       rdi,7F2F13E06684
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rsi,[rbp-88]
       lea       rdi,[rbp-70]
       mov       rdx,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2F13DC7918]
       lea       rdi,[rbp-88]
       mov       rsi,offset MT_System.Collections.Generic.KeyValuePair<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>
       call      qword ptr [7F2F13DC7930]
       mov       [rbp-0A0],rax
       lea       rdi,[rbp-88]
       mov       rsi,offset MT_System.Collections.Generic.KeyValuePair<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>
       call      qword ptr [7F2F13DC7948]
       mov       [rbp-98],rax
       mov       [rbp-90],rdx
       mov       rsi,[rbp-98]
       mov       rdx,[rbp-90]
       mov       rdi,[rbp-0A0]
       mov       rcx,[rbp-38]
       mov       r8,[rbp-40]
       call      qword ptr [7F2F13DC7AE0]; Kevlar.KevlarProperties.CopyChangedValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
M86_L02:
       mov       eax,[rbp-0A8]
       dec       eax
       mov       [rbp-0A8],eax
       cmp       dword ptr [rbp-0A8],0
       jg        short M86_L03
       lea       rdi,[rbp-0A8]
       mov       esi,47
       call      CORINFO_HELP_PATCHPOINT
M86_L03:
       lea       rdi,[rbp-70]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2F13DC7960]
       test      eax,eax
       jne       near ptr M86_L01
       call      M86_L04
       nop
       mov       rdi,7F2F13E0668C
       call      CORINFO_HELP_COUNTPROFILE32
       nop
       add       rsp,0B0
       pop       rbp
       ret
M86_L04:
       push      rax
       mov       rdi,7F2F13E06688
       call      CORINFO_HELP_COUNTPROFILE32
       lea       rdi,[rbp-70]
       mov       rsi,offset MT_System.Collections.Generic.Dictionary<Kevlar.KevlarProperties+PropertyIdentity, Kevlar.KevlarProperties+PropertySlot>+Enumerator
       call      qword ptr [7F2F13DC7978]
       nop
       add       rsp,8
       ret
; Total bytes of code 446
```
```assembly
; System.ArgumentNullException.ThrowIfNull(System.Object, System.String)
       push      rax
       test      rdi,rdi
       je        short M87_L00
       add       rsp,8
       ret
M87_L00:
       mov       rdi,rsi
       call      qword ptr [7F2F129E1208]
       int       3
; Total bytes of code 21
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].TryResetItem(System.__Canon)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       xor       eax,eax
       mov       [rbp-14],eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2F13DC7378]; Kevlar.KevlarContext+PoolPolicy.TryReset(Kevlar.KevlarContext)
       mov       [rbp-14],eax
       mov       eax,[rbp-14]
       add       rsp,20
       pop       rbp
       ret
       push      rax
       mov       [rbp-20],rdi
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-10]
       call      qword ptr [7F2F13DC6808]
       call      CORINFO_HELP_RETHROW
       int       3
; Total bytes of code 88
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ReturnWithoutReset(System.__Canon)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       rax,[rbp-10]
       mov       rax,[rax+10]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-20],0
       je        short M89_L01
       mov       rdi,[rbp-20]
       mov       rsi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2F138BDF68]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(System.__Canon)
       test      eax,eax
       jne       short M89_L00
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       call      qword ptr [7F2F13DC6808]
M89_L00:
       nop
       add       rsp,50
       pop       rbp
       ret
M89_L01:
       mov       rdi,[rbp-10]
       call      qword ptr [7F2F13DC6838]
       mov       [rbp-24],eax
       mov       rax,[rbp-10]
       mov       rax,[rax]
       mov       [rbp-48],rax
       mov       rax,[rbp-48]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+38]
       mov       [rbp-50],rax
       cmp       qword ptr [rbp-50],0
       je        short M89_L02
       mov       rax,[rbp-50]
       mov       [rbp-38],rax
       jmp       short M89_L03
M89_L02:
       mov       rdi,[rbp-48]
       mov       rsi,7F2F13DBBA70
       call      qword ptr [7F2F12E2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-38],rax
M89_L03:
       mov       rdi,[rbp-10]
       mov       esi,[rbp-24]
       call      qword ptr [7F2F13DC6850]
       mov       [rbp-40],rax
       mov       rsi,[rbp-40]
       mov       rdi,[rbp-38]
       mov       rdx,[rbp-18]
       call      qword ptr [7F2F138BDF20]
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-30],0
       jne       short M89_L04
       add       rsp,50
       pop       rbp
       ret
M89_L04:
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-30]
       mov       ecx,[rbp-24]
       call      qword ptr [7F2F13DC7558]
       nop
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 262
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].ClearIfDisposed()
       push      rbp
       sub       rsp,10
       lea       rbp,[rsp+10]
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       dword ptr [rax+1C],0
       je        short M90_L00
       mov       rdi,[rbp-8]
       call      qword ptr [7F2F13DC7588]
M90_L00:
       nop
       add       rsp,10
       pop       rbp
       ret
; Total bytes of code 41
```
```assembly
; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       push      rax
       mov       rax,rdx
       test      rsi,rsi
       je        short M91_L00
       mov       rdx,rcx
       mov       rdi,rsi
       mov       rsi,rax
       lea       rax,[System.Reflection.CustomAttributeExtensions.GetCustomAttribute[[System.__Canon, System.Private.CoreLib]](System.Reflection.Assembly)]
       add       rsp,8
       jmp       qword ptr [rax]
M91_L00:
       call      qword ptr [7F2F129E4288]
       int       3
; Total bytes of code 39
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(System.__Canon ByRef)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-70],ymm8
       vmovdqa   xmmword ptr [rbp-50],xmm8
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       dword ptr [rbp-80],3E8
       mov       rdi,[rbp-38]
       call      qword ptr [7F2F138BDD40]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-44],eax
       xor       eax,eax
       mov       [rbp-48],eax
       jmp       near ptr M92_L07
M92_L00:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       ecx,[rbp-44]
       cmp       ecx,[rax+8]
       jae       near ptr M92_L09
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       rax,[rax]
       mov       [rbp-50],rax
       mov       rax,[rbp-50]
       mov       rax,[rax+10]
       mov       [rbp-58],rax
       cmp       qword ptr [rbp-58],0
       je        near ptr M92_L04
       mov       rax,[rbp-50]
       cmp       [rax],al
       mov       rax,[rbp-50]
       add       rax,10
       mov       [rbp-70],rax
       xor       eax,eax
       mov       [rbp-60],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-88],rax
       mov       rax,[rbp-88]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+20]
       mov       [rbp-90],rax
       cmp       qword ptr [rbp-90],0
       je        short M92_L01
       mov       rax,[rbp-90]
       mov       [rbp-78],rax
       jmp       short M92_L02
M92_L01:
       mov       rdi,[rbp-88]
       mov       rsi,7F2F13C0F9F0
       call      qword ptr [7F2F12E2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-78],rax
M92_L02:
       mov       rdi,[rbp-78]
       mov       rsi,[rbp-70]
       mov       rdx,[rbp-60]
       mov       rcx,[rbp-58]
       call      qword ptr [7F2F1321E820]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       cmp       rax,[rbp-58]
       jne       short M92_L03
       mov       rdi,7F2F13CB64D8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rdi,[rbp-40]
       mov       rsi,[rbp-58]
       call      CORINFO_HELP_CHECKED_ASSIGN_REF
       mov       eax,1
       add       rsp,90
       pop       rbp
       ret
M92_L03:
       mov       rdi,7F2F13CB64DC
       call      CORINFO_HELP_COUNTPROFILE32
M92_L04:
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       mov       rsi,[rbp-50]
       mov       rdx,[rbp-40]
       call      qword ptr [7F2F138BDD58]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPop(Stripe<System.__Canon>, System.__Canon ByRef)
       test      eax,eax
       je        short M92_L05
       mov       rdi,7F2F13CB64E0
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,90
       pop       rbp
       ret
M92_L05:
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-64],eax
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-44],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-64]
       jne       short M92_L06
       mov       rdi,7F2F13CB64E4
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-44],eax
M92_L06:
       mov       rdi,7F2F13CB64E8
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-48]
       inc       eax
       mov       [rbp-48],eax
M92_L07:
       mov       eax,[rbp-80]
       dec       eax
       mov       [rbp-80],eax
       cmp       dword ptr [rbp-80],0
       jg        short M92_L08
       lea       rdi,[rbp-80]
       mov       esi,74
       call      CORINFO_HELP_PATCHPOINT
M92_L08:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-48]
       jg        near ptr M92_L00
       mov       rdi,7F2F13CB64EC
       call      CORINFO_HELP_COUNTPROFILE32
       mov       rax,[rbp-40]
       xor       ecx,ecx
       mov       [rax],rcx
       xor       eax,eax
       add       rsp,90
       pop       rbp
       ret
M92_L09:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 546
```
```assembly
; Reservoir.ObjectPool`2[[System.__Canon, System.Private.CoreLib],[Kevlar.KevlarContext+PoolPolicy, Kevlar]].CreateItem()
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       xor       eax,eax
       mov       [rbp-10],rax
       mov       [rbp-8],rdi
       mov       rax,[rbp-8]
       cmp       [rax],al
       mov       rax,[rbp-8]
       lea       rdi,[rax+30]
       call      qword ptr [7F2F13DC68B0]; Kevlar.KevlarContext+PoolPolicy.Create()
       mov       [rbp-18],rax
       mov       rax,[rbp-18]
       mov       [rbp-20],rax
       cmp       qword ptr [rbp-18],0
       jne       short M93_L00
       mov       rdi,offset MT_System.InvalidOperationException
       call      CORINFO_HELP_NEWSFAST
       mov       [rbp-28],rax
       mov       edi,67
       mov       rsi,7F2F132A56C8
       call      qword ptr [7F2F12E2EF88]
       mov       [rbp-30],rax
       mov       rsi,[rbp-30]
       mov       rdi,[rbp-28]
       call      qword ptr [7F2F13505638]
       mov       rdi,[rbp-28]
       call      CORINFO_HELP_THROW
       int       3
M93_L00:
       mov       rax,[rbp-20]
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 147
```
```assembly
; System.Runtime.CompilerServices.AsyncMethodBuilderCore.Start[[Kevlar.Internal.ShieldEngine+<InvokeWithContextAsync>d__16`2[[System.__Canon, System.Private.CoreLib],[System.Int32, System.Private.CoreLib]], Kevlar]](<InvokeWithContextAsync>d__16`2<System.__Canon,Int32> ByRef)
       push      rbp
       sub       rsp,0A0
       lea       rbp,[rsp+0A0]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-80],ymm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       vmovdqu   ymmword ptr [rbp-40],ymm8
       xor       eax,eax
       mov       [rbp-20],rax
       mov       [rbp-8],rdi
       mov       [rbp-10],rdi
       mov       [rbp-18],rsi
       mov       rax,[rbp-18]
       vmovdqu   ymm0,ymmword ptr [rax]
       vmovdqu   ymmword ptr [rbp-80],ymm0
       vmovdqu   ymm0,ymmword ptr [rax+20]
       vmovdqu   ymmword ptr [rbp-60],ymm0
       mov       rcx,[rax+40]
       mov       [rbp-40],rcx
       call      qword ptr [7F2F13DC6DA8]; System.Threading.Thread.get_CurrentThread()
       mov       [rbp-20],rax
       mov       rax,[rbp-20]
       mov       rax,[rax+8]
       mov       [rbp-28],rax
       mov       rax,[rbp-20]
       mov       rax,[rax+10]
       mov       [rbp-30],rax
       mov       rax,[rbp-10]
       mov       rax,[rax+18]
       mov       rax,[rax+10]
       mov       [rbp-98],rax
       cmp       qword ptr [rbp-98],0
       je        short M94_L00
       mov       rax,[rbp-98]
       mov       [rbp-88],rax
       jmp       short M94_L01
M94_L00:
       mov       rdi,[rbp-10]
       mov       rsi,7F2F13DB8060
       call      qword ptr [7F2F12E2F3A8]; System.Runtime.CompilerServices.GenericsHelpers.Method(IntPtr, IntPtr)
       mov       [rbp-88],rax
M94_L01:
       mov       rax,[rbp-88]
       mov       [rbp-90],rax
       mov       rdi,[rbp-18]
       mov       rax,[rbp-90]
       call      rax
       nop
       call      M94_L02
       nop
       vzeroupper
       add       rsp,0A0
       pop       rbp
       ret
M94_L02:
       push      rax
       mov       rax,[rbp-20]
       mov       rax,[rax+10]
       cmp       rax,[rbp-30]
       je        short M94_L03
       mov       rax,[rbp-20]
       lea       rdi,[rax+10]
       mov       rsi,[rbp-30]
       call      CORINFO_HELP_ASSIGN_REF
M94_L03:
       mov       rax,[rbp-20]
       mov       rax,[rax+8]
       mov       [rbp-38],rax
       mov       rax,[rbp-28]
       cmp       rax,[rbp-38]
       je        short M94_L04
       mov       rdi,[rbp-20]
       mov       rsi,[rbp-28]
       mov       rdx,[rbp-38]
       call      qword ptr [7F2F13DC6DC0]
M94_L04:
       nop
       vzeroupper
       add       rsp,8
       ret
; Total bytes of code 318
```
```assembly
; Kevlar.KevlarProperties.RemoveMissingValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       [rbp-38],rax
       mov       [rbp-8],rdi
       mov       [rbp-18],rsi
       mov       [rbp-10],rdx
       mov       [rbp-20],rcx
       mov       [rbp-28],r8
       cmp       qword ptr [rbp-8],0
       je        near ptr M95_L01
       mov       rdi,[rbp-8]
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       je        short M95_L01
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-10]
       mov       rdi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7A98]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-30],0
       je        short M95_L00
       mov       rdi,[rbp-30]
       mov       rax,[rbp-30]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       jne       short M95_L01
M95_L00:
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-10]
       mov       rdi,[rbp-28]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7A98]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       [rbp-38],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-8]
       call      qword ptr [7F2F13DC7AB0]
       test      eax,eax
       je        short M95_L01
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-10]
       mov       rdi,[rbp-28]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7AC8]
M95_L01:
       nop
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 195
```
```assembly
; Kevlar.KevlarProperties.CopyChangedValue(PropertySlot, PropertyIdentity, Kevlar.KevlarProperties, Kevlar.KevlarProperties)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp-30],rax
       mov       [rbp-38],rax
       mov       [rbp-8],rdi
       mov       [rbp-18],rsi
       mov       [rbp-10],rdx
       mov       [rbp-20],rcx
       mov       [rbp-28],r8
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-10]
       mov       rdi,[rbp-20]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7A98]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       [rbp-30],rax
       cmp       qword ptr [rbp-8],0
       je        short M96_L00
       mov       rdi,[rbp-8]
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+20]
       test      eax,eax
       je        short M96_L00
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-30]
       call      qword ptr [7F2F13DC7AB0]
       test      eax,eax
       jne       short M96_L00
       mov       rsi,[rbp-18]
       mov       rdx,[rbp-10]
       mov       rdi,[rbp-28]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC7A98]; Kevlar.KevlarProperties.Find(PropertyIdentity)
       mov       [rbp-38],rax
       mov       rdi,[rbp-38]
       mov       rsi,[rbp-30]
       call      qword ptr [7F2F13DC7AB0]
       test      eax,eax
       je        short M96_L00
       mov       rdx,[rbp-18]
       mov       rcx,[rbp-10]
       mov       rdi,[rbp-8]
       mov       rsi,[rbp-28]
       mov       rax,[rbp-8]
       mov       rax,[rax]
       mov       rax,[rax+40]
       call      qword ptr [rax+30]
M96_L00:
       nop
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 190
```
```assembly
; Kevlar.KevlarContext+PoolPolicy.TryReset(Kevlar.KevlarContext)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-30],ymm8
       mov       [rbp-8],rdi
       mov       [rbp-10],rsi
       xor       eax,eax
       mov       [rbp-18],rax
       mov       rdi,[rbp-10]
       mov       rsi,[rbp-18]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC6568]; Kevlar.KevlarContext.set_CancellationToken(System.Threading.CancellationToken)
       mov       rdi,[rbp-10]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC6580]; Kevlar.KevlarContext.set_SynchronousExecutionKind(Kevlar.Internal.SynchronousExecutionKind)
       mov       rdi,[rbp-10]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC65B0]; Kevlar.KevlarContext.set_ShieldName(System.String)
       mov       rdi,[rbp-10]
       mov       esi,0FFFFFFFF
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC65C8]; Kevlar.KevlarContext.set_StrategyIndex(Int32)
       mov       rdi,[rbp-10]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC65E0]; Kevlar.KevlarContext.set_AttemptNumber(Int32)
       mov       rdi,[rbp-10]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC65F8]; Kevlar.KevlarContext.set_TelemetryListener(Kevlar.IKevlarTelemetryListener)
       mov       rax,[rbp-10]
       xor       ecx,ecx
       mov       [rax+48],rcx
       mov       rax,[rbp-10]
       xor       ecx,ecx
       mov       [rax+50],rcx
       mov       rax,[rbp-10]
       mov       rax,[rax+28]
       mov       [rbp-20],rax
       mov       rax,[rbp-20]
       mov       [rbp-28],rax
       cmp       qword ptr [rbp-20],0
       jne       short M97_L00
       jmp       short M97_L01
M97_L00:
       mov       rdi,[rbp-28]
       call      qword ptr [7F2F13DFEA88]
M97_L01:
       call      qword ptr [7F2F138BE598]; System.TimeProvider.get_System()
       mov       [rbp-30],rax
       mov       rsi,[rbp-30]
       mov       rdi,[rbp-10]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC6598]; Kevlar.KevlarContext.set_TimeProvider(System.TimeProvider)
       mov       rax,[rbp-10]
       mov       rdi,[rax+8]
       xor       esi,esi
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC73A8]; Kevlar.KevlarProperties.MirrorMutationsTo(Kevlar.KevlarProperties)
       mov       rax,[rbp-10]
       mov       rdi,[rax+8]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC73C0]; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       mov       rax,[rbp-10]
       mov       rdi,[rax+8]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC73D8]; Kevlar.KevlarProperties.Clear()
       mov       rax,[rbp-10]
       cmp       qword ptr [rax+10],0
       je        short M97_L02
       mov       rax,[rbp-10]
       mov       rdi,[rax+10]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC73C0]; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       mov       rax,[rbp-10]
       mov       rdi,[rax+10]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC73D8]; Kevlar.KevlarProperties.Clear()
M97_L02:
       mov       rax,[rbp-10]
       cmp       qword ptr [rax+18],0
       je        short M97_L03
       mov       rax,[rbp-10]
       mov       rdi,[rax+18]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC73C0]; Kevlar.KevlarProperties.ResetAdditionalAttemptState()
       mov       rax,[rbp-10]
       mov       rdi,[rax+18]
       cmp       [rdi],edi
       call      qword ptr [7F2F13DC73D8]; Kevlar.KevlarProperties.Clear()
M97_L03:
       mov       rax,[rbp-10]
       mov       byte ptr [rax+64],0
       mov       rax,[rbp-10]
       mov       byte ptr [rax+65],0
       mov       eax,1
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 371
```
```assembly
; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(System.__Canon)
       push      rbp
       sub       rsp,90
       lea       rbp,[rsp+90]
       vxorps    xmm8,xmm8,xmm8
       vmovdqu   ymmword ptr [rbp-60],ymm8
       mov       [rbp-30],rdi
       mov       [rbp-38],rdi
       mov       [rbp-40],rsi
       mov       dword ptr [rbp-78],3E8
       mov       rdi,[rbp-38]
       call      qword ptr [7F2F138BDD40]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].GetStartStripe()
       mov       [rbp-44],eax
       xor       eax,eax
       mov       [rbp-48],eax
       jmp       near ptr M98_L06
M98_L00:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       ecx,[rbp-44]
       cmp       ecx,[rax+8]
       jae       near ptr M98_L08
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       rax,[rax]
       mov       [rbp-50],rax
       mov       rax,[rbp-50]
       cmp       [rax],al
       mov       rax,[rbp-50]
       add       rax,10
       mov       [rbp-60],rax
       xor       eax,eax
       mov       [rbp-58],rax
       mov       rax,[rbp-38]
       mov       rax,[rax]
       mov       [rbp-80],rax
       mov       rax,[rbp-80]
       mov       rax,[rax+30]
       mov       rax,[rax]
       mov       rax,[rax+20]
       mov       [rbp-88],rax
       cmp       qword ptr [rbp-88],0
       je        short M98_L01
       mov       rax,[rbp-88]
       mov       [rbp-68],rax
       jmp       short M98_L02
M98_L01:
       mov       rdi,[rbp-80]
       mov       rsi,7F2F13C0F9F0
       call      qword ptr [7F2F12E2F270]; System.Runtime.CompilerServices.GenericsHelpers.Class(IntPtr, IntPtr)
       mov       [rbp-68],rax
M98_L02:
       mov       rdi,[rbp-68]
       mov       rsi,[rbp-60]
       mov       rdx,[rbp-40]
       mov       rcx,[rbp-58]
       call      qword ptr [7F2F1321E820]; System.Threading.Interlocked.CompareExchange[[System.__Canon, System.Private.CoreLib]](System.__Canon ByRef, System.__Canon, System.__Canon)
       test      rax,rax
       je        short M98_L03
       mov       rax,[rbp-38]
       mov       rdi,[rax]
       mov       rsi,[rbp-50]
       mov       rdx,[rbp-40]
       call      qword ptr [7F2F138BDF98]; Reservoir.StripedObjectStore`1[[System.__Canon, System.Private.CoreLib]].TryPush(Stripe<System.__Canon>, System.__Canon)
       test      eax,eax
       je        short M98_L04
       mov       rdi,7F2F13CB6938
       call      CORINFO_HELP_COUNTPROFILE32
M98_L03:
       mov       rdi,7F2F13CB693C
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,1
       add       rsp,90
       pop       rbp
       ret
M98_L04:
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-6C],eax
       mov       eax,[rbp-44]
       inc       eax
       mov       [rbp-44],eax
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-6C]
       jne       short M98_L05
       mov       rdi,7F2F13CB6940
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       mov       [rbp-44],eax
M98_L05:
       mov       rdi,7F2F13CB6944
       call      CORINFO_HELP_COUNTPROFILE32
       mov       eax,[rbp-48]
       inc       eax
       mov       [rbp-48],eax
M98_L06:
       mov       eax,[rbp-78]
       dec       eax
       mov       [rbp-78],eax
       cmp       dword ptr [rbp-78],0
       jg        short M98_L07
       lea       rdi,[rbp-78]
       mov       esi,50
       call      CORINFO_HELP_PATCHPOINT
M98_L07:
       mov       rax,[rbp-38]
       mov       rax,[rax+8]
       mov       eax,[rax+8]
       cmp       eax,[rbp-48]
       jg        near ptr M98_L00
       mov       rdi,7F2F13CB6948
       call      CORINFO_HELP_COUNTPROFILE32
       xor       eax,eax
       add       rsp,90
       pop       rbp
       ret
M98_L08:
       call      CORINFO_HELP_RNGCHKFAIL
       int       3
; Total bytes of code 457
```

