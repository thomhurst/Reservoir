```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.76GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]    : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  dry-1.4.0 : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

Job=dry-1.4.0  EnvironmentVariables=EXPECTED_RESERVOIR_VERSION=1.4.0,DOTNET_TieredPGO=1  Arguments=/p:ReservoirVersion=1.4.0,/p:KevlarDll=/home/runner/work/Reservoir/Reservoir/kevlar/artifacts/bin/Kevlar/release_net10.0/Kevlar.dll  
IterationCount=1  LaunchCount=1  RunStrategy=ColdStart  
UnrollFactor=1  WarmupCount=1  

```
| Method           | Mean     | Error | Code Size | Allocated |
|----------------- |---------:|------:|----------:|----------:|
| SingleRentReturn | 252.7 μs |    NA |   6,313 B |         - |
| NestedRentReturn | 174.6 μs |    NA |   6,364 B |         - |
| SingleContext    | 460.0 μs |    NA |  11,234 B |         - |
| NestedContext    | 449.3 μs |    NA |  16,134 B |         - |
